package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.config.Settings;
import cs.cloudstudio.listener.CooldownListener;
import cs.cloudstudio.listener.PvPListener;
import cs.cloudstudio.manager.BossbarManager;
import cs.cloudstudio.manager.CooldownManager;
import cs.cloudstudio.manager.PowerUpsManager;
import cs.cloudstudio.manager.PvPManager;
import cs.cloudstudio.manager.ScoreboardManager;
import cs.cloudstudio.util.ColorUtils;
import cs.cloudstudio.util.PlaceholderUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudRelog extends JavaPlugin {
   private Settings settings;
   private PvPManager pvpManager;
   private CooldownManager cooldownManager;
   private ScoreboardManager scoreboardManager;

   public void onEnable() {
      this.loadConfig();
      PlaceholderUtils.detect();
      this.pvpManager = new PvPManager(this.settings, this);
      this.cooldownManager = new CooldownManager(this.settings);
      this.scoreboardManager = new ScoreboardManager(this.settings, this.pvpManager, this);
      this.pvpManager.setScoreboardManager(this.scoreboardManager);
      PluginCommand command = this.getCommand("cloudrelog");
      if (command != null) {
         AdminCommand adminCommand = new AdminCommand(this);
         command.setExecutor(adminCommand);
         command.setTabCompleter(adminCommand);
      }

      this.getServer().getPluginManager().registerEvents(new PvPListener(this.pvpManager, this.settings), this);
      this.getServer().getPluginManager().registerEvents(new CooldownListener(this, this.cooldownManager, this.pvpManager, this.settings), this);
      this.getServer().getPluginManager().registerEvents(this.scoreboardManager, this);
      this.log("&fCloudRelog &aуспешно загружен!");
   }

   public void onDisable() {
      if (this.scoreboardManager != null) {
         this.scoreboardManager.shutdown();
      }

      if (this.pvpManager != null) {
         this.pvpManager.onPluginDisable();
         this.pvpManager.getBossbarManager().shutdown();
      }

      if (this.cooldownManager != null) {
         this.cooldownManager.clearAll();
      }

      this.log("&fCloudRelog &cуспешно выгружен!");
   }

   private void loadConfig() {
      this.settings = new Settings(this);
      this.settings.load();
   }

   public void reloadSettings() {
      this.settings.load();
      PlaceholderUtils.detect();
      if (this.scoreboardManager != null) {
         this.scoreboardManager.shutdown();
      }

      if (this.pvpManager != null) {
         this.pvpManager.reload();
      }

      if (this.scoreboardManager != null) {
         this.scoreboardManager.reload();
      }
   }

   private void log(String message) {
      Bukkit.getConsoleSender().sendMessage(ColorUtils.color(message));
   }

   public Settings getSettings() {
      return this.settings;
   }

   public PvPManager getPvpManager() {
      return this.pvpManager;
   }

   public PowerUpsManager getPowerUpsManager() {
      return this.pvpManager.getPowerUpsManager();
   }

   public BossbarManager getBossbarManager() {
      return this.pvpManager.getBossbarManager();
   }

   public ScoreboardManager getScoreboardManager() {
      return this.scoreboardManager;
   }
}
