package cs.cloudstudio.listener;

import cs.cloudstudio.config.Settings;
import cs.cloudstudio.event.PvpStartedEvent;
import cs.cloudstudio.event.PvpStoppedEvent;
import cs.cloudstudio.manager.CooldownManager;
import cs.cloudstudio.manager.PvPManager;
import cs.cloudstudio.util.Utils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.damage.DamageType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.Event.Result;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class CooldownListener implements Listener {
   private final Plugin plugin;
   private final CooldownManager cooldownManager;
   private final PvPManager pvpManager;
   private final Settings settings;

   public CooldownListener(Plugin plugin, CooldownManager cooldownManager, PvPManager pvpManager, Settings settings) {
      this.plugin = plugin;
      this.cooldownManager = cooldownManager;
      this.pvpManager = pvpManager;
      this.settings = settings;
   }

   @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
   public void onResurrect(EntityResurrectEvent event) {
      if (event.getEntityType() == EntityType.PLAYER) {
         Player player = (Player)event.getEntity();
         int cooldown = this.settings.getTotemCooldown();
         if (cooldown != 0 && !this.pvpManager.isBypassed(player)) {
            if (cooldown <= -1) {
               this.cancelEventIfInPvp(event, player);
            } else {
               CooldownManager.CooldownType type = CooldownManager.CooldownType.TOTEM;
               if (this.checkCooldown(player, type, cooldown * 1000L)) {
                  event.setCancelled(true);
               } else {
                  this.cooldownManager.addCooldown(player, type);
                  this.addItemCooldownIfNeeded(player, type);
               }
            }
         }
      }
   }

   @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
   public void onItemEat(PlayerItemConsumeEvent event) {
      ItemStack item = event.getItem();
      Material material = item.getType();
      CooldownManager.CooldownType type;
      int cooldown;
      if (material == Material.CHORUS_FRUIT) {
         type = CooldownManager.CooldownType.CHORUS;
         cooldown = this.settings.getChorusCooldown();
      } else if (material == Material.GOLDEN_APPLE) {
         type = CooldownManager.CooldownType.GOLDEN_APPLE;
         cooldown = this.settings.getGoldenAppleCooldown();
      } else {
         if (material != Material.ENCHANTED_GOLDEN_APPLE) {
            return;
         }

         type = CooldownManager.CooldownType.ENC_GOLDEN_APPLE;
         cooldown = this.settings.getEnchantedGoldenAppleCooldown();
      }

      Player player = event.getPlayer();
      if (cooldown != 0 && !this.pvpManager.isBypassed(player)) {
         if (cooldown <= -1) {
            this.cancelEventIfInPvp(event, player);
         } else if (this.checkCooldown(player, type, cooldown * 1000L)) {
            event.setCancelled(true);
         } else {
            this.cooldownManager.addCooldown(player, type);
            this.addItemCooldownIfNeeded(player, type);
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onProjectileLaunch(ProjectileLaunchEvent event) {
      if (event.getEntity().getShooter() instanceof Player) {
         Player player = (Player)event.getEntity().getShooter();
         if (!this.pvpManager.isBypassed(player)) {
            if (event.getEntity() instanceof Firework) {
               this.handleFireworkLaunch(event, player);
            } else if (event.getEntityType() == EntityType.ENDER_PEARL) {
               this.handleProjectileCooldown(event, player, CooldownManager.CooldownType.ENDER_PEARL, this.settings.getEnderPearlCooldown());
            } else {
               if (event.getEntityType() == EntityType.TRIDENT) {
                  this.handleProjectileCooldown(event, player, CooldownManager.CooldownType.TRIDENT, this.settings.getTridentCooldown());
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onRiptide(PlayerRiptideEvent event) {
      Player player = event.getPlayer();
      int cooldown = this.settings.getRiptideCooldown();
      if (cooldown != 0 && !this.pvpManager.isBypassed(player)) {
         if (!this.pvpManager.isPvPModeEnabled() || this.pvpManager.isInPvP(player)) {
            if (cooldown <= -1) {
               if (this.pvpManager.isInPvP(player)) {
                  this.teleportBack(player);
                  String message = this.settings.getMessages().getItemDisabledInPvp();
                  if (message != null && !message.isEmpty()) {
                     player.sendMessage(Utils.color(message));
                  }
               }
            } else {
               CooldownManager.CooldownType type = CooldownManager.CooldownType.TRIDENT_RIPTIDE;
               if (this.checkRiptideCooldown(player, type, cooldown * 1000L)) {
                  this.teleportBack(player);
               } else {
                  this.cooldownManager.addCooldown(player, type);
                  this.addItemCooldownIfNeeded(player, type);
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onWindBurstMaceHit(EntityDamageByEntityEvent event) {
      if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
         Player player = (Player)event.getDamager();
         ItemStack item = player.getInventory().getItemInMainHand();
         if (item.getType() == Material.MACE
            && item.getEnchantmentLevel(Enchantment.WIND_BURST) > 0
            && DamageType.MACE_SMASH.equals(event.getDamageSource().getDamageType())) {
            int cooldown = this.settings.getMaceWindBurstCooldown();
            if (cooldown != 0 && !this.pvpManager.isBypassed(player)) {
               if (!this.pvpManager.isPvPModeEnabled() || this.pvpManager.isInPvP(player)) {
                  if (cooldown <= -1) {
                     this.cancelEventIfInPvp(event, player);
                  } else {
                     CooldownManager.CooldownType type = CooldownManager.CooldownType.MACE_WIND_BURST;
                     long cooldownMillis = cooldown * 1000L;
                     if (this.checkCooldown(player, type, cooldownMillis)) {
                        event.setCancelled(true);
                     } else {
                        this.cooldownManager.addCooldown(player, type);
                        this.cooldownManager.addItemCooldown(player, type, cooldownMillis);
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onEnderPearlInteract(PlayerInteractEvent event) {
      int pearlCooldown = this.settings.getEnderPearlCooldown();
      if (pearlCooldown != 0 && event.hasItem()) {
         Player player = event.getPlayer();
         if (!this.pvpManager.isBypassed(player)) {
            ItemStack item = event.getItem();
            if (item != null && item.getType() == Material.ENDER_PEARL) {
               if (pearlCooldown <= -1) {
                  this.cancelEventIfInPvp(event, player);
               } else {
                  if (this.checkCooldown(player, CooldownManager.CooldownType.ENDER_PEARL, pearlCooldown * 1000L)) {
                     event.setCancelled(true);
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onFireworkInteract(PlayerInteractEvent event) {
      int fireworkCooldown = this.settings.getFireworkCooldown();
      if (fireworkCooldown != 0 && event.hasItem()) {
         Action action = event.getAction();
         if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            ItemStack item = event.getItem();
            if (item != null && item.getType() == Material.FIREWORK_ROCKET) {
               Player player = event.getPlayer();
               if (!this.pvpManager.isBypassed(player) && this.pvpManager.isInPvP(player)) {
                  if (event.useItemInHand() != Result.DENY) {
                     if (fireworkCooldown <= -1) {
                        event.setUseItemInHand(Result.DENY);
                        String message = this.settings.getMessages().getItemDisabledInPvp();
                        if (message != null && !message.isEmpty()) {
                           player.sendMessage(Utils.color(message));
                        }
                     } else {
                        if (this.checkCooldown(player, CooldownManager.CooldownType.FIREWORK, fireworkCooldown * 1000L)) {
                           event.setUseItemInHand(Result.DENY);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onEnderChestPlace(BlockPlaceEvent event) {
      if (this.settings.isDisableEnderChestInPvp()) {
         if (event.getBlockPlaced().getType() == Material.ENDER_CHEST) {
            Player player = event.getPlayer();
            if (!this.pvpManager.isBypassed(player) && this.pvpManager.isInPvP(player)) {
               event.setCancelled(true);
               String message = this.settings.getMessages().getEnderChestDisabledInPvp();
               if (message != null && !message.isEmpty()) {
                  player.sendMessage(Utils.color(message));
               }
            }
         }
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.cooldownManager.remove(event.getPlayer());
   }

   @EventHandler
   public void onPvpStart(PvpStartedEvent event) {
      switch (event.getPvpStatus()) {
         case ALL_NOT_IN_PVP:
            this.cooldownManager.enteredToPvp(event.getDefender());
            this.cooldownManager.enteredToPvp(event.getAttacker());
            break;
         case ATTACKER_IN_PVP:
            this.cooldownManager.enteredToPvp(event.getDefender());
            break;
         case DEFENDER_IN_PVP:
            this.cooldownManager.enteredToPvp(event.getAttacker());
      }
   }

   @EventHandler
   public void onPvpStop(PvpStoppedEvent event) {
      this.cooldownManager.removedFromPvp(event.getPlayer());
   }

   private void handleFireworkLaunch(ProjectileLaunchEvent event, Player player) {
      int cooldown = this.settings.getFireworkCooldown();
      if (cooldown != 0 && this.pvpManager.isInPvP(player)) {
         if (cooldown <= -1) {
            event.setCancelled(true);
            String message = this.settings.getMessages().getItemDisabledInPvp();
            if (message != null && !message.isEmpty()) {
               player.sendMessage(Utils.color(message));
            }
         } else {
            CooldownManager.CooldownType type = CooldownManager.CooldownType.FIREWORK;
            long cooldownMillis = cooldown * 1000L;
            if (this.checkCooldown(player, type, cooldownMillis)) {
               event.setCancelled(true);
            } else {
               this.cooldownManager.addCooldown(player, type);
               this.cooldownManager.addItemCooldown(player, type, cooldownMillis);
            }
         }
      }
   }

   private void handleProjectileCooldown(Cancellable event, Player player, CooldownManager.CooldownType type, int cooldown) {
      if (cooldown != 0) {
         if (cooldown <= -1) {
            this.cancelEventIfInPvp(event, player);
         } else if (this.checkCooldown(player, type, cooldown * 1000L)) {
            event.setCancelled(true);
         } else {
            this.cooldownManager.addCooldown(player, type);
            this.addItemCooldownIfNeeded(player, type);
         }
      }
   }

   private void cancelEventIfInPvp(Cancellable event, Player player) {
      if (this.pvpManager.isInPvP(player)) {
         event.setCancelled(true);
         String message = this.settings.getMessages().getItemDisabledInPvp();
         if (message != null && !message.isEmpty()) {
            player.sendMessage(Utils.color(message));
         }
      }
   }

   private boolean checkCooldown(Player player, CooldownManager.CooldownType cooldownType, long cooldownTime) {
      if (this.pvpManager.isPvPModeEnabled() && !this.pvpManager.isInPvP(player)) {
         return false;
      }

      long remaining = this.cooldownManager.getRemainingCooldown(player, cooldownType, cooldownTime);
      if (remaining <= 0L) {
         return false;
      }

      this.cooldownManager.addItemCooldown(player, cooldownType, remaining);
      this.sendCooldownMessage(player, remaining, this.settings.getMessages().getItemCooldown());
      return true;
   }

   private boolean checkRiptideCooldown(Player player, CooldownManager.CooldownType cooldownType, long cooldownTime) {
      long remaining = this.cooldownManager.getRemainingCooldown(player, cooldownType, cooldownTime);
      if (remaining <= 0L) {
         return false;
      }

      String message = this.settings.getMessages().getRiptideCooldown();
      if (message == null || message.isEmpty()) {
         message = this.settings.getMessages().getItemCooldown();
      }

      this.cooldownManager.addItemCooldown(player, cooldownType, remaining);
      this.sendCooldownMessage(player, remaining, message);
      return true;
   }

   private void sendCooldownMessage(Player player, long remaining, String message) {
      int remainingSeconds = (int)((remaining + 999L) / 1000L);
      if (message != null && !message.isEmpty()) {
         player.sendMessage(Utils.color(Utils.replaceTime(message, remainingSeconds)));
      }
   }

   private void teleportBack(Player player) {
      Location location = player.getLocation();
      this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
         if (player.isOnline()) {
            player.teleport(location);
         }
      }, 2L);
   }

   private void addItemCooldownIfNeeded(Player player, CooldownManager.CooldownType cooldownType) {
      if (!this.pvpManager.isPvPModeEnabled() || this.pvpManager.isInPvP(player)) {
         this.cooldownManager.addItemCooldown(player, cooldownType, cooldownType.getCooldown(this.settings) * 1000L);
      }
   }
}
