package cs.cloudstudio.listener;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import cs.cloudstudio.config.Messages;
import cs.cloudstudio.config.Settings;
import cs.cloudstudio.manager.PvPManager;
import cs.cloudstudio.util.Utils;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.AreaEffectCloud;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustByEntityEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PvPListener implements Listener {
   private static final String EXTERNAL_TELEPORT_METADATA = "CloudPvPRoom-Teleport";
   private final PvPManager pvpManager;
   private final Messages messages;
   private final Settings settings;
   private final Cache<Integer, UUID> fireworkShooters = CacheBuilder.newBuilder().maximumSize(2048L).expireAfterWrite(10L, TimeUnit.SECONDS).build();

   public PvPListener(PvPManager pvpManager, Settings settings) {
      this.pvpManager = pvpManager;
      this.settings = settings;
      this.messages = settings.getMessages();
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onDamageByEntity(EntityDamageByEntityEvent event) {
      if (event.getEntityType() == EntityType.PLAYER) {
         this.pvpManager.playerDamagedByPlayer(this.getDamager(event.getDamager()), (Player)event.getEntity());
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onInteractWithEntity(PlayerInteractEntityEvent event) {
      if (this.settings.isCancelInteractWithEntities() && this.pvpManager.isPvPModeEnabled() && this.pvpManager.isInPvP(event.getPlayer())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onCombust(EntityCombustByEntityEvent event) {
      if (event.getEntityType() == EntityType.PLAYER) {
         this.pvpManager.playerDamagedByPlayer(this.getDamager(event.getCombuster()), (Player)event.getEntity());
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onShootBow(EntityShootBowEvent event) {
      if (event.getProjectile() instanceof Firework && event.getEntityType() == EntityType.PLAYER) {
         this.fireworkShooters.put(event.getProjectile().getEntityId(), event.getEntity().getUniqueId());
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPotionSplash(PotionSplashEvent event) {
      if (event.getPotion().getShooter() instanceof Player && this.hasOffensiveEffect(event)) {
         Player shooter = (Player)event.getPotion().getShooter();

         for (LivingEntity entity : event.getAffectedEntities()) {
            if (entity.getType() == EntityType.PLAYER && entity != shooter) {
               this.pvpManager.playerDamagedByPlayer(shooter, (Player)entity);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onTeleport(PlayerTeleportEvent event) {
      Player player = event.getPlayer();
      if (this.settings.isDisableTeleportsInPvp() && this.pvpManager.isInPvP(player)) {
         if (!player.hasMetadata("CloudPvPRoom-Teleport")) {
            TeleportCause cause = event.getCause();
            if (cause != TeleportCause.CONSUMABLE_EFFECT && cause != TeleportCause.ENDER_PEARL) {
               if (event.getTo() == null || event.getFrom().getWorld() != event.getTo().getWorld() || event.getFrom().distanceSquared(event.getTo()) > 100.0) {
                  event.setCancelled(true);
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onCommand(PlayerCommandPreprocessEvent event) {
      if (this.settings.isDisableCommandsInPvp() && this.pvpManager.isInPvP(event.getPlayer())) {
         String message = event.getMessage();
         int start = message.length() > 0 && message.charAt(0) == '/' ? 1 : 0;
         int space = message.indexOf(32, start);
         String command = (space == -1 ? message.substring(start) : message.substring(start, space)).toLowerCase(Locale.ROOT);
         if (!this.pvpManager.isCommandWhiteListed(command)) {
            event.setCancelled(true);
            String response = Utils.color(this.messages.getCommandsDisabled());
            if (response != null && !response.isEmpty()) {
               event.getPlayer().sendMessage(Utils.replaceTime(response, this.pvpManager.getTimeRemainingInPvP(event.getPlayer())));
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onKick(PlayerKickEvent event) {
      Player player = event.getPlayer();
      if (this.pvpManager.isInSilentPvP(player)) {
         this.pvpManager.stopPvPSilent(player);
      } else if (this.pvpManager.isInPvP(player) && this.isPunishableKick(event.reason())) {
         this.pvpManager.stopPvPSilent(player);
         this.kickedInPvp(player);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      if (this.settings.isHideLeaveMessage()) {
         event.quitMessage(null);
      }

      if (this.pvpManager.isInPvP(player)) {
         this.pvpManager.stopPvPSilent(player);
         if (this.settings.isKillOnLeave()) {
            player.setHealth(0.0);
         }

         this.runCommands(player);
      } else if (this.pvpManager.isInSilentPvP(player)) {
         this.pvpManager.stopPvPSilent(player);
      } else {
         this.pvpManager.clearTransientData(player);
      }
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onDeath(PlayerDeathEvent event) {
      if (this.settings.isHideDeathMessage()) {
         event.deathMessage(null);
      }

      Player player = event.getEntity();
      if (this.pvpManager.isInSilentPvP(player) || this.pvpManager.isInPvP(player)) {
         this.pvpManager.stopPvPSilent(player);
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onJoin(PlayerJoinEvent event) {
      if (this.settings.isHideJoinMessage()) {
         event.joinMessage(null);
      }
   }

   private boolean hasOffensiveEffect(PotionSplashEvent event) {
      for (PotionEffect effect : event.getPotion().getEffects()) {
         PotionEffectType type = effect.getType();
         if (type == PotionEffectType.POISON || type == PotionEffectType.INSTANT_DAMAGE || type == PotionEffectType.WITHER) {
            return true;
         }
      }

      return false;
   }

   private boolean isPunishableKick(Component rawReason) {
      List<String> kickMessages = this.settings.getNormalizedKickMessages();
      if (kickMessages.isEmpty()) {
         return true;
      }

      if (rawReason == null) {
         return false;
      }

      String reason = PlainTextComponentSerializer.plainText().serialize(rawReason).toLowerCase(Locale.ROOT);

      for (String killReason : kickMessages) {
         if (reason.contains(killReason)) {
            return true;
         }
      }

      return false;
   }

   private void kickedInPvp(Player player) {
      if (this.settings.isKillOnKick()) {
         player.setHealth(0.0);
      }

      if (this.settings.isRunCommandsOnKick()) {
         this.runCommands(player);
      }
   }

   private void runCommands(Player leaved) {
      List<String> commands = this.settings.getCommandsOnLeave();
      if (!commands.isEmpty()) {
         String playerName = leaved.getName();

         for (String command : commands) {
            if (command != null && !command.isEmpty()) {
               Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Utils.color(command.replace("%player%", playerName)));
            }
         }
      }
   }

   private Player getDamager(Entity damager) {
      if (damager instanceof Player) {
         return (Player)damager;
      }

      if (damager instanceof Projectile) {
         Object shooter = ((Projectile)damager).getShooter();
         return shooter instanceof Player ? (Player)shooter : null;
      }

      if (damager instanceof TNTPrimed) {
         return this.getDamager(((TNTPrimed)damager).getSource());
      }

      if (damager instanceof AreaEffectCloud) {
         Object source = ((AreaEffectCloud)damager).getSource();
         return source instanceof Player ? (Player)source : null;
      }

      if (damager instanceof Firework) {
         UUID shooter = (UUID)this.fireworkShooters.getIfPresent(damager.getEntityId());
         if (shooter != null) {
            this.fireworkShooters.invalidate(damager.getEntityId());
            return Bukkit.getPlayer(shooter);
         }
      }

      return null;
   }
}
