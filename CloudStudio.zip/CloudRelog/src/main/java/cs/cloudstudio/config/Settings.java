package cs.cloudstudio.config;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class Settings {
   private final JavaPlugin plugin;
   private final File configFile;
   private final Messages messages = new Messages();
   private final ScoreboardSettings scoreboard = new ScoreboardSettings();
   private int goldenAppleCooldown = 30;
   private int enchantedGoldenAppleCooldown = 60;
   private int enderPearlCooldown = 15;
   private int chorusCooldown = 7;
   private int fireworkCooldown = 60;
   private int totemCooldown = 60;
   private int tridentCooldown = 15;
   private int riptideCooldown = 10;
   private int maceWindBurstCooldown = 40;
   private boolean disableEnderChestInPvp = true;
   private int pvpTime = 30;
   private boolean disableCommandsInPvp = true;
   private List<String> whiteListedCommands = Collections.emptyList();
   private boolean cancelInteractWithEntities = false;
   private boolean killOnLeave = true;
   private boolean killOnKick = true;
   private boolean runCommandsOnKick = true;
   private List<String> kickMessages = Arrays.asList("спам", "реклама", "анти-чит");
   private List<String> normalizedKickMessages = Arrays.asList("спам", "реклама", "анти-чит");
   private List<String> commandsOnLeave = Collections.emptyList();
   private boolean disablePowerups = true;
   private List<String> commandsOnPowerupsDisable = Collections.emptyList();
   private boolean disableTeleportsInPvp = true;
   private boolean hideJoinMessage = false;
   private boolean hideLeaveMessage = false;
   private boolean hideDeathMessage = false;
   private List<String> disabledWorlds = Arrays.asList("world1", "world2");
   private Set<String> disabledWorldsSet = Collections.emptySet();

   public Settings(JavaPlugin plugin) {
      this.plugin = plugin;
      this.configFile = new File(plugin.getDataFolder(), "config.yml");
   }

   public boolean load() {
      this.reset();

      try {
         this.ensureFileExists();
         YamlConfiguration config = YamlConfiguration.loadConfiguration(this.configFile);
         this.read(config);
         this.loaded();
         return true;
      } catch (Exception exception) {
         this.plugin.getLogger().warning("[CloudRelog] config.yml не загружен: " + exception.getMessage());
         this.loaded();
         return false;
      }
   }

   private void reset() {
      this.goldenAppleCooldown = 30;
      this.enchantedGoldenAppleCooldown = 60;
      this.enderPearlCooldown = 15;
      this.chorusCooldown = 7;
      this.fireworkCooldown = 60;
      this.totemCooldown = 60;
      this.tridentCooldown = 15;
      this.riptideCooldown = 10;
      this.maceWindBurstCooldown = 40;
      this.disableEnderChestInPvp = true;
      this.pvpTime = 30;
      this.disableCommandsInPvp = true;
      this.whiteListedCommands = Collections.emptyList();
      this.cancelInteractWithEntities = false;
      this.killOnLeave = true;
      this.killOnKick = true;
      this.runCommandsOnKick = true;
      this.kickMessages = Arrays.asList("спам", "реклама", "анти-чит");
      this.normalizedKickMessages = Arrays.asList("спам", "реклама", "анти-чит");
      this.commandsOnLeave = Collections.emptyList();
      this.disablePowerups = true;
      this.commandsOnPowerupsDisable = Collections.emptyList();
      this.disableTeleportsInPvp = true;
      this.hideJoinMessage = false;
      this.hideLeaveMessage = false;
      this.hideDeathMessage = false;
      this.disabledWorlds = Arrays.asList("world1", "world2");
      this.disabledWorldsSet = Collections.emptySet();
   }

   private void ensureFileExists() throws IOException {
      if (!this.plugin.getDataFolder().exists() && !this.plugin.getDataFolder().mkdirs()) {
         throw new IOException("папка плагина не создана: " + this.plugin.getDataFolder());
      }

      if (!this.configFile.exists()) {
         try {
            this.plugin.saveResource("config.yml", false);
         } catch (IllegalArgumentException exception) {
            YamlConfiguration defaults = new YamlConfiguration();
            this.addDefaults(defaults);
            defaults.options().copyDefaults(true);
            defaults.save(this.configFile);
         }
      }
   }

   private void addDefaults(YamlConfiguration config) {
      config.addDefault("settings.golden-apple-cooldown", this.goldenAppleCooldown);
      config.addDefault("settings.enchanted-golden-apple-cooldown", this.enchantedGoldenAppleCooldown);
      config.addDefault("settings.ender-pearl-cooldown", this.enderPearlCooldown);
      config.addDefault("settings.chorus-cooldown", this.chorusCooldown);
      config.addDefault("settings.firework-cooldown", this.fireworkCooldown);
      config.addDefault("settings.totem-cooldown", this.totemCooldown);
      config.addDefault("settings.trident-cooldown", this.tridentCooldown);
      config.addDefault("settings.riptide-cooldown", this.riptideCooldown);
      config.addDefault("settings.mace-wind-burst-cooldown", this.maceWindBurstCooldown);
      config.addDefault("settings.disable-ender-chest-in-pvp", this.disableEnderChestInPvp);
      config.addDefault("settings.pvp-time", this.pvpTime);
      config.addDefault("settings.disable-commands-in-pvp", this.disableCommandsInPvp);
      config.addDefault("settings.commands-whitelist", this.whiteListedCommands);
      config.addDefault("settings.cancel-interact-with-entities", this.cancelInteractWithEntities);
      config.addDefault("settings.kill-on-leave", this.killOnLeave);
      config.addDefault("settings.kill-on-kick", this.killOnKick);
      config.addDefault("settings.run-commands-on-kick", this.runCommandsOnKick);
      config.addDefault("settings.kick-messages", this.kickMessages);
      config.addDefault("settings.commands-on-leave", this.commandsOnLeave);
      config.addDefault("settings.disable-powerups", this.disablePowerups);
      config.addDefault("settings.commands-on-powerups-disable", this.commandsOnPowerupsDisable);
      config.addDefault("settings.disable-teleports-in-pvp", this.disableTeleportsInPvp);
      config.addDefault("settings.hide-join-message", this.hideJoinMessage);
      config.addDefault("settings.hide-leave-message", this.hideLeaveMessage);
      config.addDefault("settings.hide-death-message", this.hideDeathMessage);
      config.addDefault("settings.disabled-worlds", this.disabledWorlds);
      this.messages.addDefaults(config, "messages");
      this.scoreboard.addDefaults(config, "scoreboard");
   }

   private void read(YamlConfiguration config) {
      this.goldenAppleCooldown = config.getInt("settings.golden-apple-cooldown", this.goldenAppleCooldown);
      this.enchantedGoldenAppleCooldown = config.getInt("settings.enchanted-golden-apple-cooldown", this.enchantedGoldenAppleCooldown);
      this.enderPearlCooldown = config.getInt("settings.ender-pearl-cooldown", this.enderPearlCooldown);
      this.chorusCooldown = config.getInt("settings.chorus-cooldown", this.chorusCooldown);
      this.fireworkCooldown = config.getInt("settings.firework-cooldown", this.fireworkCooldown);
      this.totemCooldown = config.getInt("settings.totem-cooldown", this.totemCooldown);
      this.tridentCooldown = config.getInt("settings.trident-cooldown", this.tridentCooldown);
      this.riptideCooldown = config.getInt("settings.riptide-cooldown", this.riptideCooldown);
      this.maceWindBurstCooldown = config.getInt("settings.mace-wind-burst-cooldown", this.maceWindBurstCooldown);
      this.disableEnderChestInPvp = config.getBoolean("settings.disable-ender-chest-in-pvp", this.disableEnderChestInPvp);
      this.pvpTime = config.getInt("settings.pvp-time", this.pvpTime);
      this.disableCommandsInPvp = config.getBoolean("settings.disable-commands-in-pvp", this.disableCommandsInPvp);
      this.whiteListedCommands = this.getStringList(config, "settings.commands-whitelist", this.whiteListedCommands);
      this.cancelInteractWithEntities = config.getBoolean("settings.cancel-interact-with-entities", this.cancelInteractWithEntities);
      this.killOnLeave = config.getBoolean("settings.kill-on-leave", this.killOnLeave);
      this.killOnKick = config.getBoolean("settings.kill-on-kick", this.killOnKick);
      this.runCommandsOnKick = config.getBoolean("settings.run-commands-on-kick", this.runCommandsOnKick);
      this.kickMessages = this.getStringList(config, "settings.kick-messages", this.kickMessages);
      this.commandsOnLeave = this.getStringList(config, "settings.commands-on-leave", this.commandsOnLeave);
      this.disablePowerups = config.getBoolean("settings.disable-powerups", this.disablePowerups);
      this.commandsOnPowerupsDisable = this.getStringList(config, "settings.commands-on-powerups-disable", this.commandsOnPowerupsDisable);
      this.disableTeleportsInPvp = config.getBoolean("settings.disable-teleports-in-pvp", this.disableTeleportsInPvp);
      this.hideJoinMessage = config.getBoolean("settings.hide-join-message", this.hideJoinMessage);
      this.hideLeaveMessage = config.getBoolean("settings.hide-leave-message", this.hideLeaveMessage);
      this.hideDeathMessage = config.getBoolean("settings.hide-death-message", this.hideDeathMessage);
      this.disabledWorlds = this.getStringList(config, "settings.disabled-worlds", this.getStringList(config, "disabledWorlds", this.disabledWorlds));
      ConfigurationSection messagesSection = config.getConfigurationSection("messages");
      this.messages.load((ConfigurationSection)(messagesSection == null ? config : messagesSection));
      this.scoreboard.load(config.getConfigurationSection("scoreboard"));
   }

   private List<String> getStringList(YamlConfiguration config, String path, List<String> def) {
      if (!config.contains(path)) {
         return def.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(new ArrayList<>(def));
      }

      List<String> list = config.getStringList(path);
      if (list != null && !list.isEmpty()) {
         ArrayList<String> result = new ArrayList<>(list.size());

         for (String value : list) {
            if (value != null && !value.isEmpty()) {
               result.add(value);
            }
         }

         return result.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(result);
      } else {
         return Collections.emptyList();
      }
   }

   public void loaded() {
      this.normalizedKickMessages = this.normalizeLowercaseList(this.kickMessages);
      if (this.disabledWorlds.isEmpty()) {
         this.disabledWorldsSet = Collections.emptySet();
      } else {
         HashSet<String> worlds = new HashSet<>(Math.max(4, this.disabledWorlds.size() * 2));

         for (String world : this.disabledWorlds) {
            if (world != null && !world.isEmpty()) {
               worlds.add(world.toLowerCase(Locale.ROOT));
            }
         }

         this.disabledWorldsSet = worlds.isEmpty() ? Collections.emptySet() : Collections.unmodifiableSet(worlds);
      }
   }

   private List<String> normalizeLowercaseList(List<String> values) {
      if (values != null && !values.isEmpty()) {
         ArrayList<String> normalized = new ArrayList<>(values.size());

         for (String value : values) {
            if (value != null && !value.isEmpty()) {
               normalized.add(value.toLowerCase(Locale.ROOT));
            }
         }

         return normalized.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(normalized);
      } else {
         return Collections.emptyList();
      }
   }

   public Messages getMessages() {
      return this.messages;
   }

   public ScoreboardSettings getScoreboardSettings() {
      return this.scoreboard;
   }

   public int getGoldenAppleCooldown() {
      return this.goldenAppleCooldown;
   }

   public int getEnchantedGoldenAppleCooldown() {
      return this.enchantedGoldenAppleCooldown;
   }

   public int getEnderPearlCooldown() {
      return this.enderPearlCooldown;
   }

   public int getChorusCooldown() {
      return this.chorusCooldown;
   }

   public int getСhorusCooldown() {
      return this.chorusCooldown;
   }

   public int getFireworkCooldown() {
      return this.fireworkCooldown;
   }

   public int getTotemCooldown() {
      return this.totemCooldown;
   }

   public int getTridentCooldown() {
      return this.tridentCooldown;
   }

   public int getRiptideCooldown() {
      return this.riptideCooldown;
   }

   public int getMaceWindBurstCooldown() {
      return this.maceWindBurstCooldown;
   }

   public boolean isDisableEnderChestInPvp() {
      return this.disableEnderChestInPvp;
   }

   public int getPvpTime() {
      return this.pvpTime;
   }

   public boolean isDisableCommandsInPvp() {
      return this.disableCommandsInPvp;
   }

   public boolean isCancelInteractWithEntities() {
      return this.cancelInteractWithEntities;
   }

   public List<String> getCommandsOnPowerupsDisable() {
      return this.commandsOnPowerupsDisable;
   }

   public List<String> getWhiteListedCommands() {
      return this.whiteListedCommands;
   }

   public boolean isKillOnLeave() {
      return this.killOnLeave;
   }

   public boolean isKillOnKick() {
      return this.killOnKick;
   }

   public boolean isRunCommandsOnKick() {
      return this.runCommandsOnKick;
   }

   public List<String> getKickMessages() {
      return this.kickMessages;
   }

   public List<String> getNormalizedKickMessages() {
      return this.normalizedKickMessages;
   }

   public boolean isDisablePowerups() {
      return this.disablePowerups;
   }

   public boolean isDisableTeleportsInPvp() {
      return this.disableTeleportsInPvp;
   }

   public boolean isHideJoinMessage() {
      return this.hideJoinMessage;
   }

   public boolean isHideLeaveMessage() {
      return this.hideLeaveMessage;
   }

   public boolean isHideDeathMessage() {
      return this.hideDeathMessage;
   }

   public List<String> getCommandsOnLeave() {
      return this.commandsOnLeave;
   }

   public Set<String> getDisabledWorlds() {
      return this.disabledWorldsSet;
   }
}
