package cs.cloudstudio.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.bukkit.configuration.ConfigurationSection;

public class ScoreboardSettings {
   private static final boolean DEFAULT_ENABLED = true;
   private static final boolean DEFAULT_USE_TAB_API = false;
   private static final int DEFAULT_UPDATE_INTERVAL = 20;
   private static final String DEFAULT_TITLE = "<#fabc00>&lPVP</#f85a28>";
   private static final String DEFAULT_GRADIENT_START = "#faa709";
   private static final String DEFAULT_GRADIENT_END = "#f86126";
   private static final List<String> DEFAULT_LINES = Collections.unmodifiableList(
      Arrays.asList("", "{opponents}", "", " {c}ꐁ &fДо окончания PVP", " {c}ꐀ &fрежима {c}{timer}!", "", "    <#fabc00>&lReallyWorld.ru</#f85a28>", "")
   );
   private static final String DEFAULT_OPPONENT_LINE = "{opponent_symbol}&f{player_name}: {c}{health} хп";
   private static final String DEFAULT_OPPONENT_SYMBOL = " {c}ꐁ ";
   private static final String DEFAULT_LAST_OPPONENT_SYMBOL = " {c}ꐀ ";
   private static final int DEFAULT_MAX_OPPONENTS = 8;
   private boolean enabled = true;
   private boolean useTabApi = false;
   private int updateInterval = 20;
   private String title = "<#fabc00>&lPVP</#f85a28>";
   private String gradientStart = "#faa709";
   private String gradientEnd = "#f86126";
   private List<String> lines = DEFAULT_LINES;
   private String opponentLine = "{opponent_symbol}&f{player_name}: {c}{health} хп";
   private String opponentSymbol = " {c}ꐁ ";
   private String lastOpponentSymbol = " {c}ꐀ ";
   private int maxOpponents = 8;

   void addDefaults(ConfigurationSection config, String path) {
      config.addDefault(path + ".enabled", true);
      config.addDefault(path + ".use-tab-api", false);
      config.addDefault(path + ".update-interval", 20);
      config.addDefault(path + ".title", "<#fabc00>&lPVP</#f85a28>");
      config.addDefault(path + ".start", "#faa709");
      config.addDefault(path + ".end", "#f86126");
      config.addDefault(path + ".lines", DEFAULT_LINES);
      config.addDefault(path + ".opponent_line", "{opponent_symbol}&f{player_name}: {c}{health} хп");
      config.addDefault(path + ".opponent_symbol", " {c}ꐁ ");
      config.addDefault(path + ".last_opponent_symbol", " {c}ꐀ ");
      config.addDefault(path + ".max-opponents", 8);
   }

   void load(ConfigurationSection section) {
      this.reset();
      if (section != null) {
         this.enabled = section.getBoolean("enabled", this.enabled);
         this.useTabApi = section.getBoolean("use-tab-api", this.useTabApi);
         this.updateInterval = section.getInt("update-interval", this.updateInterval);
         this.title = section.getString("title", this.title);
         this.gradientStart = section.getString("start", this.gradientStart);
         this.gradientEnd = section.getString("end", this.gradientEnd);
         List<String> configLines = section.getStringList("lines");
         if (!configLines.isEmpty()) {
            this.lines = Collections.unmodifiableList(new ArrayList<>(configLines));
         }

         this.opponentLine = section.getString("opponent_line", this.opponentLine);
         this.opponentSymbol = section.getString("opponent_symbol", this.opponentSymbol);
         this.lastOpponentSymbol = section.getString("last_opponent_symbol", this.lastOpponentSymbol);
         this.maxOpponents = section.getInt("max-opponents", this.maxOpponents);
      }
   }

   private void reset() {
      this.enabled = true;
      this.useTabApi = false;
      this.updateInterval = 20;
      this.title = "<#fabc00>&lPVP</#f85a28>";
      this.gradientStart = "#faa709";
      this.gradientEnd = "#f86126";
      this.lines = DEFAULT_LINES;
      this.opponentLine = "{opponent_symbol}&f{player_name}: {c}{health} хп";
      this.opponentSymbol = " {c}ꐁ ";
      this.lastOpponentSymbol = " {c}ꐀ ";
      this.maxOpponents = 8;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public boolean isUseTabApi() {
      return this.useTabApi;
   }

   public int getUpdateInterval() {
      return Math.max(20, this.updateInterval);
   }

   public String getTitle() {
      return this.title;
   }

   public String getGradientStart() {
      return this.gradientStart;
   }

   public String getGradientEnd() {
      return this.gradientEnd;
   }

   public List<String> getLines() {
      return this.lines;
   }

   public String getOpponentLine() {
      return this.opponentLine;
   }

   public String getOpponentSymbol() {
      return this.opponentSymbol;
   }

   public String getLastOpponentSymbol() {
      return this.lastOpponentSymbol;
   }

   public int getMaxOpponents() {
      return Math.max(1, this.maxOpponents);
   }
}
