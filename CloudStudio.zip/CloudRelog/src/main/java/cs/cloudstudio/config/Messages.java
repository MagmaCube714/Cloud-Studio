package cs.cloudstudio.config;

import cs.cloudstudio.util.ColorUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.bukkit.configuration.ConfigurationSection;

public class Messages {
   private static final String DEFAULT_PVP_STARTED = "&6АнтиРелог &7» &fВы вошли в PVP режим. За выход с сервера - &cсмерть&7.";
   private static final String DEFAULT_PVP_STOPPED = "&6АнтиРелог &7» &fPVP режим &aзакончился. &fМожно спокойно выходить";
   private static final String DEFAULT_IN_PVP_BOSSBAR = "&7До окончания PvP режима &c%time% &7сек.";
   private static final String DEFAULT_COMMANDS_DISABLED = "&6АнтиРелог &7» &cКоманды недоступны в PVP режиме";
   private static final String DEFAULT_ITEM_COOLDOWN = "&6АнтиРелог &7» &fПредмет будет доступен через &6%time% &f%formated-sec%";
   private static final String DEFAULT_ITEM_DISABLED_IN_PVP = "&6АнтиРелог &7» &fИспользование этого предмета во время боя - запрещено.";
   private static final String DEFAULT_RIPTIDE_COOLDOWN = "&6Трезубец &7» &cПодождите %time% секунд!";
   private static final String DEFAULT_ENDER_CHEST_DISABLED_IN_PVP = "&6АнтиРелог &7» &cНедоступно в PVP режиме";
   private static final String DEFAULT_NO_PERM = "&6АнтиРелог &7» &cУ вас нет прав";
   private static final List<String> DEFAULT_ADMIN_USAGE = Arrays.asList("&6АнтиРелог &7» &f/cloudrelog reload");
   private static final String DEFAULT_RELOADED = "&6АнтиРелог &7» &aКонфиг перезагружен";
   private String pvpStarted;
   private String pvpStopped;
   private String inPvpBossbar;
   private String commandsDisabled;
   private String itemCooldown;
   private String itemDisabledInPvp;
   private String riptideCooldown;
   private String enderChestDisabledInPvp;
   private String noPerm;
   private List<String> adminUsage;
   private String reloaded;

   public Messages() {
      this.reset();
   }

   void addDefaults(ConfigurationSection config, String path) {
      config.addDefault(path + ".pvp-started", "&6АнтиРелог &7» &fВы вошли в PVP режим. За выход с сервера - &cсмерть&7.");
      config.addDefault(path + ".pvp-stopped", "&6АнтиРелог &7» &fPVP режим &aзакончился. &fМожно спокойно выходить");
      config.addDefault(path + ".in-pvp-bossbar", "&7До окончания PvP режима &c%time% &7сек.");
      config.addDefault(path + ".commands-disabled", "&6АнтиРелог &7» &cКоманды недоступны в PVP режиме");
      config.addDefault(path + ".item-cooldown", "&6АнтиРелог &7» &fПредмет будет доступен через &6%time% &f%formated-sec%");
      config.addDefault(path + ".item-disabled-in-pvp", "&6АнтиРелог &7» &fИспользование этого предмета во время боя - запрещено.");
      config.addDefault(path + ".riptide-cooldown", "&6Трезубец &7» &cПодождите %time% секунд!");
      config.addDefault(path + ".ender-chest-disabled-in-pvp", "&6АнтиРелог &7» &cНедоступно в PVP режиме");
      config.addDefault(path + ".no-perm", "&6АнтиРелог &7» &cУ вас нет прав");
      config.addDefault(path + ".admin-usage", DEFAULT_ADMIN_USAGE);
      config.addDefault(path + ".reloaded", "&6АнтиРелог &7» &aКонфиг перезагружен");
   }

   void load(ConfigurationSection section) {
      this.reset();
      if (section != null) {
         this.pvpStarted = this.color(section.getString("pvp-started", this.pvpStarted));
         this.pvpStopped = this.color(section.getString("pvp-stopped", this.pvpStopped));
         this.inPvpBossbar = this.color(section.getString("in-pvp-bossbar", this.inPvpBossbar));
         this.commandsDisabled = this.color(section.getString("commands-disabled", this.commandsDisabled));
         this.itemCooldown = this.color(section.getString("item-cooldown", this.itemCooldown));
         this.itemDisabledInPvp = this.color(section.getString("item-disabled-in-pvp", this.itemDisabledInPvp));
         this.riptideCooldown = this.color(section.getString("riptide-cooldown", this.riptideCooldown));
         this.enderChestDisabledInPvp = this.color(section.getString("ender-chest-disabled-in-pvp", this.enderChestDisabledInPvp));
         this.noPerm = this.color(section.getString("no-perm", this.noPerm));
         this.adminUsage = this.colorList(section.getStringList("admin-usage"), this.adminUsage);
         this.reloaded = this.color(section.getString("reloaded", this.reloaded));
      }
   }

   private void reset() {
      this.pvpStarted = this.color("&6АнтиРелог &7» &fВы вошли в PVP режим. За выход с сервера - &cсмерть&7.");
      this.pvpStopped = this.color("&6АнтиРелог &7» &fPVP режим &aзакончился. &fМожно спокойно выходить");
      this.inPvpBossbar = this.color("&7До окончания PvP режима &c%time% &7сек.");
      this.commandsDisabled = this.color("&6АнтиРелог &7» &cКоманды недоступны в PVP режиме");
      this.itemCooldown = this.color("&6АнтиРелог &7» &fПредмет будет доступен через &6%time% &f%formated-sec%");
      this.itemDisabledInPvp = this.color("&6АнтиРелог &7» &fИспользование этого предмета во время боя - запрещено.");
      this.riptideCooldown = this.color("&6Трезубец &7» &cПодождите %time% секунд!");
      this.enderChestDisabledInPvp = this.color("&6АнтиРелог &7» &cНедоступно в PVP режиме");
      this.noPerm = this.color("&6АнтиРелог &7» &cУ вас нет прав");
      this.adminUsage = this.colorList(DEFAULT_ADMIN_USAGE, DEFAULT_ADMIN_USAGE);
      this.reloaded = this.color("&6АнтиРелог &7» &aКонфиг перезагружен");
   }

   private String color(String value) {
      return value == null ? "" : ColorUtils.color(value);
   }

   private List<String> colorList(List<String> values, List<String> def) {
      List<String> source = values != null && !values.isEmpty() ? values : def;
      List<String> result = new ArrayList<>(source.size());

      for (String value : source) {
         result.add(this.color(value));
      }

      return Collections.unmodifiableList(result);
   }

   public String getPvpStarted() {
      return this.pvpStarted;
   }

   public String getPvpStopped() {
      return this.pvpStopped;
   }

   public String getInPvpBossbar() {
      return this.inPvpBossbar;
   }

   public String getCommandsDisabled() {
      return this.commandsDisabled;
   }

   public String getItemCooldown() {
      return this.itemCooldown;
   }

   public String getItemDisabledInPvp() {
      return this.itemDisabledInPvp;
   }

   public String getRiptideCooldown() {
      return this.riptideCooldown;
   }

   public String getEnderChestDisabledInPvp() {
      return this.enderChestDisabledInPvp;
   }

   public String getNoPerm() {
      return this.noPerm;
   }

   public List<String> getAdminUsage() {
      return this.adminUsage;
   }

   public String getReloaded() {
      return this.reloaded;
   }
}
