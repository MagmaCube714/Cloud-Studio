package cs.cloudstudio.command;

import cs.cloudstudio.CloudRelog;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public final class AdminCommand implements CommandExecutor, TabCompleter {
   private final CloudRelog plugin;
   private final BaseCommand baseCommand;

   public AdminCommand(CloudRelog plugin) {
      this.plugin = plugin;
      this.baseCommand = new BaseCommand(plugin);
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("cloudrelog.admin")) {
         sender.sendMessage(this.plugin.getSettings().getMessages().getNoPerm());
         return true;
      } else if (args.length == 0) {
         this.sendUsage(sender);
         return true;
      } else {
         SubCommand subCommand = this.baseCommand.get(args[0]);
         if (subCommand == null) {
            this.sendUsage(sender);
            return true;
         } else {
            subCommand.execute(sender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.hasPermission("cloudrelog.admin")) {
         return Collections.emptyList();
      }

      if (args.length == 1) {
         return this.filter(this.baseCommand.names(), args[0]);
      }

      SubCommand subCommand = this.baseCommand.get(args[0]);
      return subCommand == null ? Collections.emptyList() : this.filter(subCommand.tabComplete(args), args[args.length - 1]);
   }

   private void sendUsage(CommandSender sender) {
      for (String line : this.plugin.getSettings().getMessages().getAdminUsage()) {
         sender.sendMessage(line);
      }
   }

   private List<String> filter(List<String> values, String input) {
      String lowered = input.toLowerCase();
      List<String> result = new ArrayList<>();

      for (String value : values) {
         if (value.toLowerCase().startsWith(lowered)) {
            result.add(value);
         }
      }

      return result;
   }
}
