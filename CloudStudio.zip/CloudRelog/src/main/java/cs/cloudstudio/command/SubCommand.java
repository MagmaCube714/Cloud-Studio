package cs.cloudstudio.command;

import java.util.Collections;
import java.util.List;
import org.bukkit.command.CommandSender;

public interface SubCommand {
   String name();

   void execute(CommandSender var1, String[] var2);

   default List<String> tabComplete(String[] args) {
      return Collections.emptyList();
   }
}
