package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudRelog;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand implements SubCommand {
   private final CloudRelog plugin;

   public ReloadSubCommand(CloudRelog plugin) {
      this.plugin = plugin;
   }

   @Override
   public String name() {
      return "reload";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      this.plugin.reloadSettings();
      sender.sendMessage(this.plugin.getSettings().getMessages().getReloaded());
   }
}
