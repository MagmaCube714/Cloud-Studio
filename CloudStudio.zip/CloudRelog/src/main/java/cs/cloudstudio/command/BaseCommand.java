package cs.cloudstudio.command;

import cs.cloudstudio.CloudRelog;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class BaseCommand {
   private final Map<String, SubCommand> commands = new LinkedHashMap<>();

   public BaseCommand(CloudRelog plugin) {
      this.register(new ReloadSubCommand(plugin));
   }

   public SubCommand get(String name) {
      return name == null ? null : this.commands.get(name.toLowerCase());
   }

   public List<String> names() {
      return new ArrayList<>(this.commands.keySet());
   }

   private void register(SubCommand command) {
      this.commands.put(command.name().toLowerCase(), command);
   }
}
