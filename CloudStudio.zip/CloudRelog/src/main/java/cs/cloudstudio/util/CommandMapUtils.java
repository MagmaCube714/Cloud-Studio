package cs.cloudstudio.util;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandMap;

public final class CommandMapUtils {
   private CommandMapUtils() {
   }

   public static Command getCommand(String command) {
      if (command != null && !command.isEmpty()) {
         CommandMap commandMap = Bukkit.getCommandMap();
         return commandMap == null ? null : commandMap.getCommand(command);
      } else {
         return null;
      }
   }
}
