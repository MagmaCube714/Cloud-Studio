package cs.cloudstudio.util;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class PlaceholderUtils {
   private static boolean available;

   private PlaceholderUtils() {
   }

   public static void detect() {
      available = Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI");
   }

   public static String setPlaceholders(Player player, String text) {
      return canProcess(text) && player != null ? PlaceholderUtils.Bridge.setPlaceholders(player, text) : text;
   }

   public static String setRelationalPlaceholders(Player viewer, Player target, String text) {
      return canProcessRelational(text) && viewer != null && target != null ? PlaceholderUtils.Bridge.setRelationalPlaceholders(viewer, target, text) : text;
   }

   public static void reset() {
      detect();
   }

   private static boolean canProcess(String text) {
      return available && text != null && !text.isEmpty() && text.indexOf(37) != -1;
   }

   private static boolean canProcessRelational(String text) {
      return available && text != null && !text.isEmpty() && text.indexOf("%rel_") != -1;
   }

   private static final class Bridge {
      private static String setPlaceholders(Player player, String text) {
         return PlaceholderAPI.setPlaceholders(player, text);
      }

      private static String setRelationalPlaceholders(Player viewer, Player target, String text) {
         return PlaceholderAPI.setRelationalPlaceholders(viewer, target, text);
      }
   }
}
