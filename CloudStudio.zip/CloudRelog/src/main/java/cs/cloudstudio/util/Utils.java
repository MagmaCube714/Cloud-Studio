package cs.cloudstudio.util;

public class Utils {
   private static final String SEC_SHORT = "сек.";

   public static String color(String message) {
      return ColorUtils.color(message);
   }

   public static String replaceTime(String message, int time) {
      return message.replace("%time%", Integer.toString(time)).replace("%formated-sec%", "сек.");
   }
}
