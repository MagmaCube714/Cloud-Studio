package cs.cloudstudio.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public final class ColorUtils {
   private static final char[] HEX = "0123456789abcdef".toCharArray();
   private static final String WHITE = "#ffffff";
   private static final int COLOR_CACHE_LIMIT = 4096;
   private static final int MAX_CACHEABLE_LENGTH = 2048;
   private static final Map<String, String> COLOR_CACHE = new LinkedHashMap<String, String>(4096, 0.75F, true) {
      @Override
      protected boolean removeEldestEntry(Entry<String, String> eldest) {
         return this.size() > 4096;
      }
   };

   private ColorUtils() {
   }

   public static String color(String text) {
      if (text != null && !text.isEmpty() && needsColoring(text)) {
         if (text.length() > 2048) {
            return colorUncached(text);
         }

         synchronized (COLOR_CACHE) {
            String cached = COLOR_CACHE.get(text);
            if (cached != null) {
               return cached;
            }
         }

         String colored = colorUncached(text);
         synchronized (COLOR_CACHE) {
            String cached = COLOR_CACHE.get(text);
            if (cached != null) {
               return cached;
            }

            COLOR_CACHE.put(text, colored);
            return colored;
         }
      } else {
         return text;
      }
   }

   private static boolean needsColoring(String text) {
      return text.indexOf(38) != -1 || text.indexOf("<#") != -1;
   }

   public static List<String> gradient(String startHex, String endHex, int steps) {
      List<String> gradient = new ArrayList<>(Math.max(steps, 0));
      if (steps <= 0) {
         return gradient;
      }

      if (steps == 1) {
         gradient.add(normalizeHex(startHex));
         return gradient;
      }

      int start = parseHexColor(startHex);
      int end = parseHexColor(endHex);
      int startRed = start >> 16 & 0xFF;
      int startGreen = start >> 8 & 0xFF;
      int startBlue = start & 0xFF;
      int redDiff = (end >> 16 & 0xFF) - startRed;
      int greenDiff = (end >> 8 & 0xFF) - startGreen;
      int blueDiff = (end & 0xFF) - startBlue;

      for (int i = 0; i < steps; i++) {
         float ratio = (float)i / (steps - 1);
         gradient.add(rgbToHex((int)(startRed + ratio * redDiff), (int)(startGreen + ratio * greenDiff), (int)(startBlue + ratio * blueDiff)));
      }

      return gradient;
   }

   public static String toLegacyHex(String hex) {
      int rgb = parseHexColor(hex);
      return toLegacyHex(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF);
   }

   public static String gradientLegacy(String startHex, String endHex, int steps, int index) {
      if (steps <= 1) {
         return toLegacyHex(startHex);
      }

      if (index < 0) {
         index = 0;
      } else if (index >= steps) {
         index = steps - 1;
      }

      int start = parseHexColor(startHex);
      int end = parseHexColor(endHex);
      float ratio = (float)index / (steps - 1);
      int red = (int)((start >> 16 & 0xFF) + ratio * ((end >> 16 & 0xFF) - (start >> 16 & 0xFF)));
      int green = (int)((start >> 8 & 0xFF) + ratio * ((end >> 8 & 0xFF) - (start >> 8 & 0xFF)));
      int blue = (int)((start & 0xFF) + ratio * ((end & 0xFF) - (start & 0xFF)));
      return toLegacyHex(red, green, blue);
   }

   public static String normalizeHex(String hex) {
      if (hex == null) {
         return "#ffffff";
      }

      String value = hex.trim();
      int offset = value.startsWith("#") ? 1 : 0;
      if (value.length() - offset != 6) {
         return "#ffffff";
      }

      for (int i = offset; i < offset + 6; i++) {
         if (hexValue(value.charAt(i)) == -1) {
            return "#ffffff";
         }
      }

      char[] normalized = new char[7];
      normalized[0] = '#';

      for (int i = 0; i < 6; i++) {
         normalized[i + 1] = Character.toLowerCase(value.charAt(offset + i));
      }

      return new String(normalized);
   }

   private static String colorUncached(String text) {
      String result = applyGradients(text);
      result = applyHexColors(result);
      return result.indexOf(38) == -1 ? result : translateAmpersand(result);
   }

   public static String translateAmpersand(String text) {
      if (text != null && !text.isEmpty()) {
         char[] chars = text.toCharArray();

         for (int i = 0; i < chars.length - 1; i++) {
            if (chars[i] == '&' && "0123456789AaBbCcDdEeFfKkLlMmNnOoRrXx".indexOf(chars[i + 1]) > -1) {
               chars[i] = 167;
               chars[i + 1] = Character.toLowerCase(chars[i + 1]);
            }
         }

         return new String(chars);
      } else {
         return text;
      }
   }

   public static String getLastColors(String input) {
      if (input == null || input.isEmpty()) {
         return "";
      }

      StringBuilder result = new StringBuilder();
      int length = input.length();

      for (int index = length - 1; index > -1; index--) {
         char section = input.charAt(index);
         if (section == 167 && index < length - 1) {
            if (index > 11 && input.charAt(index - 12) == 167 && (input.charAt(index - 11) == 'x' || input.charAt(index - 11) == 'X')) {
               String hex = input.substring(index - 12, index + 2);
               if (isLegacyHex(hex)) {
                  result.insert(0, hex);
                  break;
               }
            }

            char code = Character.toLowerCase(input.charAt(index + 1));
            if (code >= 'k' && code <= 'o') {
               result.insert(0, new char[]{167, code});
            } else if (code >= '0' && code <= '9' || code >= 'a' && code <= 'f' || code == 'r') {
               result.insert(0, new char[]{167, code});
               break;
            }
         }
      }

      return result.toString();
   }

   private static boolean isLegacyHex(String value) {
      if (value.length() != 14 || value.charAt(0) != 167) {
         return false;
      }

      for (int i = 2; i < 14; i += 2) {
         if (value.charAt(i) != 167 || hexValue(value.charAt(i + 1)) == -1) {
            return false;
         }
      }

      return true;
   }

   private static String toLegacyHex(int rgb) {
      return toLegacyHex(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF);
   }

   private static String toLegacyHex(int red, int green, int blue) {
      char[] out = new char[14];
      out[0] = 167;
      out[1] = 'x';
      appendHexByte(out, 2, red);
      appendHexByte(out, 6, green);
      appendHexByte(out, 10, blue);
      return new String(out);
   }

   private static void appendHexByte(char[] out, int offset, int value) {
      out[offset] = 167;
      out[offset + 1] = HEX[value >>> 4 & 15];
      out[offset + 2] = 167;
      out[offset + 3] = HEX[value & 15];
   }

   private static String applyGradients(String text) {
      int open = text.indexOf("<#");
      if (open == -1) {
         return text;
      }

      StringBuilder result = null;
      int last = 0;

      while (open != -1) {
         int openEnd = open + 8;
         if (openEnd < text.length() && text.charAt(openEnd) == '>' && isHex(text, open + 2)) {
            int close = text.indexOf("</#", openEnd + 1);
            if (close != -1 && close + 9 < text.length() && text.charAt(close + 9) == '>' && isHex(text, close + 3)) {
               if (result == null) {
                  result = new StringBuilder(text.length() * 2);
               }

               result.append(text, last, open);
               result.append(applyGradient(text.substring(openEnd + 1, close), text, open + 2, text, close + 3));
               last = close + 10;
               open = text.indexOf("<#", last);
            } else {
               open = text.indexOf("<#", open + 2);
            }
         } else {
            open = text.indexOf("<#", open + 2);
         }
      }

      if (result == null) {
         return text;
      }

      result.append(text, last, text.length());
      return result.toString();
   }

   private static String applyGradient(String text, String startSource, int startOffset, String endSource, int endOffset) {
      if (text != null && !text.isEmpty()) {
         int start = parseHexColor(startSource, startOffset);
         int end = parseHexColor(endSource, endOffset);
         StringBuilder formatting = new StringBuilder(8);

         int position;
         for (position = 0; position < text.length() - 1 && text.charAt(position) == '&'; position += 2) {
            char code = Character.toLowerCase(text.charAt(position + 1));
            if ("klmnor".indexOf(code) == -1) {
               break;
            }

            formatting.append('§').append(code);
         }

         String cleanText = stripLegacyAmpersandCodes(text, position);
         if (cleanText.isEmpty()) {
            return text;
         }

         int startRed = start >> 16 & 0xFF;
         int startGreen = start >> 8 & 0xFF;
         int startBlue = start & 0xFF;
         int redDiff = (end >> 16 & 0xFF) - startRed;
         int greenDiff = (end >> 8 & 0xFF) - startGreen;
         int blueDiff = (end & 0xFF) - startBlue;
         int length = cleanText.length();
         StringBuilder result = new StringBuilder(length * (14 + formatting.length() + 1));

         for (int i = 0; i < length; i++) {
            float ratio = length > 1 ? (float)i / (length - 1) : 0.0F;
            result.append(toLegacyHex((int)(startRed + ratio * redDiff), (int)(startGreen + ratio * greenDiff), (int)(startBlue + ratio * blueDiff)))
               .append(formatting)
               .append(cleanText.charAt(i));
         }

         return result.toString();
      } else {
         return text;
      }
   }

   private static String applyHexColors(String text) {
      int marker = findHexMarker(text, 0);
      if (marker == -1) {
         return text;
      }

      StringBuilder result = new StringBuilder(text.length() + 32);
      int last = 0;

      while (marker != -1) {
         int hexOffset = marker + 2;
         if (isHex(text, hexOffset)) {
            int end = hexOffset + 6;
            boolean hasTrailingBracket = end < text.length() && text.charAt(end) == '>';
            result.append(text, last, marker);
            result.append(toLegacyHex(parseHexColor(text, hexOffset)));
            last = hasTrailingBracket ? end + 1 : end;
            marker = findHexMarker(text, last);
         } else {
            marker = findHexMarker(text, marker + 2);
         }
      }

      result.append(text, last, text.length());
      return result.toString();
   }

   private static int findHexMarker(String text, int fromIndex) {
      int angle = text.indexOf("<#", fromIndex);
      int ampersand = text.indexOf("&#", fromIndex);
      if (angle == -1) {
         return ampersand;
      } else {
         return ampersand == -1 ? angle : Math.min(angle, ampersand);
      }
   }

   private static String stripLegacyAmpersandCodes(String text, int from) {
      StringBuilder result = null;
      int last = from;

      for (int i = from; i < text.length() - 1; i++) {
         if (text.charAt(i) == '&' && isLegacyCode(text.charAt(i + 1))) {
            if (result == null) {
               result = new StringBuilder(text.length());
            }

            result.append(text, last, i);
            last = ++i + 1;
         }
      }

      if (result == null) {
         return text.substring(from);
      }

      result.append(text, last, text.length());
      return result.toString();
   }

   private static boolean isLegacyCode(char code) {
      char lower = Character.toLowerCase(code);
      return lower >= '0' && lower <= '9' || lower >= 'a' && lower <= 'f' || lower >= 'k' && lower <= 'o' || lower == 'r';
   }

   private static String rgbToHex(int red, int green, int blue) {
      char[] out = new char[]{'#', HEX[red >>> 4 & 15], HEX[red & 15], HEX[green >>> 4 & 15], HEX[green & 15], HEX[blue >>> 4 & 15], HEX[blue & 15]};
      return new String(out);
   }

   private static int parseHexColor(String hex) {
      String normalized = normalizeHex(hex);
      return parseHexColor(normalized, 1);
   }

   private static int parseHexColor(String source, int offset) {
      int value = 0;

      for (int i = 0; i < 6; i++) {
         int digit = hexValue(source.charAt(offset + i));
         if (digit == -1) {
            return 16777215;
         }

         value = value << 4 | digit;
      }

      return value;
   }

   private static boolean isHex(String source, int offset) {
      if (offset >= 0 && offset + 6 <= source.length()) {
         for (int i = 0; i < 6; i++) {
            if (hexValue(source.charAt(offset + i)) == -1) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private static int hexValue(char c) {
      if (c >= '0' && c <= '9') {
         return c - 48;
      } else if (c >= 'a' && c <= 'f') {
         return c - 97 + 10;
      } else {
         return c >= 65 && c <= 70 ? c - 65 + 10 : -1;
      }
   }
}
