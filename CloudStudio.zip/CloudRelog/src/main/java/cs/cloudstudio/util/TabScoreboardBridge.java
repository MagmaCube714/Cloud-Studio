package cs.cloudstudio.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import me.neznamy.tab.api.TabAPI;
import me.neznamy.tab.api.TabPlayer;
import me.neznamy.tab.api.scoreboard.Line;
import me.neznamy.tab.api.scoreboard.Scoreboard;
import me.neznamy.tab.api.scoreboard.ScoreboardManager;
import org.bukkit.entity.Player;

public final class TabScoreboardBridge {
   private final String ownerPrefix;
   private final Map<UUID, TabScoreboardBridge.TabBoard> boards = new HashMap<>();
   private final Set<UUID> pausedPlayers = new HashSet<>();

   public TabScoreboardBridge(String ownerPrefix) {
      this.ownerPrefix = ownerPrefix;
   }

   public boolean show(Player player, String title, List<String> lines) {
      if (player != null && player.isOnline() && lines != null) {
         TabScoreboardBridge.TabContext context = this.context(player.getUniqueId());
         if (context == null) {
            return false;
         }

         try {
            UUID uuid = player.getUniqueId();
            TabScoreboardBridge.TabBoard board = this.boards.get(uuid);
            if (board != null && this.isRegistered(context.manager, board)) {
               if (board.needsUpdate(title, lines) && !this.updateBoard(board, title, lines)) {
                  TabScoreboardBridge.TabBoard replacement = this.createBoard(context.manager, uuid, title, lines, board.version + 1);
                  if (replacement == null) {
                     return false;
                  }

                  try {
                     context.manager.setScoreboardVisible(context.player, true, false);
                     context.manager.showScoreboard(context.player, replacement.scoreboard);
                  } catch (RuntimeException | LinkageError error) {
                     this.unregister(context.manager, replacement);
                     return false;
                  }

                  this.boards.put(uuid, replacement);
                  this.unregister(context.manager, board);
                  board = replacement;
               }
            } else {
               if (board != null) {
                  this.unregister(context.manager, board);
               }

               board = this.createBoard(context.manager, uuid, title, lines, 0);
               if (board == null) {
                  return false;
               }

               this.boards.put(uuid, board);
            }

            Scoreboard active = context.manager.getActiveScoreboard(context.player);
            if (active != board.scoreboard) {
               context.manager.setScoreboardVisible(context.player, true, false);
               context.manager.showScoreboard(context.player, board.scoreboard);
            }

            board.shown = true;
            this.pausedPlayers.remove(uuid);
            return true;
         } catch (Throwable ignored) {
            return false;
         }
      } else {
         return false;
      }
   }

   public void markInactive(Player player) {
      if (player != null) {
         this.markInactive(player.getUniqueId());
      }
   }

   public void markInactive(UUID uuid) {
      TabScoreboardBridge.TabBoard board = uuid == null ? null : this.boards.get(uuid);
      if (board != null) {
         board.shown = false;
      }
   }

   public boolean isOwned(UUID uuid) {
      if (uuid == null) {
         return false;
      }

      TabScoreboardBridge.TabBoard board = this.boards.get(uuid);
      if (board == null) {
         return false;
      }

      TabScoreboardBridge.TabContext context = this.context(uuid);
      if (context == null) {
         board.shown = false;
         return false;
      }

      try {
         boolean owned = context.manager.getActiveScoreboard(context.player) == board.scoreboard;
         board.shown = owned;
         return owned;
      } catch (Throwable ignored) {
         board.shown = false;
         return false;
      }
   }

   public boolean pauseDefault(Player player) {
      if (player != null && player.isOnline()) {
         UUID uuid = player.getUniqueId();
         if (this.pausedPlayers.contains(uuid)) {
            return true;
         }

         TabScoreboardBridge.TabContext context = this.context(uuid);
         if (context == null) {
            return false;
         }

         try {
            context.manager.setScoreboardVisible(context.player, false, false);
            this.pausedPlayers.add(uuid);
            return true;
         } catch (Throwable ignored) {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean reset(Player player) {
      if (player != null && player.isOnline()) {
         UUID uuid = player.getUniqueId();
         TabScoreboardBridge.TabContext context = this.context(uuid);
         if (context == null) {
            return false;
         }

         try {
            TabScoreboardBridge.TabBoard board = this.boards.get(uuid);
            Scoreboard active = context.manager.getActiveScoreboard(context.player);
            boolean ours = board != null && active == board.scoreboard;
            boolean wasPaused = this.pausedPlayers.remove(uuid);
            if (wasPaused) {
               context.manager.setScoreboardVisible(context.player, true, false);
            }

            if (ours) {
               context.manager.resetScoreboard(context.player);
            } else if (wasPaused && !context.manager.hasCustomScoreboard(context.player)) {
               context.manager.resetScoreboard(context.player);
            }

            if (board != null) {
               board.shown = false;
            }

            return true;
         } catch (Throwable ignored) {
            return false;
         }
      } else {
         return false;
      }
   }

   public void remove(Player player) {
      if (player != null) {
         if (player.isOnline()) {
            this.reset(player);
         }

         this.remove(player.getUniqueId());
      }
   }

   public void remove(UUID uuid) {
      if (uuid != null) {
         TabScoreboardBridge.TabBoard board = this.boards.remove(uuid);
         boolean paused = this.pausedPlayers.remove(uuid);
         ScoreboardManager manager = this.manager();
         if (manager == null) {
            this.unregister(null, board);
         } else {
            TabPlayer tabPlayer = this.player(uuid);

            try {
               if (tabPlayer != null) {
                  if (paused) {
                     manager.setScoreboardVisible(tabPlayer, true, false);
                  }

                  if (board != null && manager.getActiveScoreboard(tabPlayer) == board.scoreboard) {
                     manager.resetScoreboard(tabPlayer);
                  }
               }
            } catch (Throwable var7) {
            }

            this.unregister(manager, board);
         }
      }
   }

   public void clear() {
      for (UUID uuid : new ArrayList<>(this.boards.keySet())) {
         this.remove(uuid);
      }

      this.boards.clear();
      this.pausedPlayers.clear();
   }

   private TabScoreboardBridge.TabContext context(UUID uuid) {
      ScoreboardManager manager = this.manager();
      TabPlayer player = this.player(uuid);
      return manager != null && player != null ? new TabScoreboardBridge.TabContext(manager, player) : null;
   }

   private ScoreboardManager manager() {
      try {
         TabAPI api = TabAPI.getInstance();
         return api == null ? null : api.getScoreboardManager();
      } catch (Throwable ignored) {
         return null;
      }
   }

   private TabPlayer player(UUID uuid) {
      try {
         TabAPI api = TabAPI.getInstance();
         TabPlayer player = api == null ? null : api.getPlayer(uuid);
         return player != null && player.isLoaded() ? player : null;
      } catch (Throwable ignored) {
         return null;
      }
   }

   private TabScoreboardBridge.TabBoard createBoard(ScoreboardManager manager, UUID uuid, String title, List<String> lines, int version) {
      String name = this.boardName(uuid, version);

      try {
         Scoreboard stale = (Scoreboard)manager.getRegisteredScoreboards().get(name);
         if (stale != null) {
            this.unregister(manager, stale);
         }

         Scoreboard scoreboard = manager.createScoreboard(name, safe(title), new ArrayList<>(lines));
         return scoreboard == null ? null : new TabScoreboardBridge.TabBoard(manager, scoreboard, title, lines, version);
      } catch (Throwable ignored) {
         return null;
      }
   }

   private String boardName(UUID uuid, int version) {
      return this.ownerPrefix + "_" + uuid.toString().replace("-", "") + "_" + version;
   }

   private boolean updateBoard(TabScoreboardBridge.TabBoard board, String title, List<String> lines) {
      try {
         if (!equals(board.title, title)) {
            board.scoreboard.setTitle(safe(title));
         }

         List<Line> currentLines = board.scoreboard.getLines();
         if (currentLines.size() == lines.size() && board.lines.size() == lines.size()) {
            for (int i = 0; i < lines.size(); i++) {
               String newLine = lines.get(i);
               if (!equals(board.lines.get(i), newLine)) {
                  currentLines.get(i).setText(safe(newLine));
               }
            }

            board.title = title;
            board.lines = new ArrayList<>(lines);
            return true;
         } else {
            return false;
         }
      } catch (Throwable ignored) {
         return false;
      }
   }

   private void unregister(ScoreboardManager manager, TabScoreboardBridge.TabBoard board) {
      if (board != null) {
         this.unregister(board.manager == null ? manager : board.manager, board.scoreboard);
      }
   }

   private void unregister(ScoreboardManager manager, Scoreboard scoreboard) {
      if (scoreboard != null) {
         if (manager != null) {
            try {
               manager.removeScoreboard(scoreboard);
               return;
            } catch (Throwable var5) {
            }
         }

         try {
            scoreboard.unregister();
         } catch (Throwable var4) {
         }
      }
   }

   private boolean isRegistered(ScoreboardManager manager, TabScoreboardBridge.TabBoard board) {
      if (manager != null && board != null) {
         try {
            return manager.getRegisteredScoreboards().get(board.scoreboard.getName()) == board.scoreboard;
         } catch (Throwable ignored) {
            return true;
         }
      } else {
         return false;
      }
   }

   private static boolean equals(String first, String second) {
      return first == null ? second == null : first.equals(second);
   }

   private static String safe(String text) {
      return text == null ? "" : text;
   }

   private static final class TabBoard {
      private final ScoreboardManager manager;
      private final Scoreboard scoreboard;
      private String title;
      private List<String> lines;
      private boolean shown;
      private final int version;

      private TabBoard(ScoreboardManager manager, Scoreboard scoreboard, String title, List<String> lines, int version) {
         this.manager = manager;
         this.scoreboard = scoreboard;
         this.title = title;
         this.lines = new ArrayList<>(lines);
         this.version = version;
      }

      private boolean needsUpdate(String title, List<String> lines) {
         return !TabScoreboardBridge.equals(this.title, title) || !this.lines.equals(lines);
      }
   }

   private static final class TabContext {
      private final ScoreboardManager manager;
      private final TabPlayer player;

      private TabContext(ScoreboardManager manager, TabPlayer player) {
         this.manager = manager;
         this.player = player;
      }
   }
}
