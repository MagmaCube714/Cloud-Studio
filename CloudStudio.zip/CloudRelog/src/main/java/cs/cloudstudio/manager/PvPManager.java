package cs.cloudstudio.manager;

import cs.cloudstudio.CloudRelog;
import cs.cloudstudio.config.Settings;
import cs.cloudstudio.event.PvpPreStartEvent;
import cs.cloudstudio.event.PvpStartedEvent;
import cs.cloudstudio.event.PvpStoppedEvent;
import cs.cloudstudio.event.PvpTimeUpdateEvent;
import cs.cloudstudio.util.CommandMapUtils;
import cs.cloudstudio.util.Utils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.scheduler.BukkitTask;

public class PvPManager {
   private static final int POWERUP_CHECK_INTERVAL_TICKS = 40;
   private static final long BYPASS_CACHE_MILLIS = 2000L;
   private static final int BYPASS_CACHE_MAX_SIZE = 2048;
   private static final int DAMAGE_DEDUPE_MAX_SIZE = 2048;
   private final Settings settings;
   private final CloudRelog plugin;
   private final PluginManager pluginManager;
   private final Map<UUID, PvPManager.CombatState> pvpMap = new HashMap<>();
   private final Map<UUID, PvPManager.CombatState> silentPvpMap = new HashMap<>();
   private final PowerUpsManager powerUpsManager;
   private final BossbarManager bossbarManager;
   private final Set<String> whiteListedCommands = new HashSet<>();
   private final List<UUID> tickBuffer = new ArrayList<>();
   private final Map<UUID, PvPManager.BypassCacheEntry> bypassCache = new HashMap<>();
   private final Map<UUID, PvPManager.DamageStamp> lastDamageByDefender = new HashMap<>();
   private BukkitTask pvpTask;
   private int updateEventIntervalTicks = 20;
   private int currentTick;
   private ScoreboardManager scoreboardManager;

   public PvPManager(Settings settings, CloudRelog plugin) {
      this.settings = settings;
      this.plugin = plugin;
      this.pluginManager = plugin.getServer().getPluginManager();
      this.powerUpsManager = new PowerUpsManager(settings);
      this.bossbarManager = new BossbarManager(plugin, settings);
      this.onPluginEnable();
   }

   public void onPluginDisable() {
      if (this.pvpTask != null) {
         this.pvpTask.cancel();
         this.pvpTask = null;
      }

      this.pvpMap.clear();
      this.silentPvpMap.clear();
      this.tickBuffer.clear();
      this.bypassCache.clear();
      this.lastDamageByDefender.clear();
      this.powerUpsManager.clearCache();
      this.bossbarManager.clearBossbars();
   }

   public void onPluginEnable() {
      this.stopPvpTask();
      this.reloadWhitelistedCommands();
      this.updateEventIntervalTicks = Math.max(20, this.settings.getScoreboardSettings().getUpdateInterval());
      if (this.settings.getPvpTime() > 0 && (!this.pvpMap.isEmpty() || !this.silentPvpMap.isEmpty())) {
         this.ensurePvpTask();
      }

      this.bossbarManager.createBossBars();
   }

   public void reload() {
      this.stopPvpTask();
      this.reloadWhitelistedCommands();
      this.updateEventIntervalTicks = Math.max(20, this.settings.getScoreboardSettings().getUpdateInterval());
      this.bypassCache.clear();
      this.powerUpsManager.clearCache();
      this.bossbarManager.createBossBars();
      if (this.settings.getPvpTime() <= 0) {
         List<Player> active = new ArrayList<>();
         this.collectStatePlayers(this.pvpMap, active);
         this.collectStatePlayers(this.silentPvpMap, active);

         for (Player player : active) {
            this.stopPvPSilent(player);
         }

         this.pvpMap.clear();
         this.silentPvpMap.clear();
      } else {
         int maxTime = this.settings.getPvpTime();
         this.clampStateTime(this.pvpMap, maxTime);
         this.clampStateTime(this.silentPvpMap, maxTime);
         this.ensurePvpTask();
      }
   }

   private void collectStatePlayers(Map<UUID, PvPManager.CombatState> map, List<Player> result) {
      for (Map.Entry<UUID, PvPManager.CombatState> entry : map.entrySet()) {
         Player player = entry.getValue().player;
         if (player == null || !player.isOnline()) {
            player = this.plugin.getServer().getPlayer(entry.getKey());
         }

         if (player != null) {
            result.add(player);
         }
      }
   }

   private void clampStateTime(Map<UUID, PvPManager.CombatState> map, int maxTime) {
      for (PvPManager.CombatState state : map.values()) {
         if (state.time > maxTime) {
            state.time = maxTime;
         }
      }
   }

   private void ensurePvpTask() {
      if (this.settings.getPvpTime() > 0 && (!this.pvpMap.isEmpty() || !this.silentPvpMap.isEmpty())) {
         if (this.pvpTask == null || this.pvpTask.isCancelled()) {
            this.pvpTask = this.plugin.getServer().getScheduler().runTaskTimer(this.plugin, () -> {
               if (this.pvpMap.isEmpty() && this.silentPvpMap.isEmpty()) {
                  this.stopPvpTask();
               } else {
                  this.currentTick += 20;
                  this.iterateMap(this.pvpMap, false, this.currentTick);
                  this.iterateMap(this.silentPvpMap, true, this.currentTick);
                  this.stopPvpTaskIfIdle();
               }
            }, 20L, 20L);
         }
      }
   }

   private void stopPvpTaskIfIdle() {
      if (this.pvpMap.isEmpty() && this.silentPvpMap.isEmpty()) {
         this.stopPvpTask();
      }
   }

   private void stopPvpTask() {
      if (this.pvpTask != null) {
         this.pvpTask.cancel();
         this.pvpTask = null;
      }
   }

   private void reloadWhitelistedCommands() {
      this.whiteListedCommands.clear();
      if (this.settings.isDisableCommandsInPvp() && !this.settings.getWhiteListedCommands().isEmpty()) {
         for (String whitelistedCommand : this.settings.getWhiteListedCommands()) {
            if (whitelistedCommand != null && !whitelistedCommand.isEmpty()) {
               String normalized = this.normalizeCommand(whitelistedCommand);
               Command command = CommandMapUtils.getCommand(normalized);
               this.whiteListedCommands.add(normalized);
               if (command != null) {
                  this.whiteListedCommands.add(command.getName().toLowerCase(Locale.ROOT));

                  for (String alias : command.getAliases()) {
                     if (alias != null && !alias.isEmpty()) {
                        this.whiteListedCommands.add(alias.toLowerCase(Locale.ROOT));
                     }
                  }
               }
            }
         }
      }
   }

   private void iterateMap(Map<UUID, PvPManager.CombatState> map, boolean bypassed, int currentTick) {
      if (!map.isEmpty()) {
         this.tickBuffer.clear();
         this.tickBuffer.addAll(map.keySet());

         for (UUID uuid : this.tickBuffer) {
            PvPManager.CombatState state = map.get(uuid);
            if (state != null) {
               Player player = state.player;
               if (player == null || !player.isOnline()) {
                  player = this.plugin.getServer().getPlayer(uuid);
               }

               if (player != null && player.isOnline()) {
                  state.player = player;
                  int currentTime = state.time;
                  int timeRemaining = currentTime - 1;
                  if (timeRemaining <= 0) {
                     if (bypassed) {
                        this.stopPvPSilent(player);
                     } else {
                        this.stopPvP(player);
                     }
                  } else {
                     state.time = timeRemaining;
                     if (!bypassed) {
                        this.bossbarManager.setBossBar(player, timeRemaining);
                        if (this.settings.isDisablePowerups() && !state.powerupsBypassChecks && state.nextPowerupCheckTick <= currentTick) {
                           this.powerUpsManager.disablePowerUpsUnchecked(player);
                           state.nextPowerupCheckTick = currentTick + 40;
                        }
                     }

                     if (state.nextUpdateEventTick <= currentTick) {
                        state.nextUpdateEventTick = currentTick + this.updateEventIntervalTicks;
                        this.updateScoreboard(player, currentTime, timeRemaining, null, null);
                     }
                  }
               } else {
                  map.remove(uuid);
                  this.bypassCache.remove(uuid);
                  this.powerUpsManager.invalidate(uuid);
                  this.bossbarManager.clearBossbar(uuid);
               }
            }
         }

         this.tickBuffer.clear();
      }
   }

   public void collectActivePvpPlayers(Set<UUID> result) {
      if (result != null) {
         if (!this.pvpMap.isEmpty()) {
            result.addAll(this.pvpMap.keySet());
         }

         if (!this.silentPvpMap.isEmpty()) {
            result.addAll(this.silentPvpMap.keySet());
         }
      }
   }

   public boolean isInPvP(Player player) {
      return player != null && this.pvpMap.containsKey(player.getUniqueId());
   }

   public boolean isInSilentPvP(Player player) {
      return player != null && this.silentPvpMap.containsKey(player.getUniqueId());
   }

   public boolean isInAnyPvP(Player player) {
      if (player == null) {
         return false;
      }

      UUID uuid = player.getUniqueId();
      return this.pvpMap.containsKey(uuid) || this.silentPvpMap.containsKey(uuid);
   }

   public int getTimeRemainingInPvP(Player player) {
      PvPManager.CombatState state = player == null ? null : this.pvpMap.get(player.getUniqueId());
      return state == null ? 0 : state.time;
   }

   public int getTimeRemainingInPvPSilent(Player player) {
      PvPManager.CombatState state = player == null ? null : this.silentPvpMap.get(player.getUniqueId());
      return state == null ? 0 : state.time;
   }

   public int getTimeRemainingInAnyPvP(Player player) {
      if (player == null) {
         return 0;
      }

      UUID uuid = player.getUniqueId();
      PvPManager.CombatState state = this.pvpMap.get(uuid);
      if (state == null) {
         state = this.silentPvpMap.get(uuid);
      }

      return state == null ? 0 : state.time;
   }

   public void playerDamagedByPlayer(Player attacker, Player defender) {
      if (attacker != null && defender != null && attacker != defender && attacker.getWorld() == defender.getWorld()) {
         if (defender.getGameMode() != GameMode.CREATIVE && !defender.isDead() && !attacker.isDead()) {
            if (!attacker.hasMetadata("NPC") && !defender.hasMetadata("NPC")) {
               UUID defenderId = defender.getUniqueId();
               int defenderTick = defender.getTicksLived();
               PvPManager.DamageStamp previousDamage = this.lastDamageByDefender.get(defenderId);
               if (previousDamage == null || previousDamage.defenderTick != defenderTick || !previousDamage.attackerId.equals(attacker.getUniqueId())) {
                  if (this.lastDamageByDefender.size() >= 2048 && !this.lastDamageByDefender.containsKey(defenderId)) {
                     this.lastDamageByDefender.clear();
                  }

                  this.lastDamageByDefender.put(defenderId, new PvPManager.DamageStamp(attacker.getUniqueId(), defenderTick));
                  this.tryStartPvP(attacker, defender);
               }
            }
         }
      }
   }

   private void tryStartPvP(Player attacker, Player defender) {
      if (!this.isInIgnoredWorld(attacker)) {
         int pvpTime = this.settings.getPvpTime();
         boolean pvpEnabled = pvpTime > 0;
         if (!pvpEnabled && this.settings.isDisablePowerups()) {
            if (!this.isHasBypassPermission(attacker)) {
               this.powerUpsManager.disablePowerUpsWithRunCommands(attacker);
            }

            if (!this.isHasBypassPermission(defender)) {
               this.powerUpsManager.disablePowerUps(defender);
            }
         } else if (pvpEnabled) {
            boolean attackerBypassed = this.isHasBypassPermission(attacker);
            boolean defenderBypassed = this.isHasBypassPermission(defender);
            boolean attackerInPvp = this.isInAnyPvP(attacker);
            boolean defenderInPvp = this.isInAnyPvP(defender);
            PvpPreStartEvent.PvPStatus pvpStatus = PvpPreStartEvent.PvPStatus.ALL_NOT_IN_PVP;
            if (attackerInPvp && defenderInPvp) {
               this.updateAttackerAndCallEvent(attacker, defender, attackerBypassed);
               this.updateDefenderAndCallEvent(defender, attacker, defenderBypassed);
            } else {
               if (attackerInPvp) {
                  pvpStatus = PvpPreStartEvent.PvPStatus.ATTACKER_IN_PVP;
               } else if (defenderInPvp) {
                  pvpStatus = PvpPreStartEvent.PvPStatus.DEFENDER_IN_PVP;
               }

               if (pvpStatus != PvpPreStartEvent.PvPStatus.ALL_NOT_IN_PVP) {
                  if (this.callPvpPreStartEvent(defender, attacker, pvpStatus, pvpTime)) {
                     if (attackerInPvp) {
                        this.updateAttackerAndCallEvent(attacker, defender, attackerBypassed);
                        this.startPvp(defender, defenderBypassed, false, pvpTime);
                     } else {
                        this.updateDefenderAndCallEvent(defender, attacker, defenderBypassed);
                        this.startPvp(attacker, attackerBypassed, true, pvpTime);
                     }

                     this.pluginManager.callEvent(new PvpStartedEvent(defender, attacker, pvpTime, pvpStatus));
                  }
               } else {
                  if (this.callPvpPreStartEvent(defender, attacker, pvpStatus, pvpTime)) {
                     this.startPvp(attacker, attackerBypassed, true, pvpTime);
                     this.startPvp(defender, defenderBypassed, false, pvpTime);
                     this.pluginManager.callEvent(new PvpStartedEvent(defender, attacker, pvpTime, pvpStatus));
                  }
               }
            }
         }
      }
   }

   private void startPvp(Player player, boolean bypassed, boolean attacker, int pvpTime) {
      if (!bypassed) {
         String message = Utils.color(this.settings.getMessages().getPvpStarted());
         if (message != null && !message.isEmpty()) {
            player.sendMessage(message);
         }

         if (attacker && this.settings.isDisablePowerups()) {
            this.powerUpsManager.disablePowerUpsWithRunCommands(player);
         }
      }

      this.updatePvpMode(player, bypassed, pvpTime);
      player.setNoDamageTicks(0);
   }

   private void updatePvpMode(Player player, boolean bypassed, int newTime) {
      int currentTick = this.currentTick;
      UUID uuid = player.getUniqueId();
      Map<UUID, PvPManager.CombatState> target = bypassed ? this.silentPvpMap : this.pvpMap;
      Map<UUID, PvPManager.CombatState> opposite = bypassed ? this.pvpMap : this.silentPvpMap;
      PvPManager.CombatState movedState = opposite.remove(uuid);
      PvPManager.CombatState state = target.get(uuid);
      if (state == null) {
         state = movedState == null ? new PvPManager.CombatState() : movedState;
         state.powerupsBypassChecks = this.settings.isDisablePowerups() && this.powerUpsManager.hasBypassChecks(player);
         target.put(uuid, state);
      }

      state.player = player;
      state.time = newTime;
      state.nextUpdateEventTick = currentTick + this.updateEventIntervalTicks;
      this.ensurePvpTask();
      if (!bypassed) {
         this.bossbarManager.setBossBar(player, newTime, true);
         if (this.settings.isDisablePowerups() && !state.powerupsBypassChecks) {
            this.powerUpsManager.disablePowerUpsUnchecked(player);
            state.nextPowerupCheckTick = currentTick + 40;
         }
      }
   }

   private boolean callPvpPreStartEvent(Player defender, Player attacker, PvpPreStartEvent.PvPStatus pvpStatus, int pvpTime) {
      PvpPreStartEvent pvpPreStartEvent = new PvpPreStartEvent(defender, attacker, pvpTime, pvpStatus);
      this.pluginManager.callEvent(pvpPreStartEvent);
      return !pvpPreStartEvent.isCancelled();
   }

   private void updateAttackerAndCallEvent(Player attacker, Player defender, boolean bypassed) {
      int oldTime = bypassed ? this.getTimeRemainingInPvPSilent(attacker) : this.getTimeRemainingInPvP(attacker);
      int newTime = this.settings.getPvpTime();
      this.updatePvpMode(attacker, bypassed, newTime);
      PvpTimeUpdateEvent event = new PvpTimeUpdateEvent(attacker, oldTime, newTime);
      event.setDamagedPlayer(defender);
      this.pluginManager.callEvent(event);
   }

   private void updateDefenderAndCallEvent(Player defender, Player attackedBy, boolean bypassed) {
      int oldTime = bypassed ? this.getTimeRemainingInPvPSilent(defender) : this.getTimeRemainingInPvP(defender);
      int newTime = this.settings.getPvpTime();
      this.updatePvpMode(defender, bypassed, newTime);
      PvpTimeUpdateEvent event = new PvpTimeUpdateEvent(defender, oldTime, newTime);
      event.setDamagedBy(attackedBy);
      this.pluginManager.callEvent(event);
   }

   private void updateScoreboard(Player player, int oldTime, int newTime, Player damagedBy, Player damagedPlayer) {
      if (this.scoreboardManager != null) {
         this.scoreboardManager.handlePvpTimeUpdate(player, oldTime, newTime, damagedBy, damagedPlayer);
      }
   }

   public void setScoreboardManager(ScoreboardManager scoreboardManager) {
      this.scoreboardManager = scoreboardManager;
   }

   public void stopPvP(Player player) {
      if (this.clearPvPState(player)) {
         String message = Utils.color(this.settings.getMessages().getPvpStopped());
         if (message != null && !message.isEmpty() && player.isOnline()) {
            player.sendMessage(message);
         }
      }
   }

   public void stopPvPSilent(Player player) {
      this.clearPvPState(player);
   }

   public boolean stopPvPExternal(Player player) {
      return this.clearPvPState(player);
   }

   private boolean clearPvPState(Player player) {
      if (player == null) {
         return false;
      }

      UUID uuid = player.getUniqueId();
      boolean removed = this.pvpMap.remove(uuid) != null;
      boolean removedSilent = this.silentPvpMap.remove(uuid) != null;
      if (!removed && !removedSilent) {
         return false;
      }

      this.bossbarManager.clearBossbar(player);
      this.bypassCache.remove(uuid);
      this.lastDamageByDefender.remove(uuid);
      this.powerUpsManager.invalidate(player);
      this.pluginManager.callEvent(new PvpStoppedEvent(player));
      this.stopPvpTaskIfIdle();
      return true;
   }

   public boolean isCommandWhiteListed(String command) {
      if (this.whiteListedCommands.isEmpty()) {
         return false;
      }

      String normalized = this.normalizeCommand(command);
      if (normalized.isEmpty()) {
         return false;
      }

      if (this.whiteListedCommands.contains(normalized)) {
         return true;
      }

      int namespace = normalized.indexOf(58);
      return namespace != -1 && this.whiteListedCommands.contains(normalized.substring(namespace + 1));
   }

   public void clearTransientData(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         this.bypassCache.remove(uuid);
         this.lastDamageByDefender.remove(uuid);
         this.powerUpsManager.invalidate(uuid);
      }
   }

   public PowerUpsManager getPowerUpsManager() {
      return this.powerUpsManager;
   }

   public BossbarManager getBossbarManager() {
      return this.bossbarManager;
   }

   public int getCurrentTick() {
      return this.currentTick;
   }

   public boolean isPvPModeEnabled() {
      return this.settings.getPvpTime() > 0;
   }

   public boolean isBypassed(Player player) {
      return this.isInIgnoredWorld(player) || this.isHasBypassPermission(player);
   }

   public boolean isHasBypassPermission(Player player) {
      if (player == null) {
         return false;
      }

      UUID uuid = player.getUniqueId();
      long now = System.currentTimeMillis();
      PvPManager.BypassCacheEntry cached = this.bypassCache.get(uuid);
      if (cached != null && cached.expiresAtMillis >= now) {
         return cached.allowed;
      }

      boolean allowed = player.hasPermission("cloudrelog.bypass");
      if (this.bypassCache.size() >= 2048) {
         this.bypassCache.clear();
      }

      this.bypassCache.put(uuid, new PvPManager.BypassCacheEntry(allowed, now + 2000L));
      return allowed;
   }

   public boolean isInIgnoredWorld(Player player) {
      Set<String> disabledWorlds = this.settings.getDisabledWorlds();
      return player != null && !disabledWorlds.isEmpty() && disabledWorlds.contains(player.getWorld().getName().toLowerCase(Locale.ROOT));
   }

   private String normalizeCommand(String command) {
      String normalized = command == null ? "" : command;
      if (!normalized.isEmpty() && normalized.charAt(0) == '/') {
         normalized = normalized.substring(1);
      }

      int space = normalized.indexOf(32);
      if (space != -1) {
         normalized = normalized.substring(0, space);
      }

      return normalized.toLowerCase(Locale.ROOT);
   }

   private static final class BypassCacheEntry {
      private final boolean allowed;
      private final long expiresAtMillis;

      private BypassCacheEntry(boolean allowed, long expiresAtMillis) {
         this.allowed = allowed;
         this.expiresAtMillis = expiresAtMillis;
      }
   }

   private static final class CombatState {
      private Player player;
      private int time;
      private int nextPowerupCheckTick;
      private int nextUpdateEventTick;
      private boolean powerupsBypassChecks;
   }

   private static final class DamageStamp {
      private final UUID attackerId;
      private final int defenderTick;

      private DamageStamp(UUID attackerId, int defenderTick) {
         this.attackerId = attackerId;
         this.defenderTick = defenderTick;
      }
   }
}
