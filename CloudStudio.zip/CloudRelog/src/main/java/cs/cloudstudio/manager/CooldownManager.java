package cs.cloudstudio.manager;

import cs.cloudstudio.config.Settings;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.bukkit.Material;
import org.bukkit.entity.Player;

public class CooldownManager {
   private static final int COOLDOWN_TYPES = CooldownManager.CooldownType.VALUES.length;
   private static final long[] EMPTY_COOLDOWNS = new long[COOLDOWN_TYPES];
   private final Settings settings;
   private final Map<UUID, long[]> cooldowns = new HashMap<>();

   public CooldownManager(Settings settings) {
      this.settings = settings;
   }

   public void addCooldown(Player player, CooldownManager.CooldownType type) {
      if (player != null && type != null) {
         UUID uuid = player.getUniqueId();
         long[] row = this.cooldowns.get(uuid);
         if (row == null) {
            row = new long[COOLDOWN_TYPES];
            this.cooldowns.put(uuid, row);
         }

         row[type.ordinal()] = System.nanoTime();
      }
   }

   public void addItemCooldown(Player player, CooldownManager.CooldownType type, long duration) {
      if (duration > 0L) {
         long ticks = (duration + 49L) / 50L;
         this.sendItemCooldown(player, type, ticks > 2147483647L ? Integer.MAX_VALUE : (int)ticks);
      }
   }

   public void removeItemCooldown(Player player, CooldownManager.CooldownType type) {
      this.sendItemCooldown(player, type, 0);
   }

   public void enteredToPvp(Player player) {
      if (player != null) {
         long now = System.nanoTime();

         for (CooldownManager.CooldownType cooldownType : CooldownManager.CooldownType.VALUES) {
            int cooldown = cooldownType.getCooldown(this.settings);
            if (cooldown != 0) {
               if (cooldown > 0) {
                  long remaining = this.getRemaining(player, cooldownType, cooldown * 1000L, now);
                  if (remaining > 0L) {
                     this.addItemCooldown(player, cooldownType, remaining);
                  }
               } else {
                  this.addItemCooldown(player, cooldownType, Math.max(1L, this.settings.getPvpTime()) * 1000L);
               }
            }
         }
      }
   }

   public void removedFromPvp(Player player) {
      if (player != null) {
         for (CooldownManager.CooldownType cooldownType : CooldownManager.CooldownType.VALUES) {
            if (cooldownType.getCooldown(this.settings) != 0) {
               this.removeItemCooldown(player, cooldownType);
            }
         }
      }
   }

   public boolean hasCooldown(Player player, CooldownManager.CooldownType type, long duration) {
      return this.getRemainingCooldown(player, type, duration) > 0L;
   }

   public long getRemainingCooldown(Player player, CooldownManager.CooldownType type, long duration) {
      return player != null && type != null && duration > 0L ? this.getRemaining(player, type, duration, System.nanoTime()) : 0L;
   }

   public long getRemaining(Player player, CooldownManager.CooldownType type, long duration) {
      return this.getRemainingCooldown(player, type, duration);
   }

   public void remove(Player player) {
      if (player != null) {
         this.cooldowns.remove(player.getUniqueId());
      }
   }

   public void clearAll() {
      this.cooldowns.clear();
   }

   public Settings getSettings() {
      return this.settings;
   }

   private long getRemaining(Player player, CooldownManager.CooldownType type, long duration, long now) {
      long added = this.getCooldownRow(player)[type.ordinal()];
      if (added == 0L) {
         return 0L;
      }

      long durationNanos = TimeUnit.MILLISECONDS.toNanos(duration);
      long remainingNanos = durationNanos - (now - added);
      return remainingNanos <= 0L ? 0L : (remainingNanos + 999999L) / 1000000L;
   }

   private long[] getCooldownRow(Player player) {
      long[] row = this.cooldowns.get(player.getUniqueId());
      return row == null ? EMPTY_COOLDOWNS : row;
   }

   private void sendItemCooldown(Player player, CooldownManager.CooldownType type, int ticks) {
      if (player != null && type != null && player.isOnline()) {
         player.setCooldown(type.getMaterial(), Math.max(0, ticks));
      }
   }

   public enum CooldownType {
      GOLDEN_APPLE(Material.GOLDEN_APPLE) {
         @Override
         public int getCooldown(Settings settings) {
            return settings.getGoldenAppleCooldown();
         }
      },
      ENC_GOLDEN_APPLE(Material.ENCHANTED_GOLDEN_APPLE) {
         @Override
         public int getCooldown(Settings settings) {
            return settings.getEnchantedGoldenAppleCooldown();
         }
      },
      ENDER_PEARL(Material.ENDER_PEARL) {
         @Override
         public int getCooldown(Settings settings) {
            return settings.getEnderPearlCooldown();
         }
      },
      CHORUS(Material.CHORUS_FRUIT) {
         @Override
         public int getCooldown(Settings settings) {
            return settings.getChorusCooldown();
         }
      },
      TOTEM(Material.TOTEM_OF_UNDYING) {
         @Override
         public int getCooldown(Settings settings) {
            return settings.getTotemCooldown();
         }
      },
      FIREWORK(Material.FIREWORK_ROCKET) {
         @Override
         public int getCooldown(Settings settings) {
            return settings.getFireworkCooldown();
         }
      },
      TRIDENT(Material.TRIDENT) {
         @Override
         public int getCooldown(Settings settings) {
            return settings.getTridentCooldown();
         }
      },
      TRIDENT_RIPTIDE(Material.TRIDENT) {
         @Override
         public int getCooldown(Settings settings) {
            return settings.getRiptideCooldown();
         }
      },
      MACE_WIND_BURST(Material.MACE) {
         @Override
         public int getCooldown(Settings settings) {
            return settings.getMaceWindBurstCooldown();
         }
      };

      public static final CooldownManager.CooldownType[] VALUES = values();
      private final Material material;

      CooldownType(Material material) {
         this.material = material;
      }

      public abstract int getCooldown(Settings var1);

      public Material getMaterial() {
         return this.material;
      }
   }
}
