package cs.cloudstudio.manager;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import cs.cloudstudio.config.Settings;
import cs.cloudstudio.util.Utils;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

public class PowerUpsManager {
   private final Settings settings;
   private final Cache<UUID, Boolean> bypassChecksCache = CacheBuilder.newBuilder().maximumSize(2048L).expireAfterWrite(2L, TimeUnit.SECONDS).build();

   public PowerUpsManager(Settings settings) {
      this.settings = settings;
   }

   public boolean disablePowerUps(Player player) {
      return !this.hasBypassChecks(player) && this.disablePowerUpsUnchecked(player);
   }

   public boolean disablePowerUpsUnchecked(Player player) {
      if (player == null) {
         return false;
      }

      boolean disabled = false;
      if (player.getGameMode() == GameMode.CREATIVE) {
         GameMode fallback = Bukkit.getDefaultGameMode() == GameMode.ADVENTURE ? GameMode.ADVENTURE : GameMode.SURVIVAL;
         player.setGameMode(fallback);
         disabled = true;
      }

      if (player.isFlying()) {
         player.setFlying(false);
         disabled = true;
      }

      if (player.getAllowFlight()) {
         player.setAllowFlight(false);
         disabled = true;
      }

      if (player.isInvulnerable()) {
         player.setInvulnerable(false);
         disabled = true;
      }

      return disabled;
   }

   public void disablePowerUpsWithRunCommands(Player player) {
      List<String> commands = this.settings.getCommandsOnPowerupsDisable();
      if (this.disablePowerUps(player) && !commands.isEmpty()) {
         String playerName = player.getName();

         for (String command : commands) {
            if (command != null && !command.isEmpty()) {
               Bukkit.dispatchCommand(Bukkit.getConsoleSender(), Utils.color(command.replace("%player%", playerName)));
            }
         }
      }
   }

   public void invalidate(Player player) {
      if (player != null) {
         this.bypassChecksCache.invalidate(player.getUniqueId());
      }
   }

   public void invalidate(UUID uuid) {
      if (uuid != null) {
         this.bypassChecksCache.invalidate(uuid);
      }
   }

   public void clearCache() {
      this.bypassChecksCache.invalidateAll();
   }

   public boolean hasBypassChecks(Player player) {
      if (player == null) {
         return false;
      }

      UUID uuid = player.getUniqueId();
      Boolean cached = (Boolean)this.bypassChecksCache.getIfPresent(uuid);
      if (cached != null) {
         return cached;
      }

      boolean allowed = player.hasPermission("cloudrelog.bypass.checks");
      this.bypassChecksCache.put(uuid, allowed);
      return allowed;
   }
}
