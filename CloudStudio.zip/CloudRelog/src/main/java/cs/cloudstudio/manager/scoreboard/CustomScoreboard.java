package cs.cloudstudio.manager.scoreboard;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import cs.cloudstudio.util.ColorUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public final class CustomScoreboard {
   private static final int MAX_LINES = 15;
   private static final int TITLE_LIMIT = 128;
   private static final int TEAM_PART_LIMIT = 64;
   private static final int ENTRY_LIMIT = 40;
   private static final int UNIQUE_TOKEN_LENGTH = 2;
   private static final int MAX_UNIQUE_LINE_LENGTH = 168;
   private static final int MAX_DUPLICATE_LINE_LENGTH = 166;
   private static final int PACKET_LINE_LIMIT = 512;
   private static final int NO_SCORE = Integer.MIN_VALUE;
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();
   private static final NmsLongScoreboardBridge LONG_LINE_BRIDGE = new NmsLongScoreboardBridge();
   private static final String[] TEAM_NAMES = new String[15];
   private static final String[] UNIQUE_TOKENS = new String[15];
   private final UUID playerId;
   private final Scoreboard scoreboard;
   private final Objective objective;
   private final Team[] teams = new Team[15];
   private final String[] entries = new String[15];
   private final String[] cachedLines = new String[15];
   private final String[] cachedPrefixes = new String[15];
   private final String[] cachedSuffixes = new String[15];
   private final int[] cachedScores = new int[15];
   private final String[] sentPacketLines = new String[15];
   private String cachedTitle;
   private int lineCount;

   public CustomScoreboard(Player player) {
      this.playerId = player.getUniqueId();
      this.scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
      this.objective = this.scoreboard.registerNewObjective("cloudrelog", Criteria.DUMMY, Component.empty());
      this.objective.setDisplaySlot(DisplaySlot.SIDEBAR);
      Arrays.fill(this.cachedScores, Integer.MIN_VALUE);
      player.setScoreboard(this.scoreboard);
   }

   public void setTitle(String title) {
      String displayName = this.cut(title == null ? "" : title, 128);
      if (!displayName.equals(this.cachedTitle)) {
         this.objective.displayName(LEGACY.deserialize(displayName));
         this.cachedTitle = displayName;
      }
   }

   public void setLines(List<String> lines) {
      if (lines != null && !lines.isEmpty()) {
         int size = Math.min(lines.size(), 15);
         int cacheLimit = LONG_LINE_BRIDGE.isAvailable() ? 512 : 168;

         for (int index = 0; index < size; index++) {
            String line = lines.get(index);
            if (line == null) {
               line = "";
            }

            int score = size - index;
            String cached = line.length() > cacheLimit ? this.cut(line, cacheLimit) : line;
            if (index >= this.lineCount || score != this.cachedScores[index] || !cached.equals(this.cachedLines[index])) {
               this.setLine(index, line, score);
               this.cachedLines[index] = cached;
            }
         }

         for (int index = size; index < this.lineCount; index++) {
            this.clearLine(index);
         }

         this.lineCount = size;
      } else {
         this.clearLines();
         this.clearCache();
         this.lineCount = 0;
      }
   }

   private void setLine(int index, String text, int score) {
      Team team = this.teams[index];
      if (team == null) {
         team = this.scoreboard.registerNewTeam(TEAM_NAMES[index]);
         this.teams[index] = team;
      }

      this.setTeamText(index, team, text, score);
   }

   private void setTeamText(int index, Team team, String text, int score) {
      if (LONG_LINE_BRIDGE.isAvailable()) {
         this.setLongPacketTeamText(index, team, text, score);
      } else {
         this.setBukkitTeamText(index, team, text, score);
      }
   }

   private void setBukkitTeamText(int index, Team team, String text, int score) {
      String safe = text == null ? "" : this.cut(text, 168);
      int prefixEnd = this.safeSplit(safe, 64);
      String prefix = safe.substring(0, prefixEnd);
      int entryStart = prefixEnd;
      int entryEnd = this.safeSplit(safe, entryStart, 40);
      String visibleEntry = safe.substring(entryStart, entryEnd);
      String entry = visibleEntry;
      if (entry.isEmpty() || isEntryUsed(this.entries, index, entry)) {
         safe = this.cut(safe, 166);
         prefixEnd = this.safeSplit(safe, 64);
         prefix = safe.substring(0, prefixEnd);
         entryStart = prefixEnd;
         entryEnd = this.safeSplit(safe, entryStart, 38);
         visibleEntry = safe.substring(entryStart, entryEnd);
         entry = visibleEntry + UNIQUE_TOKENS[index];
      }

      String suffixText = safe.substring(entryEnd);
      String colorBeforeSuffix = ColorUtils.getLastColors(prefix + visibleEntry);
      String suffix = this.needsColorCarry(suffixText) ? colorBeforeSuffix + suffixText : suffixText;
      if (suffix.length() > 64) {
         suffix = this.cut(suffix, 64);
      }

      String previousEntry = this.entries[index];
      boolean entryChanged = previousEntry == null || !previousEntry.equals(entry);
      if (entryChanged) {
         if (previousEntry != null) {
            team.removeEntry(previousEntry);
            this.scoreboard.resetScores(previousEntry);
         }

         team.addEntry(entry);
         this.entries[index] = entry;
         this.sentPacketLines[index] = null;
      }

      if (entryChanged || this.cachedScores[index] != score) {
         this.objective.getScore(entry).setScore(score);
         this.cachedScores[index] = score;
      }

      if (!prefix.equals(this.cachedPrefixes[index])) {
         team.prefix(LEGACY.deserialize(prefix));
         this.cachedPrefixes[index] = prefix;
      }

      if (!suffix.equals(this.cachedSuffixes[index])) {
         team.suffix(LEGACY.deserialize(suffix));
         this.cachedSuffixes[index] = suffix;
      }
   }

   private void setLongPacketTeamText(int index, Team team, String text, int score) {
      String line = text == null ? "" : this.cut(text, 512);
      String entry = UNIQUE_TOKENS[index];
      String previousEntry = this.entries[index];
      boolean entryChanged = previousEntry == null || !previousEntry.equals(entry);
      if (entryChanged) {
         if (previousEntry != null) {
            team.removeEntry(previousEntry);
            this.scoreboard.resetScores(previousEntry);
         }

         team.addEntry(entry);
         this.entries[index] = entry;
      }

      if (entryChanged || this.cachedScores[index] != score) {
         this.objective.getScore(entry).setScore(score);
         this.cachedScores[index] = score;
      }

      boolean prefixManaged = this.cachedPrefixes[index] != null && this.cachedPrefixes[index].isEmpty();
      if (!prefixManaged) {
         this.cachedPrefixes[index] = "";
         this.sentPacketLines[index] = null;
      }

      if (this.cachedSuffixes[index] == null || !this.cachedSuffixes[index].isEmpty()) {
         team.suffix(Component.empty());
         this.cachedSuffixes[index] = "";
      }

      if (entryChanged || !line.equals(this.sentPacketLines[index])) {
         Player player = Bukkit.getPlayer(this.playerId);
         if (player == null || !player.isOnline()) {
            if (!prefixManaged) {
               team.prefix(Component.empty());
            }

            this.sentPacketLines[index] = null;
         } else if (!LONG_LINE_BRIDGE.updatePrefix(player, team, line)) {
            this.sentPacketLines[index] = null;
            this.setBukkitFallbackAfterPacketFailure(index, team, line, score);
         } else {
            this.sentPacketLines[index] = line;
         }
      }
   }

   private void setBukkitFallbackAfterPacketFailure(int index, Team team, String text, int score) {
      String previousEntry = this.entries[index];
      if (previousEntry != null) {
         team.removeEntry(previousEntry);
         this.scoreboard.resetScores(previousEntry);
         this.entries[index] = null;
      }

      this.cachedScores[index] = Integer.MIN_VALUE;
      this.cachedPrefixes[index] = null;
      this.cachedSuffixes[index] = null;
      this.setBukkitTeamText(index, team, text, score);
   }

   private static boolean isEntryUsed(String[] entries, int index, String entry) {
      for (int i = 0; i < entries.length; i++) {
         if (i != index) {
            String used = entries[i];
            if (entry.equals(used)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean needsColorCarry(String suffixText) {
      if (suffixText != null && !suffixText.isEmpty()) {
         if (suffixText.length() >= 2 && suffixText.charAt(0) == 167) {
            char code = Character.toLowerCase(suffixText.charAt(1));
            return code == 'x' ? !this.isFullHexColor(suffixText, 0) : !this.isColorOrReset(code);
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean isColorOrReset(char code) {
      return code == 'r' || code >= '0' && code <= '9' || code >= 'a' && code <= 'f';
   }

   public void clear() {
      this.clearLines();
      this.clearCache();
      this.cachedTitle = null;
      this.lineCount = 0;
   }

   public void remove() {
      this.clear();

      try {
         this.objective.unregister();
      } catch (IllegalStateException var2) {
      }
   }

   private void clearLine(int index) {
      Team team = this.teams[index];
      String entry = this.entries[index];
      if (team != null) {
         if (entry != null) {
            team.removeEntry(entry);
         }

         team.unregister();
         this.teams[index] = null;
      }

      if (entry != null) {
         this.scoreboard.resetScores(entry);
         this.entries[index] = null;
      }

      this.cachedLines[index] = null;
      this.cachedPrefixes[index] = null;
      this.cachedSuffixes[index] = null;
      this.cachedScores[index] = Integer.MIN_VALUE;
      this.sentPacketLines[index] = null;
   }

   private void clearLines() {
      for (int i = 0; i < this.teams.length; i++) {
         this.clearLine(i);
      }
   }

   private void clearCache() {
      Arrays.fill(this.cachedLines, null);
      Arrays.fill(this.cachedPrefixes, null);
      Arrays.fill(this.cachedSuffixes, null);
      Arrays.fill(this.cachedScores, Integer.MIN_VALUE);
      Arrays.fill(this.sentPacketLines, null);
   }

   private int safeSplit(String text, int limit) {
      return this.safeSplit(text, 0, limit);
   }

   private int safeSplit(String text, int start, int limit) {
      if (text != null && !text.isEmpty()) {
         int max = Math.min(text.length(), start + limit);
         if (max <= start) {
            return start;
         }

         if (max >= text.length()) {
            return text.length();
         }

         int split = max;
         if (text.charAt(split - 1) == 167) {
            split--;
         } else if (split - 2 >= start && text.charAt(split - 2) == 167) {
            split -= 2;
         } else if (this.isInsideHexColor(text, start, split)) {
            split = this.hexColorStart(text, start, split);
         }

         return Math.max(start, split);
      } else {
         return start;
      }
   }

   private boolean isInsideHexColor(String text, int start, int split) {
      return this.hexColorStart(text, start, split) != split;
   }

   private int hexColorStart(String text, int start, int split) {
      int from = Math.max(start, split - 13);

      for (int i = from; i < split; i++) {
         if (this.isFullHexColor(text, i) && split > i && split < i + 14) {
            return i;
         }
      }

      return split;
   }

   private boolean isFullHexColor(String text, int offset) {
      if (offset >= 0 && offset + 13 < text.length()) {
         if (text.charAt(offset) == 167 && Character.toLowerCase(text.charAt(offset + 1)) == 'x') {
            for (int j = offset + 2; j <= offset + 12; j += 2) {
               if (text.charAt(j) != 167) {
                  return false;
               }
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private String cut(String text, int limit) {
      return text.length() <= limit ? text : text.substring(0, this.safeSplit(text, limit));
   }

   public UUID getPlayerId() {
      return this.playerId;
   }

   public Scoreboard getScoreboard() {
      return this.scoreboard;
   }

   static {
      String codes = "0123456789abcdefklmnor";

      for (int i = 0; i < 15; i++) {
         TEAM_NAMES[i] = "cr_line_" + i;
         UNIQUE_TOKENS[i] = new String(new char[]{167, codes.charAt(i)});
      }
   }
}
