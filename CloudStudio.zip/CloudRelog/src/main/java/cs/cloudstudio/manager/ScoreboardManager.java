package cs.cloudstudio.manager;

import cs.cloudstudio.CloudRelog;
import cs.cloudstudio.config.ScoreboardSettings;
import cs.cloudstudio.config.Settings;
import cs.cloudstudio.event.PvpStartedEvent;
import cs.cloudstudio.event.PvpStoppedEvent;
import cs.cloudstudio.event.PvpTimeUpdateEvent;
import cs.cloudstudio.manager.scoreboard.CustomScoreboard;
import cs.cloudstudio.util.ColorUtils;
import cs.cloudstudio.util.PlaceholderUtils;
import cs.cloudstudio.util.TabScoreboardBridge;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;

public class ScoreboardManager implements Listener {
   private static final int MAX_SCOREBOARD_LINES = 15;
   private static final int REASSERT_RUNS = 3;
   private static final int REASSERT_PERIOD_TICKS = 2;
   private static final long RECONCILE_PERIOD_TICKS = 5L;
   private static final long EVENTS_SCOREBOARD_HANDSHAKE_DELAY_TICKS = 5L;
   private static final int MAX_SCOREBOARD_UPDATES_PER_TICK = 8;
   private static final int MIN_QUEUED_RENDER_GAP_TICKS = 4;
   private final Settings settings;
   private final PvPManager pvpManager;
   private final CloudRelog plugin;
   private final Map<UUID, CustomScoreboard> scoreboards = new HashMap<>();
   private final Set<UUID> tabScoreboards = new HashSet<>();
   private final TabScoreboardBridge tabBridge = new TabScoreboardBridge("cloudrelog");
   private final ScoreboardManager.EventsScoreboardBridge eventsBridge = new ScoreboardManager.EventsScoreboardBridge();
   private final Map<UUID, Scoreboard> previousScoreboards = new HashMap<>();
   private final Map<UUID, Set<UUID>> opponents = new HashMap<>();
   private final Map<UUID, Integer> lastUpdateTicks = new HashMap<>();
   private final Map<UUID, Integer> lastRenderServerTicks = new HashMap<>();
   private Plugin jobsPlugin;
   private Method jobsPriorityMethod;
   private final Map<UUID, BukkitTask> reassertTasks = new HashMap<>();
   private final Map<UUID, BukkitTask> delayedShowTasks = new HashMap<>();
   private final Set<UUID> waitingEventsClear = new HashSet<>();
   private final ArrayDeque<UUID> scoreboardUpdateQueue = new ArrayDeque<>();
   private final Set<UUID> queuedScoreboardUpdates = new HashSet<>();
   private final Map<UUID, Boolean> pendingScoreboardForces = new HashMap<>();
   private BukkitTask scoreboardUpdateTask;
   private BukkitTask reconcileTask;
   private final List<Player> opponentBuffer = new ArrayList<>(8);
   private final List<String> lineBuffer = new ArrayList<>(15);
   private final Set<UUID> reconcileBuffer = new LinkedHashSet<>();
   private String gradientStart;
   private String gradientEnd;
   private int gradientSize;
   private String[] gradientCache;

   public ScoreboardManager(Settings settings, PvPManager pvpManager, CloudRelog plugin) {
      this.settings = settings;
      this.pvpManager = pvpManager;
      this.plugin = plugin;
   }

   public void reload() {
      this.shutdown(false);
      this.stopReconcileTask();
      PlaceholderUtils.reset();
      this.gradientCache = null;
   }

   public void showScoreboard(Player player) {
      this.requestScoreboard(player, true);
   }

   public boolean isScoreboardShown(Player player) {
      if (player != null && player.isOnline()) {
         UUID uuid = player.getUniqueId();
         if (this.tabScoreboards.contains(uuid) && this.pvpManager.isInAnyPvP(player) && this.tabBridge.isOwned(uuid)) {
            return true;
         }

         CustomScoreboard scoreboard = this.scoreboards.get(uuid);
         return scoreboard != null && player.getScoreboard() == scoreboard.getScoreboard();
      } else {
         return false;
      }
   }

   public void onEventsScoreboardHidden(Player player) {
      if (player != null && this.plugin != null && player.isOnline()) {
         UUID uuid = player.getUniqueId();
         this.cancelDelayedShow(uuid);
         this.waitingEventsClear.remove(uuid);
         if (this.pvpManager.isInAnyPvP(player)) {
            this.showScoreboard(player, this.scoreboards.get(uuid), true, false);
         }
      }
   }

   private void queueScoreboardUpdate(Player player, boolean force) {
      if (player != null && player.isOnline()) {
         UUID uuid = player.getUniqueId();
         if (!this.pvpManager.isInAnyPvP(player)) {
            this.removeScoreboard(player);
         } else {
            Boolean oldForce = this.pendingScoreboardForces.get(uuid);
            this.pendingScoreboardForces.put(uuid, force || Boolean.TRUE.equals(oldForce));
            if (this.queuedScoreboardUpdates.add(uuid)) {
               this.scoreboardUpdateQueue.addLast(uuid);
            }

            this.startScoreboardUpdateTask();
         }
      }
   }

   private void startScoreboardUpdateTask() {
      if (this.scoreboardUpdateTask == null || this.scoreboardUpdateTask.isCancelled()) {
         this.scoreboardUpdateTask = Bukkit.getScheduler().runTaskTimer(this.plugin, new Runnable() {
            @Override
            public void run() {
               ScoreboardManager.this.flushScoreboardUpdates();
            }
         }, 1L, 1L);
      }
   }

   private void flushScoreboardUpdates() {
      int processed = 0;
      int serverTick = Bukkit.getCurrentTick();
      int budget = this.scoreboardUpdateQueue.size();

      while (processed < 8 && budget-- > 0 && !this.scoreboardUpdateQueue.isEmpty()) {
         UUID uuid = this.scoreboardUpdateQueue.pollFirst();
         Integer lastRender = this.lastRenderServerTicks.get(uuid);
         if (lastRender != null && serverTick - lastRender < MIN_QUEUED_RENDER_GAP_TICKS && this.pendingScoreboardForces.containsKey(uuid)) {
            this.scoreboardUpdateQueue.addLast(uuid);
            continue;
         }

         this.queuedScoreboardUpdates.remove(uuid);
         Boolean force = this.pendingScoreboardForces.remove(uuid);
         if (force != null) {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null || !player.isOnline()) {
               this.cleanupOffline(uuid);
            } else if (this.pvpManager.isInAnyPvP(player)) {
               this.requestScoreboard(player, force);
            } else {
               this.removeScoreboard(player);
            }

            processed++;
         }
      }

      this.stopScoreboardUpdateTaskIfIdle();
   }

   private void discardPendingScoreboardUpdate(UUID uuid) {
      if (uuid != null) {
         this.pendingScoreboardForces.remove(uuid);
         if (this.queuedScoreboardUpdates.remove(uuid)) {
            this.scoreboardUpdateQueue.remove(uuid);
         }

         this.stopScoreboardUpdateTaskIfIdle();
      }
   }

   private void stopScoreboardUpdateTaskIfIdle() {
      if (this.scoreboardUpdateQueue.isEmpty()) {
         if (this.scoreboardUpdateTask != null) {
            this.scoreboardUpdateTask.cancel();
            this.scoreboardUpdateTask = null;
         }
      }
   }

   private void stopScoreboardUpdateTask() {
      if (this.scoreboardUpdateTask != null) {
         this.scoreboardUpdateTask.cancel();
         this.scoreboardUpdateTask = null;
      }

      this.scoreboardUpdateQueue.clear();
      this.queuedScoreboardUpdates.clear();
      this.pendingScoreboardForces.clear();
   }

   private void requestScoreboard(Player player, boolean force) {
      if (player != null && player.isOnline()) {
         UUID uuid = player.getUniqueId();
         if (!this.pvpManager.isInAnyPvP(player)) {
            this.removeScoreboard(player);
         } else {
            this.cancelDelayedShow(uuid);
            this.waitingEventsClear.remove(uuid);
            boolean alreadyManaged = this.tabScoreboards.contains(uuid) || this.scoreboards.containsKey(uuid) || this.tabBridge.isOwned(uuid);
            if (!alreadyManaged) {
               this.notifyEventsScoreboardLocked(player);
            }

            this.showScoreboard(player, this.scoreboards.get(uuid), force, false);
         }
      }
   }

   private void scheduleDelayedShow(final UUID uuid) {
      if (uuid != null && this.plugin != null) {
         this.cancelDelayedShow(uuid);
         this.startReconcileTaskIfNeeded();
         BukkitTask task = Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
            @Override
            public void run() {
               ScoreboardManager.this.delayedShowTasks.remove(uuid);
               Player player = Bukkit.getPlayer(uuid);
               if (player == null || !player.isOnline()) {
                  ScoreboardManager.this.waitingEventsClear.remove(uuid);
                  ScoreboardManager.this.cleanupOffline(uuid);
               } else if (!ScoreboardManager.this.pvpManager.isInAnyPvP(player)) {
                  ScoreboardManager.this.waitingEventsClear.remove(uuid);
                  ScoreboardManager.this.removeScoreboard(player);
               } else {
                  ScoreboardManager.this.waitingEventsClear.remove(uuid);
                  ScoreboardManager.this.showScoreboard(player, ScoreboardManager.this.scoreboards.get(uuid), true, false);
               }
            }
         }, 5L);
         this.delayedShowTasks.put(uuid, task);
      }
   }

   private void cancelDelayedShow(UUID uuid) {
      if (uuid != null) {
         BukkitTask task = this.delayedShowTasks.remove(uuid);
         if (task != null) {
            task.cancel();
         }

         this.stopReconcileTaskIfIdle();
      }
   }

   private void cancelReassert(UUID uuid) {
      if (uuid != null) {
         BukkitTask task = this.reassertTasks.remove(uuid);
         if (task != null) {
            task.cancel();
         }

         this.stopReconcileTaskIfIdle();
      }
   }

   private void scheduleReassert(final UUID uuid) {
      if (uuid != null && this.plugin != null) {
         this.cancelReassert(uuid);
         this.startReconcileTaskIfNeeded();
         BukkitTask task = Bukkit.getScheduler().runTaskTimer(this.plugin, new Runnable() {
            private int runs;

            @Override
            public void run() {
               Player player = Bukkit.getPlayer(uuid);
               if (player == null || !player.isOnline()) {
                  ScoreboardManager.this.cancelReassert(uuid);
                  ScoreboardManager.this.cleanupOffline(uuid);
               } else if (!ScoreboardManager.this.pvpManager.isInAnyPvP(player)) {
                  ScoreboardManager.this.cancelReassert(uuid);
                  ScoreboardManager.this.removeScoreboard(player);
               } else {
                  CustomScoreboard scoreboard = ScoreboardManager.this.scoreboards.get(uuid);
                  if (scoreboard != null && player.getScoreboard() == scoreboard.getScoreboard()) {
                     ScoreboardManager.this.cancelReassert(uuid);
                  } else {
                     ScoreboardManager.this.showScoreboard(player, scoreboard, true, false);
                     this.runs++;
                     if (this.runs >= 3) {
                        ScoreboardManager.this.cancelReassert(uuid);
                     }
                  }
               }
            }
         }, 1L, 2L);
         this.reassertTasks.put(uuid, task);
      }
   }

   private boolean notifyEventsScoreboardLocked(Player player) {
      return this.eventsBridge.prepare(player);
   }

   private boolean notifyEventsScoreboardReleased(Player player) {
      return this.eventsBridge.release(player);
   }

   private void showScoreboard(Player player, boolean force) {
      if (player != null) {
         this.requestScoreboard(player, force);
      }
   }

   private void showScoreboard(Player player, CustomScoreboard scoreboard, boolean force, boolean notifyEvents) {
      ScoreboardSettings scoreboardSettings = this.settings.getScoreboardSettings();
      if (scoreboardSettings.isEnabled() && player.isOnline() && this.pvpManager.isInAnyPvP(player)) {
         UUID uuid = player.getUniqueId();
         int currentTick = this.pvpManager.getCurrentTick();
         boolean detached = scoreboard != null && player.getScoreboard() != scoreboard.getScoreboard();
         if (force || detached || this.shouldUpdate(uuid, currentTick, scoreboardSettings.getUpdateInterval())) {
            this.lastUpdateTicks.put(uuid, currentTick);
            this.lastRenderServerTicks.put(uuid, Bukkit.getCurrentTick());
            this.fillOnlineOpponents(player, scoreboardSettings.getMaxOpponents(), this.opponentBuffer);
            int opponentCount = this.opponentBuffer.size();
            int timeRemaining = this.pvpManager.getTimeRemainingInAnyPvP(player);
            Player relationalTarget = opponentCount == 0 ? null : this.opponentBuffer.get(0);
            this.lineBuffer.clear();

            for (String line : scoreboardSettings.getLines()) {
               if (this.lineBuffer.size() >= 15) {
                  break;
               }

               if (line != null && line.indexOf("{opponents}") != -1) {
                  this.addOpponentLines(player, this.opponentBuffer, this.lineBuffer, scoreboardSettings, timeRemaining);
               } else {
                  this.lineBuffer.add(this.processLine(player, player, relationalTarget, line, opponentCount, timeRemaining));
               }
            }

            this.colorLines(this.lineBuffer, scoreboardSettings);
            String title = ColorUtils.color(this.processLine(player, player, relationalTarget, scoreboardSettings.getTitle(), opponentCount, timeRemaining));
            if (scoreboardSettings.isUseTabApi() && this.tabBridge.show(player, title, this.lineBuffer)) {
               this.tabScoreboards.add(uuid);
               if (scoreboard != null) {
                  this.scoreboards.remove(uuid);
                  this.previousScoreboards.remove(uuid);
                  scoreboard.remove();
               }

               this.stopReconcileTaskIfIdle();
               this.opponentBuffer.clear();
            } else {
               if (this.tabScoreboards.remove(uuid)) {
                  this.tabBridge.remove(uuid);
               }

               if (scoreboard == null) {
                  this.previousScoreboards.put(uuid, player.getScoreboard());
                  this.tabBridge.pauseDefault(player);
                  scoreboard = new CustomScoreboard(player);
                  this.scoreboards.put(uuid, scoreboard);
               } else if (player.getScoreboard() != scoreboard.getScoreboard()) {
                  this.tabBridge.pauseDefault(player);
                  player.setScoreboard(scoreboard.getScoreboard());
               }

               this.startReconcileTaskIfNeeded();
               scoreboard.setTitle(title);
               scoreboard.setLines(this.lineBuffer);
               this.opponentBuffer.clear();
            }
         }
      } else {
         this.removeScoreboard(player);
      }
   }

   private boolean shouldUpdate(UUID uuid, int currentTick, int interval) {
      Integer previousTick = this.lastUpdateTicks.get(uuid);
      return previousTick == null || currentTick - previousTick >= interval;
   }

   private void addOpponentLines(Player viewer, List<Player> playerOpponents, List<String> rawLines, ScoreboardSettings scoreboardSettings, int timeRemaining) {
      int size = playerOpponents.size();
      int limit = scoreboardSettings.getMaxOpponents();
      int displayLimit = Math.min(size, limit);

      for (int index = 0; index < displayLimit && rawLines.size() < 15; index++) {
         Player opponent = playerOpponents.get(index);
         String symbol = index == size - 1 ? scoreboardSettings.getLastOpponentSymbol() : scoreboardSettings.getOpponentSymbol();
         String line = scoreboardSettings.getOpponentLine()
            .replace("{opponent_symbol}", symbol)
            .replace("{player_name}", opponent.getName())
            .replace("{health}", Integer.toString((int)Math.ceil(opponent.getHealth())));
         rawLines.add(this.processLine(viewer, opponent, opponent, line, size, timeRemaining));
      }
   }

   private void colorLines(List<String> rawLines, ScoreboardSettings scoreboardSettings) {
      int size = rawLines.size();

      for (int index = 0; index < size; index++) {
         String line = rawLines.get(index);
         if (line != null && line.indexOf("{c}") != -1) {
            line = line.replace("{c}", this.getGradientColor(scoreboardSettings, size, size - 1 - index));
         }

         rawLines.set(index, ColorUtils.color(line));
      }
   }

   private String getGradientColor(ScoreboardSettings scoreboardSettings, int size, int index) {
      String start = scoreboardSettings.getGradientStart();
      String end = scoreboardSettings.getGradientEnd();
      if (this.gradientCache == null || this.gradientSize != size || !start.equals(this.gradientStart) || !end.equals(this.gradientEnd)) {
         this.gradientStart = start;
         this.gradientEnd = end;
         this.gradientSize = size;
         this.gradientCache = new String[size];

         for (int i = 0; i < size; i++) {
            this.gradientCache[i] = ColorUtils.gradientLegacy(start, end, size, i);
         }
      }

      if (index < 0) {
         index = 0;
      } else if (index >= this.gradientCache.length) {
         index = this.gradientCache.length - 1;
      }

      return this.gradientCache[index];
   }

   private String processLine(Player viewer, Player placeholderPlayer, Player relationalTarget, String line, int opponentCount, int timeRemaining) {
      if (line != null && !line.isEmpty()) {
         String playerName = viewer.getName();
         String time = Integer.toString(timeRemaining);
         String result = line.replace("{timer}", time)
            .replace("{time}", time)
            .replace("{player}", playerName)
            .replace("{player_name}", playerName)
            .replace("{opponent_count}", Integer.toString(opponentCount));
         result = PlaceholderUtils.setPlaceholders(placeholderPlayer == null ? viewer : placeholderPlayer, result);
         return PlaceholderUtils.setRelationalPlaceholders(viewer, relationalTarget, result);
      } else {
         return "";
      }
   }

   private void fillOnlineOpponents(Player player, int limit, List<Player> result) {
      result.clear();
      UUID uuid = player.getUniqueId();
      Set<UUID> opponentIds = this.opponents.get(uuid);
      if (opponentIds != null && !opponentIds.isEmpty()) {
         Iterator<UUID> iterator = opponentIds.iterator();

         while (iterator.hasNext()) {
            UUID opponentId = iterator.next();
            Player opponent = Bukkit.getPlayer(opponentId);
            if (opponent != null && opponent.isOnline() && this.pvpManager.isInAnyPvP(opponent)) {
               result.add(opponent);
               if (result.size() >= limit) {
                  break;
               }
            } else {
               iterator.remove();
            }
         }

         if (opponentIds.isEmpty()) {
            this.opponents.remove(uuid);
         }
      }
   }

   private boolean addOpponents(Player first, Player second) {
      if (first != null && second != null && !first.equals(second)) {
         UUID firstId = first.getUniqueId();
         UUID secondId = second.getUniqueId();
         Set<UUID> firstOpponents = this.opponents.get(firstId);
         if (firstOpponents == null) {
            firstOpponents = new LinkedHashSet<>();
            this.opponents.put(firstId, firstOpponents);
         }

         Set<UUID> secondOpponents = this.opponents.get(secondId);
         if (secondOpponents == null) {
            secondOpponents = new LinkedHashSet<>();
            this.opponents.put(secondId, secondOpponents);
         }

         boolean firstAdded = firstOpponents.add(secondId);
         boolean secondAdded = secondOpponents.add(firstId);
         return firstAdded || secondAdded;
      } else {
         return false;
      }
   }

   @EventHandler
   public void onPvpStarted(PvpStartedEvent event) {
      this.addOpponents(event.getAttacker(), event.getDefender());
      this.queueScoreboardUpdate(event.getAttacker(), true);
      this.queueScoreboardUpdate(event.getDefender(), true);
      this.notifyCloudJobsPriorityChanged(event.getAttacker());
      this.notifyCloudJobsPriorityChanged(event.getDefender());
   }

   public void handlePvpTimeUpdate(Player player, int oldTime, int newTime, Player damagedBy, Player damagedPlayer) {
      boolean force = oldTime != newTime + 1;
      if (damagedBy != null) {
         force |= this.addOpponents(player, damagedBy);
      }

      if (damagedPlayer != null) {
         force |= this.addOpponents(player, damagedPlayer);
      }

      this.queueScoreboardUpdate(player, force);
   }

   private void notifyCloudJobsPriorityChanged(Player player) {
      if (player != null) {
         Plugin jobs = Bukkit.getPluginManager().getPlugin("CloudJobs");
         if (jobs != null && jobs.isEnabled()) {
            try {
               Method method = this.jobsPriorityMethod;
               if (method == null || this.jobsPlugin != jobs) {
                  method = jobs.getClass().getMethod("onExternalScoreboardPriorityChanged", Player.class);
                  this.jobsPlugin = jobs;
                  this.jobsPriorityMethod = method;
               }

               method.invoke(jobs, player);
            } catch (ReflectiveOperationException | LinkageError var4) {
               this.jobsPlugin = null;
               this.jobsPriorityMethod = null;
            }
         }
      }
   }

   @EventHandler
   public void onPvpTimeUpdate(PvpTimeUpdateEvent event) {
      this.handlePvpTimeUpdate(event.getPlayer(), event.getOldTime(), event.getNewTime(), event.getDamagedBy(), event.getDamagedPlayer());
   }

   @EventHandler
   public void onPvpStopped(PvpStoppedEvent event) {
      this.removeScoreboard(event.getPlayer());
      this.removeOpponent(event.getPlayer().getUniqueId());
      this.notifyCloudJobsPriorityChanged(event.getPlayer());
      UUID uuid = event.getPlayer().getUniqueId();
      Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
         Player player = Bukkit.getPlayer(uuid);
         if (player != null && player.isOnline() && !this.pvpManager.isInAnyPvP(player)) {
            this.notifyEventsScoreboardReleased(player);
            this.notifyCloudJobsPriorityChanged(player);
         }
      }, 2L);
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      UUID uuid = event.getPlayer().getUniqueId();
      this.cleanupOffline(uuid);
      this.removeOpponent(uuid);
   }

   @EventHandler
   public void onKick(PlayerKickEvent event) {
      UUID uuid = event.getPlayer().getUniqueId();
      this.cleanupOffline(uuid);
      this.removeOpponent(uuid);
   }

   public void removeScoreboard(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         this.discardPendingScoreboardUpdate(uuid);
         this.cancelReassert(uuid);
         this.cancelDelayedShow(uuid);
         this.waitingEventsClear.remove(uuid);
         CustomScoreboard scoreboard = this.scoreboards.remove(uuid);
         boolean hadTabScoreboard = this.tabScoreboards.remove(uuid);
         this.lastUpdateTicks.remove(uuid);
         this.lastRenderServerTicks.remove(uuid);
         boolean hadScoreboard = scoreboard != null || hadTabScoreboard;
         boolean wasCurrent = scoreboard != null && player.isOnline() && player.getScoreboard() == scoreboard.getScoreboard();
         if (!hadScoreboard) {
            this.previousScoreboards.remove(uuid);
            this.stopReconcileTaskIfIdle();
         } else {
            boolean restoredByEvents = false;
            if (player.isOnline()) {
               if (hadTabScoreboard) {
                  this.tabBridge.markInactive(uuid);
               }

               restoredByEvents = this.notifyEventsScoreboardReleased(player);
            }

            if (player.isOnline()) {
               if (hadTabScoreboard) {
                  if (!restoredByEvents) {
                     if (wasCurrent) {
                        this.restoreScoreboard(player);
                     } else {
                        this.tabBridge.reset(player);
                        this.previousScoreboards.remove(uuid);
                     }
                  } else {
                     this.previousScoreboards.remove(uuid);
                  }
               } else if (wasCurrent) {
                  if (player.getScoreboard() == scoreboard.getScoreboard()) {
                     if (restoredByEvents) {
                        this.previousScoreboards.remove(uuid);
                        this.restoreExternalScoreboards(player);
                        if (player.getScoreboard() == scoreboard.getScoreboard() && Bukkit.getScoreboardManager() != null) {
                           player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
                        }
                     } else {
                        this.restoreScoreboard(player);
                     }
                  } else {
                     this.previousScoreboards.remove(uuid);
                     this.restoreExternalScoreboards(player);
                  }
               } else if (!restoredByEvents) {
                  this.restoreExternalScoreboards(player);
                  this.previousScoreboards.remove(uuid);
               }
            } else {
               this.previousScoreboards.remove(uuid);
               this.tabBridge.remove(uuid);
            }

            if (scoreboard != null) {
               scoreboard.remove();
            }

            this.stopReconcileTaskIfIdle();
         }
      }
   }

   private void scheduleLegacyScoreboardCleanup(final UUID uuid, final CustomScoreboard scoreboard) {
      if (uuid != null && scoreboard != null && this.plugin != null) {
         BukkitTask task = Bukkit.getScheduler()
            .runTaskLater(
               this.plugin,
               new Runnable() {
                  @Override
                  public void run() {
                     Player player = Bukkit.getPlayer(uuid);
                     if (player == null
                        || !player.isOnline()
                        || player.getScoreboard() != scoreboard.getScoreboard()
                        || !ScoreboardManager.this.pvpManager.isInAnyPvP(player)) {
                        scoreboard.remove();
                     }
                  }
               },
               8L
            );
      }
   }

   private void removeScoreboard(UUID uuid, CustomScoreboard scoreboard, Iterator<Entry<UUID, CustomScoreboard>> iterator) {
      iterator.remove();
      this.cancelReassert(uuid);
      this.cancelDelayedShow(uuid);
      this.waitingEventsClear.remove(uuid);
      Player player = Bukkit.getPlayer(uuid);
      if (player != null && player.isOnline() && scoreboard != null && player.getScoreboard() == scoreboard.getScoreboard()) {
         this.restoreScoreboard(player);
         this.notifyEventsScoreboardReleased(player);
      } else {
         if (player != null && player.isOnline()) {
            this.restoreExternalScoreboards(player);
            this.notifyEventsScoreboardReleased(player);
         }

         this.previousScoreboards.remove(uuid);
      }

      if (scoreboard != null) {
         scoreboard.remove();
      }

      this.lastUpdateTicks.remove(uuid);
      this.lastRenderServerTicks.remove(uuid);
      this.stopReconcileTaskIfIdle();
   }

   private void restoreScoreboard(Player player) {
      if (player != null && player.isOnline()) {
         Scoreboard previous = this.previousScoreboards.remove(player.getUniqueId());
         if (previous != null) {
            player.setScoreboard(previous);
            this.restoreExternalScoreboards(player);
         } else if (!this.restoreExternalScoreboards(player)) {
            if (Bukkit.getScoreboardManager() != null) {
               player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            }
         }
      }
   }

   private boolean restoreExternalScoreboards(Player player) {
      return this.tabBridge.reset(player);
   }

   private void removeOpponent(UUID uuid) {
      this.opponents.remove(uuid);
      Iterator<Entry<UUID, Set<UUID>>> iterator = this.opponents.entrySet().iterator();

      while (iterator.hasNext()) {
         Set<UUID> playerOpponents = iterator.next().getValue();
         playerOpponents.remove(uuid);
         if (playerOpponents.isEmpty()) {
            iterator.remove();
         }
      }
   }

   private void startReconcileTaskIfNeeded() {
      if (this.reconcileTask == null || this.reconcileTask.isCancelled()) {
         this.reconcileTask = Bukkit.getScheduler().runTaskTimer(this.plugin, new Runnable() {
            @Override
            public void run() {
               ScoreboardManager.this.reconcileOnlinePlayers();
            }
         }, 1L, 5L);
      }
   }

   private void stopReconcileTask() {
      if (this.reconcileTask != null) {
         this.reconcileTask.cancel();
         this.reconcileTask = null;
      }
   }

   private void stopReconcileTaskIfIdle() {
      if (!this.hasActiveNativeScoreboards() && this.reassertTasks.isEmpty() && this.delayedShowTasks.isEmpty() && this.waitingEventsClear.isEmpty()) {
         this.stopReconcileTask();
      }
   }

   private boolean hasActiveNativeScoreboards() {
      for (UUID uuid : this.scoreboards.keySet()) {
         if (!this.tabScoreboards.contains(uuid)) {
            return true;
         }
      }

      return false;
   }

   private void reconcileOnlinePlayers() {
      this.reconcileBuffer.clear();
      if (!this.scoreboards.isEmpty()) {
         for (UUID uuid : this.scoreboards.keySet()) {
            if (!this.tabScoreboards.contains(uuid)) {
               this.reconcileBuffer.add(uuid);
            }
         }
      }

      if (!this.reassertTasks.isEmpty()) {
         this.reconcileBuffer.addAll(this.reassertTasks.keySet());
      }

      if (!this.delayedShowTasks.isEmpty()) {
         this.reconcileBuffer.addAll(this.delayedShowTasks.keySet());
      }

      if (!this.waitingEventsClear.isEmpty()) {
         this.reconcileBuffer.addAll(this.waitingEventsClear);
      }

      if (this.reconcileBuffer.isEmpty()) {
         this.stopReconcileTaskIfIdle();
      } else {
         for (UUID uuid : this.reconcileBuffer) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
               boolean inPvp = this.pvpManager.isInAnyPvP(player);
               CustomScoreboard scoreboard = this.scoreboards.get(uuid);
               if (!inPvp) {
                  if (scoreboard != null || this.tabScoreboards.contains(uuid) || this.reassertTasks.containsKey(uuid)) {
                     this.removeScoreboard(player);
                  }
               } else if (scoreboard == null || player.getScoreboard() != scoreboard.getScoreboard()) {
                  this.showScoreboard(player, scoreboard, true, false);
               }
            } else {
               this.cleanupOffline(uuid);
            }
         }

         this.reconcileBuffer.clear();
      }
   }

   private void cleanupOffline(UUID uuid) {
      this.discardPendingScoreboardUpdate(uuid);
      this.cancelReassert(uuid);
      this.cancelDelayedShow(uuid);
      this.waitingEventsClear.remove(uuid);
      CustomScoreboard scoreboard = this.scoreboards.remove(uuid);
      this.tabScoreboards.remove(uuid);
      if (scoreboard != null) {
         scoreboard.remove();
      }

      this.previousScoreboards.remove(uuid);
      this.lastUpdateTicks.remove(uuid);
      this.lastRenderServerTicks.remove(uuid);
      this.tabBridge.remove(uuid);
      this.stopReconcileTaskIfIdle();
   }

   public void shutdown() {
      this.stopScoreboardUpdateTask();
      this.shutdown(true);
      this.stopReconcileTask();
   }

   private void shutdown(boolean clearOpponents) {
      Iterator<Entry<UUID, CustomScoreboard>> iterator = this.scoreboards.entrySet().iterator();

      while (iterator.hasNext()) {
         Entry<UUID, CustomScoreboard> entry = iterator.next();
         this.removeScoreboard(entry.getKey(), entry.getValue(), iterator);
      }

      this.scoreboards.clear();

      for (UUID uuid : new ArrayList<>(this.tabScoreboards)) {
         Player player = Bukkit.getPlayer(uuid);
         if (player != null && player.isOnline()) {
            this.tabBridge.reset(player);
            this.notifyEventsScoreboardReleased(player);
         }

         this.tabBridge.remove(uuid);
      }

      this.tabScoreboards.clear();
      this.tabBridge.clear();
      this.previousScoreboards.clear();
      this.lastUpdateTicks.clear();
      this.lastRenderServerTicks.clear();

      for (BukkitTask task : this.reassertTasks.values()) {
         task.cancel();
      }

      this.reassertTasks.clear();

      for (BukkitTask task : this.delayedShowTasks.values()) {
         task.cancel();
      }

      this.delayedShowTasks.clear();
      this.waitingEventsClear.clear();
      if (clearOpponents) {
         this.opponents.clear();
      }

      this.stopReconcileTaskIfIdle();
   }

   private static final class EventsScoreboardBridge {
      private boolean initialized;
      private boolean available;
      private Object api;
      private Method activeMethod;
      private Method prepareMethod;
      private Method releaseMethod;

      private boolean isEventActive() {
         if (this.connect() && this.activeMethod != null) {
            Object result = this.invoke(this.activeMethod, null);
            return result instanceof Boolean && (Boolean)result;
         } else {
            return false;
         }
      }

      private boolean prepare(Player player) {
         if (player != null && player.isOnline() && this.connect() && this.prepareMethod != null) {
            Object result = this.invoke(this.prepareMethod, player);
            return !(result instanceof Boolean) || (Boolean)result;
         } else {
            return false;
         }
      }

      private boolean release(Player player) {
         if (player != null && player.isOnline() && this.connect() && this.releaseMethod != null) {
            Object result = this.invoke(this.releaseMethod, player);
            return result instanceof Boolean && (Boolean)result;
         } else {
            return false;
         }
      }

      private boolean connect() {
         if (this.initialized && this.available) {
            return true;
         }

         this.initialized = true;
         this.available = false;
         this.api = null;
         this.activeMethod = null;
         this.prepareMethod = null;
         this.releaseMethod = null;

         try {
            Plugin plugin = Bukkit.getPluginManager().getPlugin("CloudEvents");
            if (plugin != null && plugin.isEnabled()) {
               this.api = plugin.getClass().getMethod("getEventsAPI").invoke(plugin);
               if (this.api == null) {
                  return false;
               }

               Class<?> apiClass = this.api.getClass();
               this.activeMethod = this.findNoArgMethod(apiClass, "isEventActive");
               this.prepareMethod = this.findPlayerMethod(apiClass, "prepareForRelogScoreboard", "onPlayerEnterPvP");
               this.releaseMethod = this.findPlayerMethod(apiClass, "resumeScoreboardAfterRelogNow", "onRelogScoreboardHidden");
               this.available = this.activeMethod != null || this.prepareMethod != null || this.releaseMethod != null;
               return this.available;
            } else {
               return false;
            }
         } catch (ReflectiveOperationException ignored) {
            return false;
         }
      }

      private Method findNoArgMethod(Class<?> owner, String name) {
         try {
            return owner.getMethod(name);
         } catch (NoSuchMethodException ignored) {
            return null;
         }
      }

      private Method findPlayerMethod(Class<?> owner, String preferred, String fallback) {
         try {
            return owner.getMethod(preferred, Player.class);
         } catch (NoSuchMethodException ignored) {
            try {
               return owner.getMethod(fallback, Player.class);
            } catch (NoSuchMethodException ignoredAgain) {
               return null;
            }
         }
      }

      private Object invoke(Method method, Player player) {
         if (method == null) {
            return null;
         }

         try {
            return player == null ? method.invoke(this.api) : method.invoke(this.api, player);
         } catch (ReflectiveOperationException ignored) {
            this.available = false;
            this.initialized = false;
            return null;
         }
      }
   }
}
