package cs.cloudstudio.manager.scoreboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Team;

final class NmsLongScoreboardBridge {
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

   boolean isAvailable() {
      return true;
   }

   boolean updateLine(Player player, Team team, String prefix, String suffix) {
      if (player != null && team != null && player.isOnline()) {
         try {
            team.prefix(toComponent(prefix));
            team.suffix(toComponent(suffix));
            return true;
         } catch (RuntimeException ignored) {
            return false;
         }
      } else {
         return false;
      }
   }

   boolean updatePrefix(Player player, Team team, String prefix) {
      if (player != null && team != null && player.isOnline()) {
         try {
            team.prefix(toComponent(prefix));
            return true;
         } catch (RuntimeException ignored) {
            return false;
         }
      } else {
         return false;
      }
   }

   private static Component toComponent(String text) {
      return text != null && !text.isEmpty() ? LEGACY.deserialize(text) : Component.empty();
   }
}
