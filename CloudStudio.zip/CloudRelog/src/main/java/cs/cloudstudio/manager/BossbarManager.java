package cs.cloudstudio.manager;

import cs.cloudstudio.CloudRelog;
import cs.cloudstudio.config.Settings;
import cs.cloudstudio.util.Utils;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import me.neznamy.tab.api.TabAPI;
import me.neznamy.tab.api.TabPlayer;
import me.neznamy.tab.api.bossbar.BarColor;
import me.neznamy.tab.api.bossbar.BarStyle;
import me.neznamy.tab.api.bossbar.BossBar;
import me.neznamy.tab.api.bossbar.BossBarManager;
import me.neznamy.tab.api.event.EventBus;
import me.neznamy.tab.api.event.EventHandler;
import me.neznamy.tab.api.event.player.PlayerLoadEvent;
import me.neznamy.tab.api.event.plugin.TabLoadEvent;
import org.bukkit.entity.Player;

public class BossbarManager {
   private final CloudRelog plugin;
   private final Settings settings;
   private final Map<UUID, BossbarManager.BossBarState> playerBars = new HashMap<>();
   /** Боссбары закончивших PvP игроков: скрыты, но не удалены из TAB — при следующем PvP используются снова. */
   private final Map<UUID, BossbarManager.BossBarState> parkedBars = new HashMap<>();
   private static final long PARKED_TTL_MS = 600000L;
   private TabAPI tabApi;
   private BossBarManager tabBossBars;
   private EventBus tabEventBus;
   private EventHandler<PlayerLoadEvent> playerLoadHandler;
   private EventHandler<TabLoadEvent> tabLoadHandler;
   private String[] titles = new String[0];
   private float[] progress = new float[0];
   private int maxTime;
   private boolean enabled;
   private BarColor barColor = BarColor.RED;
   private BarStyle barStyle = BarStyle.PROGRESS;

   public BossbarManager(CloudRelog plugin, Settings settings) {
      this.plugin = plugin;
      this.settings = settings;
      this.refreshTabApi();
   }

   public void createBossBars() {
      this.clearBossbars();
      this.refreshTabApi();
      this.maxTime = this.settings.getPvpTime();
      String titleTemplate = this.settings.getMessages().getInPvpBossbar();
      this.enabled = this.maxTime > 0 && titleTemplate != null && !titleTemplate.isEmpty();
      if (!this.enabled) {
         this.titles = new String[0];
         this.progress = new float[0];
      } else {
         this.titles = new String[this.maxTime + 1];
         this.progress = new float[this.maxTime + 1];
         String previousTitle = null;

         for (int time = 0; time <= this.maxTime; time++) {
            String title = Utils.replaceTime(titleTemplate, time);
            if (title.equals(previousTitle)) {
               this.titles[time] = previousTitle;
            } else {
               previousTitle = title;
               this.titles[time] = title;
            }

            this.progress[time] = (float)(Math.max(0.0, Math.min(1.0, (double)time / this.maxTime)) * 100.0);
         }
      }
   }

   public void setBossBar(Player player, int time) {
      this.setBossBar(player, time, false);
   }

   public void setBossBar(Player player, int time, boolean force) {
      if (this.enabled && player != null && player.isOnline()) {
         UUID uuid = player.getUniqueId();
         int safeTime = this.clampTime(time);
         BossbarManager.BossBarState state = this.playerBars.get(uuid);
         if (state == null) {
            state = this.takeParked(uuid);
            this.playerBars.put(uuid, state);
            force = true;
         }

         int previousTime = state.lastTime;
         state.lastTime = safeTime;
         TabPlayer tabPlayer = this.getTabPlayer(uuid);
         if (tabPlayer != null && tabPlayer.isLoaded()) {
            if (state.bar == null) {
               state.bar = this.createBar(this.titles[safeTime], this.progress[safeTime]);
               if (state.bar != null) {
                  state.owner = this.tabBossBars;
                  state.lastTitle = this.titles[safeTime];
                  state.lastProgress = this.progress[safeTime];
                  this.attachViewer(state, tabPlayer);
               }
            } else {
               boolean viewerChanged = this.attachViewer(state, tabPlayer);
               if (previousTime != safeTime || viewerChanged) {
                  String title = this.titles[safeTime];
                  if (state.lastTitle == null || !state.lastTitle.equals(title)) {
                     state.bar.setTitle(title);
                     state.lastTitle = title;
                  }

                  float pct = this.progress[safeTime];
                  if (Float.compare(state.lastProgress, pct) != 0) {
                     state.bar.setProgress(pct);
                     state.lastProgress = pct;
                  }
               }
            }
         }
      }
   }

   public void clearBossbar(Player player) {
      if (player != null) {
         this.clearBossbar(player.getUniqueId());
      }
   }

   public void clearBossbar(UUID uuid) {
      if (uuid != null) {
         BossbarManager.BossBarState state = this.playerBars.remove(uuid);
         if (!this.park(uuid, state)) {
            this.removeBar(state, uuid);
         }
      }
   }

   /** Скрыть боссбар (убрать зрителя) и отложить; false — отложить нельзя, нужно удалить. */
   private boolean park(UUID uuid, BossbarManager.BossBarState state) {
      if (state == null || state.bar == null || state.owner == null || state.owner != this.tabBossBars
         || this.plugin.getServer().getPlayer(uuid) == null) {
         return false;
      }

      try {
         if (state.viewer != null && state.bar.containsPlayer(state.viewer)) {
            state.bar.removePlayer(state.viewer);
         }
      } catch (RuntimeException ignored) {
         return false;
      }

      state.viewer = null;
      state.parkedAt = System.currentTimeMillis();
      this.pruneParked();
      BossbarManager.BossBarState old = this.parkedBars.put(uuid, state);
      if (old != null && old != state) {
         this.removeBar(old, uuid);
      }
      return true;
   }

   private BossbarManager.BossBarState takeParked(UUID uuid) {
      BossbarManager.BossBarState parked = this.parkedBars.remove(uuid);
      if (parked == null) {
         return new BossbarManager.BossBarState();
      }
      if (parked.bar == null || parked.owner != this.tabBossBars) {
         this.removeBar(parked, uuid);
         return new BossbarManager.BossBarState();
      }
      return parked; // зритель снова добавится в attachViewer, заголовок/прогресс обновятся при отличии
   }

   private void pruneParked() {
      long now = System.currentTimeMillis();
      this.parkedBars.entrySet().removeIf(entry -> {
         BossbarManager.BossBarState state = entry.getValue();
         if (now - state.parkedAt < PARKED_TTL_MS && this.plugin.getServer().getPlayer(entry.getKey()) != null) {
            return false;
         }
         this.removeBar(state, entry.getKey());
         return true;
      });
   }

   private void clearParked() {
      for (Entry<UUID, BossbarManager.BossBarState> entry : this.parkedBars.entrySet()) {
         this.removeBar(entry.getValue(), entry.getKey());
      }
      this.parkedBars.clear();
   }

   public void clearBossbars() {
      if (!this.playerBars.isEmpty()) {
         for (Entry<UUID, BossbarManager.BossBarState> entry : this.playerBars.entrySet()) {
            this.removeBar(entry.getValue(), entry.getKey());
         }

         this.playerBars.clear();
      }
      this.clearParked();
   }

   public void shutdown() {
      this.clearBossbars();
      this.unregisterTabEvents();
      this.tabApi = null;
      this.tabBossBars = null;
   }

   private boolean attachViewer(BossbarManager.BossBarState state, TabPlayer tabPlayer) {
      if (state.viewer == tabPlayer) {
         return false;
      }

      try {
         if (state.viewer != null && state.bar.containsPlayer(state.viewer)) {
            state.bar.removePlayer(state.viewer);
         }

         if (!state.bar.containsPlayer(tabPlayer)) {
            state.bar.addPlayer(tabPlayer);
         }

         state.viewer = tabPlayer;
         return true;
      } catch (RuntimeException ignored) {
         return false;
      }
   }

   private BossBar createBar(String title, float pct) {
      if (!this.isTabReady() && !this.refreshTabApi()) {
         return null;
      }

      int attempt = 0;

      while (attempt < 2) {
         try {
            return this.tabBossBars.createBossBar(title, pct, this.barColor, this.barStyle);
         } catch (IllegalStateException exception) {
            if (attempt > 0 || !this.refreshTabApi()) {
               this.plugin.getLogger().warning("TAB не смог создать bossbar: " + exception.getMessage());
               return null;
            }

            attempt++;
         } catch (RuntimeException exception) {
            this.plugin.getLogger().warning("TAB не смог создать bossbar: " + exception.getMessage());
            return null;
         }
      }

      return null;
   }

   private void removeBar(BossbarManager.BossBarState state, UUID uuid) {
      if (state != null && state.bar != null) {
         BossBar bar = state.bar;
         state.bar = null;

         try {
            if (state.viewer != null && bar.containsPlayer(state.viewer)) {
               bar.removePlayer(state.viewer);
            }
         } catch (RuntimeException var7) {
         }

         BossBarManager owner = state.owner;
         state.owner = null;
         state.viewer = null;
         if (owner != null) {
            try {
               owner.removeBossBar(bar);
            } catch (RuntimeException var6) {
            }
         }
      }
   }

   private int clampTime(int time) {
      if (time < 0) {
         return 0;
      } else {
         return time > this.maxTime ? this.maxTime : time;
      }
   }

   private TabPlayer getTabPlayer(UUID uuid) {
      return this.tabApi != null && uuid != null ? this.tabApi.getPlayer(uuid) : null;
   }

   private boolean isTabReady() {
      return this.tabApi != null && this.tabBossBars != null;
   }

   private boolean refreshTabApi() {
      try {
         this.tabApi = TabAPI.getInstance();
         this.tabBossBars = this.tabApi.getBossBarManager();
      } catch (IllegalStateException exception) {
         this.tabApi = null;
         this.tabBossBars = null;
         return false;
      }

      if (this.tabBossBars == null) {
         return false;
      }

      this.registerTabEvents();
      return true;
   }

   private void registerTabEvents() {
      if (this.isTabReady() && this.tabEventBus == null) {
         this.tabEventBus = this.tabApi.getEventBus();
         if (this.tabEventBus != null) {
            this.playerLoadHandler = event -> this.onTabPlayerLoaded(event.getPlayer());
            this.tabLoadHandler = event -> this.onTabReloaded();
            this.tabEventBus.register(PlayerLoadEvent.class, this.playerLoadHandler);
            this.tabEventBus.register(TabLoadEvent.class, this.tabLoadHandler);
         }
      }
   }

   private void unregisterTabEvents() {
      if (this.tabEventBus != null) {
         try {
            if (this.playerLoadHandler != null) {
               this.tabEventBus.unregister(this.playerLoadHandler);
            }

            if (this.tabLoadHandler != null) {
               this.tabEventBus.unregister(this.tabLoadHandler);
            }
         } catch (RuntimeException var2) {
         }
      }

      this.tabEventBus = null;
      this.playerLoadHandler = null;
      this.tabLoadHandler = null;
   }

   private void onTabPlayerLoaded(TabPlayer tabPlayer) {
      if (tabPlayer != null && this.enabled) {
         UUID uuid = tabPlayer.getUniqueId();
         if (this.playerBars.containsKey(uuid)) {
            this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
               BossbarManager.BossBarState state = this.playerBars.get(uuid);
               Player player = this.plugin.getServer().getPlayer(uuid);
               if (state != null && player != null && player.isOnline()) {
                  state.viewer = null;
                  this.setBossBar(player, state.lastTime, true);
               }
            });
         }
      }
   }

   private void onTabReloaded() {
      this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
         this.clearParked(); // бары старого экземпляра TAB больше не годятся
         if (!this.playerBars.isEmpty() && this.refreshTabApi()) {
            for (Entry<UUID, BossbarManager.BossBarState> entry : this.playerBars.entrySet()) {
               BossbarManager.BossBarState state = entry.getValue();
               this.removeBar(state, entry.getKey());
               state.lastTitle = null;
               state.lastProgress = -1.0F;
               Player player = this.plugin.getServer().getPlayer(entry.getKey());
               if (player != null && player.isOnline()) {
                  this.setBossBar(player, state.lastTime, true);
               }
            }
         }
      });
   }

   private static final class BossBarState {
      private BossBar bar;
      private BossBarManager owner;
      private TabPlayer viewer;
      private String lastTitle;
      private float lastProgress = -1.0F;
      private int lastTime;
      private long parkedAt;
   }
}
