package cs.cloudstudio.listener;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;

public final class TridentDupeListener implements Listener {
   private static final long THROW_LOCK_SECONDS = 2L;
   private static final long MAX_TRACKED_PLAYERS = 2048L;
   private final Cache<UUID, Boolean> readyToThrow = CacheBuilder.newBuilder().expireAfterWrite(2L, TimeUnit.SECONDS).maximumSize(2048L).build();

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onProjectileLaunch(ProjectileLaunchEvent event) {
      if (event.getEntity() instanceof Trident && event.getEntity().getShooter() instanceof Player) {
         Player player = (Player)event.getEntity().getShooter();
         this.readyToThrow.invalidate(player.getUniqueId());
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onPlayerInteract(PlayerInteractEvent event) {
      ItemStack item = event.getItem();
      if (item != null && item.getType() == Material.TRIDENT && !item.containsEnchantment(Enchantment.RIPTIDE)) {
         Action action = event.getAction();
         if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            this.readyToThrow.put(event.getPlayer().getUniqueId(), Boolean.TRUE);
         }
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
      if (this.isReadyToThrow(event.getPlayer().getUniqueId())) {
         String command = event.getMessage().toLowerCase(Locale.ROOT);
         if (command.equals("/ah")
            || command.startsWith("/ah ")
            || command.equals("/auc")
            || command.startsWith("/auc ")
            || command.equals("/auction")
            || command.startsWith("/auction ")
            || command.equals("/cloudauction")
            || command.startsWith("/cloudauction ")) {
            event.setCancelled(true);
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onPlayerItemHeld(PlayerItemHeldEvent event) {
      Player player = event.getPlayer();
      ItemStack itemStack = player.getInventory().getItem(event.getNewSlot());
      if (itemStack == null || itemStack.getType() != Material.TRIDENT) {
         this.readyToThrow.invalidate(player.getUniqueId());
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onPlayerSwapHandItems(PlayerSwapHandItemsEvent event) {
      this.readyToThrow.invalidate(event.getPlayer().getUniqueId());
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onPlayerDropItem(PlayerDropItemEvent event) {
      if (event.getItemDrop().getItemStack().getType() == Material.TRIDENT) {
         this.readyToThrow.invalidate(event.getPlayer().getUniqueId());
      }
   }

   @EventHandler(ignoreCancelled = true)
   public void onPlayerQuit(PlayerQuitEvent event) {
      this.readyToThrow.invalidate(event.getPlayer().getUniqueId());
   }

   public boolean isReadyToThrow(UUID playerId) {
      return this.readyToThrow.getIfPresent(playerId) != null;
   }
}
