package cs.cloudstudio.listener;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.manager.data.AuctionItem;
import cs.cloudstudio.manager.data.Category;
import cs.cloudstudio.menu.AuctionInventoryHolder;
import java.util.UUID;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public final class GUIListener implements Listener {
   private final CloudAuction plugin;
   private final NamespacedKey auctionIdKey;
   private final NamespacedKey categoryKey;

   public GUIListener(CloudAuction plugin) {
      this.plugin = plugin;
      this.auctionIdKey = new NamespacedKey(plugin, "auction_id");
      this.categoryKey = new NamespacedKey(plugin, "category");
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onInventoryClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         AuctionInventoryHolder holder = this.getAuctionHolder(event.getView().getTopInventory().getHolder(false));
         if (holder != null) {
            event.setCancelled(true);
            if (this.isHandledClick(event.getClick())) {
               int rawSlot = event.getRawSlot();
               if (rawSlot >= 0 && rawSlot < event.getView().getTopInventory().getSize()) {
                  ItemStack clicked = event.getCurrentItem();
                  if (clicked != null && !clicked.getType().isAir()) {
                     Player player = (Player)event.getWhoClicked();
                     String menuType = holder.getMenuType();
                     if ("confirm".equals(menuType)) {
                        this.handleConfirmMenu(player, rawSlot);
                     } else if ("category".equals(menuType)) {
                        this.handleCategoryMenu(player, clicked);
                     } else if ("my".equals(menuType)) {
                        this.handleMyItemsMenu(player, rawSlot, clicked);
                     } else {
                        this.handleMainMenu(player, rawSlot, clicked, event.isShiftClick());
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onCreativeInventoryClick(InventoryCreativeEvent event) {
      if (this.getAuctionHolder(event.getView().getTopInventory().getHolder(false)) != null) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onInventoryDrag(InventoryDragEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         if (this.getAuctionHolder(event.getView().getTopInventory().getHolder(false)) != null) {
            int topSize = event.getView().getTopInventory().getSize();

            for (Integer rawSlot : event.getRawSlots()) {
               if (rawSlot != null && rawSlot < topSize) {
                  event.setCancelled(true);
                  return;
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onInventoryClose(InventoryCloseEvent event) {
      if (event.getPlayer() instanceof Player) {
         if (this.getAuctionHolder(event.getInventory().getHolder(false)) != null) {
            Player player = (Player)event.getPlayer();
            UUID playerId = player.getUniqueId();
            if (!this.plugin.getGUIManager().isSwitching(playerId)) {
               this.plugin.getGUIManager().clearSession(player);
            }
         }
      }
   }

   @EventHandler(ignoreCancelled = true)
   public void onPlayerJoin(PlayerJoinEvent event) {
      UUID playerId = event.getPlayer().getUniqueId();
      this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
         Player player = this.plugin.getServer().getPlayer(playerId);
         if (player != null && player.isOnline()) {
            this.plugin.getAuctionManager().tryReturnPendingItems(player);
         }
      }, 20L);
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPlayerDrop(PlayerDropItemEvent event) {
      if (this.plugin.getGUIManager().hasSession(event.getPlayer().getUniqueId())
         || this.plugin.getAuctionManager().isTransactionLocked(event.getPlayer().getUniqueId())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onSwapHands(PlayerSwapHandItemsEvent event) {
      if (this.plugin.getGUIManager().hasSession(event.getPlayer().getUniqueId())
         || this.plugin.getAuctionManager().isTransactionLocked(event.getPlayer().getUniqueId())) {
         event.setCancelled(true);
      }
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      this.clearPlayerState(event.getPlayer(), true);
   }

   @EventHandler(ignoreCancelled = true)
   public void onPlayerKick(PlayerKickEvent event) {
      this.clearPlayerState(event.getPlayer(), true);
   }

   @EventHandler
   public void onPlayerDeath(PlayerDeathEvent event) {
      this.clearPlayerState(event.getEntity(), false);
   }

   @EventHandler(ignoreCancelled = true)
   public void onPlayerChangedWorld(PlayerChangedWorldEvent event) {
      this.clearPlayerState(event.getPlayer(), false);
   }

   @EventHandler(ignoreCancelled = true)
   public void onPlayerTeleport(PlayerTeleportEvent event) {
      if (this.plugin.getGUIManager().hasSession(event.getPlayer().getUniqueId())
         || this.plugin.getAuctionManager().isTransactionLocked(event.getPlayer().getUniqueId())) {
         this.clearPlayerState(event.getPlayer(), false);
      }
   }

   private void clearPlayerState(Player player, boolean forgetCategory) {
      if (forgetCategory) {
         this.plugin.getGUIManager().clearPlayer(player);
      } else {
         this.plugin.getGUIManager().clearSession(player);
      }

      this.plugin.getPermissionManager().invalidate(player.getUniqueId());
   }

   private AuctionInventoryHolder getAuctionHolder(InventoryHolder holder) {
      return holder instanceof AuctionInventoryHolder ? (AuctionInventoryHolder)holder : null;
   }

   private boolean isHandledClick(ClickType clickType) {
      return clickType == ClickType.LEFT || clickType == ClickType.RIGHT || clickType == ClickType.SHIFT_LEFT || clickType == ClickType.SHIFT_RIGHT;
   }

   private void handleMainMenu(Player player, int slot, ItemStack item, boolean shiftClick) {
      if (this.plugin.getGUIManager().isButtonSlot("nextPage", 53, slot)) {
         this.reopenMainMenu(player, this.plugin.getGUIManager().getCurrentPage(player) + 1);
      } else if (this.plugin.getGUIManager().isButtonSlot("prevPage", 45, slot)) {
         this.reopenMainMenu(player, Math.max(0, this.plugin.getGUIManager().getCurrentPage(player) - 1));
      } else if (this.plugin.getGUIManager().isButtonSlot("sort", 3, slot)) {
         this.plugin.getGUIManager().cycleSortType(player);
         this.reopenMainMenu(player, 0);
      } else if (this.plugin.getGUIManager().isButtonSlot("refresh", 4, slot)) {
         this.reopenMainMenu(player, this.plugin.getGUIManager().getCurrentPage(player));
      } else if (this.plugin.getGUIManager().isButtonSlot("category", 5, slot)) {
         this.plugin.getGUIManager().openCategoryMenuNextTick(player);
      } else if (this.plugin.getGUIManager().isButtonSlot("myItems", 49, slot)) {
         this.plugin.getGUIManager().openMyItemsMenuNextTick(player, 0);
      } else if (this.plugin.getGUIManager().isAuctionItemSlot("auction", slot)) {
         UUID id = this.extractAuctionId(item);
         if (id != null) {
            AuctionItem auctionItem = this.plugin.getAuctionManager().getItem(id);
            if (auctionItem == null) {
               player.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemAlreadySold"));
            } else if (auctionItem.getSeller().equals(player.getUniqueId())) {
               player.sendMessage(this.plugin.getConfigManager().getMessage("messages.cantBuyOwnItem"));
            } else if (shiftClick) {
               this.plugin.getAuctionManager().buyItem(player, id);
               this.reopenMainMenu(player, this.plugin.getGUIManager().getCurrentPage(player));
            } else {
               this.plugin.getGUIManager().openConfirmMenuNextTick(player, id);
            }
         }
      }
   }

   private void handleMyItemsMenu(Player player, int slot, ItemStack item) {
      if (this.plugin.getGUIManager().isButtonSlot("nextPage", 53, slot)) {
         this.plugin.getGUIManager().openMyItemsMenuNextTick(player, this.plugin.getGUIManager().getCurrentPage(player) + 1);
      } else if (this.plugin.getGUIManager().isButtonSlot("prevPage", 45, slot)) {
         this.plugin.getGUIManager().openMyItemsMenuNextTick(player, Math.max(0, this.plugin.getGUIManager().getCurrentPage(player) - 1));
      } else if (this.plugin.getGUIManager().isButtonSlot("back", 49, slot)) {
         this.plugin.getGUIManager().openMainMenuNextTick(player, 0, null);
      } else if (this.plugin.getGUIManager().isAuctionItemSlot("my", slot)) {
         UUID id = this.extractAuctionId(item);
         if (id != null) {
            AuctionItem auctionItem = this.plugin.getAuctionManager().getItem(id);
            if (auctionItem != null && auctionItem.getSeller().equals(player.getUniqueId())) {
               if (this.plugin.getConfigManager().isExpired(auctionItem.getExpireTime())) {
                  this.plugin.getAuctionManager().claimExpiredItem(player, id);
               } else {
                  this.plugin.getAuctionManager().returnItem(player, id);
               }

               this.plugin.getGUIManager().openMyItemsMenuNextTick(player, this.plugin.getGUIManager().getCurrentPage(player));
            }
         }
      }
   }

   private void handleConfirmMenu(Player player, int slot) {
      if (this.plugin.getConfigManager().isConfirmSlot(slot)) {
         ItemStack centerItem = player.getOpenInventory().getTopInventory().getItem(this.plugin.getConfigManager().getConfirmItemSlot());
         UUID id = this.extractAuctionId(centerItem);
         if (id != null) {
            this.plugin.getAuctionManager().buyItem(player, id);
            this.plugin.getGUIManager().openMainMenuNextTick(player, 0, null);
         }
      } else {
         if (this.plugin.getConfigManager().isCancelSlot(slot)) {
            this.plugin.getGUIManager().openMainMenuNextTick(player, 0, null);
         }
      }
   }

   private void handleCategoryMenu(Player player, ItemStack item) {
      String categoryName = this.extractCategory(item);
      if (categoryName != null) {
         Category category = Category.fromString(categoryName);
         this.plugin.getGUIManager().setCategory(player, category);
         this.plugin.getGUIManager().openMainMenuNextTick(player, 0, null);
      }
   }

   private void reopenMainMenu(Player player, int page) {
      this.plugin.getGUIManager().openMainMenuNextTick(player, page, this.plugin.getGUIManager().getCurrentSearchQuery(player));
   }

   private UUID extractAuctionId(ItemStack stack) {
      if (stack != null && stack.hasItemMeta()) {
         String raw = (String)stack.getPersistentDataContainer().get(this.auctionIdKey, PersistentDataType.STRING);
         if (raw == null) {
            return null;
         }

         try {
            return UUID.fromString(raw);
         } catch (IllegalArgumentException e) {
            return null;
         }
      } else {
         return null;
      }
   }

   private String extractCategory(ItemStack stack) {
      if (stack != null && stack.hasItemMeta()) {
         return (String)stack.getPersistentDataContainer().get(this.categoryKey, PersistentDataType.STRING);
      } else {
         return null;
      }
   }
}
