package cs.cloudstudio.manager;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import cs.cloudstudio.CloudAuction;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import org.bukkit.entity.Player;

public final class PermissionManager {
   private static final int OP_SLOTS = 999;
   private static final String SLOT_PERMISSION_PREFIX = "cloudauction.";
   private final CloudAuction plugin;
   private final Map<String, Integer> configuredPermSlots = new HashMap<>();
   private final Cache<UUID, Integer> playerSlotCache = CacheBuilder.newBuilder().expireAfterWrite(60L, TimeUnit.SECONDS).maximumSize(2048L).build();
   private int defaultConfiguredSlots;

   public PermissionManager(CloudAuction plugin) {
      this.plugin = plugin;
      this.loadGroupPermissions();
   }

   public void loadGroupPermissions() {
      this.configuredPermSlots.clear();
      this.playerSlotCache.invalidateAll();
      this.defaultConfiguredSlots = 0;
      List<String> entries = this.plugin.getConfigManager().getGroupPermissions();
      if (entries != null && !entries.isEmpty()) {
         for (String raw : entries) {
            if (raw != null) {
               String entry = raw.trim();
               int slots = this.parseSlotPermission(entry);
               if (slots >= 0) {
                  String normalized = entry.toLowerCase(Locale.ROOT);
                  this.configuredPermSlots.put(normalized, slots);
                  if (normalized.startsWith("cloudauction.default.")) {
                     this.defaultConfiguredSlots = Math.max(this.defaultConfiguredSlots, slots);
                  }
               }
            }
         }
      }
   }

   private int parseSlotPermission(String entry) {
      int length = entry.length();
      if (length > "cloudauction.".length() && this.startsWithIgnoreCase(entry, "cloudauction.")) {
         int lastDot = entry.lastIndexOf(46);
         if (lastDot > "cloudauction.".length() && lastDot != length - 1) {
            for (int i = "cloudauction.".length(); i < lastDot; i++) {
               char c = entry.charAt(i);
               boolean allowed = c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_';
               if (!allowed) {
                  return -1;
               }
            }

            int value = 0;

            for (int i = lastDot + 1; i < length; i++) {
               char c = entry.charAt(i);
               if (c < '0' || c > '9') {
                  return -1;
               }

               value = value * 10 + c - 48;
            }

            return value;
         } else {
            return -1;
         }
      } else {
         return -1;
      }
   }

   private boolean startsWithIgnoreCase(String value, String prefix) {
      if (value.length() < prefix.length()) {
         return false;
      }

      for (int i = 0; i < prefix.length(); i++) {
         char a = value.charAt(i);
         char b = prefix.charAt(i);
         if (a != b && (a | ' ') != b) {
            return false;
         }
      }

      return true;
   }

   public int getPlayerPermissionSlots(Player player) {
      UUID id = player.getUniqueId();
      Integer cached = (Integer)this.playerSlotCache.getIfPresent(id);
      if (cached != null) {
         return cached;
      }

      int slots = this.computeSlots(player);
      this.playerSlotCache.put(id, slots);
      return slots;
   }

   private int computeSlots(Player player) {
      if (player.isOp()) {
         return 999;
      }

      int best = 0;

      for (Entry<String, Integer> entry : this.configuredPermSlots.entrySet()) {
         if (player.hasPermission(entry.getKey())) {
            int slots = entry.getValue();
            if (slots > best) {
               best = slots;
            }
         }
      }

      if (best > 0) {
         return best;
      } else {
         return this.defaultConfiguredSlots > 0 ? this.defaultConfiguredSlots : this.plugin.getConfigManager().getMaxItemsDefault();
      }
   }

   public void invalidate(UUID playerId) {
      this.playerSlotCache.invalidate(playerId);
   }
}
