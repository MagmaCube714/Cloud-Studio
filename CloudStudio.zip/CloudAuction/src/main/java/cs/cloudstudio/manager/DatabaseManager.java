package cs.cloudstudio.manager;

import com.zaxxer.hikari.HikariDataSource;
import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.database.DataSourceFactory;
import cs.cloudstudio.database.DatabaseSettings;
import cs.cloudstudio.database.DatabaseType;
import cs.cloudstudio.database.SqlDialect;
import cs.cloudstudio.manager.data.AuctionItem;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;

public final class DatabaseManager {
   private static final byte[] EMPTY_BYTES = new byte[0];
   private static final String RESCUE_FILE = "returns-rescue.txt";
   private static final long SHUTDOWN_WAIT_SECONDS = 30L;
   private final CloudAuction plugin;
   private final DatabaseSettings settings;
   private final SqlDialect dialect;
   private final HikariDataSource dataSource;
   private final ExecutorService databaseExecutor;
   private final Set<DatabaseManager.MainThreadCallback> pendingCallbacks = ConcurrentHashMap.newKeySet();
   private volatile boolean closed;
   private volatile boolean draining;

   public DatabaseManager(CloudAuction plugin) {
      this.plugin = plugin;
      this.settings = plugin.getConfigManager().getDatabaseSettings();
      this.dialect = SqlDialect.of(this.settings.getType());
      this.dataSource = DataSourceFactory.create(plugin, this.settings);
      this.databaseExecutor = Executors.newSingleThreadExecutor(runnable -> {
         Thread thread = new Thread(runnable, "CloudAuction-Database");
         thread.setDaemon(true);
         return thread;
      });
      if (!this.createTables()) {
         this.dataSource.close();
         this.databaseExecutor.shutdownNow();
         throw new IllegalStateException("Database initialization failed");
      }

      this.runAsync(this::importRescuedReturns);
   }

   private boolean createTables() {
      try {
         if (this.settings.getType() == DatabaseType.SQLITE) {
            DataSourceFactory.configureSqlitePragmas(this.dataSource);
         }

         try (
            Connection connection = this.dataSource.getConnection();
            Statement statement = connection.createStatement();
         ) {
            statement.execute(this.dialect.createAuctionTableSql());
            statement.execute(this.dialect.createPendingReturnsTableSql());

            for (String sql : this.dialect.indexSql()) {
               statement.execute(sql);
            }
         }

         return true;
      } catch (SQLException e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось инициализировать базу данных: " + e.getMessage());
         return false;
      }
   }

   public void saveAuctionItemAsync(AuctionItem item) {
      this.saveAuctionItemAsync(item, null);
   }

   public void saveAuctionItemAsync(AuctionItem item, Consumer<Boolean> callback) {
      if (item != null && item.getAuctionId() != null && item.getSeller() != null && item.getItem() != null && !item.getItem().getType().isAir()) {
         UUID auctionId = item.getAuctionId();
         UUID sellerUuid = item.getSeller();
         byte[] itemData = this.serializeItem(item.getItem());
         double price = item.getPrice();
         long expireTime = item.getExpireTime();
         if (itemData.length == 0) {
            this.runCallback(callback, false);
         } else {
            this.runAsync(() -> this.runCallback(callback, this.saveAuctionItem(auctionId, sellerUuid, itemData, price, expireTime)));
         }
      } else {
         this.runCallback(callback, false);
      }
   }

   private boolean saveAuctionItem(UUID auctionId, UUID sellerUuid, byte[] itemData, double price, long expireTime) {
      try (
         Connection connection = this.dataSource.getConnection();
         PreparedStatement statement = connection.prepareStatement(this.dialect.upsertAuctionItemSql());
      ) {
         statement.setString(1, auctionId.toString());
         statement.setString(2, sellerUuid.toString());
         statement.setBytes(3, itemData);
         statement.setDouble(4, price);
         statement.setLong(5, expireTime);
         return statement.executeUpdate() > 0;
      } catch (SQLException e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось сохранить предмет аукциона " + auctionId + ": " + e.getMessage());
         return false;
      }
   }

   public void removeAuctionItemAsync(UUID auctionId, Consumer<DatabaseManager.RemoveResult> callback) {
      if (auctionId == null) {
         this.runCallback(callback, DatabaseManager.RemoveResult.NOT_FOUND);
      } else {
         this.runAsync(() -> this.runCallback(callback, this.removeAuctionItem(auctionId)));
      }
   }

   private DatabaseManager.RemoveResult removeAuctionItem(UUID auctionId) {
      try (
         Connection connection = this.dataSource.getConnection();
         PreparedStatement statement = connection.prepareStatement("DELETE FROM auction_items WHERE auction_id = ?");
      ) {
         statement.setString(1, auctionId.toString());
         return statement.executeUpdate() == 1 ? DatabaseManager.RemoveResult.REMOVED : DatabaseManager.RemoveResult.NOT_FOUND;
      } catch (SQLException e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось удалить предмет аукциона " + auctionId + ": " + e.getMessage());
         return DatabaseManager.RemoveResult.ERROR;
      }
   }

   public void removeAuctionItemsBatchAsync(List<UUID> auctionIds, Consumer<Map<UUID, DatabaseManager.RemoveResult>> callback) {
      List<UUID> copy = new ArrayList<>();
      if (auctionIds != null) {
         for (UUID auctionId : auctionIds) {
            if (auctionId != null) {
               copy.add(auctionId);
            }
         }
      }

      if (copy.isEmpty()) {
         this.runCallback(callback, new HashMap<>());
      } else {
         this.runAsync(() -> this.runCallback(callback, this.removeAuctionItemsBatch(copy)));
      }
   }

   private Map<UUID, DatabaseManager.RemoveResult> removeAuctionItemsBatch(List<UUID> auctionIds) {
      Map<UUID, DatabaseManager.RemoveResult> results = new HashMap<>(auctionIds.size() * 2);
      Connection connection = null;

      try {
         connection = this.dataSource.getConnection();
         connection.setAutoCommit(false);

         try (PreparedStatement statement = connection.prepareStatement("DELETE FROM auction_items WHERE auction_id = ?")) {
            for (UUID id : auctionIds) {
               statement.setString(1, id.toString());
               results.put(id, statement.executeUpdate() == 1 ? DatabaseManager.RemoveResult.REMOVED : DatabaseManager.RemoveResult.NOT_FOUND);
            }
         }

         connection.commit();
         return results;
      } catch (SQLException e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось удалить пакет предметов: " + e.getMessage());
         this.rollback(connection);
         results.clear();

         for (UUID id : auctionIds) {
            results.put(id, DatabaseManager.RemoveResult.ERROR);
         }

         return results;
      } finally {
         this.restoreAutoCommit(connection);
         this.closeQuietly(connection);
      }
   }

   public List<AuctionItem> loadAllAuctionItems() {
      List<AuctionItem> items = new ArrayList<>();

      try (
         Connection connection = this.dataSource.getConnection();
         PreparedStatement statement = connection.prepareStatement("SELECT auction_id, seller_uuid, item_data, price, expire_time FROM auction_items");
         ResultSet resultSet = statement.executeQuery();
      ) {
         while (resultSet.next()) {
            String rawId = resultSet.getString("auction_id");

            try {
               UUID auctionId = UUID.fromString(rawId);
               UUID sellerUuid = UUID.fromString(resultSet.getString("seller_uuid"));
               ItemStack item = this.deserializeItem(resultSet.getBytes("item_data"));
               if (item != null && !item.getType().isAir()) {
                  double price = resultSet.getDouble("price");
                  long expireTime = resultSet.getLong("expire_time");
                  items.add(new AuctionItem(auctionId, item, sellerUuid, price, expireTime));
               } else {
                  this.plugin.getLogger().warning("[CloudAuction] Лот " + rawId + " не удалось прочитать, запись оставлена в базе без изменений");
               }
            } catch (Exception e) {
               this.plugin.getLogger().warning("[CloudAuction] Не удалось загрузить предмет аукциона " + rawId + ": " + e.getMessage());
            }
         }
      } catch (SQLException e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось загрузить предметы аукциона: " + e.getMessage());
      }

      return items;
   }

   public void savePendingReturnAsync(UUID playerUuid, ItemStack item) {
      if (playerUuid != null && item != null && !item.getType().isAir()) {
         byte[] itemData = this.serializeItem(item);
         if (itemData.length != 0) {
            this.runAsync(() -> this.savePendingReturn(playerUuid, itemData));
         } else {
            this.plugin.getLogger().severe("[CloudAuction] Возврат для " + playerUuid + " не сохранён (ошибка сериализации): " + item);
         }
      }
   }

   public void savePendingReturnsBatchAsync(UUID playerUuid, List<ItemStack> items) {
      if (playerUuid != null && items != null && !items.isEmpty()) {
         Map<UUID, List<ItemStack>> single = new HashMap<>();
         single.put(playerUuid, items);
         this.savePendingReturnsBatchAsync(single);
      }
   }

   public void savePendingReturnsBatchAsync(Map<UUID, List<ItemStack>> itemsByPlayer) {
      if (itemsByPlayer != null && !itemsByPlayer.isEmpty()) {
         Map<UUID, List<byte[]>> serialized = new HashMap<>(itemsByPlayer.size());

         for (Entry<UUID, List<ItemStack>> entry : itemsByPlayer.entrySet()) {
            UUID playerUuid = entry.getKey();
            List<ItemStack> items = entry.getValue();
            if (playerUuid != null && items != null && !items.isEmpty()) {
               List<byte[]> playerItems = new ArrayList<>(items.size());

               for (ItemStack item : items) {
                  if (item != null && !item.getType().isAir()) {
                     byte[] data = this.serializeItem(item);
                     if (data.length > 0) {
                        playerItems.add(data);
                     } else {
                        this.plugin.getLogger().severe("[CloudAuction] Возврат для " + playerUuid + " не сохранён (ошибка сериализации): " + item);
                     }
                  }
               }

               if (!playerItems.isEmpty()) {
                  serialized.put(playerUuid, playerItems);
               }
            }
         }

         if (!serialized.isEmpty()) {
            this.runAsync(() -> this.savePendingReturnData(serialized));
         }
      }
   }

   private void savePendingReturn(UUID playerUuid, byte[] itemData) {
      Map<UUID, List<byte[]>> single = new HashMap<>();
      single.put(playerUuid, List.of(itemData));
      this.savePendingReturnData(single);
   }

   private void savePendingReturnData(Map<UUID, List<byte[]>> itemDataByPlayer) {
      if (!this.insertPendingReturns(itemDataByPlayer)) {
         this.rescueReturns(itemDataByPlayer);
      }
   }

   private synchronized void rescueReturns(Map<UUID, List<byte[]>> itemDataByPlayer) {
      StringBuilder lines = new StringBuilder();
      for (Entry<UUID, List<byte[]>> entry : itemDataByPlayer.entrySet()) {
         for (byte[] data : entry.getValue()) {
            lines.append(entry.getKey()).append(' ').append(Base64.getEncoder().encodeToString(data)).append('\n');
         }
      }

      Path file = this.plugin.getDataFolder().toPath().resolve(RESCUE_FILE);
      try {
         Files.createDirectories(file.getParent());
         Files.writeString(file, lines, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
         this.plugin.getLogger().severe("[CloudAuction] Возвраты " + itemDataByPlayer.keySet() + " не записаны в базу и сохранены в " + RESCUE_FILE + ", они будут перенесены при следующем запуске");
      } catch (IOException e) {
         this.plugin.getLogger().severe("[CloudAuction] КРИТИЧНО: возвраты не сохранены ни в базу, ни в файл. Данные для ручного восстановления:\n" + lines);
      }
   }

   private synchronized void importRescuedReturns() {
      Path file = this.plugin.getDataFolder().toPath().resolve(RESCUE_FILE);
      if (!Files.exists(file)) {
         return;
      }

      Map<UUID, List<byte[]>> data = new HashMap<>();
      try {
         for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            String[] parts = line.trim().split(" ", 2);
            if (parts.length == 2) {
               data.computeIfAbsent(UUID.fromString(parts[0]), ignored -> new ArrayList<>()).add(Base64.getDecoder().decode(parts[1]));
            }
         }
      } catch (IOException | IllegalArgumentException e) {
         this.plugin.getLogger().severe("[CloudAuction] Не удалось прочитать " + RESCUE_FILE + ": " + e.getMessage());
         return;
      }

      if (data.isEmpty() || this.insertPendingReturns(data)) {
         try {
            Files.deleteIfExists(file);
            if (!data.isEmpty()) {
               this.plugin.getLogger().info("[CloudAuction] Перенесено в базу возвратов из " + RESCUE_FILE + ": " + data.values().stream().mapToInt(List::size).sum());
            }
         } catch (IOException e) {
            this.plugin.getLogger().severe("[CloudAuction] Возвраты перенесены, но " + RESCUE_FILE + " не удалён: удалите его вручную, иначе они будут выданы повторно");
         }
      }
   }

   private boolean insertPendingReturns(Map<UUID, List<byte[]>> itemDataByPlayer) {
      Connection connection = null;

      try {
         connection = this.dataSource.getConnection();
         connection.setAutoCommit(false);

         try (PreparedStatement statement = connection.prepareStatement("INSERT INTO pending_returns (player_uuid, item_data) VALUES (?, ?)")) {
            for (Entry<UUID, List<byte[]>> entry : itemDataByPlayer.entrySet()) {
               String playerId = entry.getKey().toString();

               for (byte[] data : entry.getValue()) {
                  statement.setString(1, playerId);
                  statement.setBytes(2, data);
                  statement.executeUpdate();
               }
            }
         }

         connection.commit();
         return true;
      } catch (SQLException e) {
         this.plugin.getLogger().severe("[CloudAuction] Не удалось сохранить пакет возвратов " + itemDataByPlayer.keySet() + ": " + e.getMessage());
         this.rollback(connection);
         return false;
      } finally {
         this.restoreAutoCommit(connection);
         this.closeQuietly(connection);
      }
   }

   public void claimPendingReturnsAsync(UUID playerUuid, Consumer<List<ItemStack>> callback) {
      if (playerUuid != null && callback != null) {
         this.runAsync(() -> {
            List<byte[]> rawItems = this.claimPendingReturnData(playerUuid);
            if (!rawItems.isEmpty()) {
               this.runOnMain(() -> {
                  List<ItemStack> result = new ArrayList<>(rawItems.size());
                  List<byte[]> unreadable = null;

                  for (byte[] raw : rawItems) {
                     ItemStack item = this.deserializeItem(raw);
                     if (item != null && !item.getType().isAir()) {
                        result.add(item);
                     } else {
                        if (unreadable == null) {
                           unreadable = new ArrayList<>();
                        }

                        unreadable.add(raw);
                     }
                  }

                  if (unreadable != null) {
                     Map<UUID, List<byte[]>> keep = new HashMap<>();
                     keep.put(playerUuid, unreadable);
                     this.plugin.getLogger().warning("[CloudAuction] " + unreadable.size() + " возврат(ов) игрока " + playerUuid + " не удалось прочитать, они оставлены в базе");
                     this.runAsync(() -> this.savePendingReturnData(keep));
                  }

                  callback.accept(result);
               });
            }
         });
      }
   }

   private List<byte[]> claimPendingReturnData(UUID playerUuid) {
      List<byte[]> items = new ArrayList<>();
      Connection connection = null;
      String playerId = playerUuid.toString();

      try {
         connection = this.dataSource.getConnection();
         connection.setAutoCommit(false);
         Map<Long, byte[]> rows = new LinkedHashMap<>();

         try (PreparedStatement statement = connection.prepareStatement("SELECT id, item_data FROM pending_returns WHERE player_uuid = ?")) {
            statement.setString(1, playerId);

            try (ResultSet resultSet = statement.executeQuery()) {
               while (resultSet.next()) {
                  rows.put(resultSet.getLong("id"), resultSet.getBytes("item_data"));
               }
            }
         }

         if (!rows.isEmpty()) {
            try (PreparedStatement statement = connection.prepareStatement("DELETE FROM pending_returns WHERE id = ?")) {
               for (Map.Entry<Long, byte[]> row : rows.entrySet()) {
                  statement.setLong(1, row.getKey());
                  byte[] data = row.getValue();
                  if (statement.executeUpdate() == 1 && data != null && data.length > 0) {
                     items.add(data);
                  }
               }
            }
         }

         connection.commit();
      } catch (SQLException e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось получить ожидающие возвраты: " + e.getMessage());
         this.rollback(connection);
         return new ArrayList<>();
      } finally {
         this.restoreAutoCommit(connection);
         this.closeQuietly(connection);
      }

      return items;
   }

   public void resetDatabaseAsync() {
      this.runAsync(this::resetDatabase);
   }

   private void resetDatabase() {
      try (
         Connection connection = this.dataSource.getConnection();
         Statement statement = connection.createStatement();
      ) {
         statement.executeUpdate("DELETE FROM auction_items");
         statement.executeUpdate("DELETE FROM pending_returns");
      } catch (SQLException e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось сбросить базу данных: " + e.getMessage());
      }
   }

   private byte[] serializeItem(ItemStack item) {
      if (item != null && !item.getType().isAir()) {
         try {
            return item.serializeAsBytes();
         } catch (RuntimeException e) {
            this.plugin.getLogger().log(Level.WARNING, "[CloudAuction] Не удалось сериализовать предмет", e);
            return EMPTY_BYTES;
         }
      } else {
         return EMPTY_BYTES;
      }
   }

   private ItemStack deserializeItem(byte[] data) {
      if (data != null && data.length != 0) {
         if (data.length > 1 && data[0] == (byte)0xAC && data[1] == (byte)0xED) {
            return this.deserializeLegacyItem(data);
         }

         try {
            return ItemStack.deserializeBytes(data);
         } catch (RuntimeException e) {
            this.plugin.getLogger().warning("[CloudAuction] Не удалось десериализовать предмет: " + e.getMessage());
            return null;
         }
      } else {
         return null;
      }
   }

   @SuppressWarnings("deprecation")
   private ItemStack deserializeLegacyItem(byte[] data) {
      try (BukkitObjectInputStream dataInput = new BukkitObjectInputStream(new ByteArrayInputStream(data))) {
         Object object = dataInput.readObject();
         return object instanceof ItemStack ? (ItemStack)object : null;
      } catch (Exception e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось десериализовать предмет старого формата: " + e.getMessage());
         return null;
      }
   }

   private void rollback(Connection connection) {
      if (connection != null) {
         try {
            connection.rollback();
         } catch (SQLException e) {
            this.plugin.getLogger().warning("[CloudAuction] Ошибка отката транзакции: " + e.getMessage());
         }
      }
   }

   private void restoreAutoCommit(Connection connection) {
      if (connection != null) {
         try {
            connection.setAutoCommit(true);
         } catch (SQLException e) {
            this.plugin.getLogger().fine("[CloudAuction] setAutoCommit: " + e.getMessage());
         }
      }
   }

   private void closeQuietly(Connection connection) {
      if (connection != null) {
         try {
            connection.close();
         } catch (SQLException e) {
            this.plugin.getLogger().fine("[CloudAuction] close: " + e.getMessage());
         }
      }
   }

   private <T> void runCallback(Consumer<T> callback, T result) {
      if (callback != null) {
         this.runOnMain(() -> callback.accept(result));
      }
   }

   private void runOnMain(Runnable body) {
      DatabaseManager.MainThreadCallback callback = new DatabaseManager.MainThreadCallback(body);
      this.pendingCallbacks.add(callback);
      if (!this.draining && this.plugin.isEnabled()) {
         try {
            Bukkit.getScheduler().runTask(this.plugin, callback);
         } catch (RuntimeException e) {
            this.plugin.getLogger().fine("[CloudAuction] Колбэк отложен до выгрузки: " + e.getMessage());
         }
      }
   }

   public void disconnect() {
      this.closed = true;
      this.databaseExecutor.shutdown();

      try {
         if (!this.databaseExecutor.awaitTermination(SHUTDOWN_WAIT_SECONDS, TimeUnit.SECONDS)) {
            this.plugin.getLogger().severe("[CloudAuction] Операции с базой не завершились за " + SHUTDOWN_WAIT_SECONDS + " с");
            this.databaseExecutor.shutdownNow();
         }
      } catch (InterruptedException e) {
         this.databaseExecutor.shutdownNow();
         Thread.currentThread().interrupt();
      }

      this.draining = true;
      this.drainCallbacks();
      this.dataSource.close();
   }

   private void drainCallbacks() {
      int guard = 0;

      while (!this.pendingCallbacks.isEmpty() && guard++ < 64) {
         for (DatabaseManager.MainThreadCallback callback : new ArrayList<>(this.pendingCallbacks)) {
            try {
               callback.run();
            } catch (RuntimeException e) {
               this.plugin.getLogger().log(Level.SEVERE, "[CloudAuction] Ошибка при завершении операции во время выгрузки", e);
            }
         }
      }
   }

   private void runAsync(Runnable task) {
      if (!this.closed && !this.databaseExecutor.isShutdown()) {
         try {
            this.databaseExecutor.execute(task);
            return;
         } catch (RejectedExecutionException e) {
            this.plugin.getLogger().fine("[CloudAuction] Пул базы остановлен, выполняю синхронно");
         }
      }

      if (this.dataSource.isClosed()) {
         this.plugin.getLogger().severe("[CloudAuction] Операция с базой после закрытия пула отброшена");
      } else {
         task.run();
      }
   }

   public static enum RemoveResult {
      REMOVED,
      NOT_FOUND,
      ERROR;
   }

   private final class MainThreadCallback implements Runnable {
      private final Runnable body;
      private final AtomicBoolean done = new AtomicBoolean();

      private MainThreadCallback(Runnable body) {
         this.body = body;
      }

      @Override
      public void run() {
         if (this.done.compareAndSet(false, true)) {
            DatabaseManager.this.pendingCallbacks.remove(this);
            this.body.run();
         }
      }
   }
}
