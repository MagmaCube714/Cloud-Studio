package cs.cloudstudio.manager.data;

import java.math.BigDecimal;
import java.util.UUID;
import org.bukkit.inventory.ItemStack;

public final class AuctionItem {
   private final UUID auctionId;
   private final ItemStack item;
   private final UUID seller;
   private final double price;
   private final String formattedPrice;
   private final long expireTime;

   public AuctionItem(UUID auctionId, ItemStack item, UUID seller, double price, long expireTime) {
      this.auctionId = auctionId;
      this.item = item;
      this.seller = seller;
      this.price = price;
      this.formattedPrice = BigDecimal.valueOf(price).stripTrailingZeros().toPlainString();
      this.expireTime = expireTime;
   }

   public UUID getAuctionId() {
      return this.auctionId;
   }

   public ItemStack getItem() {
      return this.item;
   }

   public UUID getSeller() {
      return this.seller;
   }

   public double getPrice() {
      return this.price;
   }

   public String getFormattedPrice() {
      return this.formattedPrice;
   }

   public long getExpireTime() {
      return this.expireTime;
   }
}
