package cs.cloudstudio.manager.data;

import java.util.Comparator;

public enum SortType {
   NEWEST((a, b) -> Long.compare(b.getExpireTime(), a.getExpireTime())),
   OLDEST((a, b) -> Long.compare(a.getExpireTime(), b.getExpireTime())),
   CHEAPEST((a, b) -> Double.compare(a.getPrice(), b.getPrice())),
   EXPENSIVE((a, b) -> Double.compare(b.getPrice(), a.getPrice()));

   private static final SortType[] VALUES = values();
   private final Comparator<AuctionItem> comparator;

   SortType(Comparator<AuctionItem> comparator) {
      this.comparator = comparator;
   }

   public Comparator<AuctionItem> getComparator() {
      return this.comparator;
   }

   public SortType next() {
      return VALUES[(this.ordinal() + 1) % VALUES.length];
   }
}
