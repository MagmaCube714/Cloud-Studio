package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.manager.data.AuctionItem;
import cs.cloudstudio.manager.data.Category;
import cs.cloudstudio.manager.data.SortType;
import cs.cloudstudio.util.InventoryUtility;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitTask;

public final class AuctionManager {
   private static final double MIN_PRICE = 1.0;
   private static final double MAX_PRICE = 1.0E18;
   private static final int MAX_SUGGESTIONS = 20;
   private static final int MAX_EXPIRED_PER_BATCH = 128;
   private static final int MAX_EXPIRY_QUEUE_SCANS_PER_BATCH = 512;
   private final CloudAuction plugin;
   private final Map<UUID, AuctionItem> items;
   private final Map<UUID, String> cleanNameCache;
   private final Map<UUID, Set<UUID>> bySeller;
   private final Map<UUID, Integer> listingReservations;
   private final PriorityQueue<AuctionManager.ExpiryEntry> expiryQueue;
   private final Set<UUID> processing;
   private final Set<UUID> playerTransactions;
   private final Set<UUID> unpersisted;
   private final NamespacedKey auctionIdKey;
   private final NamespacedKey categoryKey;
   private boolean expiryCleanupInFlight;
   private boolean expirySchedulingStarted;
   private BukkitTask expiryCleanupTask;
   private long scheduledExpiryTime = Long.MAX_VALUE;
   private long expiryRetryAfter;
   private final Map<Integer, AuctionManager.SortedListing> sortedListings = new HashMap<>();
   private long listingRevision;

   public AuctionManager(CloudAuction plugin) {
      this.plugin = plugin;
      this.unpersisted = new HashSet<>();
      this.items = new HashMap<>();
      this.cleanNameCache = new HashMap<>();
      this.bySeller = new HashMap<>();
      this.listingReservations = new HashMap<>();
      this.expiryQueue = new PriorityQueue<>();
      this.processing = new HashSet<>();
      this.playerTransactions = new HashSet<>();
      this.auctionIdKey = new NamespacedKey(plugin, "auction_id");
      this.categoryKey = new NamespacedKey(plugin, "category");
      this.loadItems();
   }

   private void loadItems() {
      this.touchListings();
      this.items.clear();
      this.cleanNameCache.clear();
      this.bySeller.clear();
      this.listingReservations.clear();
      this.processing.clear();
      this.playerTransactions.clear();
      this.expiryQueue.clear();
      this.expiryCleanupInFlight = false;

      for (AuctionItem item : this.plugin.getDatabaseManager().loadAllAuctionItems()) {
         if (this.isValidAuctionItem(item)) {
            this.indexAdd(item);
         }
      }
   }

   private void touchListings() {
      this.listingRevision++;
      this.sortedListings.clear();
   }

   public List<AuctionItem> getSortedItems(Category category, SortType sortType) {
      Category selectedCategory = category == null ? Category.ALL : category;
      long now = System.currentTimeMillis();
      AuctionManager.SortedListing cached = this.sortedListings.get(selectedCategory.ordinal() * 16 + sortType.ordinal());
      if (cached != null && cached.revision == this.listingRevision && now < cached.validUntil) {
         return cached.items;
      }

      List<AuctionItem> result = this.getItems(selectedCategory, null, null);
      result.sort(sortType.getComparator());
      long validUntil = Long.MAX_VALUE;

      for (int i = 0, size = result.size(); i < size; i++) {
         long expireTime = result.get(i).getExpireTime();
         if (expireTime < validUntil) {
            validUntil = expireTime;
         }
      }

      List<AuctionItem> items = Collections.unmodifiableList(result);
      this.sortedListings.put(selectedCategory.ordinal() * 16 + sortType.ordinal(), new AuctionManager.SortedListing(this.listingRevision, validUntil, items));
      return items;
   }

   private static final class SortedListing {
      private final long revision;
      private final long validUntil;
      private final List<AuctionItem> items;

      private SortedListing(long revision, long validUntil, List<AuctionItem> items) {
         this.revision = revision;
         this.validUntil = validUntil;
         this.items = items;
      }
   }

   private void indexAdd(AuctionItem item) {
      this.touchListings();
      this.items.put(item.getAuctionId(), item);
      this.expiryQueue.add(new AuctionManager.ExpiryEntry(item.getAuctionId(), item.getExpireTime()));
      this.scheduleNextExpiryCleanup();
      this.cleanNameCache.remove(item.getAuctionId());
      Set<UUID> sellerItems = this.bySeller.get(item.getSeller());
      if (sellerItems == null) {
         sellerItems = new HashSet<>();
         this.bySeller.put(item.getSeller(), sellerItems);
      }

      sellerItems.add(item.getAuctionId());
   }

   private AuctionItem indexRemove(UUID auctionId) {
      AuctionItem item = this.items.remove(auctionId);
      if (item != null) {
         this.touchListings();
         this.removeSecondaryIndexes(item);
      }

      return item;
   }

   private void removeSecondaryIndexes(AuctionItem item) {
      this.cleanNameCache.remove(item.getAuctionId());
      Set<UUID> sellerSet = this.bySeller.get(item.getSeller());
      if (sellerSet != null) {
         sellerSet.remove(item.getAuctionId());
         if (sellerSet.isEmpty()) {
            this.bySeller.remove(item.getSeller());
         }
      }
   }

   public void listItem(Player player, ItemStack item, double price) {
      if (!this.isValidItem(item)) {
         player.sendMessage(this.plugin.getConfigManager().getMessage("messages.noItemInHand"));
      } else if (!this.isValidPrice(price)) {
         player.sendMessage(this.plugin.getConfigManager().getMessage("messages.invalidPrice"));
      } else {
         UUID sellerId = player.getUniqueId();
         if (this.playerTransactions.add(sellerId)) {
            if (this.plugin.getTridentDupeListener().isReadyToThrow(sellerId)) {
               this.playerTransactions.remove(sellerId);
               player.sendMessage(this.plugin.getConfigManager().getMessage("messages.noItemInHand"));
            } else {
               int max = this.plugin.getPermissionManager().getPlayerPermissionSlots(player);
               if (this.getActiveItemsCount(player) + this.getReservedListings(sellerId) >= max) {
                  player.sendMessage(this.plugin.getConfigManager().getMessage("messages.maxItemsReached"));
                  this.playerTransactions.remove(sellerId);
               } else {
                  ItemStack currentItem = player.getInventory().getItemInMainHand();
                  if (this.isSameHandItem(currentItem, item) && !player.isHandRaised()) {
                     ItemStack clone = currentItem.clone();
                     ItemStack finalCheck = player.getInventory().getItemInMainHand();
                     if (!this.isSameHandItem(finalCheck, currentItem)) {
                        player.sendMessage(this.plugin.getConfigManager().getMessage("messages.noItemInHand"));
                        this.playerTransactions.remove(sellerId);
                     } else {
                        this.sanitizeAuctionItem(clone);
                        player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
                        player.updateInventory();
                        UUID auctionId = UUID.randomUUID();
                        long expireTime = System.currentTimeMillis() + this.plugin.getConfigManager().getListingDurationMillis();
                        AuctionItem auctionItem = new AuctionItem(auctionId, clone, sellerId, price, expireTime);
                        this.addListingReservation(sellerId);
                        this.plugin.getDatabaseManager().saveAuctionItemAsync(auctionItem, saved -> {
                           this.playerTransactions.remove(sellerId);
                           this.removeListingReservation(sellerId);
                           if (!saved) {
                              this.returnToSeller(auctionItem, "messages.itemReturned");
                           } else {
                              this.indexAdd(auctionItem);
                              Player seller = Bukkit.getPlayer(sellerId);
                              if (seller != null) {
                                 seller.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemListed"));
                              }
                           }
                        });
                     }
                  } else {
                     player.sendMessage(this.plugin.getConfigManager().getMessage("messages.noItemInHand"));
                     this.playerTransactions.remove(sellerId);
                  }
               }
            }
         }
      }
   }

   public void buyItem(Player buyer, UUID itemId) {
      if (itemId != null) {
         if (!this.processing.add(itemId)) {
            buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemAlreadySold"));
         } else {
            UUID buyerId = buyer.getUniqueId();
            if (!this.playerTransactions.add(buyerId)) {
               this.processing.remove(itemId);
               buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemAlreadySold"));
            } else {
               String buyerName = buyer.getName();
               AuctionItem item = this.items.get(itemId);
               if (!this.canStartPurchase(buyer, item)) {
                  this.playerTransactions.remove(buyerId);
                  this.processing.remove(itemId);
               } else {
                  this.indexRemove(itemId);
                  this.plugin.getDatabaseManager().removeAuctionItemAsync(itemId, result -> {
                     try {
                        if (this.isRemoved(item, result)) {
                           this.finishPurchase(buyerId, buyerName, item);
                           return;
                        }

                        this.handleFailedRemoval(item, result);
                        Player onlineBuyer = Bukkit.getPlayer(buyerId);
                        if (onlineBuyer != null) {
                           onlineBuyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemAlreadySold"));
                        }
                     } finally {
                        this.playerTransactions.remove(buyerId);
                        this.processing.remove(itemId);
                     }
                  });
               }
            }
         }
      }
   }

   private boolean canStartPurchase(Player buyer, AuctionItem item) {
      if (item == null) {
         buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemAlreadySold"));
         return false;
      } else if (this.plugin.getConfigManager().isExpired(item.getExpireTime())) {
         buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemExpired"));
         return false;
      } else if (item.getSeller().equals(buyer.getUniqueId())) {
         buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.cantBuyOwnItem"));
         return false;
      } else {
         Economy economy = this.plugin.getVaultHook().getEconomy();
         if (economy == null) {
            return false;
         } else if (!economy.has(buyer, item.getPrice())) {
            buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.notEnoughMoney"));
            return false;
         } else if (!InventoryUtility.canFit(buyer, item.getItem())) {
            buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.inventoryFull"));
            return false;
         } else {
            return true;
         }
      }
   }

   private void finishPurchase(UUID buyerId, String buyerName, AuctionItem item) {
      Player buyer = Bukkit.getPlayer(buyerId);
      if (buyer == null || !buyer.isOnline()) {
         this.restoreAuctionItem(item);
         return;
      }

      if (this.plugin.getConfigManager().isExpired(item.getExpireTime())) {
         this.restoreAuctionItem(item);
         buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemExpired"));
         return;
      }

      if (!InventoryUtility.canFit(buyer, item.getItem())) {
         this.restoreAuctionItem(item);
         buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.inventoryFull"));
         return;
      }

      Economy economy = this.plugin.getVaultHook().getEconomy();
      if (economy == null) {
         this.restoreAuctionItem(item);
         return;
      }

      double price = item.getPrice();
      if (!economy.has(buyer, price)) {
         this.restoreAuctionItem(item);
         buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.notEnoughMoney"));
         return;
      }

      EconomyResponse withdraw = economy.withdrawPlayer(buyer, price);
      if (withdraw == null || !withdraw.transactionSuccess()) {
         this.restoreAuctionItem(item);
         buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.notEnoughMoney"));
         return;
      }

      OfflinePlayer sellerAccount = Bukkit.getOfflinePlayer(item.getSeller());
      EconomyResponse deposit = economy.depositPlayer(sellerAccount, price);
      if (deposit == null || !deposit.transactionSuccess()) {
         EconomyResponse refund = economy.depositPlayer(buyer, price);
         if (refund == null || !refund.transactionSuccess()) {
            this.plugin
               .getLogger()
               .severe(
                  "[CloudAuction] Не удалось вернуть "
                     + price
                     + " покупателю "
                     + buyerName
                     + " ("
                     + buyerId
                     + ") после ошибки зачисления продавцу "
                     + item.getSeller()
                     + ", лот "
                     + item.getAuctionId()
               );
         }

         this.restoreAuctionItem(item);
         buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemAlreadySold"));
         return;
      }

      ItemStack leftover = InventoryUtility.giveOrLeftover(buyer, item.getItem());
      if (leftover != null) {
         this.plugin.getDatabaseManager().savePendingReturnAsync(buyerId, leftover);
         buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.inventoryFullPending"));
      }

      buyer.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemPurchased"));
      Player seller = Bukkit.getPlayer(item.getSeller());
      if (seller != null) {
         String saleMessage = this.plugin
            .getConfigManager()
            .getMessage("messages.itemSold")
            .replace("{buyer}", buyerName)
            .replace("{item}", this.plugin.getItemTranslator().getTranslatedName(item.getItem()))
            .replace("{price}", item.getFormattedPrice());
         seller.sendMessage(saleMessage);
      }
   }

   public void returnItem(Player player, UUID itemId) {
      if (itemId != null) {
         if (this.processing.add(itemId)) {
            UUID playerId = player.getUniqueId();
            if (!this.playerTransactions.add(playerId)) {
               this.processing.remove(itemId);
            } else {
               AuctionItem item = this.items.get(itemId);
               if (item == null) {
                  this.playerTransactions.remove(playerId);
                  this.processing.remove(itemId);
                  player.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemNotFound"));
               } else if (!item.getSeller().equals(playerId)) {
                  this.playerTransactions.remove(playerId);
                  this.processing.remove(itemId);
                  player.sendMessage(this.plugin.getConfigManager().getMessage("messages.notYourItem"));
               } else {
                  this.indexRemove(itemId);
                  this.plugin.getDatabaseManager().removeAuctionItemAsync(itemId, result -> {
                     try {
                        if (this.isRemoved(item, result)) {
                           this.returnToSeller(item, "messages.itemReturned");
                           return;
                        }

                        this.handleFailedRemoval(item, result);
                        Player seller = Bukkit.getPlayer(playerId);
                        if (seller != null) {
                           seller.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemNotFound"));
                        }
                     } finally {
                        this.playerTransactions.remove(playerId);
                        this.processing.remove(itemId);
                     }
                  });
               }
            }
         }
      }
   }

   public void claimExpiredItem(Player player, UUID itemId) {
      if (itemId != null) {
         if (!this.processing.add(itemId)) {
            player.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemAlreadySold"));
         } else {
            UUID playerId = player.getUniqueId();
            if (!this.playerTransactions.add(playerId)) {
               this.processing.remove(itemId);
            } else {
               AuctionItem item = this.items.get(itemId);
               if (item == null) {
                  this.playerTransactions.remove(playerId);
                  this.processing.remove(itemId);
                  player.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemNotFound"));
               } else if (!item.getSeller().equals(playerId)) {
                  this.playerTransactions.remove(playerId);
                  this.processing.remove(itemId);
                  player.sendMessage(this.plugin.getConfigManager().getMessage("messages.notYourItem"));
               } else if (!this.plugin.getConfigManager().isExpired(item.getExpireTime())) {
                  this.playerTransactions.remove(playerId);
                  this.processing.remove(itemId);
                  player.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemNotExpired"));
               } else if (!InventoryUtility.canFit(player, item.getItem())) {
                  this.playerTransactions.remove(playerId);
                  this.processing.remove(itemId);
                  player.sendMessage(this.plugin.getConfigManager().getMessage("messages.inventoryFull"));
               } else {
                  this.indexRemove(itemId);
                  this.plugin.getDatabaseManager().removeAuctionItemAsync(itemId, result -> {
                     try {
                        if (this.isRemoved(item, result)) {
                           this.returnToSeller(item, "messages.expiredItemClaimed");
                           return;
                        }

                        this.handleFailedRemoval(item, result);
                        Player seller = Bukkit.getPlayer(playerId);
                        if (seller != null) {
                           seller.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemNotFound"));
                        }
                     } finally {
                        this.playerTransactions.remove(playerId);
                        this.processing.remove(itemId);
                     }
                  });
               }
            }
         }
      }
   }

   public void cleanupExpiredItems() {
      if (this.expiryCleanupTask != null) {
         this.expiryCleanupTask.cancel();
         this.expiryCleanupTask = null;
         this.scheduledExpiryTime = Long.MAX_VALUE;
      }

      if (!this.expiryCleanupInFlight) {
         long now = System.currentTimeMillis();
         List<AuctionItem> expired = new ArrayList<>();
         List<UUID> expiredIds = new ArrayList<>();
         List<AuctionManager.ExpiryEntry> deferred = new ArrayList<>();
         int scanned = 0;

         while (expired.size() < 128 && scanned++ < 512) {
            AuctionManager.ExpiryEntry entry = this.expiryQueue.peek();
            if (entry == null || entry.expireTime > now) {
               break;
            }

            this.expiryQueue.poll();
            AuctionItem item = this.items.get(entry.auctionId);
            if (item != null && item.getExpireTime() == entry.expireTime) {
               UUID auctionId = item.getAuctionId();
               if (!this.processing.add(auctionId)) {
                  deferred.add(entry);
               } else {
                  expired.add(item);
                  expiredIds.add(auctionId);
               }
            }
         }

         this.expiryQueue.addAll(deferred);
         if (expired.isEmpty()) {
            this.compactExpiryQueueIfNeeded();
            this.scheduleNextExpiryCleanup();
         } else {
            for (UUID auctionId : expiredIds) {
               this.indexRemove(auctionId);
            }

            List<AuctionItem> expiredItems = expired;
            List<UUID> ids = expiredIds;
            this.expiryCleanupInFlight = true;
            this.plugin.getDatabaseManager().removeAuctionItemsBatchAsync(ids, results -> {
               try {
                  List<AuctionItem> removedItems = new ArrayList<>(expiredItems.size());
                  boolean failed = false;

                  for (AuctionItem item : expiredItems) {
                     DatabaseManager.RemoveResult result = results.get(item.getAuctionId());
                     if (result == null) {
                        result = DatabaseManager.RemoveResult.ERROR;
                     }

                     if (this.isRemoved(item, result)) {
                        removedItems.add(item);
                     } else {
                        if (result == DatabaseManager.RemoveResult.ERROR) {
                           failed = true;
                        }

                        this.handleFailedRemoval(item, result);
                     }
                  }

                  if (failed) {
                     this.expiryRetryAfter = System.currentTimeMillis() + 30000L;
                  }

                  if (!removedItems.isEmpty()) {
                     this.deliverExpiredItems(removedItems);
                  }
               } finally {
                  for (UUID auctionIdx : ids) {
                     this.processing.remove(auctionIdx);
                  }

                  this.expiryCleanupInFlight = false;
                  this.compactExpiryQueueIfNeeded();
                  this.scheduleNextExpiryCleanup();
               }
            });
         }
      }
   }

   public void startExpiryCleanup() {
      this.expirySchedulingStarted = true;
      this.cleanupExpiredItems();
   }

   private void scheduleNextExpiryCleanup() {
      if (this.expirySchedulingStarted && !this.expiryCleanupInFlight && this.plugin.isEnabled()) {
         AuctionManager.ExpiryEntry next = this.liveExpiryHead();
         if (next == null) {
            if (this.expiryCleanupTask != null) {
               this.expiryCleanupTask.cancel();
               this.expiryCleanupTask = null;
            }

            this.scheduledExpiryTime = Long.MAX_VALUE;
         } else {
            long runAt = Math.max(next.expireTime, this.expiryRetryAfter);
            if (this.expiryCleanupTask == null || this.expiryCleanupTask.isCancelled() || this.scheduledExpiryTime > runAt) {
               if (this.expiryCleanupTask != null) {
                  this.expiryCleanupTask.cancel();
               }

               this.scheduledExpiryTime = runAt;
               long delayMillis = Math.max(0L, runAt - System.currentTimeMillis());
               long delayTicks = Math.max(1L, (delayMillis + 49L) / 50L);
               this.expiryCleanupTask = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                  this.expiryCleanupTask = null;
                  this.scheduledExpiryTime = Long.MAX_VALUE;
                  this.cleanupExpiredItems();
               }, delayTicks);
            }
         }
      }
   }

   private AuctionManager.ExpiryEntry liveExpiryHead() {
      while (true) {
         AuctionManager.ExpiryEntry entry = this.expiryQueue.peek();
         if (entry == null) {
            return null;
         }

         AuctionItem item = this.items.get(entry.auctionId);
         if (item != null && item.getExpireTime() == entry.expireTime) {
            return entry;
         }

         this.expiryQueue.poll();
      }
   }

   private void compactExpiryQueueIfNeeded() {
      int liveSize = this.items.size();
      int threshold = Math.max(1024, liveSize * 3 + 64);
      if (this.expiryQueue.size() > threshold) {
         this.expiryQueue.clear();

         for (AuctionItem item : this.items.values()) {
            this.expiryQueue.add(new AuctionManager.ExpiryEntry(item.getAuctionId(), item.getExpireTime()));
         }
      }
   }

   private void deliverExpiredItems(List<AuctionItem> expiredItems) {
      Map<UUID, List<ItemStack>> pendingReturns = null;
      Set<UUID> notifiedFull = null;

      for (AuctionItem item : expiredItems) {
         Player seller = Bukkit.getPlayer(item.getSeller());
         ItemStack leftover = seller == null ? item.getItem().clone() : InventoryUtility.giveOrLeftover(seller, item.getItem());
         if (leftover == null) {
            seller.sendMessage(this.plugin.getConfigManager().getMessage("messages.itemExpiredReturned"));
         } else {
            if (pendingReturns == null) {
               pendingReturns = new HashMap<>();
            }

            List<ItemStack> playerItems = pendingReturns.get(item.getSeller());
            if (playerItems == null) {
               playerItems = new ArrayList<>();
               pendingReturns.put(item.getSeller(), playerItems);
            }

            playerItems.add(leftover);
            if (seller != null) {
               if (notifiedFull == null) {
                  notifiedFull = new HashSet<>();
               }

               if (notifiedFull.add(item.getSeller())) {
                  seller.sendMessage(this.plugin.getConfigManager().getMessage("messages.inventoryFullPending"));
               }
            }
         }
      }

      if (pendingReturns != null) {
         this.plugin.getDatabaseManager().savePendingReturnsBatchAsync(pendingReturns);
      }
   }

   public void tryReturnPendingItems(Player player) {
      UUID playerId = player.getUniqueId();
      this.plugin.getDatabaseManager().claimPendingReturnsAsync(playerId, pendingItems -> {
         if (!pendingItems.isEmpty()) {
            Player onlinePlayer = Bukkit.getPlayer(playerId);
            if (onlinePlayer == null) {
               this.plugin.getDatabaseManager().savePendingReturnsBatchAsync(playerId, pendingItems);
            } else {
               boolean anyReturned = false;
               List<ItemStack> leftovers = null;

               for (ItemStack item : pendingItems) {
                  ItemStack leftover = InventoryUtility.giveOrLeftover(onlinePlayer, item);
                  if (leftover == null) {
                     anyReturned = true;
                  } else {
                     if (leftover.getAmount() < item.getAmount()) {
                        anyReturned = true;
                     }

                     if (leftovers == null) {
                        leftovers = new ArrayList<>();
                     }

                     leftovers.add(leftover);
                  }
               }

               if (leftovers != null) {
                  this.plugin.getDatabaseManager().savePendingReturnsBatchAsync(playerId, leftovers);
               }

               if (anyReturned) {
                  onlinePlayer.sendMessage(this.plugin.getConfigManager().getMessage("messages.expiredItemsReturned"));
               }
            }
         }
      });
   }

   public List<AuctionItem> getItems(Category category, String searchQuery) {
      return this.getItems(category, searchQuery, null);
   }

   public List<AuctionItem> getItems(Category category, String searchQuery, UUID excludePlayer) {
      Category selectedCategory = category == null ? Category.ALL : category;
      List<AuctionItem> result = new ArrayList<>(this.items.size());
      boolean hasSearch = searchQuery != null && !searchQuery.isEmpty();
      String cleanQuery = hasSearch ? this.plugin.getItemTranslator().cleanItemName(searchQuery) : null;
      long now = System.currentTimeMillis();

      for (AuctionItem item : this.items.values()) {
         if (item.getExpireTime() > now
            && (excludePlayer == null || !item.getSeller().equals(excludePlayer))
            && (selectedCategory == Category.ALL || selectedCategory.contains(item.getItem().getType()))
            && (cleanQuery == null || this.matchesCleanSearch(item, cleanQuery))) {
            result.add(item);
         }
      }

      return result;
   }

   public List<String> suggestItemNames(String partial) {
      String query = this.plugin.getItemTranslator().cleanItemName(partial);
      Set<String> uniqueNames = new HashSet<>();
      long now = System.currentTimeMillis();

      for (AuctionItem item : this.items.values()) {
         if (item.getExpireTime() > now) {
            String name = this.getCachedCleanName(item);
            if (!name.isEmpty() && name.contains(query)) {
               uniqueNames.add(name);
            }
         }
      }

      List<String> suggestions = new ArrayList<>(uniqueNames);
      Collections.sort(suggestions);
      return suggestions.size() <= 20 ? suggestions : new ArrayList<>(suggestions.subList(0, 20));
   }

   public List<AuctionItem> getPlayerItems(Player player) {
      Set<UUID> ids = this.bySeller.get(player.getUniqueId());
      if (ids != null && !ids.isEmpty()) {
         List<AuctionItem> result = new ArrayList<>(ids.size());

         for (UUID id : ids) {
            AuctionItem item = this.items.get(id);
            if (item != null) {
               result.add(item);
            }
         }

         result.sort((a, b) -> Long.compare(b.getExpireTime(), a.getExpireTime()));
         return result;
      } else {
         return Collections.emptyList();
      }
   }

   public int[] getActiveAndExpiredItemsCount(Player player) {
      Set<UUID> ids = this.bySeller.get(player.getUniqueId());
      if (ids != null && !ids.isEmpty()) {
         int active = 0;
         int expired = 0;
         long now = System.currentTimeMillis();

         for (UUID id : ids) {
            AuctionItem item = this.items.get(id);
            if (item != null) {
               if (item.getExpireTime() <= now) {
                  expired++;
               } else {
                  active++;
               }
            }
         }

         return new int[]{active, expired};
      } else {
         return new int[]{0, 0};
      }
   }

   public int getActiveItemsCount(Player player) {
      Set<UUID> ids = this.bySeller.get(player.getUniqueId());
      if (ids != null && !ids.isEmpty()) {
         int active = 0;
         long now = System.currentTimeMillis();

         for (UUID id : ids) {
            AuctionItem item = this.items.get(id);
            if (item != null && item.getExpireTime() > now) {
               active++;
            }
         }

         return active;
      } else {
         return 0;
      }
   }

   public int getExpiredItemsCount(Player player) {
      Set<UUID> ids = this.bySeller.get(player.getUniqueId());
      if (ids != null && !ids.isEmpty()) {
         int expired = 0;
         long now = System.currentTimeMillis();

         for (UUID id : ids) {
            AuctionItem item = this.items.get(id);
            if (item != null && item.getExpireTime() <= now) {
               expired++;
            }
         }

         return expired;
      } else {
         return 0;
      }
   }

   public AuctionItem getItem(UUID id) {
      return this.items.get(id);
   }

   public List<AuctionItem> getAllItems() {
      Collection<AuctionItem> values = this.items.values();
      return new ArrayList<>(values);
   }

   public void resetAllData() {
      this.touchListings();
      this.items.clear();
      this.cleanNameCache.clear();
      this.bySeller.clear();
      this.listingReservations.clear();
      this.processing.clear();
      this.playerTransactions.clear();
      this.unpersisted.clear();
      this.expiryQueue.clear();
      this.plugin.getDatabaseManager().resetDatabaseAsync();
   }

   public boolean isTransactionLocked(UUID playerId) {
      return playerId != null && this.playerTransactions.contains(playerId);
   }

   private void returnToSeller(AuctionItem item, String messagePath) {
      Player seller = Bukkit.getPlayer(item.getSeller());
      ItemStack leftover = seller == null ? item.getItem().clone() : InventoryUtility.giveOrLeftover(seller, item.getItem());
      if (leftover == null) {
         seller.sendMessage(this.plugin.getConfigManager().getMessage(messagePath));
      } else {
         this.plugin.getDatabaseManager().savePendingReturnAsync(item.getSeller(), leftover);
         if (seller != null) {
            seller.sendMessage(this.plugin.getConfigManager().getMessage("messages.inventoryFullPending"));
         }
      }
   }

   private boolean isRemoved(AuctionItem item, DatabaseManager.RemoveResult result) {
      if (result == DatabaseManager.RemoveResult.REMOVED) {
         this.unpersisted.remove(item.getAuctionId());
         return true;
      } else {
         return result == DatabaseManager.RemoveResult.NOT_FOUND && this.unpersisted.remove(item.getAuctionId());
      }
   }

   private void handleFailedRemoval(AuctionItem item, DatabaseManager.RemoveResult result) {
      if (result == DatabaseManager.RemoveResult.NOT_FOUND) {
         this.plugin
            .getLogger()
            .warning("[CloudAuction] Лот " + item.getAuctionId() + " продавца " + item.getSeller() + " уже отсутствует в базе, повторно не выставляется");
      } else {
         this.restoreAuctionItem(item);
      }
   }

   public void rebuildNameCache() {
      this.cleanNameCache.clear();

      for (AuctionItem item : this.items.values()) {
         this.cleanNameCache.put(item.getAuctionId(), this.plugin.getItemTranslator().getCleanTranslatedName(item.getItem()));
      }
   }

   private void restoreAuctionItem(AuctionItem item) {
      if (item != null && !this.items.containsKey(item.getAuctionId())) {
         UUID auctionId = item.getAuctionId();
         this.indexAdd(item);
         this.unpersisted.add(auctionId);
         this.plugin.getDatabaseManager().saveAuctionItemAsync(item, saved -> {
            if (saved) {
               this.unpersisted.remove(auctionId);
            } else {
               this.plugin.getLogger().severe("[CloudAuction] Лот " + auctionId + " восстановлен только в памяти, запись в базу не удалась");
            }
         });
      }
   }

   private void addListingReservation(UUID sellerId) {
      Integer current = this.listingReservations.get(sellerId);
      this.listingReservations.put(sellerId, current == null ? 1 : current + 1);
   }

   private void removeListingReservation(UUID sellerId) {
      Integer current = this.listingReservations.get(sellerId);
      if (current != null && current > 1) {
         this.listingReservations.put(sellerId, current - 1);
      } else {
         this.listingReservations.remove(sellerId);
      }
   }

   private int getReservedListings(UUID sellerId) {
      Integer reserved = this.listingReservations.get(sellerId);
      return reserved == null ? 0 : reserved;
   }

   private boolean matchesCleanSearch(AuctionItem item, String cleanQuery) {
      return this.getCachedCleanName(item).contains(cleanQuery);
   }

   private String getCachedCleanName(AuctionItem item) {
      if (item == null) {
         return "";
      }

      String name = this.cleanNameCache.get(item.getAuctionId());
      if (name != null) {
         return name;
      }

      name = this.plugin.getItemTranslator().getCleanTranslatedName(item.getItem());
      this.cleanNameCache.put(item.getAuctionId(), name);
      return name;
   }

   private boolean isSameHandItem(ItemStack currentItem, ItemStack originalItem) {
      return this.isValidItem(currentItem) && currentItem.isSimilar(originalItem) && currentItem.getAmount() == originalItem.getAmount();
   }

   private boolean isValidItem(ItemStack item) {
      return item != null && !item.getType().isAir();
   }

   private boolean isValidAuctionItem(AuctionItem item) {
      return item != null
         && item.getAuctionId() != null
         && item.getSeller() != null
         && this.isValidItem(item.getItem())
         && this.isValidPrice(item.getPrice())
         && item.getExpireTime() > 0L;
   }

   private boolean isValidPrice(double price) {
      return price >= 1.0 && price <= 1.0E18 && !Double.isNaN(price) && !Double.isInfinite(price);
   }

   private ItemStack sanitizeAuctionItem(ItemStack item) {
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      meta.getPersistentDataContainer().remove(this.auctionIdKey);
      meta.getPersistentDataContainer().remove(this.categoryKey);
      item.setItemMeta(meta);
      return item;
   }

   private static final class ExpiryEntry implements Comparable<AuctionManager.ExpiryEntry> {
      private final UUID auctionId;
      private final long expireTime;

      private ExpiryEntry(UUID auctionId, long expireTime) {
         this.auctionId = auctionId;
         this.expireTime = expireTime;
      }

      public int compareTo(AuctionManager.ExpiryEntry other) {
         return Long.compare(this.expireTime, other.expireTime);
      }
   }
}
