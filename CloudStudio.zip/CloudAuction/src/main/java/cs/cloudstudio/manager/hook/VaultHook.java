package cs.cloudstudio.manager.hook;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class VaultHook {
   private Economy economy;

   public VaultHook() {
      if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
         RegisteredServiceProvider<Economy> economyProvider = Bukkit.getServicesManager().getRegistration(Economy.class);
         if (economyProvider != null) {
            this.economy = (Economy)economyProvider.getProvider();
         }
      }
   }

   public boolean isEnabled() {
      return this.economy != null;
   }

   public Economy getEconomy() {
      return this.economy;
   }
}
