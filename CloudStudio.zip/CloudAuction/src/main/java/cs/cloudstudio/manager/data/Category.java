package cs.cloudstudio.manager.data;

import java.util.EnumSet;
import java.util.Locale;
import java.util.Set;
import org.bukkit.Material;

public enum Category {
   ALL,
   ARMOR,
   WEAPONS,
   TOOLS,
   HEADS,
   SPAWNERS,
   ENCHANTS,
   FOOD,
   POTIONS;

   private static final Set<Material> ARMOR_MATERIALS = EnumSet.noneOf(Material.class);
   private static final Set<Material> WEAPON_MATERIALS = EnumSet.noneOf(Material.class);
   private static final Set<Material> TOOL_MATERIALS = EnumSet.noneOf(Material.class);
   private static final Set<Material> HEAD_MATERIALS = EnumSet.noneOf(Material.class);
   private static final Set<Material> SPAWNER_MATERIALS = EnumSet.noneOf(Material.class);
   private static final Set<Material> ENCHANT_MATERIALS = EnumSet.noneOf(Material.class);
   private static final Set<Material> FOOD_MATERIALS = EnumSet.noneOf(Material.class);
   private static final Set<Material> POTION_MATERIALS = EnumSet.noneOf(Material.class);
   private static final Category[] VALUES = values();

   public boolean contains(Material material) {
      if (material == null) {
         return false;
      }

      switch (this) {
         case ALL:
            return true;
         case ARMOR:
            return ARMOR_MATERIALS.contains(material);
         case WEAPONS:
            return WEAPON_MATERIALS.contains(material);
         case TOOLS:
            return TOOL_MATERIALS.contains(material);
         case HEADS:
            return HEAD_MATERIALS.contains(material);
         case SPAWNERS:
            return SPAWNER_MATERIALS.contains(material);
         case ENCHANTS:
            return ENCHANT_MATERIALS.contains(material);
         case FOOD:
            return FOOD_MATERIALS.contains(material);
         case POTIONS:
            return POTION_MATERIALS.contains(material);
         default:
            return false;
      }
   }

   public static Category fromString(String name) {
      if (name == null) {
         return ALL;
      }

      String normalized = name.toUpperCase(Locale.ROOT);

      for (Category category : VALUES) {
         if (category.name().equals(normalized)) {
            return category;
         }
      }

      return ALL;
   }

   static {
      for (Material mat : Material.values()) {
         String name = mat.name();
         if (name.endsWith("_HELMET")
            || name.endsWith("_CHESTPLATE")
            || name.endsWith("_LEGGINGS")
            || name.endsWith("_BOOTS")
            || name.equals("SHIELD")
            || name.equals("TOTEM_OF_UNDYING")
            || name.equals("ELYTRA")) {
            ARMOR_MATERIALS.add(mat);
         } else if (name.endsWith("_SWORD")
            || name.endsWith("_AXE")
            || name.equals("BOW")
            || name.equals("CROSSBOW")
            || name.equals("TRIDENT")
            || name.startsWith("ARROW")
            || name.equals("SPECTRAL_ARROW")) {
            WEAPON_MATERIALS.add(mat);
         } else if (name.endsWith("_PICKAXE")
            || name.endsWith("_SHOVEL")
            || name.endsWith("_HOE")
            || name.equals("FISHING_ROD")
            || name.equals("FLINT_AND_STEEL")
            || name.equals("SHEARS")) {
            TOOL_MATERIALS.add(mat);
         } else if (name.equals("PLAYER_HEAD")
            || name.endsWith("_HEAD")
            || name.equals("DRAGON_HEAD")
            || name.equals("CREEPER_HEAD")
            || name.equals("ZOMBIE_HEAD")
            || name.equals("SKELETON_SKULL")) {
            HEAD_MATERIALS.add(mat);
         } else if (name.equals("SPAWNER") || name.endsWith("_SPAWN_EGG")) {
            SPAWNER_MATERIALS.add(mat);
         } else if (name.equals("ENCHANTED_BOOK") || name.equals("EXPERIENCE_BOTTLE") || name.equals("LAPIS_LAZULI") || name.equals("BOOKSHELF")) {
            ENCHANT_MATERIALS.add(mat);
         } else if (mat.isEdible() || name.endsWith("_SEEDS") || name.equals("CAKE") || name.endsWith("_CAKE")) {
            FOOD_MATERIALS.add(mat);
         } else if (name.equals("POTION")
            || name.equals("SPLASH_POTION")
            || name.equals("LINGERING_POTION")
            || name.equals("BREWING_STAND")
            || name.equals("CAULDRON")
            || name.equals("GLASS_BOTTLE")
            || name.equals("DRAGON_BREATH")) {
            POTION_MATERIALS.add(mat);
         }
      }
   }
}
