package cs.cloudstudio.util;

import cs.cloudstudio.config.ConfigManager;

public final class TimeUtility {
   private TimeUtility() {
   }

   public static String formatTimeLeft(ConfigManager configManager, long expireTime) {
      long now = System.currentTimeMillis();
      if (now >= expireTime) {
         return configManager.getMessage("time.expired");
      }

      long diff = expireTime - now;
      long totalSeconds = diff / 1000L;
      long days = totalSeconds / 86400L;
      long hours = totalSeconds % 86400L / 3600L;
      long minutes = totalSeconds % 3600L / 60L;
      long seconds = totalSeconds % 60L;
      StringBuilder result = new StringBuilder();
      int added = 0;
      if (days > 0L && added < 2) {
         appendValue(result, days, getUnit(configManager, "time.days", declension(days, "день", "дня", "дней")));
         added++;
      }

      if (hours > 0L && added < 2) {
         appendValue(result, hours, getUnit(configManager, "time.hours", declension(hours, "час", "часа", "часов")));
         added++;
      }

      if (minutes > 0L && added < 2) {
         appendValue(result, minutes, getUnit(configManager, "time.minutes", declension(minutes, "минута", "минуты", "минут")));
         added++;
      }

      if (seconds > 0L && added < 2) {
         appendValue(result, seconds, getUnit(configManager, "time.seconds", declension(seconds, "секунда", "секунды", "секунд")));
      }

      return result.length() > 0 ? result.toString() : "0" + getUnit(configManager, "time.seconds", " секунд");
   }

   private static void appendValue(StringBuilder builder, long value, String unit) {
      if (builder.length() > 0) {
         builder.append(" ");
      }

      builder.append(value);
      if (unit.startsWith(" ")) {
         builder.append(unit);
      } else {
         builder.append(" ").append(unit);
      }
   }

   private static String getUnit(ConfigManager configManager, String path, String fallback) {
      String unit = configManager.getMessage(path);
      return unit != null && !unit.isEmpty() ? unit : fallback;
   }

   private static String declension(long value, String form1, String form2, String form5) {
      long mod100 = value % 100L;
      if (mod100 >= 11L && mod100 <= 14L) {
         return form5;
      } else {
         long mod10 = value % 10L;
         if (mod10 == 1L) {
            return form1;
         } else {
            return mod10 >= 2L && mod10 <= 4L ? form2 : form5;
         }
      }
   }
}
