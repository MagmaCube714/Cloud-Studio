package cs.cloudstudio.util;

import io.papermc.paper.datacomponent.DataComponentType;
import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.TooltipDisplay;
import java.util.List;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

public final class ItemMetaUtility {
   private static final DataComponentType[] ADDITIONAL_TOOLTIP = new DataComponentType[]{
      DataComponentTypes.BANNER_PATTERNS,
      DataComponentTypes.BUNDLE_CONTENTS,
      DataComponentTypes.CHARGED_PROJECTILES,
      DataComponentTypes.CONTAINER,
      DataComponentTypes.CONTAINER_LOOT,
      DataComponentTypes.FIREWORK_EXPLOSION,
      DataComponentTypes.FIREWORKS,
      DataComponentTypes.INSTRUMENT,
      DataComponentTypes.MAP_ID,
      DataComponentTypes.PAINTING_VARIANT,
      DataComponentTypes.POT_DECORATIONS,
      DataComponentTypes.POTION_CONTENTS,
      DataComponentTypes.TROPICAL_FISH_PATTERN,
      DataComponentTypes.WRITTEN_BOOK_CONTENT,
      DataComponentTypes.JUKEBOX_PLAYABLE,
      DataComponentTypes.SUSPICIOUS_STEW_EFFECTS,
      DataComponentTypes.OMINOUS_BOTTLE_AMPLIFIER
   };

   private ItemMetaUtility() {
   }

   public static void setCustomModelData(ItemMeta meta, Integer customModelData) {
      if (meta != null && customModelData != null) {
         CustomModelDataComponent component = meta.getCustomModelDataComponent();
         component.setFloats(List.of(customModelData.floatValue()));
         meta.setCustomModelDataComponent(component);
      }
   }

   public static ItemStack hideAdditionalTooltip(ItemStack item) {
      if (item != null && !item.getType().isAir()) {
         TooltipDisplay current = item.getData(DataComponentTypes.TOOLTIP_DISPLAY);
         TooltipDisplay.Builder builder = TooltipDisplay.tooltipDisplay();
         if (current != null) {
            builder.hideTooltip(current.hideTooltip());
            builder.hiddenComponents(current.hiddenComponents());
         }

         builder.addHiddenComponents(ADDITIONAL_TOOLTIP);
         item.setData(DataComponentTypes.TOOLTIP_DISPLAY, builder);
      }

      return item;
   }
}
