package cs.cloudstudio.util;

import cs.cloudstudio.CloudAuction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class PlaceholderUtility {
   private static boolean placeholderAPIEnabled;

   private PlaceholderUtility() {
   }

   public static void init() {
      refreshPlaceholderAPI();
   }

   public static String apply(Player player, String text) {
      if (text != null && !text.isEmpty()) {
         String result = text;
         if (player != null && result.indexOf(37) >= 0 && isPlaceholderAPIAvailable()) {
            try {
               String replaced = PlaceholderApiHook.apply(player, result);
               if (replaced != null) {
                  result = replaced;
               }
            } catch (RuntimeException | LinkageError e) {
               Bukkit.getLogger().warning("[CloudAuction] PlaceholderAPI error: " + e.getMessage());
            }
         }

         return ColorUtility.colorize(result);
      } else {
         return text;
      }
   }

   public static List<String> apply(Player player, List<String> lines) {
      if (lines != null && !lines.isEmpty()) {
         ArrayList<String> result = new ArrayList<>(lines.size());

         for (String line : lines) {
            result.add(apply(player, line));
         }

         return result;
      } else {
         return lines;
      }
   }

   public static Map<String, String> base(CloudAuction plugin, Player player) {
      return base(plugin, player, true);
   }

   public static Map<String, String> base(CloudAuction plugin, Player player, boolean includeBalance) {
      Map<String, String> placeholders = new HashMap<>(includeBalance ? 16 : 8);
      if (player != null) {
         String name = player.getName();
         put(placeholders, "player", name);
         put(placeholders, "player_name", name);
         put(placeholders, "viewer", name);
         put(placeholders, "viewer_name", name);
         put(placeholders, "display_name", ColorUtility.legacy(player.displayName()));
         put(placeholders, "uuid", player.getUniqueId().toString());
         if (includeBalance && plugin != null && plugin.getVaultHook() != null && plugin.getVaultHook().isEnabled()) {
            double balance = plugin.getVaultHook().getEconomy().getBalance(player);
            put(placeholders, "balance", balance);
            put(placeholders, "money", balance);
            put(placeholders, "vault_balance", balance);
         }
      }

      return placeholders;
   }

   public static void put(Map<String, String> placeholders, String key, Object value) {
      if (placeholders != null && key != null && !key.isEmpty()) {
         String normalized = normalizeKey(key);
         if (!normalized.isEmpty()) {
            String stringValue = value == null ? "" : String.valueOf(value);
            placeholders.put(normalized, stringValue);
         }
      }
   }

   public static String render(CloudAuction plugin, Player player, String text, Map<String, String> placeholders) {
      String result = text == null ? "" : text;
      result = replaceLocal(result, placeholders);
      return apply(player, result);
   }

   public static List<String> render(CloudAuction plugin, Player player, List<String> lines, Map<String, String> placeholders) {
      if (lines != null && !lines.isEmpty()) {
         List<String> result = new ArrayList<>(lines.size());

         for (String line : lines) {
            result.add(render(plugin, player, line, placeholders));
         }

         return result;
      } else {
         return new ArrayList<>();
      }
   }

   private static boolean isPlaceholderAPIAvailable() {
      if (placeholderAPIEnabled) {
         return true;
      }

      refreshPlaceholderAPI();
      return placeholderAPIEnabled;
   }

   private static void refreshPlaceholderAPI() {
      Plugin plugin = Bukkit.getPluginManager().getPlugin("PlaceholderAPI");
      placeholderAPIEnabled = plugin != null && plugin.isEnabled();
   }

   private static String replaceLocal(String text, Map<String, String> placeholders) {
      if (text != null && !text.isEmpty() && placeholders != null && !placeholders.isEmpty()) {
         boolean hasBrace = text.indexOf(123) >= 0;
         boolean hasPercent = text.indexOf(37) >= 0;
         if (!hasBrace && !hasPercent) {
            return text;
         }

         StringBuilder out = null;
         int copied = 0;
         int length = text.length();
         int index = 0;

         while (index < length) {
            char open = text.charAt(index);
            if (open == '{' || open == '%') {
               int close = text.indexOf(open == '{' ? '}' : '%', index + 1);
               if (close > index + 1) {
                  String value = lookup(placeholders, text, index, close);
                  if (value != null) {
                     if (out == null) {
                        out = new StringBuilder(length + 32);
                     }

                     out.append(text, copied, index).append(value);
                     index = close + 1;
                     copied = index;
                     continue;
                  }
               }
            }

            index++;
         }

         if (out == null) {
            return text;
         }

         return out.append(text, copied, length).toString();
      } else {
         return text == null ? "" : text;
      }
   }

   private static String lookup(Map<String, String> placeholders, String text, int open, int close) {
      String wrapped = text.substring(open, close + 1);
      if (placeholders.containsKey(wrapped)) {
         String value = placeholders.get(wrapped);
         return value == null ? "" : value;
      }

      String bare = text.substring(open + 1, close);
      if (placeholders.containsKey(bare) && !isWrappedKey(bare)) {
         String value = placeholders.get(bare);
         return value == null ? "" : value;
      }

      return null;
   }

   private static String normalizeKey(String key) {
      return isWrappedKey(key) ? key.substring(1, key.length() - 1) : key;
   }

   private static boolean isWrappedKey(String key) {
      return key != null
         && key.length() > 2
         && (key.charAt(0) == '{' && key.charAt(key.length() - 1) == '}' || key.charAt(0) == '%' && key.charAt(key.length() - 1) == '%');
   }

   public static boolean isEnabled() {
      return isPlaceholderAPIAvailable();
   }
}
