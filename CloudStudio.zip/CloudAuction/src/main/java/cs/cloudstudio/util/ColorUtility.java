package cs.cloudstudio.util;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class ColorUtility {
   private static final Cache<String, String> COLOR_CACHE = CacheBuilder.newBuilder().maximumSize(1024L).build();
   private static final char COLOR_CHAR = '§';
   private static final Pattern STRIP_COLOR_PATTERN = Pattern.compile("(?i)§[0-9A-FK-ORX]");
   private static final LegacyComponentSerializer SECTION_SERIALIZER = LegacyComponentSerializer.builder()
      .character('§')
      .hexColors()
      .useUnusualXRepeatedCharacterHexFormat()
      .build();

   private ColorUtility() {
   }

   public static String colorize(String text) {
      if (text != null && !text.isEmpty()) {
         String cached = (String)COLOR_CACHE.getIfPresent(text);
         if (cached != null) {
            return cached;
         }

         String result = colorizeInternal(text);
         COLOR_CACHE.put(text, result);
         return result;
      } else {
         return text;
      }
   }

   public static Component component(String legacyText) {
      return legacyText != null && !legacyText.isEmpty() ? SECTION_SERIALIZER.deserialize(legacyText) : Component.empty();
   }

   public static Component itemText(String legacyText) {
      if (legacyText == null) {
         return null;
      }

      Component component = component(legacyText);
      return startsWithColor(legacyText) ? component.decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE) : component;
   }

   private static boolean startsWithColor(String text) {
      if (text.length() > 1 && text.charAt(0) == COLOR_CHAR) {
         char c = Character.toLowerCase(text.charAt(1));
         return c >= '0' && c <= '9' || c >= 'a' && c <= 'f' || c == 'r' || c == 'x';
      } else {
         return false;
      }
   }

   public static List<Component> itemLines(List<String> lines) {
      if (lines == null) {
         return null;
      }

      List<Component> result = new ArrayList<>(lines.size());

      for (String line : lines) {
         result.add(itemText(line == null ? "" : line));
      }

      return result;
   }

   public static String legacy(Component component) {
      return component == null ? null : SECTION_SERIALIZER.serialize(component);
   }

   private static String colorizeInternal(String text) {
      String hexTranslated = text.indexOf("&#") >= 0 ? translateHexCodes(text) : text;
      return translateAlternateColorCodes('&', hexTranslated);
   }

   private static String translateHexCodes(String message) {
      int length = message.length();
      StringBuilder builder = null;

      for (int i = 0; i < length; i++) {
         char c = message.charAt(i);
         if (c == '&' && i + 7 < length && message.charAt(i + 1) == '#' && isHex(message, i + 2)) {
            if (builder == null) {
               builder = new StringBuilder(length + 32);
               builder.append(message, 0, i);
            }

            builder.append('§').append('x');

            for (int j = 0; j < 6; j++) {
               builder.append('§').append(message.charAt(i + 2 + j));
            }

            i += 7;
         } else if (builder != null) {
            builder.append(c);
         }
      }

      return builder == null ? message : builder.toString();
   }

   private static boolean isHex(String value, int offset) {
      for (int i = 0; i < 6; i++) {
         char c = value.charAt(offset + i);
         if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F')) {
            return false;
         }
      }

      return true;
   }

   public static void clearCache() {
      COLOR_CACHE.invalidateAll();
   }

   public static String translateAlternateColorCodes(String text) {
      return text != null && !text.isEmpty() ? translateAlternateColorCodes('&', text) : text;
   }

   public static String translateAlternateColorCodes(char altColorChar, String textToTranslate) {
      if (textToTranslate != null && !textToTranslate.isEmpty()) {
         if (textToTranslate.indexOf(altColorChar) < 0) {
            return textToTranslate;
         }

         char[] chars = textToTranslate.toCharArray();

         for (int i = 0; i < chars.length - 1; i++) {
            if (chars[i] == altColorChar && isValidColorCharacter(chars[i + 1])) {
               chars[i++] = 167;
               chars[i] = (char)(chars[i] | 32);
            }
         }

         return new String(chars);
      } else {
         return textToTranslate;
      }
   }

   private static boolean isValidColorCharacter(char c) {
      return c >= '0' && c <= '9'
         || c >= 'a' && c <= 'f'
         || c >= 'A' && c <= 'F'
         || c == 'r'
         || c == 'R'
         || c == 'k'
         || c == 'K'
         || c == 'l'
         || c == 'L'
         || c == 'm'
         || c == 'M'
         || c == 'n'
         || c == 'N'
         || c == 'o'
         || c == 'O'
         || c == 'x'
         || c == 'X';
   }

   public static String stripColor(String text) {
      return text != null && !text.isEmpty() ? STRIP_COLOR_PATTERN.matcher(text).replaceAll("") : text;
   }
}
