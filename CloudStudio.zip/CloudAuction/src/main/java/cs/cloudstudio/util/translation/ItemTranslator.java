package cs.cloudstudio.util.translation;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.util.ColorUtility;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

public final class ItemTranslator {
   private static final String LANG_VERSION = resolveLangVersion();
   private static final String RU_LANG_SOURCE = "https://raw.githubusercontent.com/InventivetalentDev/minecraft-assets/"
      + LANG_VERSION
      + "/assets/minecraft/lang/ru_ru.json";
   private static final int MAX_SUGGESTIONS = 20;
   private static final long REFRESH_INTERVAL_MILLIS = 604800000L;
   private static final Material[] MATERIALS = Material.values();
   private static final String[][] MATERIAL_KEYS = buildMaterialKeys();
   private static final String[] FALLBACK_NAMES = buildFallbackNames();
   private final CloudAuction plugin;
   private final File cacheFile;
   private volatile String[] materialTranslations = new String[MATERIALS.length];
   private volatile Map<String, String> variantTranslations = Collections.emptyMap();
   private volatile boolean loading;
   private volatile boolean shuttingDown;

   private static String resolveLangVersion() {
      try {
         String version = Bukkit.getMinecraftVersion();
         if (version != null && !version.isEmpty()) {
            return version;
         }
      } catch (Throwable var1) {
      }

      return "1.21.11";
   }

   public ItemTranslator(CloudAuction plugin) {
      this.plugin = plugin;
      this.cacheFile = new File(plugin.getDataFolder(), "auction_items-" + LANG_VERSION + ".json");
      this.loadFromFile();
      if (this.isCacheStale()) {
         this.updateAsync();
      }
   }

   public String getTranslatedName(ItemStack item) {
      if (item != null && !item.getType().isAir()) {
         ItemMeta meta = item.getItemMeta();
         if (meta != null && meta.hasDisplayName()) {
            return ColorUtility.legacy(meta.displayName());
         }

         String variant = this.translatePotionVariant(item, meta);
         return variant != null ? variant : this.translate(item.getType());
      } else {
         return "";
      }
   }

   private String translatePotionVariant(ItemStack item, ItemMeta meta) {
      if (!(meta instanceof PotionMeta)) {
         return null;
      }

      String prefix = this.potionLangPrefix(item.getType());
      if (prefix == null) {
         return null;
      }

      PotionType type;
      try {
         type = ((PotionMeta)meta).getBasePotionType();
      } catch (RuntimeException exception) {
         return null;
      }

      if (type == null) {
         return null;
      }

      String effect = type.name().toLowerCase(Locale.ROOT);
      if (effect.startsWith("long_")) {
         effect = effect.substring(5);
      } else if (effect.startsWith("strong_")) {
         effect = effect.substring(7);
      }

      String translated = this.lookupRaw(prefix + ".effect." + effect);
      return translated != null && !translated.isEmpty() ? translated : null;
   }

   private String potionLangPrefix(Material material) {
      switch (material) {
         case POTION:
            return "item.minecraft.potion";
         case SPLASH_POTION:
            return "item.minecraft.splash_potion";
         case LINGERING_POTION:
            return "item.minecraft.lingering_potion";
         case TIPPED_ARROW:
            return "item.minecraft.tipped_arrow";
         default:
            return null;
      }
   }

   public String getCleanTranslatedName(ItemStack item) {
      return this.cleanItemName(this.getTranslatedName(item));
   }

   public String cleanItemName(String itemName) {
      if (itemName == null) {
         return "";
      }

      String stripped = ColorUtility.stripColor(itemName);
      if (stripped == null) {
         stripped = itemName;
      }

      return this.stripFormatting(stripped).toLowerCase(Locale.ROOT).trim();
   }

   public List<String> suggest(List<ItemStack> sourceItems, String partial) {
      String query = this.cleanItemName(partial);
      Set<String> uniqueNames = new HashSet<>();

      for (ItemStack item : sourceItems) {
         String name = this.getCleanTranslatedName(item);
         if (!name.isEmpty() && name.contains(query)) {
            uniqueNames.add(name);
         }
      }

      List<String> suggestions = new ArrayList<>(uniqueNames);
      Collections.sort(suggestions);
      return suggestions.size() > 20 ? suggestions.subList(0, 20) : suggestions;
   }

   public void reload() {
      this.loading = false;
      this.shuttingDown = false;
      this.materialTranslations = new String[MATERIALS.length];
      this.loadFromFile();
      if (this.isCacheStale()) {
         this.updateAsync();
      }
   }

   public void shutdown() {
      this.shuttingDown = true;
   }

   private String translate(Material material) {
      if (material == null) {
         return "";
      }

      int ordinal = material.ordinal();
      String[] translations = this.materialTranslations;
      if (ordinal >= 0 && ordinal < translations.length) {
         String translated = translations[ordinal];
         if (translated != null && !translated.isEmpty()) {
            return translated;
         }
      }

      return ordinal >= 0 && ordinal < FALLBACK_NAMES.length ? FALLBACK_NAMES[ordinal] : material.name().toLowerCase(Locale.ROOT).replace('_', ' ');
   }

   private boolean isCacheStale() {
      return !this.cacheFile.exists() || System.currentTimeMillis() - this.cacheFile.lastModified() > 604800000L;
   }

   private String stripFormatting(String value) {
      int length = value.length();
      StringBuilder builder = null;

      for (int i = 0; i < length; i++) {
         char c = value.charAt(i);
         if (c == '&' && i + 1 < length && this.isColorCode(value.charAt(i + 1))) {
            if (builder == null) {
               builder = new StringBuilder(length);
               builder.append(value, 0, i);
            }

            i++;
         } else if (c == '#' && i + 6 < length && this.isHex(value, i + 1)) {
            if (builder == null) {
               builder = new StringBuilder(length);
               builder.append(value, 0, i);
            }

            i += 6;
         } else if (builder != null) {
            builder.append(c);
         }
      }

      return builder == null ? value : builder.toString();
   }

   private boolean isHex(String value, int offset) {
      for (int i = 0; i < 6; i++) {
         char c = value.charAt(offset + i);
         if ((c < '0' || c > '9') && (c < 'a' || c > 'f') && (c < 'A' || c > 'F')) {
            return false;
         }
      }

      return true;
   }

   private boolean isColorCode(char c) {
      return c >= '0' && c <= '9'
         || c >= 'a' && c <= 'f'
         || c >= 'A' && c <= 'F'
         || c == 'r'
         || c == 'R'
         || c == 'k'
         || c == 'K'
         || c == 'l'
         || c == 'L'
         || c == 'm'
         || c == 'M'
         || c == 'n'
         || c == 'N'
         || c == 'o'
         || c == 'O'
         || c == 'x'
         || c == 'X';
   }

   private void updateAsync() {
      if (!this.loading && !this.shuttingDown && this.plugin.isEnabled()) {
         this.loading = true;
         Bukkit.getScheduler().runTaskAsynchronously(this.plugin, () -> {
            try {
               if (!this.shuttingDown) {
                  this.loadFromUrl(RU_LANG_SOURCE);
               }
            } finally {
               this.loading = false;
            }
         });
      }
   }

   private boolean loadFromUrl(String apiUrl) {
      HttpURLConnection connection = null;

      try {
         URL url = URI.create(apiUrl).toURL();
         connection = (HttpURLConnection)url.openConnection();
         connection.setConnectTimeout(5000);
         connection.setReadTimeout(15000);
         connection.setRequestMethod("GET");
         connection.setRequestProperty("User-Agent", "CloudAuction/1.0");
         if (connection.getResponseCode() != 200) {
            return false;
         }

         String json = this.read(connection);
         Map<String, String> loaded = this.parseJson(json);
         if (loaded.isEmpty()) {
            return false;
         }

         this.rebuildMaterialCache(loaded);
         this.writeFile(loaded);
         return true;
      } catch (Exception e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось загрузить переводы предметов: " + e.getMessage());
         return false;
      } finally {
         if (connection != null) {
            connection.disconnect();
         }
      }
   }

   private String read(HttpURLConnection connection) throws Exception {
      int length = connection.getContentLength();
      StringBuilder builder = new StringBuilder(length > 0 ? length : 32768);

      try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
         char[] buffer = new char[8192];

         int read;
         while ((read = reader.read(buffer)) != -1) {
            builder.append(buffer, 0, read);
         }
      }

      return builder.toString();
   }

   private void loadFromFile() {
      if (!this.cacheFile.exists()) {
         this.loadBundled();
      } else {
         try {
            long fileLength = this.cacheFile.length();
            StringBuilder builder = new StringBuilder(fileLength > 0L && fileLength < 2147483647L ? (int)fileLength : 32768);
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(this.cacheFile), StandardCharsets.UTF_8));

            try {
               char[] buffer = new char[8192];

               int read;
               while ((read = reader.read(buffer)) != -1) {
                  builder.append(buffer, 0, read);
               }
            } catch (Throwable var8) {
               try {
                  reader.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }

               throw var8;
            }

            reader.close();
            Map<String, String> loaded = this.parseJson(builder.toString());
            if (!loaded.isEmpty()) {
               this.rebuildMaterialCache(loaded);
            }
         } catch (Exception e) {
            this.plugin.getLogger().warning("[CloudAuction] Не удалось прочитать кэш переводов: " + e.getMessage());
         }
      }
   }

   private void rebuildMaterialCache(Map<String, String> source) {
      this.rebuildVariantCache(source);
      String[] translations = new String[MATERIALS.length];

      for (int i = 0; i < MATERIALS.length; i++) {
         String[] keys = MATERIAL_KEYS[i];

         for (int j = 0; j < keys.length; j++) {
            String value = source.get(keys[j]);
            if (value != null) {
               String trimmed = trimToNull(value);
               if (trimmed != null) {
                  translations[i] = trimmed.toLowerCase(Locale.ROOT);
                  break;
               }
            }
         }
      }

      this.materialTranslations = translations;
   }

   private void rebuildVariantCache(Map<String, String> source) {
      Map<String, String> variants = new HashMap<>();

      for (Entry<String, String> entry : source.entrySet()) {
         String key = entry.getKey();
         if (key != null && key.indexOf(".effect.") >= 0) {
            String trimmed = trimToNull(entry.getValue());
            if (trimmed != null) {
               variants.put(key, trimmed.toLowerCase(Locale.ROOT));
            }
         }
      }

      this.variantTranslations = variants;
   }

   private String lookupRaw(String key) {
      return key == null ? null : this.variantTranslations.get(key);
   }

   private void loadBundled() {
      try (InputStream stream = ItemTranslator.class.getResourceAsStream("/auction_items.json")) {
         if (stream != null) {
            StringBuilder builder = new StringBuilder(65536);
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));

            try {
               char[] buffer = new char[8192];

               int read;
               while ((read = reader.read(buffer)) != -1) {
                  builder.append(buffer, 0, read);
               }
            } catch (Throwable var8) {
               try {
                  reader.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }

               throw var8;
            }

            reader.close();
            Map<String, String> loaded = this.parseJson(builder.toString());
            if (!loaded.isEmpty()) {
               this.rebuildMaterialCache(loaded);
            }
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось прочитать встроенные переводы: " + e.getMessage());
      }
   }

   private static String trimToNull(String value) {
      int start = 0;
      int end = value.length();

      while (start < end && value.charAt(start) <= ' ') {
         start++;
      }

      while (end > start && value.charAt(end - 1) <= ' ') {
         end--;
      }

      return start == end ? null : value.substring(start, end);
   }

   private static String[][] buildMaterialKeys() {
      String[][] keys = new String[MATERIALS.length][];

      for (int i = 0; i < MATERIALS.length; i++) {
         Material material = MATERIALS[i];
         String name = material.name().toLowerCase(Locale.ROOT);
         if (material.isBlock()) {
            keys[i] = new String[]{"block.minecraft." + name, "item.minecraft." + name};
         } else {
            keys[i] = new String[]{"item.minecraft." + name, "block.minecraft." + name};
         }
      }

      return keys;
   }

   private static String[] buildFallbackNames() {
      String[] fallback = new String[MATERIALS.length];

      for (int i = 0; i < MATERIALS.length; i++) {
         fallback[i] = MATERIALS[i].name().toLowerCase(Locale.ROOT).replace('_', ' ');
      }

      return fallback;
   }

   private Map<String, String> parseJson(String json) {
      Map<String, String> map = new HashMap<>();
      if (json != null && !json.isEmpty()) {
         int index = this.skipWhitespace(json, 0);
         int length = json.length();
         if (index < length && json.charAt(index) == '{') {
            index++;
         }

         while (index < length) {
            index = this.skipWhitespaceAndCommas(json, index);
            if (index >= length || json.charAt(index) == '}') {
               break;
            }

            if (json.charAt(index) != '"') {
               index++;
            } else {
               ItemTranslator.JsonString key = this.readJsonString(json, index + 1);
               if (key == null) {
                  break;
               }

               index = this.skipWhitespace(json, key.nextIndex);
               if (index < length && json.charAt(index) == ':') {
                  index = this.skipWhitespace(json, index + 1);
                  if (index < length && json.charAt(index) == '"') {
                     ItemTranslator.JsonString value = this.readJsonString(json, index + 1);
                     if (value == null) {
                        break;
                     }

                     map.put(key.value, value.value);
                     index = value.nextIndex;
                  } else {
                     index++;
                  }
               } else {
                  index++;
               }
            }
         }

         return map;
      } else {
         return map;
      }
   }

   private int skipWhitespaceAndCommas(String value, int index) {
      int length = value.length();

      while (index < length) {
         char c = value.charAt(index);
         if (c != ',' && c > ' ') {
            break;
         }

         index++;
      }

      return index;
   }

   private int skipWhitespace(String value, int index) {
      int length = value.length();

      while (index < length && value.charAt(index) <= ' ') {
         index++;
      }

      return index;
   }

   private ItemTranslator.JsonString readJsonString(String json, int index) {
      int start = index;
      int length = json.length();
      StringBuilder builder = null;

      while (index < length) {
         char c = json.charAt(index);
         if (c == '"') {
            return new ItemTranslator.JsonString(builder == null ? json.substring(start, index) : builder.toString(), index + 1);
         }

         if (c == '\\') {
            if (builder == null) {
               builder = new StringBuilder(index - start + 16);
               builder.append(json, start, index);
            }

            if (++index >= length) {
               break;
            }

            this.appendEscaped(builder, json.charAt(index), json, index);
            if (json.charAt(index) == 'u') {
               index += 4;
            }
         } else if (builder != null) {
            builder.append(c);
         }

         index++;
      }

      return null;
   }

   private void appendEscaped(StringBuilder builder, char escaped, String json, int escapeIndex) {
      switch (escaped) {
         case '"':
            builder.append('"');
            break;
         case '/':
            builder.append('/');
            break;
         case '\\':
            builder.append('\\');
            break;
         case 'b':
            builder.append('\b');
            break;
         case 'f':
            builder.append('\f');
            break;
         case 'n':
            builder.append('\n');
            break;
         case 'r':
            builder.append('\r');
            break;
         case 't':
            builder.append('\t');
            break;
         case 'u':
            if (escapeIndex + 4 < json.length()) {
               int h1 = this.hex(json.charAt(escapeIndex + 1));
               int h2 = this.hex(json.charAt(escapeIndex + 2));
               int h3 = this.hex(json.charAt(escapeIndex + 3));
               int h4 = this.hex(json.charAt(escapeIndex + 4));
               if ((h1 | h2 | h3 | h4) >= 0) {
                  builder.append((char)(h1 << 12 | h2 << 8 | h3 << 4 | h4));
                  break;
               }
            }

            builder.append('u');
            break;
         default:
            builder.append(escaped);
      }
   }

   private int hex(char c) {
      if (c >= '0' && c <= '9') {
         return c - 48;
      } else if (c >= 'a' && c <= 'f') {
         return c - 97 + 10;
      } else {
         return c >= 65 && c <= 70 ? c - 65 + 10 : -1;
      }
   }

   private void writeFile(Map<String, String> data) {
      try {
         File parent = this.cacheFile.getParentFile();
         if (parent != null && !parent.exists()) {
            parent.mkdirs();
         }

         try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.cacheFile), StandardCharsets.UTF_8))) {
            writer.write("{\n");
            boolean first = true;

            for (Entry<String, String> entry : data.entrySet()) {
               if (!first) {
                  writer.write(",\n");
               }

               writer.write("  \"");
               this.writeEscaped(writer, entry.getKey());
               writer.write("\": \"");
               this.writeEscaped(writer, entry.getValue());
               writer.write(34);
               first = false;
            }

            writer.write("\n}\n");
         }
      } catch (Exception e) {
         this.plugin.getLogger().warning("[CloudAuction] Не удалось записать кэш переводов: " + e.getMessage());
      }
   }

   private void writeEscaped(BufferedWriter writer, String value) throws Exception {
      if (value != null) {
         int length = value.length();

         for (int i = 0; i < length; i++) {
            char c = value.charAt(i);
            switch (c) {
               case '\t':
                  writer.write("\\t");
                  break;
               case '\n':
                  writer.write("\\n");
                  break;
               case '\r':
                  writer.write("\\r");
                  break;
               case '"':
                  writer.write("\\\"");
                  break;
               case '\\':
                  writer.write("\\\\");
                  break;
               default:
                  writer.write(c);
            }
         }
      }
   }

   private static final class JsonString {
      private final String value;
      private final int nextIndex;

      private JsonString(String value, int nextIndex) {
         this.value = value;
         this.nextIndex = nextIndex;
      }
   }
}
