package cs.cloudstudio.util;

import java.util.Map;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class InventoryUtility {
   private InventoryUtility() {
   }

   public static boolean canFit(Player player, ItemStack item) {
      if (player != null && item != null && !item.getType().isAir()) {
         ItemStack[] contents = player.getInventory().getStorageContents();
         int remaining = item.getAmount();
         int maxStackSize = item.getMaxStackSize();

         for (ItemStack slot : contents) {
            if (slot == null || slot.getType().isAir()) {
               remaining -= maxStackSize;
            } else if (slot.isSimilar(item)) {
               remaining -= Math.max(0, maxStackSize - slot.getAmount());
            }

            if (remaining <= 0) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static ItemStack giveOrLeftover(Player player, ItemStack item) {
      if (item == null || item.getType().isAir()) {
         return null;
      } else if (player != null && player.isOnline() && !player.isDead() && canFit(player, item)) {
         Map<Integer, ItemStack> leftovers = player.getInventory().addItem(new ItemStack[]{item.clone()});
         if (leftovers.isEmpty()) {
            return null;
         }

         int left = 0;
         ItemStack sample = null;

         for (ItemStack leftover : leftovers.values()) {
            if (leftover != null && !leftover.getType().isAir()) {
               left += leftover.getAmount();
               sample = leftover;
            }
         }

         if (left <= 0) {
            return null;
         }

         ItemStack rest = sample.clone();
         rest.setAmount(left);
         return rest;
      } else {
         return item.clone();
      }
   }
}
