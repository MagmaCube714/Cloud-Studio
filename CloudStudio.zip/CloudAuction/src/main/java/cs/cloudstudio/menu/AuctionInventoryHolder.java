package cs.cloudstudio.menu;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class AuctionInventoryHolder implements InventoryHolder {
   private final String menuType;
   private Inventory inventory;
   private String title;

   public AuctionInventoryHolder(String menuType) {
      this.menuType = menuType;
   }

   public String getMenuType() {
      return this.menuType;
   }

   public void setInventory(Inventory inventory) {
      this.inventory = inventory;
   }

   /** Заголовок, с которым окно открыто (сырой текст до цвета). */
   public String getTitle() {
      return this.title;
   }

   public void setTitle(String title) {
      this.title = title;
   }

   public Inventory getInventory() {
      return this.inventory;
   }
}
