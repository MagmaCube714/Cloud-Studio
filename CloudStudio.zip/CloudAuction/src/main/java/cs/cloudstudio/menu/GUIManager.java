package cs.cloudstudio.menu;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.manager.data.AuctionItem;
import cs.cloudstudio.manager.data.Category;
import cs.cloudstudio.manager.data.SortType;
import cs.cloudstudio.util.ColorUtility;
import cs.cloudstudio.util.ItemMetaUtility;
import cs.cloudstudio.util.PlaceholderUtility;
import cs.cloudstudio.util.TimeUtility;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class GUIManager {
   private static final int INVENTORY_SIZE = 54;
   private static final int SORT_BUTTON_SLOT = 3;
   private static final int REFRESH_BUTTON_SLOT = 4;
   private static final int CATEGORY_BUTTON_SLOT = 5;
   private static final int PREV_PAGE_SLOT = 45;
   private static final int BACK_BUTTON_SLOT = 49;
   private static final int MY_ITEMS_BUTTON_SLOT = 49;
   private static final int NEXT_PAGE_SLOT = 53;
   private static final String UNKNOWN_SELLER = "Unknown";
   private static final int NAME_CACHE_LIMIT = 500;
   private static final Category[] CATEGORIES = Category.values();
   private static final SortType[] SORT_TYPES = SortType.values();
   private final CloudAuction plugin;
   private final Map<UUID, Category> playerCategories = new HashMap<>();
   private final Map<UUID, SortType> playerSortTypes = new HashMap<>();
   private final Map<UUID, Integer> playerPages = new HashMap<>();
   private final Map<UUID, String> playerSearchQueries = new HashMap<>();
   private final Map<UUID, String> playerCurrentMenu = new HashMap<>();
   private final Set<UUID> switchingPlayers = new HashSet<>();
   private final Cache<UUID, String> sellerNameCache = CacheBuilder.newBuilder().expireAfterAccess(30L, TimeUnit.MINUTES).maximumSize(500L).build();
   private final Map<String, List<Integer>> pageSlotsCache = new HashMap<>();
   private final Map<String, Set<Integer>> pageSlotSetCache = new HashMap<>();
   private final NamespacedKey auctionIdKey;
   private final NamespacedKey categoryKey;
   private int cachedConfigVersion = -1;
   private static final String[] VIEWER_KEYS = {
      "{player}", "{player_name}", "{viewer}", "{viewer_name}", "{display_name}", "{uuid}", "{balance}", "{money}", "{vault_balance}"
   };
   private final Cache<UUID, CachedDisplay> displayCache = CacheBuilder.newBuilder().expireAfterAccess(10L, TimeUnit.MINUTES).maximumSize(5000L).build();
   private int viewerIndependentVersion = Integer.MIN_VALUE;
   private boolean viewerIndependent;
   private final Cache<UUID, CachedDisplay> myDisplayCache = CacheBuilder.newBuilder().expireAfterAccess(10L, TimeUnit.MINUTES).maximumSize(5000L).build();
   private int myIndependentVersion = Integer.MIN_VALUE;
   private boolean myIndependent;
   private final Map<String, ItemStack> buttonCache = new HashMap<>();
   private final Map<String, Boolean> buttonIndependence = new HashMap<>();

   private record CachedDisplay(String stamp, ItemStack stack) {
   }

   public GUIManager(CloudAuction plugin) {
      this.plugin = plugin;
      this.auctionIdKey = new NamespacedKey(plugin, "auction_id");
      this.categoryKey = new NamespacedKey(plugin, "category");
   }

   public String getCurrentMenuType(Player player) {
      return this.playerCurrentMenu.getOrDefault(player.getUniqueId(), "main");
   }

   public boolean hasSession(UUID playerId) {
      return playerId != null && this.playerCurrentMenu.containsKey(playerId);
   }

   public boolean isSwitching(UUID playerId) {
      return playerId != null && this.switchingPlayers.contains(playerId);
   }

   public void openMainMenuNextTick(Player player, int page, String searchQuery) {
      UUID playerId = player.getUniqueId();
      this.switchingPlayers.add(playerId);
      Bukkit.getScheduler().runTask(this.plugin, () -> {
         try {
            Player online = Bukkit.getPlayer(playerId);
            if (online != null && online.isOnline()) {
               this.openMainMenu(online, page, searchQuery);
            }
         } finally {
            this.switchingPlayers.remove(playerId);
         }
      });
   }

   public void openMyItemsMenuNextTick(Player player, int page) {
      UUID playerId = player.getUniqueId();
      this.switchingPlayers.add(playerId);
      Bukkit.getScheduler().runTask(this.plugin, () -> {
         try {
            Player online = Bukkit.getPlayer(playerId);
            if (online != null && online.isOnline()) {
               this.openMyItemsMenu(online, page);
            }
         } finally {
            this.switchingPlayers.remove(playerId);
         }
      });
   }

   public void openConfirmMenuNextTick(Player player, UUID itemId) {
      UUID playerId = player.getUniqueId();
      this.switchingPlayers.add(playerId);
      Bukkit.getScheduler().runTask(this.plugin, () -> {
         try {
            Player online = Bukkit.getPlayer(playerId);
            if (online != null && online.isOnline()) {
               this.openConfirmMenu(online, itemId);
            }
         } finally {
            this.switchingPlayers.remove(playerId);
         }
      });
   }

   public void openCategoryMenuNextTick(Player player) {
      UUID playerId = player.getUniqueId();
      this.switchingPlayers.add(playerId);
      Bukkit.getScheduler().runTask(this.plugin, () -> {
         try {
            Player online = Bukkit.getPlayer(playerId);
            if (online != null && online.isOnline()) {
               this.openCategoryMenu(online);
            }
         } finally {
            this.switchingPlayers.remove(playerId);
         }
      });
   }

   public void openMainMenu(Player player, int page, String searchQuery) {
      UUID playerId = player.getUniqueId();
      Category category = this.playerCategories.getOrDefault(playerId, Category.ALL);
      SortType sortType = this.playerSortTypes.getOrDefault(playerId, SortType.NEWEST);
      String normalizedSearch = this.normalizeSearchQuery(searchQuery);
      if (normalizedSearch == null) {
         this.playerSearchQueries.remove(playerId);
      } else {
         this.playerSearchQueries.put(playerId, normalizedSearch);
      }

      List<Integer> slots = this.getPageSlots("auction");
      List<AuctionItem> items;
      if (normalizedSearch == null) {
         items = this.plugin.getAuctionManager().getSortedItems(category, sortType);
      } else {
         items = this.plugin.getAuctionManager().getItems(category, normalizedSearch, null);
         items.sort(sortType.getComparator());
      }
      int currentPage = this.clampPage(page, items.size(), slots.size());
      String title = this.processPlaceholders(
         player, this.plugin.getConfigManager().getGuiTitle("auction"), this.createMenuPlaceholders(player, currentPage, items.size(), slots.size())
      );
      Inventory reused = this.reusableInventory(player, "main", title);
      Inventory inventory = reused != null ? reused : this.createInventory("main", title);
      this.playerPages.put(playerId, currentPage);
      this.playerCurrentMenu.put(playerId, "main");
      this.fillInventoryPage(inventory, player, items, slots, currentPage, true);
      this.setItem(inventory, this.getButtonSlot("sort", 3), this.cachedButton("sort", sortType.name(), () -> this.createSortButton(player, sortType)));
      this.setItem(inventory, this.getButtonSlot("refresh", 4), this.cachedButton("refresh", "", () -> this.createButton(player, "refresh", Material.SNOWBALL)));
      this.setItem(inventory, this.getButtonSlot("category", 5), this.cachedButton("category", category.name(), () -> this.createCategorySelectorButton(player, category)));
      this.setItem(inventory, this.getButtonSlot("myItems", 49), this.createMyItemsButton(player));
      this.setPaginationButtons(player, inventory, currentPage, items.size(), slots.size());
      if (reused == null) {
         player.openInventory(inventory);
      }
   }

   public void openMyItemsMenu(Player player, int page) {
      UUID playerId = player.getUniqueId();
      List<Integer> slots = this.getPageSlots("my");
      List<AuctionItem> items = this.plugin.getAuctionManager().getPlayerItems(player);
      int currentPage = this.clampPage(page, items.size(), slots.size());
      String title = this.processPlaceholders(
         player, this.plugin.getConfigManager().getGuiTitle("my"), this.createMenuPlaceholders(player, currentPage, items.size(), slots.size())
      );
      Inventory reused = this.reusableInventory(player, "my", title);
      Inventory inventory = reused != null ? reused : this.createInventory("my", title);
      this.playerPages.put(playerId, currentPage);
      this.playerCurrentMenu.put(playerId, "my");
      this.fillInventoryPage(inventory, player, items, slots, currentPage, false);
      this.setItem(inventory, this.getButtonSlot("back", 49), this.cachedButton("back", "", () -> this.createButton(player, "back", Material.OAK_DOOR)));
      this.setPaginationButtons(player, inventory, currentPage, items.size(), slots.size());
      if (reused == null) {
         player.openInventory(inventory);
      }
   }

   public void openConfirmMenu(Player player, UUID itemId) {
      AuctionItem auctionItem = this.plugin.getAuctionManager().getItem(itemId);
      if (auctionItem != null) {
         this.playerCurrentMenu.put(player.getUniqueId(), "confirm");
         Inventory inventory = this.createInventory(
            "confirm",
            this.processPlaceholders(player, this.plugin.getConfigManager().getGuiTitle("confirm"), this.createItemPlaceholders(player, auctionItem))
         );
         ItemStack previewItem = auctionItem.getItem().clone();
         ItemMeta meta = previewItem.getItemMeta();
         if (meta != null) {
            meta.getPersistentDataContainer().set(this.auctionIdKey, PersistentDataType.STRING, itemId.toString());
            previewItem.setItemMeta(meta);
         }

         this.setItem(inventory, this.plugin.getConfigManager().getConfirmItemSlot(), previewItem);
         ItemStack confirmButton = this.createConfirmButton(player, itemId);

         for (int slot : this.plugin.getConfigManager().getConfirmSlots()) {
            this.setItem(inventory, slot, confirmButton);
         }

         ItemStack cancelButton = this.cachedButton("cancel", "", () -> this.createButton(player, "cancel", Material.RED_STAINED_GLASS_PANE));

         for (int slot : this.plugin.getConfigManager().getCancelSlots()) {
            this.setItem(inventory, slot, cancelButton);
         }

         player.openInventory(inventory);
      }
   }

   public void openCategoryMenu(Player player) {
      this.playerCurrentMenu.put(player.getUniqueId(), "category");
      Inventory inventory = this.createInventory(
         "category",
         this.processPlaceholders(player, this.plugin.getConfigManager().getGuiTitle("category"), PlaceholderUtility.base(this.plugin, player, false))
      );

      for (Category category : CATEGORIES) {
         ConfigManager.CategoryConfig categoryConfig = this.plugin.getConfigManager().getCategoryConfig(category.name());
         if (categoryConfig != null) {
            this.setItem(inventory, categoryConfig.slot(), this.createCategoryButton(player, category, categoryConfig));
         }
      }

      player.openInventory(inventory);
   }

   private void fillInventoryPage(Inventory inventory, Player viewer, List<AuctionItem> items, List<Integer> slots, int page, boolean auctionView) {
      if (!slots.isEmpty() && !items.isEmpty()) {
         int itemsPerPage = slots.size();
         int start = page * itemsPerPage;
         int end = Math.min(start + itemsPerPage, items.size());

         for (int index = start; index < end; index++) {
            AuctionItem auctionItem = items.get(index);
            int slot = slots.get(index - start);
            this.setItem(inventory, slot, auctionView ? this.createAuctionItemStack(viewer, auctionItem) : this.createMyAuctionItemStack(viewer, auctionItem));
         }
      }
   }

   private void setPaginationButtons(Player player, Inventory inventory, int page, int itemCount, int itemsPerPage) {
      if (itemsPerPage > 0) {
         Map<String, String> placeholders = null;
         if (page > 0) {
            placeholders = this.createMenuPlaceholders(player, page, itemCount, itemsPerPage);
            Map<String, String> prev = placeholders;
            this.setItem(inventory, this.getButtonSlot("prevPage", 45), this.cachedButton("prevPage", this.pageStamp(player, page, itemCount, itemsPerPage), () -> this.createButton(player, "prevPage", Material.ARROW, prev)));
         }

         if ((page + 1) * itemsPerPage < itemCount) {
            if (placeholders == null) {
               placeholders = this.createMenuPlaceholders(player, page, itemCount, itemsPerPage);
            }

            Map<String, String> next = placeholders;
            this.setItem(inventory, this.getButtonSlot("nextPage", 53), this.cachedButton("nextPage", this.pageStamp(player, page, itemCount, itemsPerPage), () -> this.createButton(player, "nextPage", Material.ARROW, next)));
         }
      }
   }

   private boolean isViewerIndependent(ConfigManager.DisplayConfig displayConfig) {
      int version = this.plugin.getConfigManager().getVersion();
      if (this.viewerIndependentVersion != version) {
         this.viewerIndependentVersion = version;
         this.displayCache.invalidateAll();
         boolean independent = true;

         for (String line : displayConfig.lore()) {
            if (line != null && (line.indexOf('%') >= 0 || containsViewerPlaceholder(line))) {
               independent = false;
               break;
            }
         }

         this.viewerIndependent = independent;
      }

      return this.viewerIndependent;
   }

   private static boolean containsViewerPlaceholder(String line) {
      for (String key : VIEWER_KEYS) {
         if (line.contains(key)) {
            return true;
         }
      }

      return false;
   }

   private ItemStack createAuctionItemStack(Player viewer, AuctionItem auctionItem) {
      ConfigManager.DisplayConfig displayConfig = this.plugin.getConfigManager().getItemDisplayConfig();
      Player seller = Bukkit.getPlayer(auctionItem.getSeller());
      boolean online = seller != null;
      String sellerName = online ? seller.getName() : this.getCachedSellerName(auctionItem.getSeller());
      if (sellerName == null) {
         sellerName = "Unknown";
      }

      String timeLeft = TimeUtility.formatTimeLeft(this.plugin.getConfigManager(), auctionItem.getExpireTime());
      boolean cacheable = this.isViewerIndependent(displayConfig);
      String stamp = null;
      if (cacheable) {
         stamp = timeLeft + '\u0000' + online + '\u0000' + sellerName + '\u0000' + auctionItem.getFormattedPrice();
         CachedDisplay cached = this.displayCache.getIfPresent(auctionItem.getAuctionId());
         if (cached != null && cached.stamp().equals(stamp)) {
            return cached.stack();
         }
      }

      ItemStack display = auctionItem.getItem().clone();
      ItemMeta meta = display.getItemMeta();
      if (meta == null) {
         return display;
      }

      String status = online ? displayConfig.onlineStatus() : displayConfig.offlineStatus();
      String itemName = this.plugin.getItemTranslator().getTranslatedName(auctionItem.getItem());
      Map<String, String> placeholders = PlaceholderUtility.base(this.plugin, viewer, false);
      PlaceholderUtility.put(placeholders, "auction_id", auctionItem.getAuctionId());
      PlaceholderUtility.put(placeholders, "item", itemName);
      PlaceholderUtility.put(placeholders, "item_name", itemName);
      PlaceholderUtility.put(placeholders, "price", auctionItem.getFormattedPrice());
      PlaceholderUtility.put(placeholders, "cost", auctionItem.getFormattedPrice());
      PlaceholderUtility.put(placeholders, "seller_uuid", auctionItem.getSeller());
      PlaceholderUtility.put(placeholders, "seller", sellerName);
      PlaceholderUtility.put(placeholders, "seller_name", sellerName);
      PlaceholderUtility.put(placeholders, "status", status);
      PlaceholderUtility.put(placeholders, "time", timeLeft);
      PlaceholderUtility.put(placeholders, "left_time", timeLeft);
      PlaceholderUtility.put(placeholders, "clickAction", displayConfig.clickAction());
      PlaceholderUtility.put(placeholders, "click_action", displayConfig.clickAction());
      List<Component> finalLore = this.buildBaseLore(meta, displayConfig.lore().size());

      for (String line : displayConfig.lore()) {
         finalLore.add(ColorUtility.itemText(this.processPlaceholders(viewer, line, placeholders)));
      }

      meta.lore(finalLore);
      meta.getPersistentDataContainer().set(this.auctionIdKey, PersistentDataType.STRING, auctionItem.getAuctionId().toString());
      display.setItemMeta(meta);
      if (cacheable) {
         this.displayCache.put(auctionItem.getAuctionId(), new CachedDisplay(stamp, display));
      }

      return display;
   }

   private boolean isMyViewerIndependent(ConfigManager.DisplayConfig displayConfig) {
      int version = this.plugin.getConfigManager().getVersion();
      if (this.myIndependentVersion != version) {
         this.myIndependentVersion = version;
         this.myDisplayCache.invalidateAll();
         boolean independent = true;

         for (String line : displayConfig.lore()) {
            if (line != null && (line.indexOf('%') >= 0 || containsViewerPlaceholder(line))) {
               independent = false;
               break;
            }
         }

         this.myIndependent = independent;
      }

      return this.myIndependent;
   }

   private ItemStack createMyAuctionItemStack(Player viewer, AuctionItem auctionItem) {
      ConfigManager.DisplayConfig displayConfig = this.plugin.getConfigManager().getMyItemsDisplayConfig();
      String timeLeft = TimeUtility.formatTimeLeft(this.plugin.getConfigManager(), auctionItem.getExpireTime());
      boolean cacheable = this.isMyViewerIndependent(displayConfig);
      String stamp = null;
      if (cacheable) {
         stamp = timeLeft + '\u0000' + auctionItem.getFormattedPrice();
         CachedDisplay cached = this.myDisplayCache.getIfPresent(auctionItem.getAuctionId());
         if (cached != null && cached.stamp().equals(stamp)) {
            return cached.stack();
         }
      }

      ItemStack display = auctionItem.getItem().clone();
      ItemMeta meta = display.getItemMeta();
      if (meta == null) {
         return display;
      }

      String itemName = this.plugin.getItemTranslator().getTranslatedName(auctionItem.getItem());
      Map<String, String> placeholders = PlaceholderUtility.base(this.plugin, viewer, false);
      PlaceholderUtility.put(placeholders, "auction_id", auctionItem.getAuctionId());
      PlaceholderUtility.put(placeholders, "item", itemName);
      PlaceholderUtility.put(placeholders, "item_name", itemName);
      PlaceholderUtility.put(placeholders, "price", auctionItem.getFormattedPrice());
      PlaceholderUtility.put(placeholders, "cost", auctionItem.getFormattedPrice());
      PlaceholderUtility.put(placeholders, "seller_uuid", auctionItem.getSeller());
      PlaceholderUtility.put(placeholders, "time", timeLeft);
      PlaceholderUtility.put(placeholders, "left_time", timeLeft);
      PlaceholderUtility.put(placeholders, "clickAction", displayConfig.clickAction());
      PlaceholderUtility.put(placeholders, "click_action", displayConfig.clickAction());
      List<Component> finalLore = this.buildBaseLore(meta, displayConfig.lore().size());

      for (String line : displayConfig.lore()) {
         finalLore.add(ColorUtility.itemText(this.processPlaceholders(viewer, line, placeholders)));
      }

      meta.lore(finalLore);
      meta.getPersistentDataContainer().set(this.auctionIdKey, PersistentDataType.STRING, auctionItem.getAuctionId().toString());
      display.setItemMeta(meta);
      if (cacheable) {
         this.myDisplayCache.put(auctionItem.getAuctionId(), new CachedDisplay(stamp, display));
      }

      return display;
   }

   private String getCachedSellerName(UUID sellerUuid) {
      String cached = (String)this.sellerNameCache.getIfPresent(sellerUuid);
      if (cached != null) {
         return cached;
      }

      OfflinePlayer offline = Bukkit.getOfflinePlayer(sellerUuid);
      String name = offline.getName();
      if (name != null) {
         this.sellerNameCache.put(sellerUuid, name);
      }

      return name;
   }

   private List<Component> buildBaseLore(ItemMeta meta, int extraLines) {
      List<Component> originalLore = meta.hasLore() ? meta.lore() : null;
      List<Component> finalLore = new ArrayList<>((originalLore == null ? 0 : originalLore.size()) + extraLines);
      if (originalLore != null) {
         finalLore.addAll(originalLore);
         this.trimTrailingEmptyLines(finalLore);
      }

      return finalLore;
   }

   private void trimTrailingEmptyLines(List<Component> lines) {
      while (!lines.isEmpty()) {
         Component last = lines.get(lines.size() - 1);
         if (last != null && !PlainTextComponentSerializer.plainText().serialize(last).trim().isEmpty()) {
            return;
         }

         lines.remove(lines.size() - 1);
      }
   }

   private ItemStack createSortButton(Player player, SortType currentSort) {
      ConfigManager.ButtonConfig buttonConfig = this.plugin.getConfigManager().getButtonConfig("sort");
      if (buttonConfig == null) {
         return new ItemStack(Material.HOPPER);
      }

      ItemStack item = this.createConfiguredItem(buttonConfig, Material.HOPPER);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      meta.displayName(ColorUtility.itemText(this.processPlaceholders(player, buttonConfig.name())));
      List<String> lore = new ArrayList<>();

      for (String line : buttonConfig.lore()) {
         if (line.contains("{sortTypes}")) {
            for (SortType type : SORT_TYPES) {
               String sortLine = this.plugin.getConfigManager().getMessage("sortTypes." + type.name());
               sortLine = ColorUtility.colorize((type == currentSort ? "&6" : "&7") + sortLine);
               lore.add(this.processPlaceholders(player, sortLine));
            }
         } else {
            lore.add(this.processPlaceholders(player, line));
         }
      }

      meta.lore(ColorUtility.itemLines(lore));
      item.setItemMeta(meta);
      return ItemMetaUtility.hideAdditionalTooltip(item);
   }

   private String pageStamp(Player player, int page, int itemCount, int itemsPerPage) {
      String search = player == null ? null : this.playerSearchQueries.get(player.getUniqueId());
      return page + "|" + itemCount + "|" + itemsPerPage + "|" + (search == null ? "" : search);
   }

   private ItemStack cachedButton(String buttonName, String stamp, Supplier<ItemStack> factory) {
      ConfigManager.ButtonConfig buttonConfig = this.plugin.getConfigManager().getButtonConfig(buttonName);
      this.refreshGuiCache();
      if (buttonConfig == null || !this.isButtonViewerIndependent(buttonName, buttonConfig)) {
         return factory.get();
      }

      String key = buttonName + '\u0000' + stamp;
      ItemStack cached = this.buttonCache.get(key);
      if (cached == null) {
         cached = factory.get();
         if (this.buttonCache.size() >= 1024) {
            this.buttonCache.clear();
         }

         this.buttonCache.put(key, cached);
      }

      return cached;
   }

   private boolean isButtonViewerIndependent(String buttonName, ConfigManager.ButtonConfig buttonConfig) {
      Boolean known = this.buttonIndependence.get(buttonName);
      if (known != null) {
         return known;
      }

      List<String> texts = new ArrayList<>(buttonConfig.lore());
      texts.add(buttonConfig.name());
      if ("sort".equals(buttonName)) {
         for (SortType type : SORT_TYPES) {
            texts.add(this.plugin.getConfigManager().getMessage("sortTypes." + type.name()));
         }
      }

      boolean independent = true;

      for (String text : texts) {
         if (text != null && (text.indexOf('%') >= 0 || containsViewerPlaceholder(text))) {
            independent = false;
            break;
         }
      }

      this.buttonIndependence.put(buttonName, independent);
      return independent;
   }

   private ItemStack createCategorySelectorButton(Player player, Category category) {
      ConfigManager.ButtonConfig buttonConfig = this.plugin.getConfigManager().getButtonConfig("category");
      if (buttonConfig == null) {
         return new ItemStack(Material.COMPARATOR);
      }

      ItemStack item = this.createConfiguredItem(buttonConfig, Material.COMPARATOR);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      Map<String, String> replacements = new HashMap<>();
      replacements.put("{current}", this.plugin.getConfigManager().getCategoryDisplayName(category.name()));
      this.applyButtonMeta(player, meta, buttonConfig, replacements);
      item.setItemMeta(meta);
      return ItemMetaUtility.hideAdditionalTooltip(item);
   }

   private ItemStack createMyItemsButton(Player player) {
      int[] counts = this.plugin.getAuctionManager().getActiveAndExpiredItemsCount(player);
      int max = this.plugin.getPermissionManager().getPlayerPermissionSlots(player);
      return this.cachedButton("myItems", counts[0] + "|" + counts[1] + "|" + max, () -> this.createMyItemsButton(player, counts, max));
   }

   private ItemStack createMyItemsButton(Player player, int[] counts, int max) {
      ConfigManager.ButtonConfig buttonConfig = this.plugin.getConfigManager().getButtonConfig("myItems");
      if (buttonConfig == null) {
         return new ItemStack(Material.OAK_DOOR);
      }

      ItemStack item = this.createConfiguredItem(buttonConfig, Material.OAK_DOOR);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      Map<String, String> replacements = new HashMap<>();
      replacements.put("{expired}", String.valueOf(counts[1]));
      replacements.put("{active}", String.valueOf(counts[0]));
      replacements.put("{max}", String.valueOf(max));
      this.applyButtonMeta(player, meta, buttonConfig, replacements);
      item.setItemMeta(meta);
      return ItemMetaUtility.hideAdditionalTooltip(item);
   }

   private ItemStack createConfirmButton(Player player, UUID itemId) {
      ConfigManager.ButtonConfig buttonConfig = this.plugin.getConfigManager().getButtonConfig("confirm");
      if (buttonConfig == null) {
         return new ItemStack(Material.LIME_STAINED_GLASS_PANE);
      }

      ItemStack item = this.createConfiguredItem(buttonConfig, Material.LIME_STAINED_GLASS_PANE);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      AuctionItem auctionItem = this.plugin.getAuctionManager().getItem(itemId);
      Map<String, String> replacements = new HashMap<>();
      if (auctionItem != null) {
         Player seller = Bukkit.getPlayer(auctionItem.getSeller());
         String sellerName = seller != null ? seller.getName() : this.getCachedSellerName(auctionItem.getSeller());
         replacements.put("{seller}", sellerName == null ? "Unknown" : sellerName);
         replacements.put("{price}", auctionItem.getFormattedPrice());
         replacements.put("{item}", this.plugin.getItemTranslator().getTranslatedName(auctionItem.getItem()));
      }

      this.applyButtonMeta(player, meta, buttonConfig, replacements);
      meta.getPersistentDataContainer().set(this.auctionIdKey, PersistentDataType.STRING, itemId.toString());
      item.setItemMeta(meta);
      return ItemMetaUtility.hideAdditionalTooltip(item);
   }

   private ItemStack createCategoryButton(Player player, Category category, ConfigManager.CategoryConfig categoryConfig) {
      ItemStack item = new ItemStack(categoryConfig.materialType());
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
      Map<String, String> placeholders = this.createCategoryPlaceholders(player, category, categoryConfig);
      meta.displayName(ColorUtility.itemText(this.processPlaceholders(player, categoryConfig.name(), placeholders)));
      meta.lore(ColorUtility.itemLines(this.processPlaceholders(player, categoryConfig.lore(), placeholders)));
      meta.getPersistentDataContainer().set(this.categoryKey, PersistentDataType.STRING, category.name());
      item.setItemMeta(meta);
      return ItemMetaUtility.hideAdditionalTooltip(item);
   }

   private ItemStack createButton(Player player, String buttonName, Material fallbackMaterial) {
      return this.createButton(player, buttonName, fallbackMaterial, null);
   }

   private ItemStack createButton(Player player, String buttonName, Material fallbackMaterial, Map<String, String> replacements) {
      ConfigManager.ButtonConfig buttonConfig = this.plugin.getConfigManager().getButtonConfig(buttonName);
      if (buttonConfig == null) {
         return new ItemStack(fallbackMaterial);
      }

      ItemStack item = this.createConfiguredItem(buttonConfig, fallbackMaterial);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      this.applyButtonMeta(player, meta, buttonConfig, replacements);
      item.setItemMeta(meta);
      return ItemMetaUtility.hideAdditionalTooltip(item);
   }

   private ItemStack createConfiguredItem(ConfigManager.ButtonConfig buttonConfig, Material fallbackMaterial) {
      Material material = buttonConfig.materialType();
      ItemStack item = new ItemStack(material == null ? fallbackMaterial : material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
         ItemMetaUtility.setCustomModelData(meta, buttonConfig.customModelData());

         item.setItemMeta(meta);
      }

      return item;
   }

   private void applyButtonMeta(Player player, ItemMeta meta, ConfigManager.ButtonConfig buttonConfig, Map<String, String> replacements) {
      Map<String, String> placeholders = this.mergeBase(player, replacements);
      meta.displayName(ColorUtility.itemText(this.processPlaceholders(player, buttonConfig.name(), placeholders)));
      meta.lore(ColorUtility.itemLines(this.processPlaceholders(player, buttonConfig.lore(), placeholders)));
   }

   private List<Integer> getPageSlots(String menuKey) {
      this.refreshGuiCache();
      List<Integer> cached = this.pageSlotsCache.get(menuKey);
      if (cached != null) {
         return cached;
      }

      List<Integer> slots = this.plugin.getConfigManager().getGuiSlots(menuKey);
      int limit = this.plugin.getConfigManager().getItemsPerPage();
      List<Integer> result;
      if (slots.isEmpty()) {
         result = slots;
      } else if (limit >= slots.size()) {
         result = slots;
      } else {
         result = Collections.unmodifiableList(new ArrayList<>(slots.subList(0, limit)));
      }

      this.pageSlotsCache.put(menuKey, result);
      this.pageSlotSetCache.put(menuKey, new HashSet<>(result));
      return result;
   }

   private void refreshGuiCache() {
      int version = this.plugin.getConfigManager().getVersion();
      if (this.cachedConfigVersion != version) {
         this.cachedConfigVersion = version;
         this.pageSlotsCache.clear();
         this.pageSlotSetCache.clear();
         this.buttonCache.clear();
         this.buttonIndependence.clear();
      }
   }

   private Inventory createInventory(String menuType, String title) {
      AuctionInventoryHolder holder = new AuctionInventoryHolder(menuType);
      Inventory inventory = Bukkit.createInventory(holder, 54, ColorUtility.component(title));
      holder.setInventory(inventory);
      holder.setTitle(title);
      return inventory;
   }

   /**
    * Уже открытое у игрока окно того же меню с тем же заголовком (листание страниц, сортировка, обновление):
    * его содержимое перезаполняется на месте вместо открытия нового окна — для игрока то же самое,
    * а openInventory (основная цена меню) не вызывается. null — нужно открыть новое окно.
    */
   private Inventory reusableInventory(Player player, String menuType, String title) {
      Inventory top = player.getOpenInventory().getTopInventory();
      if (top.getHolder(false) instanceof AuctionInventoryHolder holder
         && holder.getInventory() == top
         && menuType.equals(holder.getMenuType())
         && title.equals(holder.getTitle())) {
         top.clear();
         return top;
      }
      return null;
   }

   private int clampPage(int page, int itemCount, int itemsPerPage) {
      if (page > 0 && itemsPerPage > 0 && itemCount > 0) {
         int maxPage = (itemCount - 1) / itemsPerPage;
         return Math.min(page, maxPage);
      } else {
         return 0;
      }
   }

   private String normalizeSearchQuery(String searchQuery) {
      if (searchQuery == null) {
         return null;
      }

      String trimmed = searchQuery.trim();
      return trimmed.isEmpty() ? null : trimmed;
   }

   private void setItem(Inventory inventory, int slot, ItemStack item) {
      if (slot >= 0 && slot < inventory.getSize() && item != null) {
         inventory.setItem(slot, item);
      }
   }

   private int getButtonSlot(String buttonName, int fallback) {
      return this.plugin.getConfigManager().getButtonSlot(buttonName, fallback);
   }

   public boolean isButtonSlot(String buttonName, int fallback, int slot) {
      return this.getButtonSlot(buttonName, fallback) == slot;
   }

   public boolean isAuctionItemSlot(String menuKey, int slot) {
      this.getPageSlots(menuKey);
      Set<Integer> slots = this.pageSlotSetCache.get(menuKey);
      return slots != null && slots.contains(slot);
   }

   public void setCategory(Player player, Category category) {
      this.playerCategories.put(player.getUniqueId(), category);
   }

   private String processPlaceholders(Player player, String text) {
      return this.processPlaceholders(player, text, PlaceholderUtility.base(this.plugin, player, false));
   }

   private String processPlaceholders(Player player, String text, Map<String, String> placeholders) {
      return text == null ? null : PlaceholderUtility.render(this.plugin, player, text, placeholders);
   }

   private List<String> processPlaceholders(Player player, List<String> lines, Map<String, String> placeholders) {
      return PlaceholderUtility.render(this.plugin, player, lines, placeholders);
   }

   private Map<String, String> mergeBase(Player player, Map<String, String> replacements) {
      Map<String, String> placeholders = PlaceholderUtility.base(this.plugin, player, false);
      if (replacements != null && !replacements.isEmpty()) {
         for (Entry<String, String> entry : replacements.entrySet()) {
            PlaceholderUtility.put(placeholders, this.normalizePlaceholderKey(entry.getKey()), entry.getValue());
         }
      }

      return placeholders;
   }

   private String normalizePlaceholderKey(String key) {
      if (key == null) {
         return "";
      } else {
         return key.length() <= 2
               || (key.charAt(0) != '{' || key.charAt(key.length() - 1) != '}') && (key.charAt(0) != '%' || key.charAt(key.length() - 1) != '%')
            ? key
            : key.substring(1, key.length() - 1);
      }
   }

   private Map<String, String> createMenuPlaceholders(Player player, int page, int itemCount, int itemsPerPage) {
      Map<String, String> placeholders = PlaceholderUtility.base(this.plugin, player, false);
      int maxPage = itemCount > 0 && itemsPerPage > 0 ? (itemCount - 1) / itemsPerPage : 0;
      PlaceholderUtility.put(placeholders, "page", page + 1);
      PlaceholderUtility.put(placeholders, "current_page", page + 1);
      PlaceholderUtility.put(placeholders, "next_page", page + 2);
      PlaceholderUtility.put(placeholders, "previous_page", Math.max(1, page));
      PlaceholderUtility.put(placeholders, "prev_page", Math.max(1, page));
      PlaceholderUtility.put(placeholders, "max_page", maxPage + 1);
      PlaceholderUtility.put(placeholders, "pages", maxPage + 1);
      PlaceholderUtility.put(placeholders, "items", itemCount);
      PlaceholderUtility.put(placeholders, "items_count", itemCount);
      String search = player == null ? null : this.playerSearchQueries.get(player.getUniqueId());
      PlaceholderUtility.put(placeholders, "search", search == null ? "" : search);
      PlaceholderUtility.put(placeholders, "query", search == null ? "" : search);
      return placeholders;
   }

   private Map<String, String> createItemPlaceholders(Player player, AuctionItem auctionItem) {
      Map<String, String> placeholders = PlaceholderUtility.base(this.plugin, player, false);
      if (auctionItem != null) {
         ItemStack item = auctionItem.getItem();
         String itemName = this.plugin.getItemTranslator().getTranslatedName(item);
         String price = auctionItem.getFormattedPrice();
         String timeLeft = TimeUtility.formatTimeLeft(this.plugin.getConfigManager(), auctionItem.getExpireTime());
         Player seller = Bukkit.getPlayer(auctionItem.getSeller());
         String sellerName = seller != null ? seller.getName() : this.getCachedSellerName(auctionItem.getSeller());
         if (sellerName == null) {
            sellerName = "Unknown";
         }

         PlaceholderUtility.put(placeholders, "auction_id", auctionItem.getAuctionId());
         PlaceholderUtility.put(placeholders, "item", itemName);
         PlaceholderUtility.put(placeholders, "item_name", itemName);
         PlaceholderUtility.put(placeholders, "price", price);
         PlaceholderUtility.put(placeholders, "cost", price);
         PlaceholderUtility.put(placeholders, "seller_uuid", auctionItem.getSeller());
         PlaceholderUtility.put(placeholders, "seller", sellerName);
         PlaceholderUtility.put(placeholders, "seller_name", sellerName);
         PlaceholderUtility.put(placeholders, "time", timeLeft);
         PlaceholderUtility.put(placeholders, "left_time", timeLeft);
      }

      return placeholders;
   }

   private Map<String, String> createCategoryPlaceholders(Player player, Category category, ConfigManager.CategoryConfig categoryConfig) {
      Map<String, String> placeholders = PlaceholderUtility.base(this.plugin, player, false);
      PlaceholderUtility.put(placeholders, "category", category.name());
      PlaceholderUtility.put(placeholders, "category_name", categoryConfig.name());
      PlaceholderUtility.put(placeholders, "current", categoryConfig.name());
      return placeholders;
   }

   public void cycleSortType(Player player) {
      UUID playerId = player.getUniqueId();
      SortType current = this.playerSortTypes.getOrDefault(playerId, SortType.NEWEST);
      this.playerSortTypes.put(playerId, current.next());
   }

   public int getCurrentPage(Player player) {
      return this.playerPages.getOrDefault(player.getUniqueId(), 0);
   }

   public String getCurrentSearchQuery(Player player) {
      return this.playerSearchQueries.get(player.getUniqueId());
   }

   public void clearSession(Player player) {
      UUID playerId = player.getUniqueId();
      this.playerSortTypes.remove(playerId);
      this.playerPages.remove(playerId);
      this.playerSearchQueries.remove(playerId);
      this.playerCurrentMenu.remove(playerId);
      this.switchingPlayers.remove(playerId);
   }

   public void clearPlayer(Player player) {
      UUID playerId = player.getUniqueId();
      this.clearSession(player);
      this.playerCategories.remove(playerId);
   }

   public void clearAll() {
      this.playerCategories.clear();
      this.playerSortTypes.clear();
      this.playerPages.clear();
      this.playerSearchQueries.clear();
      this.playerCurrentMenu.clear();
      this.switchingPlayers.clear();
      this.sellerNameCache.invalidateAll();
      this.pageSlotsCache.clear();
      this.pageSlotSetCache.clear();
   }
}
