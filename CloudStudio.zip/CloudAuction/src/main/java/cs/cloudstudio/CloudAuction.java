package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.command.PlayerCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.listener.GUIListener;
import cs.cloudstudio.listener.TridentDupeListener;
import cs.cloudstudio.manager.AuctionManager;
import cs.cloudstudio.manager.DatabaseManager;
import cs.cloudstudio.manager.PermissionManager;
import cs.cloudstudio.manager.hook.VaultHook;
import cs.cloudstudio.menu.GUIManager;
import cs.cloudstudio.util.ColorUtility;
import cs.cloudstudio.util.PlaceholderUtility;
import cs.cloudstudio.util.translation.ItemTranslator;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudAuction extends JavaPlugin {
   private static final String ADMIN_COMMAND = "cloudauction";
   private static final String AUCTION_COMMAND = "auction";
   private ConfigManager configManager;
   private PermissionManager permissionManager;
   private DatabaseManager databaseManager;
   private AuctionManager auctionManager;
   private GUIManager guiManager;
   private VaultHook vaultHook;
   private ItemTranslator itemTranslator;
   private TridentDupeListener tridentDupeListener;

   public void onEnable() {
      this.configManager = new ConfigManager(this);
      this.vaultHook = new VaultHook();
      if (!this.vaultHook.isEnabled()) {
         this.log("&fCloudAuction &cэкономика Vault не подключена (нужен плагин экономики: EssentialsX, CMI), плагин отключён");
         this.getServer().getPluginManager().disablePlugin(this);
      } else {
         try {
            this.initializeManagers();
         } catch (RuntimeException e) {
            this.getLogger().warning("[CloudAuction] Плагин не запущен: " + e.getMessage());
            this.getServer().getPluginManager().disablePlugin(this);
            return;
         }

         this.registerCommands();
         this.registerListeners();
         this.startTasks();
         this.log("&fCloudAuction &aуспешно загружен!");
      }
   }

   public void onDisable() {
      this.getServer().getScheduler().cancelTasks(this);
      if (this.guiManager != null) {
         this.guiManager.clearAll();
      }

      if (this.itemTranslator != null) {
         this.itemTranslator.shutdown();
      }

      if (this.databaseManager != null) {
         this.databaseManager.disconnect();
      }

      ColorUtility.clearCache();
      this.log("&fCloudAuction &cуспешно выгружен!");
   }

   private void initializeManagers() {
      this.permissionManager = new PermissionManager(this);
      this.databaseManager = new DatabaseManager(this);
      this.itemTranslator = new ItemTranslator(this);
      this.auctionManager = new AuctionManager(this);
      this.guiManager = new GUIManager(this);
      PlaceholderUtility.init();
   }

   private void registerCommands() {
      PluginCommand adminCommand = this.getCommand("cloudauction");
      if (adminCommand != null) {
         AdminCommand command = new AdminCommand(this);
         adminCommand.setExecutor(command);
         adminCommand.setTabCompleter(command);
      }

      PluginCommand auctionCommand = this.getCommand("auction");
      if (auctionCommand != null) {
         PlayerCommand command = new PlayerCommand(this);
         auctionCommand.setExecutor(command);
         auctionCommand.setTabCompleter(command);
      }
   }

   private void registerListeners() {
      this.tridentDupeListener = new TridentDupeListener();
      this.getServer().getPluginManager().registerEvents(this.tridentDupeListener, this);
      this.getServer().getPluginManager().registerEvents(new GUIListener(this), this);
   }

   private void startTasks() {
      this.auctionManager.startExpiryCleanup();
   }

   private void log(String message) {
      Bukkit.getConsoleSender().sendMessage(ColorUtility.component(ColorUtility.colorize(message)));
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public PermissionManager getPermissionManager() {
      return this.permissionManager;
   }

   public AuctionManager getAuctionManager() {
      return this.auctionManager;
   }

   public GUIManager getGUIManager() {
      return this.guiManager;
   }

   public VaultHook getVaultHook() {
      return this.vaultHook;
   }

   public TridentDupeListener getTridentDupeListener() {
      return this.tridentDupeListener;
   }

   public DatabaseManager getDatabaseManager() {
      return this.databaseManager;
   }

   public ItemTranslator getItemTranslator() {
      return this.itemTranslator;
   }
}
