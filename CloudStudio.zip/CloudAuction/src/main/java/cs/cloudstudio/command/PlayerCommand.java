package cs.cloudstudio.command;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.command.sub.MySubCommand;
import cs.cloudstudio.command.sub.SearchSubCommand;
import cs.cloudstudio.command.sub.SellSubCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class PlayerCommand extends BaseCommand {
   public PlayerCommand(CloudAuction plugin) {
      super(plugin);
      this.register(new SellSubCommand(plugin));
      this.register(new MySubCommand(plugin));
      this.register(new SearchSubCommand(plugin));
   }

   @Override
   protected boolean onEmpty(CommandSender sender) {
      if (!(sender instanceof Player)) {
         sender.sendMessage(this.plugin.getConfigManager().getMessage("messages.onlyPlayers"));
         return true;
      } else {
         this.plugin.getGUIManager().openMainMenu((Player)sender, 0, null);
         return true;
      }
   }
}
