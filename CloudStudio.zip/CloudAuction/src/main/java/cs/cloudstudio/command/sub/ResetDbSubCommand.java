package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;

public final class ResetDbSubCommand implements SubCommand {
   private static final String ADMIN_PERMISSION = "cloudauction.admin";
   private final CloudAuction plugin;

   public ResetDbSubCommand(CloudAuction plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "resetdb";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      this.plugin.getAuctionManager().resetAllData();
      sender.sendMessage(this.plugin.getConfigManager().getMessage("messages.resetdbCmd"));
      return true;
   }

   @Override
   public boolean canUse(CommandSender sender) {
      return sender.hasPermission("cloudauction.admin");
   }
}
