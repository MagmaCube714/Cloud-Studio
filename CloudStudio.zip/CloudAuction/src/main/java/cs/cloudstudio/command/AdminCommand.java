package cs.cloudstudio.command;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import cs.cloudstudio.command.sub.ResetDbSubCommand;
import org.bukkit.command.CommandSender;

public final class AdminCommand extends BaseCommand {
   private static final String ADMIN_PERMISSION = "cloudauction.admin";

   public AdminCommand(CloudAuction plugin) {
      super(plugin);
      this.register(new ReloadSubCommand(plugin));
      this.register(new ResetDbSubCommand(plugin));
   }

   @Override
   protected boolean onEmpty(CommandSender sender) {
      if (!sender.hasPermission("cloudauction.admin")) {
         sender.sendMessage(this.plugin.getConfigManager().getMessage("messages.noPerms"));
         return true;
      } else {
         sender.sendMessage(this.plugin.getConfigManager().getMessage("messages.adminUsage"));
         return true;
      }
   }

   @Override
   protected void sendUsage(CommandSender sender) {
      sender.sendMessage(this.plugin.getConfigManager().getMessage("messages.adminUsage"));
   }
}
