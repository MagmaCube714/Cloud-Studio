package cs.cloudstudio.command;

import cs.cloudstudio.CloudAuction;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public abstract class BaseCommand implements CommandExecutor, TabCompleter {
   protected final CloudAuction plugin;
   private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();

   protected BaseCommand(CloudAuction plugin) {
      this.plugin = plugin;
   }

   protected final void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.getName().toLowerCase(Locale.ROOT), subCommand);
   }

   public final boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (args.length == 0) {
         return this.onEmpty(sender);
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            this.sendUsage(sender);
            return true;
         } else if (!subCommand.canUse(sender)) {
            sender.sendMessage(this.plugin.getConfigManager().getMessage("messages.noPerms"));
            return true;
         } else {
            return subCommand.execute(sender, args);
         }
      }
   }

   public final List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (args.length == 1) {
         return this.getCommandSuggestions(sender, args[0]);
      }

      SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
      return subCommand != null && subCommand.canUse(sender) ? subCommand.tabComplete(sender, args) : Collections.emptyList();
   }

   protected abstract boolean onEmpty(CommandSender var1);

   protected void sendUsage(CommandSender sender) {
      for (String line : this.plugin.getConfigManager().getUsageLines()) {
         sender.sendMessage(line);
      }
   }

   private List<String> getCommandSuggestions(CommandSender sender, String partial) {
      String query = partial == null ? "" : partial.toLowerCase(Locale.ROOT);
      List<String> suggestions = new ArrayList<>();

      for (SubCommand subCommand : this.subCommands.values()) {
         String name = subCommand.getName();
         if (subCommand.canUse(sender) && name.startsWith(query)) {
            suggestions.add(name);
         }
      }

      return suggestions;
   }
}
