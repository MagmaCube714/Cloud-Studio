package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.command.SubCommand;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class SearchSubCommand implements SubCommand {
   private static final int MAX_QUERY_LENGTH = 64;
   private final CloudAuction plugin;

   public SearchSubCommand(CloudAuction plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "search";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      if (!(sender instanceof Player player)) {
         sender.sendMessage(this.plugin.getConfigManager().getMessage("messages.onlyPlayers"));
         return true;
      } else {
         if (args.length < 2) {
            player.sendMessage(this.plugin.getConfigManager().getMessage("messages.specifySearch"));
            return true;
         }

         StringBuilder query = new StringBuilder(args[1]);

         for (int i = 2; i < args.length; i++) {
            query.append(' ').append(args[i]);
            if (query.length() > 64) {
               break;
            }
         }

         String q = query.length() > 64 ? query.substring(0, 64) : query.toString();
         this.plugin.getGUIManager().openMainMenu(player, 0, q);
         return true;
      }
   }

   @Override
   public List<String> tabComplete(CommandSender sender, String[] args) {
      if (sender instanceof Player && args.length != 0) {
         String partial = args[args.length - 1];
         return this.plugin.getAuctionManager().suggestItemNames(partial);
      } else {
         return Collections.emptyList();
      }
   }
}
