package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class SellSubCommand implements SubCommand {
   private static final double MIN_PRICE = 1.0;
   private static final double MAX_PRICE = 1.0E18;
   private final CloudAuction plugin;

   public SellSubCommand(CloudAuction plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "sell";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      if (!(sender instanceof Player player)) {
         sender.sendMessage(this.plugin.getConfigManager().getMessage("messages.onlyPlayers"));
         return true;
      } else {
         if (args.length < 2) {
            player.sendMessage(this.plugin.getConfigManager().getMessage("messages.specifyPrice"));
            return true;
         }

         double price;
         try {
            price = Double.parseDouble(args[1].replace(',', '.'));
         } catch (NumberFormatException e) {
            player.sendMessage(this.plugin.getConfigManager().getMessage("messages.invalidPrice"));
            return true;
         }

         if (!this.isValidPrice(price)) {
            player.sendMessage(this.plugin.getConfigManager().getMessage("messages.invalidPrice"));
            return true;
         } else {
            ItemStack item = player.getInventory().getItemInMainHand();
            if (item != null && !item.getType().isAir()) {
               this.plugin.getAuctionManager().listItem(player, item, price);
               return true;
            } else {
               player.sendMessage(this.plugin.getConfigManager().getMessage("messages.noItemInHand"));
               return true;
            }
         }
      }
   }

   private boolean isValidPrice(double price) {
      return price >= 1.0 && price <= 1.0E18 && !Double.isNaN(price) && !Double.isInfinite(price);
   }
}
