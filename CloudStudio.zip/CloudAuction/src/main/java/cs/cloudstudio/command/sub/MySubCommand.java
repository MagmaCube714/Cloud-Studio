package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class MySubCommand implements SubCommand {
   private final CloudAuction plugin;

   public MySubCommand(CloudAuction plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "my";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage(this.plugin.getConfigManager().getMessage("messages.onlyPlayers"));
         return true;
      } else {
         this.plugin.getGUIManager().openMyItemsMenu((Player)sender, 0);
         return true;
      }
   }
}
