package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.command.SubCommand;
import cs.cloudstudio.util.PlaceholderUtility;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand implements SubCommand {
   private static final String ADMIN_PERMISSION = "cloudauction.admin";
   private final CloudAuction plugin;

   public ReloadSubCommand(CloudAuction plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "reload";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      this.plugin.getConfigManager().reload();
      this.plugin.getPermissionManager().loadGroupPermissions();
      PlaceholderUtility.init();
      this.plugin.getItemTranslator().reload();
      this.plugin.getAuctionManager().rebuildNameCache();
      sender.sendMessage(this.plugin.getConfigManager().getMessage("messages.reloadCmd"));
      return true;
   }

   @Override
   public boolean canUse(CommandSender sender) {
      return sender.hasPermission("cloudauction.admin");
   }
}
