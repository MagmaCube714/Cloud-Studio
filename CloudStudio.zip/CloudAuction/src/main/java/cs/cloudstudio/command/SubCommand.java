package cs.cloudstudio.command;

import java.util.Collections;
import java.util.List;
import org.bukkit.command.CommandSender;

public interface SubCommand {
   String getName();

   boolean execute(CommandSender var1, String[] var2);

   default List<String> tabComplete(CommandSender sender, String[] args) {
      return Collections.emptyList();
   }

   default boolean canUse(CommandSender sender) {
      return true;
   }
}
