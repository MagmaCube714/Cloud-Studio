package cs.cloudstudio.database;

public final class SqlDialect {
   private final DatabaseType type;

   private SqlDialect(DatabaseType type) {
      this.type = type;
   }

   public static SqlDialect of(DatabaseType type) {
      return new SqlDialect(type == null ? DatabaseType.SQLITE : type);
   }

   public String createAuctionTableSql() {
      return this.type == DatabaseType.MYSQL
         ? "CREATE TABLE IF NOT EXISTS auction_items (auction_id VARCHAR(36) PRIMARY KEY,seller_uuid VARCHAR(36) NOT NULL,item_data LONGBLOB NOT NULL,price DOUBLE NOT NULL,expire_time BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
         : "CREATE TABLE IF NOT EXISTS auction_items (auction_id TEXT PRIMARY KEY,seller_uuid TEXT NOT NULL,item_data BLOB NOT NULL,price REAL NOT NULL,expire_time INTEGER NOT NULL)";
   }

   public String createPendingReturnsTableSql() {
      return this.type == DatabaseType.MYSQL
         ? "CREATE TABLE IF NOT EXISTS pending_returns (id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,player_uuid VARCHAR(36) NOT NULL,item_data LONGBLOB NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
         : "CREATE TABLE IF NOT EXISTS pending_returns (id INTEGER PRIMARY KEY AUTOINCREMENT,player_uuid TEXT NOT NULL,item_data BLOB NOT NULL)";
   }

   public String upsertAuctionItemSql() {
      return this.type == DatabaseType.MYSQL
         ? "INSERT INTO auction_items (auction_id, seller_uuid, item_data, price, expire_time) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE seller_uuid = VALUES(seller_uuid), item_data = VALUES(item_data), price = VALUES(price), expire_time = VALUES(expire_time)"
         : "INSERT INTO auction_items (auction_id, seller_uuid, item_data, price, expire_time) VALUES (?, ?, ?, ?, ?) ON CONFLICT(auction_id) DO UPDATE SET seller_uuid = excluded.seller_uuid, item_data = excluded.item_data, price = excluded.price, expire_time = excluded.expire_time";
   }

   public String[] indexSql() {
      return new String[]{
         "CREATE INDEX IF NOT EXISTS idx_auction_seller ON auction_items(seller_uuid)",
         "CREATE INDEX IF NOT EXISTS idx_auction_expire ON auction_items(expire_time)",
         "CREATE INDEX IF NOT EXISTS idx_returns_player ON pending_returns(player_uuid)"
      };
   }
}
