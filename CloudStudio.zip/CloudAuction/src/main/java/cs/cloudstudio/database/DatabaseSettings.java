package cs.cloudstudio.database;

public final class DatabaseSettings {
   private final DatabaseType type;
   private final String host;
   private final int port;
   private final String username;
   private final String password;
   private final String playerDatabase;

   public DatabaseSettings(DatabaseType type, String host, int port, String username, String password, String playerDatabase) {
      this.type = type == null ? DatabaseType.SQLITE : type;
      this.host = host != null && !host.trim().isEmpty() ? host.trim() : "localhost";
      this.port = port <= 0 ? 3306 : port;
      this.username = username == null ? "admin" : username;
      this.password = password == null ? "admin" : password;
      this.playerDatabase = playerDatabase != null && !playerDatabase.trim().isEmpty() ? playerDatabase.trim() : "data";
   }

   public DatabaseType getType() {
      return this.type;
   }

   public String getHost() {
      return this.host;
   }

   public int getPort() {
      return this.port;
   }

   public String getUsername() {
      return this.username;
   }

   public String getPassword() {
      return this.password;
   }

   public String getPlayerDatabase() {
      return this.playerDatabase;
   }
}
