package cs.cloudstudio.database;

import java.util.Locale;

public enum DatabaseType {
   SQLITE,
   MYSQL;

   public static DatabaseType fromString(String value) {
      if (value == null) {
         return SQLITE;
      }

      String normalized = value.trim().toUpperCase(Locale.ROOT);
      return "MYSQL".equals(normalized) ? MYSQL : SQLITE;
   }
}
