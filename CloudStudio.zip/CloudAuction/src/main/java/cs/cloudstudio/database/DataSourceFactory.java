package cs.cloudstudio.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import cs.cloudstudio.CloudAuction;
import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public final class DataSourceFactory {
   private static final int SQLITE_POOL_SIZE = 1;
   private static final int MYSQL_POOL_SIZE = 6;

   private DataSourceFactory() {
   }

   public static HikariDataSource create(CloudAuction plugin, DatabaseSettings settings) {
      HikariConfig config = new HikariConfig();
      config.setPoolName("CloudAuction-" + settings.getType().name());
      config.setMaximumPoolSize(settings.getType() == DatabaseType.MYSQL ? 6 : 1);
      config.setMinimumIdle(settings.getType() == DatabaseType.MYSQL ? 1 : 1);
      config.setConnectionTimeout(10000L);
      config.setValidationTimeout(3000L);
      config.setLeakDetectionThreshold(0L);
      if (settings.getType() == DatabaseType.MYSQL) {
         configureMySql(config, settings);
      } else {
         configureSqlite(plugin, config, settings);
      }

      return new HikariDataSource(config);
   }

   public static void configureSqlitePragmas(HikariDataSource dataSource) throws SQLException {
      try (
         Connection connection = dataSource.getConnection();
         Statement statement = connection.createStatement();
      ) {
         statement.execute("PRAGMA foreign_keys=ON");
         statement.execute("PRAGMA journal_mode=WAL");
         statement.execute("PRAGMA busy_timeout=5000");
         statement.execute("PRAGMA synchronous=NORMAL");
      }
   }

   private static void configureSqlite(CloudAuction plugin, HikariConfig config, DatabaseSettings settings) {
      File file = new File(plugin.getDataFolder(), safeDatabaseName(settings.getPlayerDatabase()) + ".db");
      File parent = file.getParentFile();
      if (parent != null && !parent.exists()) {
         parent.mkdirs();
      }

      config.setDriverClassName("org.sqlite.JDBC");
      config.setJdbcUrl("jdbc:sqlite:" + file.getAbsolutePath());
      config.setConnectionTestQuery("SELECT 1");
   }

   private static void configureMySql(HikariConfig config, DatabaseSettings settings) {
      String database = safeDatabaseName(settings.getPlayerDatabase());
      config.setDriverClassName("com.mysql.cj.jdbc.Driver");
      config.setJdbcUrl(
         "jdbc:mysql://"
            + settings.getHost()
            + ":"
            + settings.getPort()
            + "/"
            + database
            + "?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=UTC"
      );
      config.setUsername(settings.getUsername());
      config.setPassword(settings.getPassword());
      config.addDataSourceProperty("cachePrepStmts", "true");
      config.addDataSourceProperty("prepStmtCacheSize", "250");
      config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
      config.addDataSourceProperty("useServerPrepStmts", "true");
      config.addDataSourceProperty("rewriteBatchedStatements", "true");
   }

   private static String safeDatabaseName(String raw) {
      if (raw != null && !raw.trim().isEmpty()) {
         String trimmed = raw.trim();
         StringBuilder builder = new StringBuilder(trimmed.length());

         for (int i = 0; i < trimmed.length(); i++) {
            char c = trimmed.charAt(i);
            if (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_' || c == '-') {
               builder.append(c);
            }
         }

         return builder.length() == 0 ? "data" : builder.toString();
      } else {
         return "data";
      }
   }
}
