package cs.cloudstudio.config;

import cs.cloudstudio.CloudAuction;
import cs.cloudstudio.database.DatabaseSettings;
import cs.cloudstudio.database.DatabaseType;
import cs.cloudstudio.util.ColorUtility;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public final class ConfigManager {
   private static final String DEFAULT_CATEGORY_MATERIAL = "BARRIER";
   private static final String DEFAULT_BUTTON_MATERIAL = "BARRIER";
   private static final int DEFAULT_CONFIRM_ITEM_SLOT = 22;
   private final CloudAuction plugin;
   private FileConfiguration config;
   private final Map<String, String> messageCache = new HashMap<>();
   private final Map<String, ConfigManager.MenuConfig> menuCache = new HashMap<>();
   private final Map<String, ConfigManager.ButtonConfig> buttonCache = new HashMap<>();
   private final Map<String, ConfigManager.CategoryConfig> categoryCache = new HashMap<>();
   private ConfigManager.SettingsConfig settingsConfig;
   private DatabaseSettings databaseSettings;
   private ConfigManager.DisplayConfig itemDisplayConfig;
   private ConfigManager.DisplayConfig myItemsDisplayConfig;
   private List<String> usageLines = Collections.emptyList();
   private List<Integer> confirmSlots = Collections.emptyList();
   private List<Integer> cancelSlots = Collections.emptyList();
   private boolean[] confirmSlotLookup = new boolean[54];
   private boolean[] cancelSlotLookup = new boolean[54];
   private List<String> groupPermissions = Collections.emptyList();
   private int confirmItemSlot = 22;
   private int version;

   public ConfigManager(CloudAuction plugin) {
      this.plugin = plugin;
      File configFile = new File(plugin.getDataFolder(), "config.yml");
      if (!configFile.exists()) {
         plugin.saveDefaultConfig();
      }

      this.config = plugin.getConfig();
      this.reloadCaches();
   }

   public void reload() {
      this.plugin.reloadConfig();
      this.config = this.plugin.getConfig();
      this.config.options().copyDefaults(true);
      this.reloadCaches();
      ColorUtility.clearCache();
   }

   private void reloadCaches() {
      this.cacheMessages();
      this.cacheSettings();
      this.cacheDatabaseSettings();
      this.cacheMenus();
      this.cacheButtons();
      this.cacheCategories();
      this.cacheDisplays();
      this.cacheUsage();
      this.cacheConfirmSlots();
      this.cacheGroupPermissions();
      this.version++;
   }

   private void cacheMessages() {
      this.messageCache.clear();
      this.cacheSection(this.config.getConfigurationSection("messages"), "messages");
      this.cacheSection(this.config.getConfigurationSection("time"), "time");
      this.cacheSection(this.config.getConfigurationSection("sortTypes"), "sortTypes");
      this.cacheSection(this.config.getConfigurationSection("itemDisplay.status"), "itemDisplay.status");
   }

   private void cacheSection(ConfigurationSection section, String prefix) {
      if (section != null) {
         for (String key : section.getKeys(false)) {
            String path = prefix + "." + key;
            if (section.isConfigurationSection(key)) {
               this.cacheSection(section.getConfigurationSection(key), path);
            } else if (section.isString(key) || section.isInt(key) || section.isDouble(key) || section.isLong(key) || section.isBoolean(key)) {
               this.messageCache.put(path, ColorUtility.colorize(String.valueOf(section.get(key))));
            }
         }
      }
   }

   private void cacheSettings() {
      ConfigurationSection section = this.config.getConfigurationSection("settings");
      long durationMillis = 86400000L;
      int maxItemsDefault = 5;
      int itemsPerPage = 28;
      if (section != null) {
         durationMillis = Math.max(1L, section.getLong("listingDurationHours", 24L)) * 60L * 60L * 1000L;
         maxItemsDefault = Math.max(0, section.getInt("maxItemsDefault", 5));
         itemsPerPage = Math.max(1, section.getInt("itemsPerPage", 28));
      }

      this.settingsConfig = new ConfigManager.SettingsConfig(durationMillis, maxItemsDefault, itemsPerPage);
   }

   private void cacheDatabaseSettings() {
      ConfigurationSection section = this.config.getConfigurationSection("database");
      if (section == null) {
         this.databaseSettings = new DatabaseSettings(DatabaseType.SQLITE, "localhost", 3306, "admin", "admin", "data");
      } else {
         DatabaseType type = DatabaseType.fromString(section.getString("type", "SQLite"));
         String host = section.getString("host", "localhost");
         int port = section.getInt("port", 3306);
         String username = section.getString("username", "admin");
         String password = section.getString("password", "admin");
         String playerDatabase = section.getString("playerDatabase", "data");
         this.databaseSettings = new DatabaseSettings(type, host, port, username, password, playerDatabase);
      }
   }

   private void cacheMenus() {
      this.menuCache.clear();
      ConfigurationSection guiSection = this.getGuiRootSection();
      if (guiSection != null) {
         for (String key : guiSection.getKeys(false)) {
            ConfigurationSection menuSection = guiSection.getConfigurationSection(key);
            if (menuSection != null) {
               String title = this.normalizeTitle(menuSection.getString("title", ""));
               List<Integer> slots = this.sanitizeSlots(menuSection.getIntegerList("slots"));
               this.menuCache.put(key, new ConfigManager.MenuConfig(title, Collections.unmodifiableList(slots)));
            }
         }
      }
   }

   private ConfigurationSection getGuiRootSection() {
      ConfigurationSection section = this.config.getConfigurationSection("gui");
      return section == null ? this.config.getConfigurationSection("menus") : section;
   }

   private ConfigurationSection getGuiMenuSection(String key) {
      ConfigurationSection section = this.config.getConfigurationSection("gui." + key);
      return section == null ? this.config.getConfigurationSection("menus." + key) : section;
   }

   private String normalizeTitle(String title) {
      if (title != null && !title.isEmpty()) {
         String trimmed = title.trim();
         return trimmed.length() > 1 && trimmed.charAt(0) == '%' && trimmed.indexOf(37, 1) < 0 ? trimmed + "%" : title;
      } else {
         return "";
      }
   }

   private void cacheButtons() {
      this.buttonCache.clear();
      ConfigurationSection buttonsSection = this.config.getConfigurationSection("buttons");
      if (buttonsSection != null) {
         for (String key : buttonsSection.getKeys(false)) {
            ConfigurationSection section = buttonsSection.getConfigurationSection(key);
            if (section != null) {
               Integer slot = section.contains("slot") ? section.getInt("slot") : null;
               String materialName = section.getString("material", "BARRIER");
               this.buttonCache
                  .put(
                     key,
                     new ConfigManager.ButtonConfig(
                        slot,
                        materialName,
                        this.matchMaterial(materialName, "BARRIER"),
                        section.contains("customModelData") ? section.getInt("customModelData") : null,
                        ColorUtility.colorize(section.getString("name", "")),
                        Collections.unmodifiableList(this.colorizeList(section.getStringList("lore")))
                     )
                  );
            }
         }
      }
   }

   private void cacheCategories() {
      this.categoryCache.clear();
      ConfigurationSection categoriesSection = this.config.getConfigurationSection("categories");
      if (categoriesSection != null) {
         for (String key : categoriesSection.getKeys(false)) {
            ConfigurationSection section = categoriesSection.getConfigurationSection(key);
            if (section != null) {
               String materialName = section.getString("material", "BARRIER");
               this.categoryCache
                  .put(
                     key,
                     new ConfigManager.CategoryConfig(
                        this.sanitizeSlot(section.getInt("slot", 0), 0),
                        materialName,
                        this.matchMaterial(materialName, "BARRIER"),
                        ColorUtility.colorize(section.getString("name", key)),
                        Collections.unmodifiableList(this.colorizeList(section.getStringList("lore")))
                     )
                  );
            }
         }
      }
   }

   private void cacheDisplays() {
      this.itemDisplayConfig = new ConfigManager.DisplayConfig(
         Collections.unmodifiableList(this.colorizeList(this.config.getStringList("itemDisplay.lore"))),
         ColorUtility.colorize(this.getRawString("itemDisplay.clickAction")),
         this.getMessage("itemDisplay.status.online"),
         this.getMessage("itemDisplay.status.offline")
      );
      this.myItemsDisplayConfig = new ConfigManager.DisplayConfig(
         Collections.unmodifiableList(this.colorizeList(this.config.getStringList("myItemsDisplay.lore"))),
         ColorUtility.colorize(this.getRawString("myItemsDisplay.clickAction")),
         "",
         ""
      );
   }

   private void cacheUsage() {
      this.usageLines = Collections.unmodifiableList(this.colorizeList(this.config.getStringList("messages.usage")));
   }

   private void cacheConfirmSlots() {
      ConfigurationSection confirmSection = this.getGuiMenuSection("confirm");
      if (confirmSection == null) {
         this.confirmSlots = Collections.emptyList();
         this.cancelSlots = Collections.emptyList();
         this.confirmSlotLookup = new boolean[54];
         this.cancelSlotLookup = new boolean[54];
         this.confirmItemSlot = 22;
      } else {
         this.confirmItemSlot = this.sanitizeSlot(confirmSection.getInt("itemSlot", 22), 22);
         this.confirmSlots = Collections.unmodifiableList(this.sanitizeSlots(confirmSection.getIntegerList("confirmSlots")));
         this.cancelSlots = Collections.unmodifiableList(this.sanitizeSlots(confirmSection.getIntegerList("cancelSlots")));
         this.confirmSlotLookup = this.buildSlotLookup(this.confirmSlots);
         this.cancelSlotLookup = this.buildSlotLookup(this.cancelSlots);
      }
   }

   private void cacheGroupPermissions() {
      this.groupPermissions = Collections.unmodifiableList(new ArrayList<>(this.config.getStringList("groupPermissions")));
   }

   private List<Integer> sanitizeSlots(List<Integer> source) {
      List<Integer> result = new ArrayList<>(source.size());
      boolean[] seen = new boolean[54];

      for (Integer slot : source) {
         if (slot != null) {
            int value = slot;
            if (value >= 0 && value <= 53 && !seen[value]) {
               seen[value] = true;
               result.add(value);
            }
         }
      }

      return result;
   }

   private int sanitizeSlot(int slot, int fallback) {
      return slot >= 0 && slot <= 53 ? slot : fallback;
   }

   private Material matchMaterial(String configured, String fallback) {
      Material material = Material.matchMaterial(configured == null ? fallback : configured);
      if (material != null) {
         return material;
      }

      material = Material.matchMaterial(fallback);
      return material == null ? Material.BARRIER : material;
   }

   private boolean[] buildSlotLookup(List<Integer> slots) {
      boolean[] lookup = new boolean[54];

      for (Integer slot : slots) {
         if (slot != null && slot >= 0 && slot < lookup.length) {
            lookup[slot] = true;
         }
      }

      return lookup;
   }

   private List<String> colorizeList(List<String> lines) {
      List<String> result = new ArrayList<>(lines.size());

      for (String line : lines) {
         result.add(ColorUtility.colorize(line));
      }

      return result;
   }

   private String getRawString(String path) {
      String value = this.config.getString(path);
      return value == null ? "" : value;
   }

   public String getMessage(String path) {
      String message = this.messageCache.get(path);
      if (message != null) {
         return message;
      }

      String value = this.config.getString(path);
      if (value == null) {
         return "";
      }

      message = ColorUtility.colorize(value);
      this.messageCache.put(path, message);
      return message;
   }

   public DatabaseSettings getDatabaseSettings() {
      return this.databaseSettings;
   }

   public long getListingDurationMillis() {
      return this.settingsConfig.listingDurationMillis;
   }

   public int getMaxItemsDefault() {
      return this.settingsConfig.maxItemsDefault;
   }

   public int getItemsPerPage() {
      return this.settingsConfig.itemsPerPage;
   }

   public String getGuiTitle(String menuKey) {
      ConfigManager.MenuConfig menuConfig = this.menuCache.get(menuKey);
      return menuConfig == null ? "" : menuConfig.title;
   }

   public List<Integer> getGuiSlots(String menuKey) {
      ConfigManager.MenuConfig menuConfig = this.menuCache.get(menuKey);
      return menuConfig == null ? Collections.emptyList() : menuConfig.slots;
   }

   public ConfigManager.ButtonConfig getButtonConfig(String buttonKey) {
      return this.buttonCache.get(buttonKey);
   }

   public int getButtonSlot(String buttonKey, int fallback) {
      ConfigManager.ButtonConfig buttonConfig = this.buttonCache.get(buttonKey);
      return buttonConfig != null && buttonConfig.slot != null ? this.sanitizeSlot(buttonConfig.slot, fallback) : fallback;
   }

   public ConfigManager.CategoryConfig getCategoryConfig(String categoryKey) {
      return this.categoryCache.get(categoryKey);
   }

   public String getCategoryDisplayName(String categoryKey) {
      ConfigManager.CategoryConfig categoryConfig = this.categoryCache.get(categoryKey);
      return categoryConfig == null ? categoryKey : categoryConfig.name;
   }

   public ConfigManager.DisplayConfig getItemDisplayConfig() {
      return this.itemDisplayConfig;
   }

   public ConfigManager.DisplayConfig getMyItemsDisplayConfig() {
      return this.myItemsDisplayConfig;
   }

   public List<String> getUsageLines() {
      return this.usageLines;
   }

   public List<Integer> getConfirmSlots() {
      return this.confirmSlots;
   }

   public List<Integer> getCancelSlots() {
      return this.cancelSlots;
   }

   public boolean isConfirmSlot(int slot) {
      return slot >= 0 && slot < this.confirmSlotLookup.length && this.confirmSlotLookup[slot];
   }

   public boolean isCancelSlot(int slot) {
      return slot >= 0 && slot < this.cancelSlotLookup.length && this.cancelSlotLookup[slot];
   }

   public int getConfirmItemSlot() {
      return this.confirmItemSlot;
   }

   public List<String> getGroupPermissions() {
      return this.groupPermissions;
   }

   public int getVersion() {
      return this.version;
   }

   public boolean isExpired(long expireTime) {
      return System.currentTimeMillis() >= expireTime;
   }

   public static final class ButtonConfig {
      private final Integer slot;
      private final String material;
      private final Material materialType;
      private final Integer customModelData;
      private final String name;
      private final List<String> lore;

      private ButtonConfig(Integer slot, String material, Material materialType, Integer customModelData, String name, List<String> lore) {
         this.slot = slot;
         this.material = material;
         this.materialType = materialType;
         this.customModelData = customModelData;
         this.name = name;
         this.lore = lore;
      }

      public Integer slot() {
         return this.slot;
      }

      public String material() {
         return this.material;
      }

      public Material materialType() {
         return this.materialType;
      }

      public Integer customModelData() {
         return this.customModelData;
      }

      public String name() {
         return this.name;
      }

      public List<String> lore() {
         return this.lore;
      }
   }

   public static final class CategoryConfig {
      private final int slot;
      private final String material;
      private final Material materialType;
      private final String name;
      private final List<String> lore;

      private CategoryConfig(int slot, String material, Material materialType, String name, List<String> lore) {
         this.slot = slot;
         this.material = material;
         this.materialType = materialType;
         this.name = name;
         this.lore = lore;
      }

      public int slot() {
         return this.slot;
      }

      public String material() {
         return this.material;
      }

      public Material materialType() {
         return this.materialType;
      }

      public String name() {
         return this.name;
      }

      public List<String> lore() {
         return this.lore;
      }
   }

   public static final class DisplayConfig {
      private final List<String> lore;
      private final String clickAction;
      private final String onlineStatus;
      private final String offlineStatus;

      private DisplayConfig(List<String> lore, String clickAction, String onlineStatus, String offlineStatus) {
         this.lore = lore;
         this.clickAction = clickAction;
         this.onlineStatus = onlineStatus;
         this.offlineStatus = offlineStatus;
      }

      public List<String> lore() {
         return this.lore;
      }

      public String clickAction() {
         return this.clickAction;
      }

      public String onlineStatus() {
         return this.onlineStatus;
      }

      public String offlineStatus() {
         return this.offlineStatus;
      }
   }

   public static final class MenuConfig {
      private final String title;
      private final List<Integer> slots;

      private MenuConfig(String title, List<Integer> slots) {
         this.title = title;
         this.slots = slots;
      }

      public String title() {
         return this.title;
      }

      public List<Integer> slots() {
         return this.slots;
      }
   }

   private static final class SettingsConfig {
      private final long listingDurationMillis;
      private final int maxItemsDefault;
      private final int itemsPerPage;

      private SettingsConfig(long listingDurationMillis, int maxItemsDefault, int itemsPerPage) {
         this.listingDurationMillis = listingDurationMillis;
         this.maxItemsDefault = maxItemsDefault;
         this.itemsPerPage = itemsPerPage;
      }
   }
}
