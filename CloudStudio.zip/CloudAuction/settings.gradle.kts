rootProject.name = "CloudAuction"
