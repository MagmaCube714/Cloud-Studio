rootProject.name = "CloudShards"
