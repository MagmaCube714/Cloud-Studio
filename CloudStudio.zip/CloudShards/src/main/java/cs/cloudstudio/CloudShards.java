package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.config.MessageConfig;
import cs.cloudstudio.config.PluginSettings;
import cs.cloudstudio.listener.CraftingListener;
import cs.cloudstudio.listener.PlayerDeathListener;
import cs.cloudstudio.manager.ShardManager;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.NBTUtil;
import java.io.File;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudShards extends JavaPlugin {
   private PluginSettings settings;
   private ShardManager shardManager;

   public void onEnable() {
      this.saveDefaultConfig();
      this.reloadPluginConfiguration();
      NBTUtil.initialize(this);
      this.shardManager = new ShardManager(this, new File(this.getDataFolder(), "shards.yml"));
      AdminCommand adminCommand = new AdminCommand(this);
      if (!adminCommand.register()) {
         this.warning("Команда cloudshards не найдена в plugin.yml");
         this.getServer().getPluginManager().disablePlugin(this);
      } else {
         this.registerListeners();
         this.console("&fCloudShards &aуспешно загружен!");
      }
   }

   public void onDisable() {
      if (this.shardManager != null) {
         this.shardManager.unregisterRecipes();
      }

      NBTUtil.shutdown();
      this.console("&fCloudShards &cуспешно выгружен!");
   }

   public void reloadPluginConfiguration() {
      this.reloadConfig();
      this.settings = PluginSettings.load(this.getConfig());
   }

   public PluginSettings getSettings() {
      return this.settings;
   }

   public MessageConfig getMessages() {
      return this.settings.getMessages();
   }

   public ShardManager getShardManager() {
      return this.shardManager;
   }

   private void registerListeners() {
      this.getServer().getPluginManager().registerEvents(new PlayerDeathListener(this), this);
      this.getServer().getPluginManager().registerEvents(new CraftingListener(this), this);
   }

   public void console(String message) {
      this.getServer().getConsoleSender().sendMessage(ColorUtil.translateAlternateColorCodes('&', message));
   }

   public void warning(String message) {
      this.getLogger().warning("[CloudShards] " + message);
   }
}
