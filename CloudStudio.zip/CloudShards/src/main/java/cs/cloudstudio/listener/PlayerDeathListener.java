package cs.cloudstudio.listener;

import cs.cloudstudio.CloudShards;
import cs.cloudstudio.manager.BallShard;
import cs.cloudstudio.manager.ShardManager;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public final class PlayerDeathListener implements Listener {
   private final ShardManager shardConfiguration;
   private static final int HAND_MULTIPLIER = 2;
   private static final int INVENTORY_MULTIPLIER = 1;
   private static final int OFF_HAND_SLOT = 40;

   public PlayerDeathListener(CloudShards plugin) {
      this.shardConfiguration = plugin.getShardManager();
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void on(PlayerDeathEvent event) {
      Player player = event.getEntity();
      if (!event.getKeepInventory()) {
         Map<BallShard, Long> shardAmounts = new HashMap<>(2);
         this.collectFromDrops(player.getInventory(), event.getDrops(), shardAmounts);
         if (!shardAmounts.isEmpty()) {
            addShardDrops(event.getDrops(), shardAmounts);
         }
      }
   }

   private void collectFromDrops(PlayerInventory inventory, List<ItemStack> drops, Map<BallShard, Long> shardAmounts) {
      ItemStack mainHand = inventory.getItemInMainHand();
      ItemStack offHand = inventory.getItem(OFF_HAND_SLOT);
      boolean mainHandCounted = false;
      boolean offHandCounted = false;
      Iterator<ItemStack> iterator = drops.iterator();

      while (iterator.hasNext()) {
         ItemStack item = iterator.next();
         BallShard shard = this.getFinalBallShard(item);
         if (shard != null) {
            int multiplier = INVENTORY_MULTIPLIER;
            if (!mainHandCounted && sameStack(item, mainHand)) {
               mainHandCounted = true;
               multiplier = HAND_MULTIPLIER;
            } else if (!offHandCounted && sameStack(item, offHand)) {
               offHandCounted = true;
               multiplier = HAND_MULTIPLIER;
            }

            addAmount(shardAmounts, shard, item.getAmount() * multiplier);
            iterator.remove();
         }
      }
   }

   private static boolean sameStack(ItemStack item, ItemStack handItem) {
      return handItem != null && !handItem.getType().isAir() && handItem.getAmount() == item.getAmount() && handItem.isSimilar(item);
   }

   private BallShard getFinalBallShard(ItemStack item) {
      return item != null && !item.getType().isAir() && item.hasItemMeta() ? this.shardConfiguration.getBallShardByItem(item) : null;
   }

   private static void addAmount(Map<BallShard, Long> shardAmounts, BallShard shard, int amount) {
      if (amount > 0) {
         Long currentAmount = shardAmounts.get(shard);
         shardAmounts.put(shard, currentAmount == null ? amount : currentAmount + amount);
      }
   }

   private static void addShardDrops(List<ItemStack> drops, Map<BallShard, Long> shardAmounts) {
      for (Entry<BallShard, Long> entry : shardAmounts.entrySet()) {
         long remaining = entry.getValue();
         BallShard shard = entry.getKey();

         while (remaining > 0L) {
            ItemStack shardItem = shard.build();
            int stackAmount = (int)Math.min(shardItem.getType().getMaxStackSize(), remaining);
            shardItem.setAmount(stackAmount);
            drops.add(shardItem);
            remaining -= stackAmount;
         }
      }
   }
}
