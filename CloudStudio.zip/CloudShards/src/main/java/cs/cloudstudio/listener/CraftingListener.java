package cs.cloudstudio.listener;

import cs.cloudstudio.CloudShards;
import cs.cloudstudio.manager.BallShard;
import cs.cloudstudio.manager.ShardManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;

public final class CraftingListener implements Listener {
   private final ShardManager shardConfiguration;

   public CraftingListener(CloudShards plugin) {
      this.shardConfiguration = plugin.getShardManager();
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onPrepareCraft(PrepareItemCraftEvent event) {
      ItemStack[] matrix = event.getInventory().getMatrix();
      BallShard shard = this.getValidCraftShard(matrix);
      if (shard != null) {
         event.getInventory().setResult(shard.getFinalBall());
      } else {
         ItemStack result = event.getInventory().getResult();
         if (this.shardConfiguration.isManagedRecipe(event.getRecipe())
            || this.containsShardItem(matrix)
            || this.containsFinalBallItem(matrix)
            || this.shardConfiguration.isFinalBall(result)) {
            event.getInventory().setResult(null);
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onCraft(CraftItemEvent event) {
      ItemStack[] matrix = event.getInventory().getMatrix();
      BallShard shard = this.getValidCraftShard(matrix);
      if (shard != null) {
         ItemStack finalBall = shard.getFinalBall();
         event.setCurrentItem(finalBall);
         event.getInventory().setResult(finalBall);
      } else {
         if (this.shardConfiguration.isManagedRecipe(event.getRecipe())
            || this.containsShardItem(matrix)
            || this.containsFinalBallItem(matrix)
            || this.shardConfiguration.isFinalBall(event.getCurrentItem())) {
            event.setCancelled(true);
            event.setCurrentItem(null);
            event.getInventory().setResult(null);
         }
      }
   }

   private BallShard getValidCraftShard(ItemStack[] matrix) {
      BallShard firstShard = null;
      int shardCount = 0;
      boolean hasForeignItem = false;

      for (ItemStack item : matrix) {
         if (item != null && !item.getType().isAir()) {
            BallShard currentShard = this.shardConfiguration.getShardByItem(item);
            if (currentShard == null) {
               hasForeignItem = true;
            } else {
               if (firstShard == null) {
                  firstShard = currentShard;
               } else if (!firstShard.getMeta().equals(currentShard.getMeta())) {
                  return null;
               }

               shardCount++;
            }
         }
      }

      return firstShard != null && !hasForeignItem && shardCount == 4 ? firstShard : null;
   }

   private boolean containsShardItem(ItemStack[] matrix) {
      for (ItemStack item : matrix) {
         if (item != null && !item.getType().isAir() && this.shardConfiguration.getShardByItem(item) != null) {
            return true;
         }
      }

      return false;
   }

   private boolean containsFinalBallItem(ItemStack[] matrix) {
      for (ItemStack item : matrix) {
         if (item != null && !item.getType().isAir() && this.shardConfiguration.isFinalBall(item)) {
            return true;
         }
      }

      return false;
   }
}
