package cs.cloudstudio.util;

import java.util.regex.Pattern;

public final class ColorUtil {
   private static final String LEGACY_CODES = "0123456789AaBbCcDdEeFfKkLlMmNnOoRrXx";
   private static final Pattern STRIP_COLOR_PATTERN = Pattern.compile("(?i)§[0-9A-FK-ORX]");

   private ColorUtil() {
   }

   public static String color(String input) {
      if (input != null && !input.isEmpty()) {
         return input.indexOf(38) == -1 ? input : translateAlternateColorCodes('&', input);
      } else {
         return "";
      }
   }

   public static String strip(String input) {
      return input == null ? null : STRIP_COLOR_PATTERN.matcher(input).replaceAll("");
   }

   public static String translateAlternateColorCodes(char altColorChar, String text) {
      char[] chars = text.toCharArray();

      for (int i = 0; i < chars.length - 1; i++) {
         if (chars[i] == altColorChar && LEGACY_CODES.indexOf(chars[i + 1]) > -1) {
            chars[i] = '§';
            chars[i + 1] = Character.toLowerCase(chars[i + 1]);
         }
      }

      return new String(chars);
   }
}
