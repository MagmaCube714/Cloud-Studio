package cs.cloudstudio.util;

import cs.cloudstudio.CloudShards;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public final class NBTUtil {
   private static final String SHARD_META_KEY_NAME = "shard_meta";
   private static final String BALL_META_KEY_NAME = "ball_meta";
   private static final String RWITEMS_NAMESPACE = "rwitems";
   private static final String RWITEMS_ITEM_KEY = "rwitems-item";
   private static final Map<String, NamespacedKey> LEGACY_KEYS = new HashMap<>();
   private static CloudShards plugin;
   private static NamespacedKey shardMetaKey;
   private static NamespacedKey ballMetaKey;

   private NBTUtil() {
   }

   public static void initialize(CloudShards pluginInstance) {
      plugin = pluginInstance;
      shardMetaKey = new NamespacedKey(pluginInstance, "shard_meta");
      ballMetaKey = new NamespacedKey(pluginInstance, "ball_meta");
      LEGACY_KEYS.clear();
   }

   public static void shutdown() {
      LEGACY_KEYS.clear();
      shardMetaKey = null;
      ballMetaKey = null;
      plugin = null;
   }

   public static void clearLegacyKeyCache() {
      LEGACY_KEYS.clear();
   }

   public static void setShardMeta(ItemStack item, String meta) {
      setString(item, shardMetaKey, meta);
   }

   public static void setBallMeta(ItemStack item, String meta) {
      setString(item, ballMetaKey, meta);
   }

   public static String getShardMeta(ItemStack item) {
      return getString(item, shardMetaKey);
   }

   public static String getBallMeta(ItemStack item) {
      return getString(item, ballMetaKey);
   }

   public static void addItemNBT(ItemStack item, String key) {
      NamespacedKey namespacedKey = getLegacyKey(key);
      if (namespacedKey != null) {
         setString(item, namespacedKey, "");
      }
   }

   public static boolean hasItemNBT(ItemStack item, String key) {
      if (item != null && item.hasItemMeta()) {
         NamespacedKey namespacedKey = getLegacyKey(key);
         if (namespacedKey == null) {
            return false;
         }

         ItemMeta itemMeta = item.getItemMeta();
         return itemMeta != null && itemMeta.getPersistentDataContainer().has(namespacedKey, PersistentDataType.STRING);
      } else {
         return false;
      }
   }

   public static String getPersistentString(ItemStack item, String namespace, String keyName) {
      if (item != null && namespace != null && keyName != null && item.hasItemMeta()) {
         ItemMeta itemMeta = item.getItemMeta();
         if (itemMeta == null) {
            return null;
         }

         PersistentDataContainer container = itemMeta.getPersistentDataContainer();
         NamespacedKey exactKey = parseKey(namespace, keyName);
         if (exactKey != null) {
            String exactValue = (String)container.get(exactKey, PersistentDataType.STRING);
            if (exactValue != null) {
               return exactValue;
            }
         }

         for (NamespacedKey key : safeKeys(container)) {
            if (namespace.equalsIgnoreCase(key.getNamespace()) && keyName.equalsIgnoreCase(key.getKey()) && container.has(key, PersistentDataType.STRING)) {
               return (String)container.get(key, PersistentDataType.STRING);
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public static Set<String> getFinalBallCandidateTokens(ItemStack item) {
      if (item != null && item.hasItemMeta()) {
         ItemMeta itemMeta = item.getItemMeta();
         if (itemMeta == null) {
            return Collections.emptySet();
         }

         PersistentDataContainer container = itemMeta.getPersistentDataContainer();
         Set<String> tokens = new LinkedHashSet<>();
         addToken(tokens, getString(container, ballMetaKey));
         NamespacedKey rwItemsKey = parseKey("rwitems", "rwitems-item");
         String rwItemsId = getString(container, rwItemsKey);
         addToken(tokens, rwItemsId);
         if (rwItemsId != null && !rwItemsId.isEmpty()) {
            addToken(tokens, "rwitems:" + rwItemsId);
         }

         for (NamespacedKey key : safeKeys(container)) {
            String namespace = key.getNamespace();
            String keyName = key.getKey();
            boolean hasString = container.has(key, PersistentDataType.STRING);
            String value = hasString ? (String)container.get(key, PersistentDataType.STRING) : null;
            if (isOwnNamespace(namespace)) {
               addToken(tokens, keyName);
               addToken(tokens, namespace + ":" + keyName);
               if ("ball_meta".equalsIgnoreCase(keyName)) {
                  addToken(tokens, value);
               }

               if (keyName.endsWith("_ball")) {
                  addToken(tokens, keyName.substring(0, keyName.length() - 5));
               }
            } else if (isKnownExternalItemIdKey(namespace, keyName) || looksLikeItemIdKey(keyName)) {
               addToken(tokens, value);
               if (value != null && !value.isEmpty()) {
                  addToken(tokens, namespace + ":" + value);
               }
            }
         }

         return tokens.isEmpty() ? Collections.emptySet() : tokens;
      } else {
         return Collections.emptySet();
      }
   }

   private static Set<NamespacedKey> safeKeys(PersistentDataContainer container) {
      try {
         return container.getKeys();
      } catch (IllegalArgumentException ignored) {
         return Collections.emptySet();
      }
   }

   private static NamespacedKey parseKey(String namespace, String keyName) {
      if (namespace != null && keyName != null) {
         try {
            return NamespacedKey.fromString(namespace.toLowerCase(Locale.ROOT) + ":" + keyName.toLowerCase(Locale.ROOT));
         } catch (IllegalArgumentException ignored) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static String getString(PersistentDataContainer container, NamespacedKey key) {
      return container != null && key != null ? (String)container.get(key, PersistentDataType.STRING) : null;
   }

   private static boolean isOwnNamespace(String namespace) {
      return plugin != null && namespace != null && plugin.getName().equalsIgnoreCase(namespace);
   }

   private static boolean isKnownExternalItemIdKey(String namespace, String keyName) {
      return "rwitems".equalsIgnoreCase(namespace) && "rwitems-item".equalsIgnoreCase(keyName);
   }

   private static boolean looksLikeItemIdKey(String keyName) {
      if (keyName == null) {
         return false;
      }

      String normalized = keyName.toLowerCase(Locale.ROOT);
      return normalized.equals("item")
         || normalized.equals("item-id")
         || normalized.equals("item_id")
         || normalized.equals("custom-item")
         || normalized.equals("custom_item")
         || normalized.endsWith("-item")
         || normalized.endsWith("_item")
         || normalized.endsWith("-item-id")
         || normalized.endsWith("_item_id");
   }

   private static void addToken(Set<String> tokens, String token) {
      if (token != null && !token.isEmpty()) {
         tokens.add(token.toLowerCase(Locale.ROOT));
      }
   }

   private static void setString(ItemStack item, NamespacedKey key, String value) {
      if (item != null && key != null) {
         ItemMeta itemMeta = item.getItemMeta();
         if (itemMeta != null) {
            itemMeta.getPersistentDataContainer().set(key, PersistentDataType.STRING, value == null ? "" : value);
            item.setItemMeta(itemMeta);
         }
      }
   }

   private static String getString(ItemStack item, NamespacedKey key) {
      if (item != null && key != null && item.hasItemMeta()) {
         ItemMeta itemMeta = item.getItemMeta();
         return itemMeta == null ? null : (String)itemMeta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
      } else {
         return null;
      }
   }

   private static NamespacedKey getLegacyKey(String key) {
      if (plugin != null && key != null && !key.isEmpty()) {
         NamespacedKey cachedKey = LEGACY_KEYS.get(key);
         if (cachedKey != null) {
            return cachedKey;
         }

         try {
            NamespacedKey namespacedKey = new NamespacedKey(plugin, key);
            LEGACY_KEYS.put(key, namespacedKey);
            return namespacedKey;
         } catch (IllegalArgumentException ignored) {
            return null;
         }
      } else {
         return null;
      }
   }
}
