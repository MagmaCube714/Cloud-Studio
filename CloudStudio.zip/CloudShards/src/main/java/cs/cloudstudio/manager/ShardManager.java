package cs.cloudstudio.manager;

import cs.cloudstudio.CloudShards;
import cs.cloudstudio.config.ShardItemSettings;
import cs.cloudstudio.util.NBTUtil;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.bukkit.Keyed;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;

public final class ShardManager {
   private static final String BALL_SUFFIX = "_ball";
   private final CloudShards plugin;
   private final File configFile;
   private final ArrayList<BallShard> shards = new ArrayList<>();
   private final List<BallShard> shardsView = Collections.unmodifiableList(this.shards);
   private final ArrayList<String> shardMetas = new ArrayList<>();
   private final List<String> shardMetasView = Collections.unmodifiableList(this.shardMetas);
   private final Map<String, BallShard> shardsByMeta = new HashMap<>();
   private final Map<String, BallShard> finalBallTokens = new HashMap<>();
   private final Set<Material> shardMaterials = EnumSet.noneOf(Material.class);
   private final Set<Material> finalBallMaterials = EnumSet.noneOf(Material.class);
   private final Set<NamespacedKey> registeredRecipeKeys = new HashSet<>();
   private final String recipeNamespace;
   private boolean legacyRecipeScanDone;
   private YamlConfiguration config;

   public ShardManager(CloudShards plugin, File configFile) {
      this.plugin = plugin;
      this.configFile = configFile;
      this.recipeNamespace = plugin.getName().toLowerCase(Locale.ROOT);
      if (!configFile.exists()) {
         plugin.saveResource("shards.yml", false);
      }

      this.load();
   }

   public void load() {
      this.unregisterRecipes();
      NBTUtil.clearLegacyKeyCache();
      this.config = YamlConfiguration.loadConfiguration(this.configFile);
      this.shards.clear();
      this.shardMetas.clear();
      this.shardsByMeta.clear();
      this.finalBallTokens.clear();
      this.shardMaterials.clear();
      this.finalBallMaterials.clear();
      ConfigurationSection shardsSection = this.config.getConfigurationSection("shards");
      if (shardsSection != null) {
         Set<String> keys = shardsSection.getKeys(false);
         this.shards.ensureCapacity(keys.size());
         this.shardMetas.ensureCapacity(keys.size());
         ShardItemSettings shardItemSettings = this.plugin.getSettings().getShardItemSettings();

         for (String key : keys) {
            ConfigurationSection shardSection = shardsSection.getConfigurationSection(key);
            if (shardSection != null) {
               BallShard shard = BallShard.deserialize(shardSection.getValues(false), shardItemSettings);
               if (shard != null && !shard.getMeta().isEmpty()) {
                  String normalizedMeta = normalizeToken(shard.getMeta());
                  if (!this.shardsByMeta.containsKey(normalizedMeta)) {
                     this.shards.add(shard);
                     this.shardMetas.add(shard.getMeta());
                     this.shardsByMeta.put(normalizedMeta, shard);
                     this.shardMaterials.add(shard.getMaterial());
                     this.finalBallMaterials.add(shard.getFinalBallType());
                     this.registerFinalBallTokens(shard);
                  }
               }
            }
         }

         this.registerTriggerRecipes();
      }
   }

   public void saveShard(BallShard shard) throws IOException {
      this.config.set("shards." + shard.getMeta(), shard.serialize());
      this.config.save(this.configFile);
      this.load();
   }

   public void unregisterRecipes() {
      if (this.registeredRecipeKeys.isEmpty()) {
         if (!this.legacyRecipeScanDone) {
            this.legacyRecipeScanDone = true;
            this.removeLegacyRecipesByScan();
         }
      } else {
         for (NamespacedKey key : this.registeredRecipeKeys) {
            this.plugin.getServer().removeRecipe(key);
         }

         this.registeredRecipeKeys.clear();
      }
   }

   public boolean isManagedRecipe(Recipe recipe) {
      return recipe instanceof Keyed && this.isCloudShardsRecipeKey(((Keyed)recipe).getKey());
   }

   public List<BallShard> getShards() {
      return this.shardsView;
   }

   public List<String> getShardMetas() {
      return this.shardMetasView;
   }

   public BallShard getShardByMeta(String meta) {
      return meta == null ? null : this.shardsByMeta.get(normalizeToken(meta));
   }

   public BallShard getShardByItem(ItemStack item) {
      if (item != null && !item.getType().isAir()) {
         String meta = NBTUtil.getShardMeta(item);
         BallShard shard = this.getShardByMeta(meta);
         if (shard != null && item.getType() == shard.getMaterial()) {
            return shard;
         }

         if (!this.shardMaterials.contains(item.getType())) {
            return null;
         }

         for (BallShard current : this.shards) {
            if (item.getType() == current.getMaterial() && NBTUtil.hasItemNBT(item, current.getMeta())) {
               return current;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public BallShard getBallShardByItem(ItemStack item) {
      if (item != null && !item.getType().isAir()) {
         if (this.getShardByItem(item) != null) {
            return null;
         }

         String directMeta = NBTUtil.getBallMeta(item);
         BallShard shard = this.getShardByMeta(directMeta);
         if (isExpectedFinalType(item, shard)) {
            return shard;
         }

         if (!this.finalBallMaterials.contains(item.getType())) {
            return null;
         }

         for (String token : NBTUtil.getFinalBallCandidateTokens(item)) {
            shard = this.getShardByFinalBallToken(token);
            if (shard != null && item.getType() == shard.getFinalBallType()) {
               return shard;
            }
         }

         for (BallShard current : this.shards) {
            if (item.getType() == current.getFinalBallType() && NBTUtil.hasItemNBT(item, current.getMeta() + "_ball")) {
               return current;
            }
         }

         for (BallShard current : this.shards) {
            if (current.matchesConfiguredFinalBall(item)) {
               return current;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public boolean isFinalBall(ItemStack item) {
      return this.getBallShardByItem(item) != null;
   }

   public boolean containsFinalBallSimilar(ItemStack item) {
      if (item != null && !item.getType().isAir()) {
         if (!this.finalBallMaterials.contains(item.getType())) {
            return false;
         }

         for (BallShard shard : this.shards) {
            if (shard.isFinalBallSimilar(item) || shard.matchesConfiguredFinalBall(item)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private void registerFinalBallTokens(BallShard shard) {
      String meta = shard.getMeta();
      this.addFinalBallToken(meta, shard);
      this.addFinalBallToken(meta + "_ball", shard);

      for (String token : NBTUtil.getFinalBallCandidateTokens(shard.getFinalBall())) {
         this.addFinalBallToken(token, shard);
      }
   }

   private void addFinalBallToken(String token, BallShard shard) {
      if (token != null && !token.isEmpty() && shard != null) {
         this.finalBallTokens.putIfAbsent(normalizeToken(token), shard);
      }
   }

   private BallShard getShardByFinalBallToken(String token) {
      if (token != null && !token.isEmpty()) {
         String normalized = normalizeToken(token);
         BallShard shard = this.finalBallTokens.get(normalized);
         if (shard != null) {
            return shard;
         }

         shard = this.getShardByMeta(normalized);
         if (shard != null) {
            return shard;
         }

         if (normalized.endsWith("_ball")) {
            String withoutSuffix = normalized.substring(0, normalized.length() - "_ball".length());
            shard = this.finalBallTokens.get(withoutSuffix);
            if (shard != null) {
               return shard;
            }

            shard = this.getShardByMeta(withoutSuffix);
            if (shard != null) {
               return shard;
            }
         }

         int separatorIndex = normalized.indexOf(58);
         return separatorIndex >= 0 && separatorIndex + 1 < normalized.length()
            ? this.getShardByFinalBallToken(normalized.substring(separatorIndex + 1))
            : null;
      } else {
         return null;
      }
   }

   private static boolean isExpectedFinalType(ItemStack item, BallShard shard) {
      return shard != null && item != null && item.getType() == shard.getFinalBallType();
   }

   private void registerTriggerRecipes() {
      for (Material material : this.shardMaterials) {
         CustomCraftRecipe customCraftRecipe = new CustomCraftRecipe(this.plugin, material);
         customCraftRecipe.register();
         this.registeredRecipeKeys.add(customCraftRecipe.getKey());
      }
   }

   private void removeLegacyRecipesByScan() {
      List<NamespacedKey> legacyKeys = new ArrayList<>();
      Iterator<Recipe> recipeIterator = this.plugin.getServer().recipeIterator();

      while (recipeIterator.hasNext()) {
         Recipe recipe = recipeIterator.next();
         if (recipe instanceof Keyed) {
            NamespacedKey key = ((Keyed)recipe).getKey();
            if (this.isCloudShardsRecipeKey(key)) {
               legacyKeys.add(key);
            }
         }
      }

      for (NamespacedKey key : legacyKeys) {
         this.plugin.getServer().removeRecipe(key);
      }
   }

   private boolean isCloudShardsRecipeKey(NamespacedKey key) {
      return key != null && this.recipeNamespace.equals(key.getNamespace()) && key.getKey().startsWith("ball-shard-");
   }

   private static String normalizeToken(String token) {
      return token.toLowerCase(Locale.ROOT);
   }
}
