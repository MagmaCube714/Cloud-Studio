package cs.cloudstudio.manager;

import cs.cloudstudio.config.ShardItemSettings;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.NBTUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Material;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

public final class BallShard implements ConfigurationSerializable {
   private final int modelData;
   private final String name;
   private final String meta;
   private final Material material;
   private final ItemStack finalBall;
   private final Material finalBallType;
   private final List<String> lore;
   private final String coloredName;
   private final List<String> coloredLore;
   private transient ItemStack cachedShardItem;

   public BallShard(int modelData, String name, String meta, Material material, ItemStack finalBall, List<String> lore, ShardItemSettings settings) {
      this.modelData = Math.max(0, modelData);
      this.name = name == null ? "" : name;
      this.meta = meta == null ? "" : meta;
      this.material = material != null && !material.isAir() && material.isItem() ? material : Material.PAPER;
      this.finalBall = finalBall != null && !finalBall.getType().isAir() ? finalBall.clone() : new ItemStack(Material.PLAYER_HEAD);
      this.finalBall.setAmount(1);
      this.finalBallType = this.finalBall.getType();
      this.lore = copyLore(lore, settings);
      this.coloredName = createShardName(this.name, this.finalBall, settings);
      this.coloredLore = colorizeLore(this.lore);
   }

   public Map<String, Object> serialize() {
      Map<String, Object> ballShardObject = new HashMap<>(6);
      ballShardObject.put("modelData", this.modelData);
      ballShardObject.put("name", this.name);
      ballShardObject.put("meta", this.meta);
      ballShardObject.put("material", this.material.name());
      ballShardObject.put("finalBall", this.finalBall.clone());
      ballShardObject.put("lore", this.lore);
      return ballShardObject;
   }

   public static BallShard deserialize(Map<String, Object> args) {
      return deserialize(args, ShardItemSettings.defaults());
   }

   public static BallShard deserialize(Map<String, Object> args, ShardItemSettings settings) {
      if (args == null) {
         return null;
      } else {
         Object modelDataObject = args.get("modelData");
         Object nameObject = args.get("name");
         Object metaObject = args.get("meta");
         Object materialObject = args.get("material");
         Object finalBallObject = args.get("finalBall");
         Object loreObject = args.get("lore");
         if (metaObject instanceof String && finalBallObject instanceof ItemStack) {
            int modelData = modelDataObject instanceof Number ? ((Number)modelDataObject).intValue() : 0;
            String name = nameObject instanceof String ? (String)nameObject : "";
            String meta = (String)metaObject;
            Material material = materialObject instanceof String ? Material.getMaterial(((String)materialObject).toUpperCase(Locale.ROOT)) : Material.PAPER;
            List<String> lore = toStringList(loreObject);
            return new BallShard(modelData, name, meta, material, (ItemStack)finalBallObject, lore, settings);
         } else {
            return null;
         }
      }
   }

   public ItemStack build() {
      ItemStack cached = this.cachedShardItem;
      if (cached == null) {
         cached = this.createShardItem();
         this.cachedShardItem = cached;
      }

      return cached.clone();
   }

   public int getModelData() {
      return this.modelData;
   }

   public String getName() {
      return this.name;
   }

   public String getMeta() {
      return this.meta;
   }

   public Material getMaterial() {
      return this.material;
   }

   public Material getFinalBallType() {
      return this.finalBallType;
   }

   public ItemStack getFinalBall() {
      ItemStack item = this.finalBall.clone();
      item.setAmount(1);
      return item;
   }

   public boolean isFinalBallSimilar(ItemStack item) {
      return item != null && item.getType() == this.finalBallType && this.finalBall.isSimilar(item);
   }

   public boolean matchesConfiguredFinalBall(ItemStack item) {
      if (item == null || item.getType() != this.finalBallType || !item.hasItemMeta()) {
         return false;
      }

      if (this.finalBall.isSimilar(item)) {
         return true;
      }

      ItemMeta expectedMeta = this.finalBall.getItemMeta();
      ItemMeta actualMeta = item.getItemMeta();
      if (expectedMeta != null && actualMeta != null) {
         boolean expectedName = expectedMeta.hasDisplayName();
         if (expectedName && !hasSameDisplayName(expectedMeta, actualMeta)) {
            return false;
         } else if (modelData(expectedMeta) != null) {
            Integer actualModelData = modelData(actualMeta);
            return actualModelData != null && actualModelData.equals(modelData(expectedMeta));
         } else if (!expectedMeta.hasLore()) {
            Map<Enchantment, Integer> expectedEnchants = expectedMeta.getEnchants();
            return !expectedEnchants.isEmpty() ? containsAllEnchants(actualMeta, expectedEnchants) : expectedName;
         } else {
            return actualMeta.hasLore() && legacyLore(expectedMeta).equals(legacyLore(actualMeta));
         }
      } else {
         return false;
      }
   }

   public List<String> getLore() {
      return this.lore;
   }

   private ItemStack createShardItem() {
      ItemStack shard = new ItemStack(this.material);
      ItemMeta shardItemMeta = shard.getItemMeta();
      if (shardItemMeta == null) {
         return shard;
      }

      applyLegacyText(shardItemMeta, this.coloredName, this.coloredLore);
      if (this.modelData > 0) {
         CustomModelDataComponent component = shardItemMeta.getCustomModelDataComponent();
         component.setFloats(List.of((float)this.modelData));
         shardItemMeta.setCustomModelDataComponent(component);
      }

      shard.setItemMeta(shardItemMeta);
      NBTUtil.setShardMeta(shard, this.meta);
      NBTUtil.addItemNBT(shard, this.meta);
      return shard;
   }

   private static String createShardName(String configuredName, ItemStack finalBall, ShardItemSettings settings) {
      String baseName = ColorUtil.color(configuredName);
      if (baseName.isEmpty()) {
         ItemMeta finalMeta = finalBall.getItemMeta();
         if (finalMeta != null && finalMeta.hasDisplayName()) {
            baseName = ColorUtil.color(legacyDisplayName(finalMeta));
         }
      }

      String suffix = settings.getColoredNameSuffix();
      if (baseName.isEmpty()) {
         return suffix;
      } else {
         return !hasShardSuffix(baseName) && !baseName.endsWith(suffix) ? baseName + settings.getSpacedColoredNameSuffix() : baseName;
      }
   }

   private static boolean hasShardSuffix(String value) {
      String clean = ColorUtil.strip(value);
      if (clean == null) {
         return false;
      }

      String normalized = clean.trim().toLowerCase(Locale.ROOT);
      return normalized.endsWith("(осколок)") || normalized.endsWith(" осколок");
   }

   private static List<String> copyLore(List<String> rawLore, ShardItemSettings settings) {
      List<String> source = rawLore != null && !rawLore.isEmpty() ? rawLore : settings.getRawLore();
      ArrayList<String> result = new ArrayList<>(source.size());

      for (String line : source) {
         result.add(line == null ? "" : line);
      }

      return Collections.unmodifiableList(result);
   }

   private static List<String> colorizeLore(List<String> rawLore) {
      if (rawLore != null && !rawLore.isEmpty()) {
         List<String> result = new ArrayList<>(rawLore.size());

         for (String line : rawLore) {
            result.add(ColorUtil.color(line));
         }

         return Collections.unmodifiableList(result);
      } else {
         return Collections.emptyList();
      }
   }

   private static boolean hasSameDisplayName(ItemMeta expectedMeta, ItemMeta actualMeta) {
      return expectedMeta.hasDisplayName() && actualMeta.hasDisplayName() ? legacyDisplayName(expectedMeta).equals(legacyDisplayName(actualMeta)) : false;
   }

   private static Integer modelData(ItemMeta meta) {
      if (!meta.hasCustomModelDataComponent()) {
         return null;
      }

      List<Float> floats = meta.getCustomModelDataComponent().getFloats();
      return floats.isEmpty() ? null : floats.get(0).intValue();
   }

   @SuppressWarnings("deprecation")
   public static String legacyDisplayName(ItemMeta meta) {
      return meta.hasDisplayName() ? meta.getDisplayName() : "";
   }

   @SuppressWarnings("deprecation")
   private static List<String> legacyLore(ItemMeta meta) {
      List<String> lore = meta.getLore();
      return lore == null ? Collections.emptyList() : lore;
   }

   @SuppressWarnings("deprecation")
   private static void applyLegacyText(ItemMeta meta, String name, List<String> lore) {
      meta.setDisplayName(name);
      meta.setLore(lore);
   }

   private static boolean containsAllEnchants(ItemMeta actualMeta, Map<Enchantment, Integer> expectedEnchants) {
      for (Entry<Enchantment, Integer> entry : expectedEnchants.entrySet()) {
         if (!actualMeta.hasEnchant(entry.getKey()) || actualMeta.getEnchantLevel(entry.getKey()) < entry.getValue()) {
            return false;
         }
      }

      return true;
   }

   private static List<String> toStringList(Object value) {
      if (!(value instanceof List<?> input)) {
         return Collections.emptyList();
      } else {
         if (input.isEmpty()) {
            return Collections.emptyList();
         }

         ArrayList<String> result = new ArrayList<>(input.size());

         for (Object element : input) {
            if (element instanceof String) {
               result.add((String)element);
            }
         }

         return result;
      }
   }
}
