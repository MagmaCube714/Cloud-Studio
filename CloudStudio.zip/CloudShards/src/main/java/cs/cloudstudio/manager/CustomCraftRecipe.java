package cs.cloudstudio.manager;

import cs.cloudstudio.CloudShards;
import java.util.Locale;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapelessRecipe;

public final class CustomCraftRecipe {
   public static final String RECIPE_PREFIX = "ball-shard-";
   private static final String TRIGGER_PREFIX = "ball-shard-trigger-";
   private final CloudShards plugin;
   private final Material material;
   private final NamespacedKey key;

   public CustomCraftRecipe(CloudShards plugin, Material material) {
      this.plugin = plugin;
      this.material = material;
      this.key = new NamespacedKey(plugin, "ball-shard-trigger-" + material.name().toLowerCase(Locale.ROOT));
   }

   public void register() {
      if (this.plugin.getServer().getRecipe(this.key) != null) {
         this.plugin.getServer().removeRecipe(this.key);
      }

      ShapelessRecipe recipe = new ShapelessRecipe(this.key, new ItemStack(Material.PAPER));
      recipe.setGroup("cloudshards");

      for (int i = 0; i < 4; i++) {
         recipe.addIngredient(this.material);
      }

      this.plugin.getServer().addRecipe(recipe);
   }

   public NamespacedKey getKey() {
      return this.key;
   }
}
