package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudShards;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.config.MessageConfig;
import cs.cloudstudio.manager.BallShard;
import org.bukkit.entity.Player;

public final class ListSubCommand extends BaseCommand {
   public ListSubCommand(CloudShards plugin) {
      super(plugin);
   }

   @Override
   public void execute(Player player, String[] args) {
      MessageConfig messages = this.getPlugin().getMessages();

      for (BallShard shard : this.getPlugin().getShardManager().getShards()) {
         player.sendMessage(messages.listLine(shard.getMeta(), shard.getName(), shard.getMaterial().name(), shard.getModelData()));
      }
   }

   @Override
   public String getName() {
      return "list";
   }
}
