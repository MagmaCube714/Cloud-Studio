package cs.cloudstudio.command;

import org.bukkit.entity.Player;

public interface SubCommand {
   void execute(Player var1, String[] var2);

   String getName();
}
