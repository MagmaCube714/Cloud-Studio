package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudShards;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.config.MessageConfig;
import cs.cloudstudio.manager.BallShard;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.NBTUtil;
import java.io.IOException;
import java.util.Collections;
import java.util.Locale;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class CreateSubCommand extends BaseCommand {
   private static final int MAX_META_LENGTH = 64;

   public CreateSubCommand(CloudShards plugin) {
      super(plugin);
   }

   @Override
   public void execute(Player player, String[] args) {
      MessageConfig messages = this.getPlugin().getMessages();
      if (args.length < 4) {
         player.sendMessage(messages.createUsage());
      } else {
         String metaId = args[1].toLowerCase(Locale.ROOT);
         if (!isValidMeta(metaId)) {
            player.sendMessage(messages.invalidMeta());
         } else if (this.getPlugin().getShardManager().getShardByMeta(metaId) != null) {
            player.sendMessage(messages.shardExists());
         } else {
            int modelData;
            try {
               modelData = Integer.parseInt(args[2]);
            } catch (NumberFormatException e) {
               player.sendMessage(messages.modelDataNumber());
               return;
            }

            if (modelData < 0) {
               player.sendMessage(messages.modelDataNegative());
            } else {
               Material shardMaterial = Material.getMaterial(args[3].toUpperCase(Locale.ROOT));
               if (shardMaterial != null && !shardMaterial.isAir() && shardMaterial.isItem()) {
                  ItemStack mainHand = player.getInventory().getItemInMainHand();
                  if (mainHand.getType().isAir()) {
                     player.sendMessage(messages.emptyMainHand());
                  } else if (this.getPlugin().getShardManager().containsFinalBallSimilar(mainHand)) {
                     player.sendMessage(messages.finalBallExists());
                  } else {
                     String displayName = getDisplayName(mainHand);
                     if (displayName.isEmpty() && args.length > 4) {
                        displayName = ColorUtil.color(joinArgs(args, 4));
                     }

                     ItemStack finalBall = mainHand.clone();
                     finalBall.setAmount(1);
                     NBTUtil.setBallMeta(finalBall, metaId);
                     NBTUtil.addItemNBT(finalBall, metaId + "_ball");
                     BallShard shard = new BallShard(
                        modelData,
                        displayName,
                        metaId,
                        shardMaterial,
                        finalBall,
                        Collections.emptyList(),
                        this.getPlugin().getSettings().getShardItemSettings()
                     );

                     try {
                        this.getPlugin().getShardManager().saveShard(shard);
                     } catch (IOException e) {
                        player.sendMessage(messages.shardSaveFailed());
                        return;
                     }

                     ItemStack markedHand = finalBall.clone();
                     markedHand.setAmount(mainHand.getAmount());
                     player.getInventory().setItemInMainHand(markedHand);
                     this.giveOrDrop(player, shard.build());
                     player.sendMessage(messages.shardCreated(metaId, shardMaterial.name(), modelData));
                  }
               } else {
                  player.sendMessage(messages.invalidMaterial());
               }
            }
         }
      }
   }

   @Override
   public String getName() {
      return "create";
   }

   private static String getDisplayName(ItemStack item) {
      ItemMeta itemMeta = item.getItemMeta();
      return itemMeta != null && itemMeta.hasDisplayName() ? BallShard.legacyDisplayName(itemMeta) : "";
   }

   private static String joinArgs(String[] args, int startIndex) {
      StringBuilder builder = new StringBuilder(32);

      for (int i = startIndex; i < args.length; i++) {
         if (i > startIndex) {
            builder.append(' ');
         }

         builder.append(args[i]);
      }

      return builder.toString();
   }

   private static boolean isValidMeta(String meta) {
      if (meta != null && !meta.isEmpty() && meta.length() <= 64) {
         int i = 0;

         for (int length = meta.length(); i < length; i++) {
            char character = meta.charAt(i);
            if ((character < 'a' || character > 'z') && (character < '0' || character > '9') && character != '_' && character != '/' && character != '-') {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }
}
