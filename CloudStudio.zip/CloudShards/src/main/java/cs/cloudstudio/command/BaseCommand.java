package cs.cloudstudio.command;

import cs.cloudstudio.CloudShards;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public abstract class BaseCommand implements SubCommand {
   private final CloudShards plugin;

   protected BaseCommand(CloudShards plugin) {
      this.plugin = plugin;
   }

   protected CloudShards getPlugin() {
      return this.plugin;
   }

   protected void giveOrDrop(Player player, ItemStack item) {
      Map<Integer, ItemStack> leftovers = player.getInventory().addItem(new ItemStack[]{item});
      if (!leftovers.isEmpty()) {
         World world = player.getWorld();
         Location location = player.getLocation();

         for (ItemStack leftover : leftovers.values()) {
            world.dropItemNaturally(location, leftover);
         }
      }
   }
}
