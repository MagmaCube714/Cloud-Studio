package cs.cloudstudio.command;

import cs.cloudstudio.CloudShards;
import cs.cloudstudio.command.sub.CreateSubCommand;
import cs.cloudstudio.command.sub.GetSubCommand;
import cs.cloudstudio.command.sub.ListSubCommand;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import cs.cloudstudio.config.MessageConfig;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class AdminCommand implements CommandExecutor, TabCompleter {
   private static final String ADMIN_PERMISSION = "cloudshards.admin";
   private static final List<String> FIRST_ARGUMENTS = Collections.unmodifiableList(Arrays.asList("create", "list", "reload", "get"));
   private static final List<String> MATERIAL_NAMES = buildMaterialNames();
   private final Map<String, SubCommand> subCommands = new HashMap<>(4);
   private final CloudShards plugin;

   public AdminCommand(CloudShards plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender commandSender, Command command, String label, String[] args) {
      MessageConfig messages = this.plugin.getMessages();
      if (!(commandSender instanceof Player)) {
         commandSender.sendMessage(messages.onlyPlayer());
         return true;
      } else if (!commandSender.hasPermission("cloudshards.admin")) {
         commandSender.sendMessage(messages.noPermission());
         return true;
      } else if (args.length == 0) {
         commandSender.sendMessage(messages.rootUsage(label));
         return true;
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            commandSender.sendMessage(messages.unknownSubcommand());
            return true;
         } else {
            subCommand.execute((Player)commandSender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender commandSender, Command command, String label, String[] args) {
      if (!commandSender.hasPermission("cloudshards.admin")) {
         return Collections.emptyList();
      } else if (args.length == 1) {
         return filterStartsWith(FIRST_ARGUMENTS, args[0]);
      } else if (args.length == 2 && args[0].equalsIgnoreCase("get")) {
         return filterStartsWith(this.plugin.getShardManager().getShardMetas(), args[1]);
      } else if (args.length == 2 && args[0].equalsIgnoreCase("create")) {
         return Collections.singletonList("<metaId>");
      } else if (args.length == 3 && args[0].equalsIgnoreCase("create")) {
         return Collections.singletonList("[modelData]");
      } else if (args.length == 4 && args[0].equalsIgnoreCase("create")) {
         return filterStartsWith(MATERIAL_NAMES, args[3]);
      } else {
         return args.length == 5 && args[0].equalsIgnoreCase("create") ? Collections.singletonList("[displayName]") : Collections.emptyList();
      }
   }

   public boolean register() {
      this.registerSubCommand(new CreateSubCommand(this.plugin));
      this.registerSubCommand(new ListSubCommand(this.plugin));
      this.registerSubCommand(new ReloadSubCommand(this.plugin));
      this.registerSubCommand(new GetSubCommand(this.plugin));
      PluginCommand pluginCommand = this.plugin.getCommand("cloudshards");
      if (pluginCommand == null) {
         return false;
      }

      pluginCommand.setExecutor(this);
      pluginCommand.setTabCompleter(this);
      return true;
   }

   private void registerSubCommand(SubCommand subCommand) {
      this.subCommands.put(subCommand.getName().toLowerCase(Locale.ROOT), subCommand);
   }

   private static List<String> buildMaterialNames() {
      Material[] materials = Material.values();
      List<String> result = new ArrayList<>(materials.length);

      for (Material material : materials) {
         if (!material.isAir() && material.isItem()) {
            result.add(material.name());
         }
      }

      return Collections.unmodifiableList(result);
   }

   private static List<String> filterStartsWith(List<String> source, String prefix) {
      if (prefix != null && !prefix.isEmpty()) {
         List<String> result = new ArrayList<>();

         for (String value : source) {
            if (startsWithIgnoreCase(value, prefix)) {
               result.add(value);
            }
         }

         return result;
      } else {
         return source;
      }
   }

   private static boolean startsWithIgnoreCase(String value, String prefix) {
      return value.length() >= prefix.length() && value.regionMatches(true, 0, prefix, 0, prefix.length());
   }
}
