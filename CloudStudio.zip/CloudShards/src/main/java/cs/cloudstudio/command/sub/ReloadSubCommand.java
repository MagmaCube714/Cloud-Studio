package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudShards;
import cs.cloudstudio.command.BaseCommand;
import org.bukkit.entity.Player;

public final class ReloadSubCommand extends BaseCommand {
   public ReloadSubCommand(CloudShards plugin) {
      super(plugin);
   }

   @Override
   public void execute(Player player, String[] args) {
      this.getPlugin().reloadPluginConfiguration();
      this.getPlugin().getShardManager().load();
      player.sendMessage(this.getPlugin().getMessages().reloaded());
   }

   @Override
   public String getName() {
      return "reload";
   }
}
