package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudShards;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.config.MessageConfig;
import cs.cloudstudio.manager.BallShard;
import org.bukkit.entity.Player;

public final class GetSubCommand extends BaseCommand {
   public GetSubCommand(CloudShards plugin) {
      super(plugin);
   }

   @Override
   public void execute(Player player, String[] args) {
      MessageConfig messages = this.getPlugin().getMessages();
      if (args.length < 2) {
         player.sendMessage(messages.getUsage());
      } else {
         BallShard shard = this.getPlugin().getShardManager().getShardByMeta(args[1]);
         if (shard == null) {
            player.sendMessage(messages.shardNotFound());
         } else {
            this.giveOrDrop(player, shard.build());
            player.sendMessage(messages.shardReceived(shard.getName()));
         }
      }
   }

   @Override
   public String getName() {
      return "get";
   }
}
