package cs.cloudstudio.config;

import org.bukkit.configuration.file.FileConfiguration;

public final class PluginSettings {
   private final MessageConfig messages;
   private final ShardItemSettings shardItemSettings;

   private PluginSettings(FileConfiguration config) {
      this.messages = MessageConfig.load(config);
      this.shardItemSettings = ShardItemSettings.load(config);
   }

   public static PluginSettings load(FileConfiguration config) {
      return new PluginSettings(config);
   }

   public MessageConfig getMessages() {
      return this.messages;
   }

   public ShardItemSettings getShardItemSettings() {
      return this.shardItemSettings;
   }
}
