package cs.cloudstudio.config;

import cs.cloudstudio.util.ColorUtil;
import org.bukkit.configuration.file.FileConfiguration;

public final class MessageConfig {
   private final String onlyPlayer;
   private final String noPermission;
   private final String rootUsage;
   private final String unknownSubcommand;
   private final String createUsage;
   private final String invalidMeta;
   private final String shardExists;
   private final String modelDataNumber;
   private final String modelDataNegative;
   private final String invalidMaterial;
   private final String emptyMainHand;
   private final String finalBallExists;
   private final String shardSaveFailed;
   private final String shardCreated;
   private final String getUsage;
   private final String shardNotFound;
   private final String shardReceived;
   private final String listLine;
   private final String reloaded;

   private MessageConfig(FileConfiguration config) {
      this.onlyPlayer = message(config, "messages.only-player", "&cКоманда доступна только игроку");
      this.noPermission = message(config, "messages.no-permission", "&cНедостаточно прав");
      this.rootUsage = message(config, "messages.root-usage", "&cИспользование: /{label} <create|list|reload|get>");
      this.unknownSubcommand = message(config, "messages.unknown-subcommand", "&cНеизвестная подкоманда");
      this.createUsage = message(config, "messages.create-usage", "&cИспользование: /cloudshards create <metaId> <modelData> <material> [displayName]");
      this.invalidMeta = message(config, "messages.invalid-meta", "&cmetaId может содержать только a-z, 0-9, _, /, - и быть не длиннее 64 символов");
      this.shardExists = message(config, "messages.shard-exists", "&cОсколок с таким metaId уже существует");
      this.modelDataNumber = message(config, "messages.model-data-number", "&cmodelData должен быть числом");
      this.modelDataNegative = message(config, "messages.model-data-negative", "&cmodelData не может быть отрицательным");
      this.invalidMaterial = message(config, "messages.invalid-material", "&cНеверный материал предмета");
      this.emptyMainHand = message(config, "messages.empty-main-hand", "&cДержи в руке предмет, который будет восстанавливаться из осколков");
      this.finalBallExists = message(config, "messages.final-ball-exists", "&cОсколок для такого предмета уже существует Очисти конфиг вручную");
      this.shardSaveFailed = message(config, "messages.shard-save-failed", "&cНе удалось сохранить shards yml");
      this.shardCreated = message(config, "messages.shard-created", "&aОсколок создан metaId: {meta} | material: {material} | modelData: {modelData}");
      this.getUsage = message(config, "messages.get-usage", "&cИспользование: /cloudshards get <meta>");
      this.shardNotFound = message(config, "messages.shard-not-found", "&cОсколок с таким meta не найден");
      this.shardReceived = message(config, "messages.shard-received", "&aВы получили осколок: &e{name}");
      this.listLine = message(config, "messages.list-line", "&eОсколок: &a{meta} &e| Имя: &a{name} &e| Материал: &a{material} &e| МодельДата: &a{modelData}");
      this.reloaded = message(config, "messages.reloaded", "&aКонфигурация перезагружена");
   }

   public static MessageConfig load(FileConfiguration config) {
      return new MessageConfig(config);
   }

   public String onlyPlayer() {
      return this.onlyPlayer;
   }

   public String noPermission() {
      return this.noPermission;
   }

   public String rootUsage(String label) {
      return this.rootUsage.replace("{label}", label == null ? "cloudshards" : label);
   }

   public String unknownSubcommand() {
      return this.unknownSubcommand;
   }

   public String createUsage() {
      return this.createUsage;
   }

   public String invalidMeta() {
      return this.invalidMeta;
   }

   public String shardExists() {
      return this.shardExists;
   }

   public String modelDataNumber() {
      return this.modelDataNumber;
   }

   public String modelDataNegative() {
      return this.modelDataNegative;
   }

   public String invalidMaterial() {
      return this.invalidMaterial;
   }

   public String emptyMainHand() {
      return this.emptyMainHand;
   }

   public String finalBallExists() {
      return this.finalBallExists;
   }

   public String shardSaveFailed() {
      return this.shardSaveFailed;
   }

   public String shardCreated(String meta, String material, int modelData) {
      return this.shardCreated
         .replace("{meta}", meta == null ? "" : meta)
         .replace("{material}", material == null ? "" : material)
         .replace("{modelData}", String.valueOf(modelData));
   }

   public String getUsage() {
      return this.getUsage;
   }

   public String shardNotFound() {
      return this.shardNotFound;
   }

   public String shardReceived(String name) {
      return ColorUtil.color(this.shardReceived.replace("{name}", name == null ? "" : name));
   }

   public String listLine(String meta, String name, String material, int modelData) {
      return ColorUtil.color(
         this.listLine
            .replace("{meta}", meta == null ? "" : meta)
            .replace("{name}", name == null ? "" : name)
            .replace("{material}", material == null ? "" : material)
            .replace("{modelData}", String.valueOf(modelData))
      );
   }

   public String reloaded() {
      return this.reloaded;
   }

   private static String message(FileConfiguration config, String path, String fallback) {
      return ColorUtil.color(config.getString(path, fallback));
   }
}
