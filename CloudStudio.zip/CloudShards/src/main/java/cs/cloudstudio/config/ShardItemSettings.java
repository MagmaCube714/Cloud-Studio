package cs.cloudstudio.config;

import cs.cloudstudio.util.ColorUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.bukkit.configuration.file.FileConfiguration;

public final class ShardItemSettings {
   private static final String DEFAULT_NAME_SUFFIX = "&7(Осколок)";
   private static final List<String> DEFAULT_LORE = Collections.unmodifiableList(
      Arrays.asList(
         "&7Осколок разрушенного предмета", "", "&b⚡ Соберите &34 осколка&b, чтобы", "&b⚡ восстановить целый предмет", "", "&8Используйте верстак для крафта"
      )
   );
   private final String coloredNameSuffix;
   private final String spacedColoredNameSuffix;
   private final List<String> rawLore;

   private ShardItemSettings(String nameSuffix, List<String> lore) {
      String suffix = ColorUtil.color(nameSuffix != null && !nameSuffix.isEmpty() ? nameSuffix : "&7(Осколок)");
      this.coloredNameSuffix = suffix;
      this.spacedColoredNameSuffix = " " + suffix;
      this.rawLore = copyLore(lore);
   }

   public static ShardItemSettings load(FileConfiguration config) {
      return new ShardItemSettings(config.getString("settings.shard-item.name-suffix", "&7(Осколок)"), config.getStringList("settings.shard-item.lore"));
   }

   public static ShardItemSettings defaults() {
      return new ShardItemSettings("&7(Осколок)", DEFAULT_LORE);
   }

   public String getColoredNameSuffix() {
      return this.coloredNameSuffix;
   }

   public String getSpacedColoredNameSuffix() {
      return this.spacedColoredNameSuffix;
   }

   public List<String> getRawLore() {
      return this.rawLore;
   }

   private static List<String> copyLore(List<String> configuredLore) {
      List<String> source = configuredLore != null && !configuredLore.isEmpty() ? configuredLore : DEFAULT_LORE;
      ArrayList<String> result = new ArrayList<>(source.size());

      for (String line : source) {
         result.add(line == null ? "" : line);
      }

      return Collections.unmodifiableList(result);
   }
}
