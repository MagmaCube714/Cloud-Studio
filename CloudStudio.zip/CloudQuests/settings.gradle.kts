rootProject.name = "CloudQuests"
