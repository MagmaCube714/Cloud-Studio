package cs.cloudstudio.listener;

import cs.cloudstudio.CloudQuests;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.event.server.PluginEnableEvent;

public final class PluginHookListener implements Listener {
   private final CloudQuests plugin;

   public PluginHookListener(CloudQuests plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onPluginEnable(PluginEnableEvent event) {
      this.plugin.onPluginEnable(event);
      if (event.getPlugin().getName().equals("CloudEnchants")) {
         this.plugin.refreshEnchantBridge();
      }
   }

   @EventHandler
   public void onPluginDisable(PluginDisableEvent event) {
      this.plugin.onPluginDisable(event);
      if (event.getPlugin().getName().equals("CloudEnchants")) {
         this.plugin.refreshEnchantBridge();
      }
   }
}
