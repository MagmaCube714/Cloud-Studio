package cs.cloudstudio.listener;

import cs.cloudstudio.CloudQuests;
import java.util.Map;
import java.util.WeakHashMap;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;

public final class QuestProgressListener implements Listener {
   private final CloudQuests plugin;
   private final Map<BlockBreakEvent, BlockData> originalBlocks = new WeakHashMap<>();

   public QuestProgressListener(CloudQuests plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void captureBlock(BlockBreakEvent event) {
      this.originalBlocks.put(event, event.getBlock().getBlockData());
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onBlockBreak(BlockBreakEvent event) {
      BlockData data = this.originalBlocks.remove(event);
      if (!event.isCancelled() && !this.plugin.isEnchantManagedBreak(event)) {
         if (data == null) {
            this.plugin.onBlockBreak(event);
         } else {
            boolean grown = !(data instanceof Ageable ageable && ageable.getAge() != ageable.getMaximumAge());
            this.plugin.onBlockBroken(event.getPlayer(), data.getMaterial(), grown);
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onCraftItem(CraftItemEvent event) {
      this.plugin.onCraftItem(event);
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onEntityDeath(EntityDeathEvent event) {
      this.plugin.onEntityDeath(event);
   }
}
