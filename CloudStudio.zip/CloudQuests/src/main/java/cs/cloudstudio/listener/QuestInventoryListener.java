package cs.cloudstudio.listener;

import cs.cloudstudio.CloudQuests;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

public final class QuestInventoryListener implements Listener {
   private final CloudQuests plugin;

   public QuestInventoryListener(CloudQuests plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
   public void onClick(InventoryClickEvent event) {
      this.plugin.onClick(event);
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
   public void onDrag(InventoryDragEvent event) {
      this.plugin.onDrag(event);
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onDrop(PlayerDropItemEvent event) {
      this.plugin.onDrop(event);
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onSwapHand(PlayerSwapHandItemsEvent event) {
      this.plugin.onSwapHand(event);
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.plugin.onQuit(event);
   }

   @EventHandler
   public void onKick(PlayerKickEvent event) {
      this.plugin.onKick(event);
   }
}
