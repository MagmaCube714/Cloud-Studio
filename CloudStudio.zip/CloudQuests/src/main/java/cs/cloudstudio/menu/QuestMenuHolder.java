package cs.cloudstudio.menu;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class QuestMenuHolder implements InventoryHolder {
   public final String category;

   public QuestMenuHolder(String category) {
      this.category = category;
   }

   public Inventory getInventory() {
      return null;
   }
}
