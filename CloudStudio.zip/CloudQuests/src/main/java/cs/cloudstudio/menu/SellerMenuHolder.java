package cs.cloudstudio.menu;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class SellerMenuHolder implements InventoryHolder {
   public final String category;

   public SellerMenuHolder(String category) {
      this.category = category;
   }

   public Inventory getInventory() {
      return null;
   }
}
