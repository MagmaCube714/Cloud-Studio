package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.command.QuestCommand;
import cs.cloudstudio.command.SkipQuestCommand;
import cs.cloudstudio.hook.CloudEnchantsQuestBridge;
import cs.cloudstudio.listener.PluginHookListener;
import cs.cloudstudio.listener.QuestInventoryListener;
import cs.cloudstudio.listener.QuestProgressListener;
import cs.cloudstudio.manager.CommandModule;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.ItemNameTranslator;
import java.util.function.Predicate;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.plugin.PluginManager;

public final class CloudQuests extends CommandModule {
   private Predicate<BlockBreakEvent> managedBreak = event -> false;
   private Listener enchantBridge;

   public boolean isEnchantManagedBreak(BlockBreakEvent event) {
      return this.managedBreak.test(event);
   }

   public void refreshEnchantBridge() {
      if (this.enchantBridge != null) {
         HandlerList.unregisterAll(this.enchantBridge);
         this.enchantBridge = null;
      }

      this.managedBreak = event -> false;
      if (this.getServer().getPluginManager().isPluginEnabled("CloudEnchants")) {
         try {
            CloudEnchantsQuestBridge bridge = new CloudEnchantsQuestBridge(this);
            this.getServer().getPluginManager().registerEvents(bridge, this);
            this.enchantBridge = bridge;
            this.managedBreak = bridge;
         } catch (LinkageError error) {
            this.getLogger().warning("Для моста квестов необходимо обновить CloudEnchants вместе с CloudQuests");
         }
      }
   }

   public void onEnable() {
      if (!this.getDataFolder().exists() && !this.getDataFolder().mkdirs()) {
         this.getServer().getPluginManager().disablePlugin(this);
      } else {
         this.saveDefaultConfig();
         this.reloadConfig();
         this.saveDefaultSellers();
         this.commandMap = this.resolveCommandMap();
         boolean economyEnabled = this.setupEconomy();
         if (this.loadData() && this.safeLoadAllDataOnStartup()) {
            this.registerCommand("quest", new QuestCommand(this));
            this.registerCommand("skipquest", new SkipQuestCommand(this));
            this.registerCommand("cloudquests", new AdminCommand(this));
            this.placeholderApiEnabled = Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI");
            this.console(
               economyEnabled
                  ? "&fCloudQuests &aэкономика Vault подключена, seller-меню доступно"
                  : "&fCloudQuests &eэкономика Vault не подключена, покупки за монеты отключены"
            );
            if (this.placeholderApiEnabled) {
               this.console("&fCloudQuests &aPlaceholderAPI подключён");
            }

            PluginManager pluginManager = this.getServer().getPluginManager();
            ItemNameTranslator.init(this);
            pluginManager.registerEvents(new PluginHookListener(this), this);
            pluginManager.registerEvents(new QuestInventoryListener(this), this);
            pluginManager.registerEvents(new QuestProgressListener(this), this);
            this.refreshEnchantBridge();
            this.console("&fCloudQuests &aуспешно загружен!");
         } else {
            this.getServer().getPluginManager().disablePlugin(this);
         }
      }
   }

   public void onDisable() {
      this.databaseGeneration++;
      if (this.autoSaveTask != -1) {
         Bukkit.getScheduler().cancelTask(this.autoSaveTask);
         this.autoSaveTask = -1;
      }

      this.saveAllDataSync();
      this.cache.clear();
      this.closeDatabase();
      this.console("&fCloudQuests &cуспешно выгружен!");
   }

   private void registerCommand(String name, CommandExecutor executor) {
      PluginCommand command = this.getCommand(name);
      if (command == null) {
         this.getLogger().warning("[CloudQuests] Команда " + name + " не зарегистрирована в plugin.yml");
      } else {
         command.setExecutor(executor);
         if (executor instanceof TabCompleter) {
            command.setTabCompleter((TabCompleter)executor);
         }
      }
   }

   private void console(String message) {
      Bukkit.getConsoleSender().sendMessage(ColorUtil.color(message));
   }
}
