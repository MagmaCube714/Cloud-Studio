package cs.cloudstudio.manager.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class PlayerData {
   public final Map<String, Integer> stages = new HashMap<>();
   public final Map<String, Integer> progress = new HashMap<>();
   public final Map<String, Integer> skips = new HashMap<>();
   public final Map<String, Integer> completed = new HashMap<>();
   public final Map<String, Integer> skipped = new HashMap<>();
   public final Map<String, Integer> rewardClaims = new HashMap<>();
   public final Map<String, Set<Integer>> completedStages = new HashMap<>();
   public final Map<String, Set<Integer>> skippedStages = new HashMap<>();
   public final Map<String, Set<Integer>> claimedRewards = new HashMap<>();
   public final Map<String, Integer> purchases = new HashMap<>();
   public String playerName = "";
   public long updatedAt;
   public long dirtyEpoch = 1L;
   public boolean modified = true;
}
