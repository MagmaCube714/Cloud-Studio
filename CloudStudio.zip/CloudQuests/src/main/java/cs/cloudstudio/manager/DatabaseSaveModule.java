package cs.cloudstudio.manager;

import cs.cloudstudio.database.DatabaseType;
import cs.cloudstudio.manager.model.PlayerData;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.Bukkit;

public abstract class DatabaseSaveModule extends YamlStorageModule {
   @Override
   protected void saveAllDataAsync() {
      if (!this.asyncSaveRunning) {
         Map<UUID, PlayerData> snapshots = this.collectPlayerSnapshots(true);
         if (!snapshots.isEmpty()) {
            this.asyncSaveRunning = true;
            long generation = this.databaseGeneration;
            Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
               boolean saved = false;

               try {
                  saved = this.savePlayerSnapshots(snapshots, generation);
               } finally {
                  boolean savedResult = saved;
                  if (this.isEnabled()) {
                     Bukkit.getScheduler().runTask(this, () -> {
                        if (savedResult) {
                           this.markSnapshotsSaved(snapshots);
                        } else {
                           this.markSnapshotsDirty(snapshots);
                        }

                        this.asyncSaveRunning = false;
                     });
                  } else {
                     this.asyncSaveRunning = false;
                  }
               }
            });
         }
      }
   }

   @Override
   protected void saveAllDataSync() {
      Map<UUID, PlayerData> snapshots = this.collectPlayerSnapshots(false);
      if (!snapshots.isEmpty() && this.savePlayerSnapshots(snapshots, this.databaseGeneration)) {
         this.markSnapshotsSaved(snapshots);
      }
   }

   @Override
   protected boolean savePlayerDataSync(UUID uuid) {
      PlayerData current = this.cache.get(uuid);
      if (current == null) {
         return true;
      }

      Map<UUID, PlayerData> snapshots = new LinkedHashMap<>(1);
      snapshots.put(uuid, this.copyPlayerData(current));
      boolean saved = this.savePlayerSnapshots(snapshots, this.databaseGeneration);
      if (saved) {
         this.markSnapshotsSaved(snapshots);
      } else {
         this.markSnapshotsDirty(snapshots);
      }

      return saved;
   }

   @Override
   protected void savePlayerDataAsync(UUID uuid) {
      PlayerData current = this.cache.get(uuid);
      if (current != null) {
         Map<UUID, PlayerData> snapshots = new LinkedHashMap<>(1);
         snapshots.put(uuid, this.copyPlayerData(current));
         long generation = this.databaseGeneration;
         Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            boolean saved = this.savePlayerSnapshots(snapshots, generation);
            if (this.isEnabled()) {
               Bukkit.getScheduler().runTask(this, () -> {
                  if (saved) {
                     this.markSnapshotsSaved(snapshots);
                  } else {
                     this.markSnapshotsDirty(snapshots);
                  }
               });
            } else if (!saved) {
               this.markSnapshotsDirty(snapshots);
            }
         });
      }
   }

   @Override
   protected Map<UUID, PlayerData> collectPlayerSnapshots(boolean modifiedOnly) {
      Map<UUID, PlayerData> snapshots = new LinkedHashMap<>();

      for (Entry<UUID, PlayerData> entry : this.cache.entrySet()) {
         PlayerData pd = entry.getValue();
         if (!modifiedOnly || pd.modified) {
            snapshots.put(entry.getKey(), this.copyPlayerData(pd));
         }
      }

      return snapshots;
   }

   @Override
   protected void markSnapshotsSaved(Map<UUID, PlayerData> snapshots) {
      for (Entry<UUID, PlayerData> entry : snapshots.entrySet()) {
         PlayerData current = this.cache.get(entry.getKey());
         if (current != null && current.dirtyEpoch == entry.getValue().dirtyEpoch) {
            current.modified = false;
         }
      }
   }

   @Override
   protected void markSnapshotsDirty(Map<UUID, PlayerData> snapshots) {
      for (UUID uuid : snapshots.keySet()) {
         PlayerData current = this.cache.get(uuid);
         if (current != null) {
            current.modified = true;
         }
      }
   }

   @Override
   protected PlayerData copyPlayerData(PlayerData s) {
      PlayerData c = new PlayerData();
      c.playerName = s.playerName;
      c.updatedAt = s.updatedAt;
      c.dirtyEpoch = s.dirtyEpoch;
      c.stages.putAll(s.stages);
      c.progress.putAll(s.progress);
      c.skips.putAll(s.skips);
      c.completed.putAll(s.completed);
      c.skipped.putAll(s.skipped);
      c.rewardClaims.putAll(s.rewardClaims);
      c.purchases.putAll(s.purchases);
      this.copyStageSets(s.completedStages, c.completedStages);
      this.copyStageSets(s.skippedStages, c.skippedStages);
      this.copyStageSets(s.claimedRewards, c.claimedRewards);
      c.modified = s.modified;
      return c;
   }

   @Override
   protected void copyStageSets(Map<String, Set<Integer>> source, Map<String, Set<Integer>> target) {
      for (Entry<String, Set<Integer>> entry : source.entrySet()) {
         target.put(entry.getKey(), new HashSet<>(entry.getValue()));
      }
   }

   @Override
   protected boolean savePlayerSnapshots(Map<UUID, PlayerData> snapshots, long generation) {
      if (this.yamlStorage) {
         return this.savePlayerSnapshotsToYaml(snapshots);
      }

      if (this.dataSource != null && generation == this.databaseGeneration) {
         synchronized (this.databaseLock) {
            if (this.dataSource != null && generation == this.databaseGeneration) {
               try (Connection connection = this.dataSource.getConnection()) {
                  if (this.databaseSettings.type == DatabaseType.SQLITE) {
                     this.enableSqliteForeignKeys(connection);
                  }

                  connection.setAutoCommit(false);

                  try (
                     PreparedStatement upsertPlayer = connection.prepareStatement(this.sqlDialect.upsertPlayerSql());
                     PreparedStatement deleteQuestProgress = connection.prepareStatement("DELETE FROM quest_progress WHERE uuid=?");
                     PreparedStatement deleteCompletedStages = connection.prepareStatement("DELETE FROM completed_stages WHERE uuid=?");
                     PreparedStatement deleteSkippedStages = connection.prepareStatement("DELETE FROM skipped_stages WHERE uuid=?");
                     PreparedStatement deleteClaimedRewards = connection.prepareStatement("DELETE FROM claimed_rewards WHERE uuid=?");
                     PreparedStatement deletePurchases = connection.prepareStatement("DELETE FROM purchases WHERE uuid=?");
                     PreparedStatement insertQuestProgress = connection.prepareStatement(
                        "INSERT INTO quest_progress(uuid, category, stage, progress, legacy_skips, completed, skipped, rewards_received) VALUES(?, ?, ?, ?, ?, ?, ?, ?)"
                     );
                     PreparedStatement insertCompletedStage = connection.prepareStatement("INSERT INTO completed_stages(uuid, category, stage) VALUES(?, ?, ?)");
                     PreparedStatement insertSkippedStage = connection.prepareStatement("INSERT INTO skipped_stages(uuid, category, stage) VALUES(?, ?, ?)");
                     PreparedStatement insertClaimedReward = connection.prepareStatement("INSERT INTO claimed_rewards(uuid, category, stage) VALUES(?, ?, ?)");
                     PreparedStatement insertPurchase = connection.prepareStatement("INSERT INTO purchases(uuid, category, item_id, amount) VALUES(?, ?, ?, ?)");
                  ) {
                     for (Entry<UUID, PlayerData> entry : snapshots.entrySet()) {
                        PlayerData snapshot = entry.getValue();
                        PlayerData current = this.cache.get(entry.getKey());
                        if (current == null || current.dirtyEpoch == snapshot.dirtyEpoch) {
                           this.savePlayerSnapshot(
                              entry.getKey(),
                              snapshot,
                              upsertPlayer,
                              deleteQuestProgress,
                              deleteCompletedStages,
                              deleteSkippedStages,
                              deleteClaimedRewards,
                              deletePurchases,
                              insertQuestProgress,
                              insertCompletedStage,
                              insertSkippedStage,
                              insertClaimedReward,
                              insertPurchase
                           );
                        }
                     }

                     connection.commit();
                     return true;
                  } catch (SQLException e) {
                     this.getLogger().warning("[CloudQuests] Не удалось сохранить данные игроков в базу: " + e.getMessage());
                     this.rollbackConnection(connection);
                     return false;
                  } finally {
                     this.restoreAutoCommit(connection);
                  }
               } catch (SQLException e) {
                  this.getLogger().warning("[CloudQuests] Не удалось получить соединение с базой: " + e.getMessage());
                  return false;
               }
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   @Override
   protected void savePlayerSnapshot(
      UUID uuid,
      PlayerData pd,
      PreparedStatement upsertPlayer,
      PreparedStatement deleteQuestProgress,
      PreparedStatement deleteCompletedStages,
      PreparedStatement deleteSkippedStages,
      PreparedStatement deleteClaimedRewards,
      PreparedStatement deletePurchases,
      PreparedStatement insertQuestProgress,
      PreparedStatement insertCompletedStage,
      PreparedStatement insertSkippedStage,
      PreparedStatement insertClaimedReward,
      PreparedStatement insertPurchase
   ) throws SQLException {
      String uuidString = uuid.toString();
      upsertPlayer.setString(1, uuidString);
      upsertPlayer.setString(2, pd.playerName != null ? pd.playerName : "");
      upsertPlayer.setLong(3, System.currentTimeMillis());
      upsertPlayer.executeUpdate();
      this.deletePlayerChildRows(uuidString, deleteQuestProgress, deleteCompletedStages, deleteSkippedStages, deleteClaimedRewards, deletePurchases);
      this.insertQuestProgressRows(uuidString, pd, insertQuestProgress);
      this.insertStageRows(insertCompletedStage, uuidString, pd.completedStages);
      this.insertStageRows(insertSkippedStage, uuidString, pd.skippedStages);
      this.insertStageRows(insertClaimedReward, uuidString, pd.claimedRewards);
      this.insertPurchaseRows(uuidString, pd, insertPurchase);
   }

   @Override
   protected void deletePlayerChildRows(
      String uuidString,
      PreparedStatement deleteQuestProgress,
      PreparedStatement deleteCompletedStages,
      PreparedStatement deleteSkippedStages,
      PreparedStatement deleteClaimedRewards,
      PreparedStatement deletePurchases
   ) throws SQLException {
      this.executeDelete(deleteQuestProgress, uuidString);
      this.executeDelete(deleteCompletedStages, uuidString);
      this.executeDelete(deleteSkippedStages, uuidString);
      this.executeDelete(deleteClaimedRewards, uuidString);
      this.executeDelete(deletePurchases, uuidString);
   }

   @Override
   protected void executeDelete(PreparedStatement st, String uuidString) throws SQLException {
      st.setString(1, uuidString);
      st.executeUpdate();
   }

   @Override
   protected void insertQuestProgressRows(String uuidString, PlayerData pd, PreparedStatement st) throws SQLException {
      boolean hasBatch = false;

      for (String category : CATEGORIES) {
         if (this.hasCategoryData(pd, category)) {
            st.setString(1, uuidString);
            st.setString(2, category);
            st.setInt(3, Math.max(1, pd.stages.getOrDefault(category, 1)));
            st.setInt(4, Math.max(0, pd.progress.getOrDefault(category, 0)));
            st.setInt(5, Math.max(0, pd.skips.getOrDefault(category, 3)));
            st.setInt(6, Math.max(0, pd.completed.getOrDefault(category, 0)));
            st.setInt(7, Math.max(0, pd.skipped.getOrDefault(category, 0)));
            st.setInt(8, Math.max(0, pd.rewardClaims.getOrDefault(category, 0)));
            st.addBatch();
            hasBatch = true;
         }
      }

      if (hasBatch) {
         st.executeBatch();
      }
   }

   @Override
   protected boolean hasCategoryData(PlayerData pd, String category) {
      return pd.stages.containsKey(category)
         || pd.progress.containsKey(category)
         || pd.skips.containsKey(category)
         || pd.completed.getOrDefault(category, 0) > 0
         || pd.skipped.getOrDefault(category, 0) > 0
         || pd.rewardClaims.getOrDefault(category, 0) > 0
         || this.hasStageSet(pd.completedStages, category)
         || this.hasStageSet(pd.skippedStages, category)
         || this.hasStageSet(pd.claimedRewards, category);
   }

   @Override
   protected boolean hasStageSet(Map<String, Set<Integer>> map, String category) {
      Set<Integer> values = map.get(category);
      return values != null && !values.isEmpty();
   }

   @Override
   protected void insertStageRows(PreparedStatement st, String uuidString, Map<String, Set<Integer>> source) throws SQLException {
      boolean hasBatch = false;

      for (Entry<String, Set<Integer>> entry : source.entrySet()) {
         String category = entry.getKey();
         if (CATEGORY_SET.contains(category)) {
            for (Integer stage : entry.getValue()) {
               if (stage != null && stage > 0) {
                  st.setString(1, uuidString);
                  st.setString(2, category);
                  st.setInt(3, stage);
                  st.addBatch();
                  hasBatch = true;
               }
            }
         }
      }

      if (hasBatch) {
         st.executeBatch();
      }
   }

   @Override
   protected void insertPurchaseRows(String uuidString, PlayerData pd, PreparedStatement st) throws SQLException {
      boolean hasBatch = false;

      for (Entry<String, Integer> entry : pd.purchases.entrySet()) {
         String key = entry.getKey();
         int colon = key.indexOf(58);
         if (colon > 0 && colon != key.length() - 1) {
            int amount = entry.getValue() != null ? entry.getValue() : 0;
            if (amount > 0) {
               String cat = key.substring(0, colon);
               String itemId = key.substring(colon + 1);
               if (CATEGORY_SET.contains(cat)) {
                  st.setString(1, uuidString);
                  st.setString(2, cat);
                  st.setString(3, itemId);
                  st.setInt(4, amount);
                  st.addBatch();
                  hasBatch = true;
               }
            }
         }
      }

      if (hasBatch) {
         st.executeBatch();
      }
   }

   @Override
   protected void rollbackConnection(Connection connection) {
      try {
         if (connection != null) {
            connection.rollback();
         }
      } catch (SQLException var3) {
      }
   }

   @Override
   protected void restoreAutoCommit(Connection connection) {
      try {
         if (connection != null) {
            connection.setAutoCommit(true);
         }
      } catch (SQLException var3) {
      }
   }
}
