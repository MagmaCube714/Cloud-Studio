package cs.cloudstudio.manager;

import cs.cloudstudio.database.DatabaseType;
import cs.cloudstudio.manager.model.PlayerData;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import org.bukkit.Bukkit;

public abstract class DatabaseAdminModule extends DatabaseSaveModule {
   @Override
   protected void resetPlayerCategory(UUID uuid, String category) {
      PlayerData pd = this.getPlayerData(uuid);
      pd.stages.remove(category);
      pd.progress.remove(category);
      pd.skips.remove(category);
      pd.completed.remove(category);
      pd.skipped.remove(category);
      pd.rewardClaims.remove(category);
      pd.completedStages.remove(category);
      pd.skippedStages.remove(category);
      pd.claimedRewards.remove(category);
      String prefix = category + ":";
      pd.purchases.entrySet().removeIf(entry -> entry.getKey().startsWith(prefix));
      this.markPlayerDataModified(pd);
   }

   @Override
   protected void resetAllProgressOnly() {
      for (PlayerData pd : this.cache.values()) {
         pd.stages.clear();
         pd.progress.clear();
         pd.skips.clear();
         pd.completed.clear();
         pd.skipped.clear();
         pd.rewardClaims.clear();
         pd.completedStages.clear();
         pd.skippedStages.clear();
         pd.claimedRewards.clear();
         this.markPlayerDataModified(pd);
      }

      this.saveAllDataAsync();
   }

   @Override
   protected void resetPlayerDatabase(UUID uuid) {
      this.cache.remove(uuid);
      this.databaseGeneration++;
      Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
         synchronized (this.databaseLock) {
            try {
               this.deletePlayerFromDatabase(uuid.toString());
            } catch (SQLException e) {
               this.getLogger().warning("[CloudQuests] Не удалось сбросить игрока в базе: " + e.getMessage());
            }
         }
      });
   }

   @Override
   protected void resetDatabase() {
      this.cache.clear();
      this.databaseGeneration++;
      Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
         synchronized (this.databaseLock) {
            try (Connection connection = this.dataSource.getConnection()) {
               if (this.databaseSettings.type == DatabaseType.SQLITE) {
                  this.enableSqliteForeignKeys(connection);
               }

               connection.setAutoCommit(false);

               try {
                  this.clearDatabaseTables(connection);
                  connection.commit();
               } catch (SQLException e) {
                  this.rollbackConnection(connection);
                  throw e;
               } finally {
                  this.restoreAutoCommit(connection);
               }
            } catch (SQLException e) {
               this.getLogger().warning("[CloudQuests] Не удалось очистить базу: " + e.getMessage());
            }
         }
      });
   }

   @Override
   protected void deletePlayerFromDatabase(String uuidString) throws SQLException {
      try (
         Connection connection = this.dataSource.getConnection();
         PreparedStatement st = connection.prepareStatement("DELETE FROM players WHERE uuid=?");
      ) {
         if (this.databaseSettings.type == DatabaseType.SQLITE) {
            this.enableSqliteForeignKeys(connection);
         }

         st.setString(1, uuidString);
         st.executeUpdate();
      }
   }

   @Override
   protected void clearDatabaseTables(Connection connection) throws SQLException {
      try (Statement st = connection.createStatement()) {
         st.executeUpdate("DELETE FROM purchases");
         st.executeUpdate("DELETE FROM claimed_rewards");
         st.executeUpdate("DELETE FROM skipped_stages");
         st.executeUpdate("DELETE FROM completed_stages");
         st.executeUpdate("DELETE FROM quest_progress");
         st.executeUpdate("DELETE FROM players");
      }
   }

   @Override
   protected void closeDatabase() {
      synchronized (this.databaseLock) {
         if (this.dataSource != null) {
            try {
               this.dataSource.getClass().getMethod("close").invoke(this.dataSource);
            } catch (NoSuchMethodException var4) {
            } catch (Exception e) {
               this.getLogger().warning("[CloudQuests] Не удалось закрыть подключение базы: " + e.getMessage());
            }
         }

         this.dataSource = null;
      }
   }
}
