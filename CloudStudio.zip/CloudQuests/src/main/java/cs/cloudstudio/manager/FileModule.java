package cs.cloudstudio.manager;

import cs.cloudstudio.manager.model.GeneratedReward;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.command.CommandMap;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.event.server.PluginEnableEvent;
import org.bukkit.plugin.RegisteredServiceProvider;

public abstract class FileModule extends PluginBase {
   @Override
   protected boolean safeLoadAllDataOnStartup() {
      try {
         this.loadAllData();
         return true;
      } catch (Throwable first) {
         try {
            this.reloadPluginConfig();
            this.reloadQuestsConfig();

            for (String category : CATEGORIES) {
               this.generateQuestCategory(category);
            }

            this.saveQuestsConfig();
            this.loadAllData();
            return true;
         } catch (Throwable second) {
            return false;
         }
      }
   }

   @EventHandler
   @Override
   public void onPluginEnable(PluginEnableEvent e) {
      if ("PlaceholderAPI".equals(e.getPlugin().getName())) {
         this.placeholderApiEnabled = true;
      }
   }

   @EventHandler
   @Override
   public void onPluginDisable(PluginDisableEvent e) {
      if ("PlaceholderAPI".equals(e.getPlugin().getName())) {
         this.placeholderApiEnabled = false;
      }
   }

   @Override
   protected CommandMap resolveCommandMap() {
      try {
         Method method = this.getServer().getClass().getMethod("getCommandMap");
         Object value = method.invoke(this.getServer());
         if (value instanceof CommandMap) {
            return (CommandMap)value;
         }
      } catch (ReflectiveOperationException var3) {
      }

      return null;
   }

   @Override
   protected boolean setupEconomy() {
      if (this.getServer().getPluginManager().getPlugin("Vault") == null) {
         return false;
      }

      RegisteredServiceProvider<Economy> rsp = this.getServer().getServicesManager().getRegistration(Economy.class);
      if (rsp == null) {
         return false;
      }

      this.econ = (Economy)rsp.getProvider();
      return this.econ != null;
   }

   @Override
   protected void saveDefaultSellers() {
      this.ensureCategoryFilesReady();
   }

   @Override
   protected void ensureCategoryFilesReady() {
      if (!this.getDataFolder().exists()) {
         this.getDataFolder().mkdirs();
      }

      this.questsFolder = new File(this.getDataFolder(), "quests");
      if (this.questsFolder.exists() || this.questsFolder.mkdirs()) {
         File oldRootQuestsFile = new File(this.getDataFolder(), "quests.yml");
         FileConfiguration oldRoot = oldRootQuestsFile.exists() ? YamlConfiguration.loadConfiguration(oldRootQuestsFile) : null;
         FileConfiguration bundled = this.loadBundledQuestsDefaults();
         this.questsFile = oldRootQuestsFile;
         this.questsConfig = oldRoot != null ? oldRoot : bundled;
         this.categoryQuestFiles.clear();
         this.categoryQuestConfigs.clear();
         this.categoryRewardFiles.clear();
         this.categoryRewardConfigs.clear();
         this.categorySellerFiles.clear();

         for (String cat : CATEGORIES) {
            File catFolder = new File(this.questsFolder, cat);
            if (catFolder.exists() || catFolder.mkdirs()) {
               File questFile = new File(catFolder, "quests.yml");
               File rewardFile = new File(catFolder, "rewards.yml");
               File sellerFile = new File(catFolder, "seller.yml");
               this.categoryQuestFiles.put(cat, questFile);
               this.categoryRewardFiles.put(cat, rewardFile);
               this.categorySellerFiles.put(cat, sellerFile);
               if (!questFile.exists()) {
                  this.createDefaultCategoryQuestsFile(cat, questFile, oldRoot, bundled);
               }

               if (!rewardFile.exists()) {
                  this.createDefaultCategoryRewardsFile(cat, rewardFile, oldRoot, bundled);
               }

               if (!sellerFile.exists()) {
                  this.createDefaultCategorySellerFile(cat, sellerFile);
               }

               this.categoryQuestConfigs.put(cat, YamlConfiguration.loadConfiguration(questFile));
               this.categoryRewardConfigs.put(cat, YamlConfiguration.loadConfiguration(rewardFile));
            }
         }
      }
   }

   @Override
   protected FileConfiguration loadBundledQuestsDefaults() {
      try (InputStream input = this.getResource("quests.yml")) {
         if (input != null) {
            return YamlConfiguration.loadConfiguration(new InputStreamReader(input, StandardCharsets.UTF_8));
         }
      } catch (IOException var6) {
      }

      return new YamlConfiguration();
   }

   @Override
   protected void createDefaultCategoryQuestsFile(String category, File file, FileConfiguration oldRoot, FileConfiguration bundled) {
      if (oldRoot != null || !this.copyResourceFile("quests/" + category + "/quests.yml", file)) {
         YamlConfiguration cfg = new YamlConfiguration();
         FileConfiguration source = oldRoot != null ? oldRoot : bundled;
         cfg.set("settings.generate-on-startup", source.getBoolean("settings.generate-on-startup", true));
         cfg.set("settings.regenerate-on-every-startup", source.getBoolean("settings.regenerate-on-every-startup", false));
         cfg.set("settings.reset-progress-on-generate", source.getBoolean("settings.reset-progress-on-generate", true));
         cfg.set("settings.rows", source.getInt("settings.rows", 5));
         cfg.set("settings.max-amount-per-task", source.getInt("settings.max-amount-per-task", 3000));
         cfg.set("settings.ignore-custom-items", source.getBoolean("settings.ignore-custom-items", true));
         cfg.set(
            "generator.amount-multiplier",
            source.getDouble("generator.categories." + category + ".amount-multiplier", this.getDefaultGeneratorAmountMultiplier(category))
         );
         cfg.set("generator.min-score", source.getDouble("generator.categories." + category + ".min-score", this.getDefaultGeneratorMinScore(category)));
         cfg.set("generator.max-score", source.getDouble("generator.categories." + category + ".max-score", this.getDefaultGeneratorMaxScore(category)));
         ConfigurationSection customPool = source.getConfigurationSection("generator.custom-pool");
         if (customPool != null) {
            cfg.set("generator.custom-pool", customPool.getValues(true));
         }

         ConfigurationSection oldQuests = source.getConfigurationSection("menus." + category + ".quests");
         if (oldQuests != null && !oldQuests.getKeys(false).isEmpty()) {
            ConfigurationSection quests = cfg.createSection("quests");

            for (String key : oldQuests.getKeys(false)) {
               ConfigurationSection old = oldQuests.getConfigurationSection(key);
               if (old != null && !"REWARD".equalsIgnoreCase(old.getString("type", ""))) {
                  quests.set(key, old.getValues(true));
               }
            }
         } else {
            cfg.createSection("quests");
         }

         this.saveYamlFile(cfg, file, "quests/" + category + "/quests.yml");
      }
   }

   @Override
   protected void createDefaultCategoryRewardsFile(String category, File file, FileConfiguration oldRoot, FileConfiguration bundled) {
      if (oldRoot != null || !this.copyResourceFile("quests/" + category + "/rewards.yml", file)) {
         YamlConfiguration cfg = new YamlConfiguration();
         FileConfiguration source = oldRoot != null ? oldRoot : bundled;

         for (String key : REWARD_TEMPLATE_KEYS) {
            String base = "reward-items." + key;
            cfg.set(base + ".name", source.getString(base + ".name", "&b&lНаграда:"));
            List<String> lore = source.getStringList(base + ".lore");
            if (lore == null || lore.isEmpty()) {
               if ("unlock-reward".equals(key)) {
                  lore = Arrays.asList("&aНажмите, чтобы получить награду");
               } else if ("already-given".equals(key)) {
                  lore = Arrays.asList("&aВы уже получили награду");
               } else {
                  lore = Arrays.asList("&cПройди этап, чтобы забрать награду");
               }
            }

            cfg.set(base + ".lore", lore);
         }

         ConfigurationSection rewards = cfg.createSection("rewards");
         ConfigurationSection sourceRewards = source.getConfigurationSection("rewards." + category);
         if (sourceRewards != null && !sourceRewards.getKeys(false).isEmpty()) {
            for (String key : sourceRewards.getKeys(false)) {
               ConfigurationSection reward = sourceRewards.getConfigurationSection(key);
               if (reward != null) {
                  rewards.set(key, reward.getValues(true));
               }
            }
         } else {
            Map<Integer, GeneratedReward> migrated = new HashMap<>();
            this.readRewardSection(
               migrated,
               source.getConfigurationSection("menus." + category + ".quests"),
               category,
               9,
               this.getGeneratorTotalRowsForConfig(source, category) * 9
            );
            int rows = Math.max(1, Math.min(6, this.getGeneratorTotalRowsForConfig(source, category)));

            for (int row = 1; row <= rows; row++) {
               GeneratedReward reward = migrated.get(row * 9);
               if (reward == null) {
                  reward = this.createDefaultGeneratedReward(category, row);
               }

               ConfigurationSection section = rewards.createSection(Integer.toString(row));
               section.set("slot", row * 9 - 1);
               section.set("material", reward.material.name());
               section.set("commands", reward.commands);
            }
         }

         this.saveYamlFile(cfg, file, "quests/" + category + "/rewards.yml");
      }
   }

   @Override
   protected void createDefaultCategorySellerFile(String category, File file) {
      File oldSeller = new File(this.getDataFolder(), "seller_" + category + ".yml");

      try {
         if (!this.copyResourceFile("quests/" + category + "/seller.yml", file)) {
            if (oldSeller.exists()) {
               Files.copy(oldSeller.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } else {
               String resourceName = "seller_" + category + ".yml";

               try (InputStream input = this.getResource(resourceName)) {
                  if (input != null) {
                     Files.copy(input, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
                     return;
                  }
               }

               YamlConfiguration cfg = new YamlConfiguration();
               cfg.set("menu.title", "&fЯрмарка " + category);
               cfg.set("menu.size", 54);
               cfg.set("messages.success_purchase", "&fУспешная покупка");
               cfg.set("messages.not_enough_money", "&cНедостаточно монет");
               cfg.set("messages.limit_reached", "&cВы достигли лимита");
               cfg.createSection("items");
               this.saveYamlFile(cfg, file, "quests/" + category + "/seller.yml");
            }
         }
      } catch (IOException var10) {
      }
   }

   @Override
   protected boolean copyResourceFile(String resourceName, File file) {
      try (InputStream input = this.getResource(resourceName)) {
         if (input == null) {
            return false;
         }

         Files.copy(input, file.toPath(), StandardCopyOption.REPLACE_EXISTING);
         return true;
      } catch (IOException e) {
         return false;
      }
   }

   @Override
   protected void saveYamlFile(FileConfiguration cfg, File file, String name) {
      try {
         cfg.save(file);
      } catch (IOException var5) {
      }
   }
}
