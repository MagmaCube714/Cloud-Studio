package cs.cloudstudio.manager.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;

public class Stage {
   public int id;
   public String category;
   public int slot;
   public int reqAmount;
   public StageType type;
   public ActionType action = ActionType.BRING;
   public Material reqMaterial;
   public Material displayMaterial;
   public Set<Material> breakMaterials = Collections.emptySet();
   public EntityType targetEntity;
   public Material reqWeapon;
   public String itemName;
   public List<String> rewardCommands = new ArrayList<>();
}
