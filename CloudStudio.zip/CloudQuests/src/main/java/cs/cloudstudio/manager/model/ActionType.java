package cs.cloudstudio.manager.model;

public enum ActionType {
   BRING,
   BREAK,
   CRAFT,
   KILL;
}
