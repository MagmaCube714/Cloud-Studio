package cs.cloudstudio.manager;

import cs.cloudstudio.manager.model.ActionType;
import cs.cloudstudio.manager.model.Stage;
import cs.cloudstudio.manager.model.StageType;
import cs.cloudstudio.menu.QuestMenuHolder;
import cs.cloudstudio.menu.SellerMenuHolder;
import java.util.List;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Event.Result;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public abstract class ListenerModule extends MenuModule {
   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
   @Override
   public void onClick(InventoryClickEvent e) {
      Inventory topInventory = e.getView().getTopInventory();
      InventoryHolder holder = topInventory.getHolder();
      if (holder instanceof QuestMenuHolder || holder instanceof SellerMenuHolder) {
         e.setCancelled(true);
         e.setResult(Result.DENY);
         int raw = e.getRawSlot();
         if (raw >= 0 && raw < topInventory.getSize()) {
            InventoryAction action = e.getAction();
            if (action != InventoryAction.NOTHING
               && action != InventoryAction.UNKNOWN
               && action != InventoryAction.MOVE_TO_OTHER_INVENTORY
               && action != InventoryAction.COLLECT_TO_CURSOR
               && action != InventoryAction.HOTBAR_SWAP) {
               ClickType click = e.getClick();
               if (click == ClickType.LEFT || click == ClickType.RIGHT || click == ClickType.SHIFT_LEFT || click == ClickType.SHIFT_RIGHT) {
                  if (e.getWhoClicked() instanceof Player p) {
                     UUID uuid = p.getUniqueId();
                     if (this.activeTransactions.add(uuid)) {
                        try {
                           if (holder instanceof QuestMenuHolder) {
                              this.handleQuestClick(p, ((QuestMenuHolder)holder).category, raw);
                           } else {
                              this.handleSellerClick(p, ((SellerMenuHolder)holder).category, raw);
                           }
                        } finally {
                           this.activeTransactions.remove(uuid);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
   @Override
   public void onDrag(InventoryDragEvent e) {
      Inventory topInventory = e.getView().getTopInventory();
      InventoryHolder holder = topInventory.getHolder();
      if (holder instanceof QuestMenuHolder || holder instanceof SellerMenuHolder) {
         int topSize = topInventory.getSize();

         for (Integer rawSlot : e.getRawSlots()) {
            if (rawSlot != null && rawSlot >= 0 && rawSlot < topSize) {
               e.setCancelled(true);
               e.setResult(Result.DENY);
               return;
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   @Override
   public void onDrop(PlayerDropItemEvent event) {
      Player player = event.getPlayer();
      if (this.activeTransactions.contains(player.getUniqueId()) || this.hasPluginMenuOpen(player)) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   @Override
   public void onSwapHand(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (this.activeTransactions.contains(player.getUniqueId()) || this.hasPluginMenuOpen(player)) {
         event.setCancelled(true);
      }
   }

   @EventHandler
   @Override
   public void onQuit(PlayerQuitEvent event) {
      UUID uuid = event.getPlayer().getUniqueId();
      this.activeTransactions.remove(uuid);
      this.savePlayerDataAsync(uuid);
   }

   @EventHandler
   @Override
   public void onKick(PlayerKickEvent event) {
      UUID uuid = event.getPlayer().getUniqueId();
      this.activeTransactions.remove(uuid);
      this.savePlayerDataAsync(uuid);
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   @Override
   public void onBlockBreak(BlockBreakEvent e) {
      if (!e.isCancelled()) {
         this.onBlockBroken(e.getPlayer(), e.getBlock().getType(), this.isFullyGrown(e.getBlock()));
      }
   }

   public void onBlockBroken(Player p, Material broken, boolean fullyGrown) {
      if (p != null && p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR) {
         List<String> cats = this.breakIndex.get(broken);
         if (cats != null && !cats.isEmpty()) {
            if (!AGEABLE_BREAK_MATERIALS.contains(broken) || fullyGrown) {
               int i = 0;

               for (int n = cats.size(); i < n; i++) {
                  String cat = cats.get(i);
                  Stage active = this.getActiveStage(p, cat);
                  if (active != null && active.type == StageType.TASK && active.action == ActionType.BREAK && active.breakMaterials.contains(broken)) {
                     this.addTaskProgress(p, cat, active, 1);
                  }
               }
            }
         }
      }
   }

   @Override
   public boolean isFullyGrown(Block block) {
      return block.getBlockData() instanceof Ageable ageable ? ageable.getAge() == ageable.getMaximumAge() : true;
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   @Override
   public void onCraftItem(CraftItemEvent e) {
      if (!e.isCancelled()) {
         if (e.getRecipe() != null) {
            ItemStack result = e.getCurrentItem();
            if (result != null && result.getAmount() > 0) {
               Material crafted = result.getType();
               if (crafted != Material.AIR) {
                  List<String> cats = this.craftIndex.get(crafted);
                  if (cats != null && !cats.isEmpty()) {
                     if (e.getWhoClicked() instanceof Player) {
                        Player p = (Player)e.getWhoClicked();
                        int amountCrafted = this.calculateCraftAmount(e);
                        if (amountCrafted > 0) {
                           int i = 0;

                           for (int n = cats.size(); i < n; i++) {
                              String cat = cats.get(i);
                              Stage active = this.getActiveStage(p, cat);
                              if (active != null && active.type == StageType.TASK && active.action == ActionType.CRAFT && crafted == active.reqMaterial) {
                                 this.addTaskProgress(p, cat, active, amountCrafted);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   @Override
   public void onEntityDeath(EntityDeathEvent e) {
      if (!e.isCancelled()) {
         List<String> cats = this.killIndex.get(e.getEntityType());
         if (cats != null && !cats.isEmpty()) {
            Player killer = e.getEntity().getKiller();
            if (killer != null) {
               if (killer.getGameMode() != GameMode.CREATIVE && killer.getGameMode() != GameMode.SPECTATOR) {
                  EntityType killed = e.getEntityType();
                  Material weaponInHand = null;
                  int i = 0;

                  for (int n = cats.size(); i < n; i++) {
                     String cat = cats.get(i);
                     Stage active = this.getActiveStage(killer, cat);
                     if (active != null && active.type == StageType.TASK && active.action == ActionType.KILL && killed == active.targetEntity) {
                        if (active.reqWeapon != null) {
                           if (weaponInHand == null) {
                              weaponInHand = killer.getInventory().getItemInMainHand().getType();
                           }

                           if (weaponInHand != active.reqWeapon) {
                              continue;
                           }
                        }

                        this.addTaskProgress(killer, cat, active, 1);
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   protected int calculateCraftAmount(CraftItemEvent event) {
      if (!event.isCancelled()
         && event.getAction() != InventoryAction.NOTHING
         && event.getAction() != InventoryAction.CLONE_STACK
         && event.getAction() != InventoryAction.UNKNOWN
         && event.getWhoClicked().getGameMode() != GameMode.CREATIVE
         && event.getWhoClicked().getGameMode() != GameMode.SPECTATOR) {
         ItemStack resultStack = event.getCurrentItem();
         if (resultStack == null || resultStack.getType() == Material.AIR || resultStack.getAmount() <= 0) {
            return 0;
         }

         if (!event.isShiftClick()) {
            return resultStack.getAmount();
         }

         ItemStack[] matrix = event.getInventory().getMatrix();
         int maxCraftable = Integer.MAX_VALUE;
         int i = 0;

         for (int n = matrix.length; i < n; i++) {
            ItemStack item = matrix[i];
            if (item != null && item.getType() != Material.AIR) {
               int a = item.getAmount();
               if (a < maxCraftable) {
                  maxCraftable = a;
               }
            }
         }

         if (maxCraftable != Integer.MAX_VALUE && maxCraftable > 0) {
            i = resultStack.getAmount();
            int maxInventorySpace = 0;
            ItemStack[] storage = event.getWhoClicked().getInventory().getStorageContents();
            int ix = 0;

            for (int n = storage.length; ix < n; ix++) {
               ItemStack content = storage[ix];
               if (content == null || content.getType() == Material.AIR) {
                  maxInventorySpace += resultStack.getMaxStackSize();
               } else if (content.isSimilar(resultStack)) {
                  maxInventorySpace += content.getMaxStackSize() - content.getAmount();
               }
            }

            ix = (int)Math.min((long)maxCraftable * i, maxInventorySpace);
            return ix / i * i;
         } else {
            return 0;
         }
      } else {
         return 0;
      }
   }
}
