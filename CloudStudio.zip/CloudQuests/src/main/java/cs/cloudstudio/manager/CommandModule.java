package cs.cloudstudio.manager;

import cs.cloudstudio.manager.model.PlayerData;
import cs.cloudstudio.manager.model.Stage;
import cs.cloudstudio.manager.model.StageType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public abstract class CommandModule extends ListenerModule {
   @Override
   public boolean executeCommand(CommandSender sender, Command cmd, String label, String[] args) {
      if (label.equalsIgnoreCase("quest")) {
         if (!(sender instanceof Player p)) {
            sender.sendMessage(this.color("&cЭта команда доступна только игроку"));
            return true;
         } else if (args.length < 1) {
            p.sendMessage(this.color("&6Квесты &7» &cИспользуйте: &b/quest <type>"));
            p.sendMessage(this.color("&7Доступно: &beasy&7, &bmedium&7, &bhard&7, &bfish&7, &bmine&7, &bwood&7, &bfarm&7, &balch"));
            return true;
         } else {
            String cat = args[0].toLowerCase(Locale.ROOT);
            if (!CATEGORY_SET.contains(cat)) {
               p.sendMessage(this.color("&6Квесты &7» &cНеизвестная категория: &f" + args[0]));
               return true;
            } else {
               this.updatePlayerIdentity(p.getUniqueId(), p.getName());
               this.handleMenuOpen(p, cat);
               return true;
            }
         }
      } else if (label.equalsIgnoreCase("skipquest")) {
         if (!(sender instanceof Player p)) {
            sender.sendMessage(this.color("&cЭта команда доступна только игроку"));
            return true;
         } else {
            if (!p.hasPermission("cloudquests.skipquest")) {
               this.sendMsg(p, "no_permission_skip");
               return true;
            }

            if (args.length < 2) {
               p.sendMessage(this.color("&6Квесты &7» &cИспользуйте: &b/skipquest <type> <number>"));
               p.sendMessage(this.color("&7Доступно: &beasy&7, &bmedium&7, &bhard&7, &bfish&7, &bmine&7, &bwood&7, &bfarm&7, &balch"));
               return true;
            }

            String cat = args[0].toLowerCase(Locale.ROOT);
            if (!CATEGORY_SET.contains(cat)) {
               p.sendMessage(this.color("&6Квесты &7» &cНеизвестная категория: &6" + args[0]));
               return true;
            }

            int expectedStage;
            try {
               expectedStage = Integer.parseInt(args[1]);
            } catch (NumberFormatException ignored) {
               p.sendMessage(this.color("&6Квесты &7» &cНомер квеста должен быть числом. Используйте: &6/skipquest <type> <number>"));
               return true;
            }

            this.updatePlayerIdentity(p.getUniqueId(), p.getName());
            if (!this.ensureCategoryUnlocked(p, cat)) {
               return true;
            } else {
               int currentStage = this.normalizePlayerStageAfterRewards(p.getUniqueId(), cat);
               if (expectedStage != currentStage) {
                  p.sendMessage(
                     this.color("&6Квесты &7» &fВы не можете пропустить этап &6" + expectedStage + "&f, так как сейчас находитесь на &6" + currentStage + "&f.")
                  );
                  return true;
               } else {
                  this.handleSkip(p, cat);
                  return true;
               }
            }
         }
      } else {
         return label.equalsIgnoreCase("cloudquests") ? this.handleAdmin(sender, args) : true;
      }
   }

   @Override
   public List<String> tabCompleteCommand(CommandSender sender, Command cmd, String alias, String[] args) {
      List<String> completions = new ArrayList<>();
      if (!alias.equalsIgnoreCase("quest") && !alias.equalsIgnoreCase("skipquest")) {
         if (!alias.equalsIgnoreCase("cloudquests")) {
            return completions;
         }

         if (!sender.hasPermission("cloudquests.admin")) {
            return Collections.emptyList();
         }

         if (args.length == 1) {
            this.addMatching(completions, ADMIN_SUB_COMMANDS, args[0]);
            return completions;
         }

         String sub = args[0].toLowerCase(Locale.ROOT);
         if (args.length == 2) {
            if ("generate".equals(sub) || "regen".equals(sub)) {
               this.addMatching(completions, GENERATOR_TARGETS, args[1]);
            } else if (subRequiresPlayerArg(sub)) {
               String input = args[1].toLowerCase(Locale.ROOT);

               for (Player p : Bukkit.getOnlinePlayers()) {
                  if (p.getName().toLowerCase(Locale.ROOT).startsWith(input)) {
                     completions.add(p.getName());
                  }
               }
            }

            return completions;
         } else if (args.length == 3) {
            if (("generate".equals(sub) || "regen".equals(sub)) && CATEGORY_SET.contains(args[1].toLowerCase(Locale.ROOT))) {
               String category = args[1].toLowerCase(Locale.ROOT);
               int totalStages = this.getGeneratorTotalRows(category) * 9;
               String input = args[2];

               for (int id = 1; id <= totalStages; id++) {
                  if ((id - 1) % 9 != 8) {
                     String value = Integer.toString(id);
                     if (value.startsWith(input)) {
                        completions.add(value);
                     }
                  }
               }
            } else if (subRequiresCategoryArg(sub)) {
               this.addMatching(completions, CATEGORIES, args[2]);
            }

            return completions;
         } else {
            if (args.length == 4) {
               if ("setstage".equals(sub)) {
                  List<Stage> stages = this.categoryStages.get(args[2].toLowerCase(Locale.ROOT));
                  if (stages != null) {
                     int i = 0;

                     for (int n = stages.size(); i < n; i++) {
                        String id = Integer.toString(stages.get(i).id);
                        if (id.startsWith(args[3])) {
                           completions.add(id);
                        }
                     }
                  }
               } else if ("setprogress".equals(sub)) {
                  this.addMatching(completions, new String[]{"0", "1", "16", "32", "64", "128", "256", "512"}, args[3]);
               } else if ("setskips".equals(sub)) {
                  this.addMatching(completions, new String[]{"0", "1", "2", "3", "5", "10"}, args[3]);
               }
            }

            return completions;
         }
      } else {
         if (alias.equalsIgnoreCase("skipquest") && !sender.hasPermission("cloudquests.skipquest")) {
            return Collections.emptyList();
         }

         if (args.length == 1) {
            this.addMatching(completions, CATEGORIES, args[0]);
         } else if (alias.equalsIgnoreCase("skipquest") && args.length == 2 && sender instanceof Player) {
            String cat = args[0].toLowerCase(Locale.ROOT);
            Player player = (Player)sender;
            if (CATEGORY_SET.contains(cat) && this.isCategoryUnlocked(player.getUniqueId(), cat)) {
               String stage = Integer.toString(this.normalizePlayerStageAfterRewards(player.getUniqueId(), cat));
               if (stage.startsWith(args[1])) {
                  completions.add(stage);
               }
            }
         }

         return completions;
      }
   }

   @Override
   protected void addMatching(List<String> completions, String[] values, String input) {
      String lower = input.toLowerCase(Locale.ROOT);

      for (int i = 0; i < values.length; i++) {
         String v = values[i];
         if (v.startsWith(lower)) {
            completions.add(v);
         }
      }
   }

   @Override
   protected boolean handleAdmin(CommandSender sender, String[] args) {
      if (!sender.hasPermission("cloudquests.admin")) {
         this.sendMessageLine(sender, "no-perm", "&6Квесты &7» &cНедостаточно прав");
         return true;
      }

      if (args.length != 0 && !args[0].equalsIgnoreCase("help")) {
         String sub = args[0].toLowerCase(Locale.ROOT);
         switch (sub) {
            case "reload":
               this.loadAllData();
               this.placeholderApiEnabled = Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI");
               this.sendMessageLine(sender, "reloaded", "&6Квесты &7» &aКонфиги перезагружены");
               return true;
            case "generate":
            case "regen":
               return this.handleGenerate(sender, args);
            case "info":
               return this.handleInfo(sender, args);
            case "reset":
               return this.handleReset(sender, args);
            case "resetall":
               this.resetAllProgressOnly();
               this.sendMessageLine(sender, "resetall-success", "&6Квесты &7» &aПрогресс всех игроков сброшен");
               return true;
            case "resetdb":
               return this.handleResetDb(sender, args);
            case "setstage":
               return this.handleSetStage(sender, args);
            case "setprogress":
               return this.handleSetProgress(sender, args);
            case "setskips":
               return this.handleSetSkips(sender, args);
            case "complete":
               return this.handleComplete(sender, args);
            case "completeall":
               return this.handleCompleteAll(sender, args);
            default:
               this.sendAdminHelp(sender);
               return true;
         }
      } else {
         this.sendAdminHelp(sender);
         return true;
      }
   }

   @Override
   protected boolean handleInfo(CommandSender sender, String[] args) {
      if (args.length < 3) {
         sender.sendMessage(this.color("&6Квесты &7» &cИспользуйте: &6/cloudquests info <игрок> <категория>"));
         return true;
      } else {
         UUID target = this.getTargetUUID(sender, args[1]);
         if (target == null) {
            return true;
         } else {
            String category = args[2].toLowerCase(Locale.ROOT);
            if (!CATEGORY_SET.contains(category)) {
               sender.sendMessage(this.color("&6Квесты &7» &cНеизвестная категория: &6" + args[2]));
               return true;
            } else {
               PlayerData data = this.getPlayerData(target);
               int stage = this.getPlayerStage(target, category);
               int progress = this.getPlayerProgress(target, category);
               Stage current = this.getStage(category, stage);
               String stageName = current != null ? current.itemName : "—";
               String stageType = current != null ? current.type.name() : "—";
               String reqInfo = current != null && current.type == StageType.TASK ? " &f/ &6" + current.reqAmount : "";
               sender.sendMessage(this.color("&6Квесты &7» &fИгрок: &6" + args[1]));
               sender.sendMessage(this.color("&6Квесты &7» &fКатегория: &6" + category));
               sender.sendMessage(this.color("&6Квесты &7» &fЭтап: &6" + stage + " &f(&6" + stageName + "&f)"));
               sender.sendMessage(this.color("&6Квесты &7» &fТип: &6" + stageType));
               sender.sendMessage(this.color("&6Квесты &7» &fПрогресс: &6" + progress + reqInfo));
               sender.sendMessage(this.color("&6Квесты &7» &fПройдено заданий: &6" + data.completed.getOrDefault(category, 0)));
               sender.sendMessage(this.color("&6Квесты &7» &fПропущено этапов: &6" + data.skipped.getOrDefault(category, 0)));
               sender.sendMessage(this.color("&6Квесты &7» &fПолучено наград: &6" + data.rewardClaims.getOrDefault(category, 0)));
               sender.sendMessage(this.color("&6Квесты &7» &fПропуски: &6" + this.getSkipsLeft(target, category)));
               return true;
            }
         }
      }
   }

   @Override
   protected boolean handleReset(CommandSender sender, String[] args) {
      if (args.length < 3) {
         sender.sendMessage(this.color("&6Квесты &7» &cИспользуйте: &6/cloudquests reset <игрок> <категория>"));
         return true;
      } else {
         UUID target = this.getTargetUUID(sender, args[1]);
         if (target == null) {
            return true;
         } else {
            String category = args[2].toLowerCase(Locale.ROOT);
            if (!CATEGORY_SET.contains(category)) {
               sender.sendMessage(this.color("&6Квесты &7» &cНеизвестная категория: &6" + args[2]));
               return true;
            } else {
               PlayerData rollback = this.copyPlayerData(this.getPlayerData(target));
               this.resetPlayerCategory(target, category);
               if (!this.savePlayerDataSync(target)) {
                  this.cache.put(target, rollback);
                  sender.sendMessage(this.color("&6Квесты &7» &cСброс не сохранен: ошибка базы данных."));
                  return true;
               } else {
                  sender.sendMessage(this.color("&6Квесты &7» &aДанные &6" + args[1] + " &aв &6" + category + " &aсброшены."));
                  return true;
               }
            }
         }
      }
   }

   @Override
   protected boolean handleResetDb(CommandSender sender, String[] args) {
      if (args.length >= 2) {
         UUID target = this.getTargetUUID(sender, args[1]);
         if (target == null) {
            return true;
         }

         this.resetPlayerDatabase(target);
         sender.sendMessage(this.color("&6Квесты &7» &aБаза данных игрока &6" + args[1] + " &aсброшена."));
      } else {
         this.resetDatabase();
         sender.sendMessage(this.color("&6Квесты &7» &aБаза данных игроков полностью сброшена."));
      }

      return true;
   }

   @Override
   protected boolean handleSetStage(CommandSender sender, String[] args) {
      if (args.length < 4) {
         sender.sendMessage(this.color("&6Квесты &7» &cИспользуйте: &6/cloudquests setstage <игрок> <кат> <id>"));
         return true;
      }

      UUID target = this.getTargetUUID(sender, args[1]);
      if (target == null) {
         return true;
      }

      String category = args[2].toLowerCase(Locale.ROOT);
      if (!CATEGORY_SET.contains(category)) {
         sender.sendMessage(this.color("&6Квесты &7» &cНеизвестная категория: &6" + args[2]));
         return true;
      }

      try {
         int stageId = Math.max(1, Integer.parseInt(args[3]));
         PlayerData rollback = this.copyPlayerData(this.getPlayerData(target));
         this.setPlayerStage(target, category, stageId);
         if (!this.savePlayerDataSync(target)) {
            this.cache.put(target, rollback);
            sender.sendMessage(this.color("&6Квесты &7» &cЭтап не сохранен: ошибка базы данных."));
            return true;
         }

         sender.sendMessage(this.color("&6Квесты &7» &aЭтап &6" + args[1] + " &a(&6" + category + "&a) → &6" + stageId));
      } catch (NumberFormatException ignored) {
         sender.sendMessage(this.color("&6Квесты &7» &cНекорректный ID этапа."));
      }

      return true;
   }

   @Override
   protected boolean handleSetProgress(CommandSender sender, String[] args) {
      if (args.length < 4) {
         sender.sendMessage(this.color("&6Квесты &7» &cИспользуйте: &6/cloudquests setprogress <игрок> <кат> <значение>"));
         return true;
      }

      UUID target = this.getTargetUUID(sender, args[1]);
      if (target == null) {
         return true;
      }

      String category = args[2].toLowerCase(Locale.ROOT);
      if (!CATEGORY_SET.contains(category)) {
         sender.sendMessage(this.color("&6Квесты &7» &cНеизвестная категория: &6" + args[2]));
         return true;
      }

      try {
         int progress = Math.max(0, Integer.parseInt(args[3]));
         PlayerData rollback = this.copyPlayerData(this.getPlayerData(target));
         this.setPlayerProgress(target, category, progress);
         if (!this.savePlayerDataSync(target)) {
            this.cache.put(target, rollback);
            sender.sendMessage(this.color("&6Квесты &7» &cПрогресс не сохранен: ошибка базы данных."));
            return true;
         }

         sender.sendMessage(this.color("&6Квесты &7» &aПрогресс &6" + args[1] + " &a(&6" + category + "&a) → &6" + progress));
      } catch (NumberFormatException ignored) {
         sender.sendMessage(this.color("&6Квесты &7» &cНекорректное значение прогресса."));
      }

      return true;
   }

   @Override
   protected boolean handleSetSkips(CommandSender sender, String[] args) {
      if (args.length < 4) {
         sender.sendMessage(this.color("&6Квесты &7» &cИспользуйте: &6/cloudquests setskips <игрок> <кат> <значение>"));
         return true;
      }

      UUID target = this.getTargetUUID(sender, args[1]);
      if (target == null) {
         return true;
      }

      String category = args[2].toLowerCase(Locale.ROOT);
      if (!CATEGORY_SET.contains(category)) {
         sender.sendMessage(this.color("&6Квесты &7» &cНеизвестная категория: &6" + args[2]));
         return true;
      }

      try {
         int skips = Math.max(0, Integer.parseInt(args[3]));
         PlayerData rollback = this.copyPlayerData(this.getPlayerData(target));
         this.setSkipsLeft(target, category, skips);
         if (!this.savePlayerDataSync(target)) {
            this.cache.put(target, rollback);
            sender.sendMessage(this.color("&6Квесты &7» &cПропуски не сохранены: ошибка базы данных."));
            return true;
         }

         sender.sendMessage(this.color("&6Квесты &7» &aПропуски &6" + args[1] + " &a(&6" + category + "&a) → &6" + skips));
      } catch (NumberFormatException ignored) {
         sender.sendMessage(this.color("&6Квесты &7» &cНекорректное значение пропусков."));
      }

      return true;
   }

   @Override
   protected boolean handleComplete(CommandSender sender, String[] args) {
      if (args.length < 3) {
         sender.sendMessage(this.color("&6Квесты &7» &cИспользуйте: &6/cloudquests complete <игрок> <кат>"));
         return true;
      }

      UUID target = this.getTargetUUID(sender, args[1]);
      if (target == null) {
         return true;
      }

      String category = args[2].toLowerCase(Locale.ROOT);
      if (!CATEGORY_SET.contains(category)) {
         sender.sendMessage(this.color("&6Квесты &7» &cНеизвестная категория: &6" + args[2]));
         return true;
      }

      PlayerData rollback = this.copyPlayerData(this.getPlayerData(target));
      int[] result = this.skipCurrentQuestLine(target, args[1], category);
      if (!this.savePlayerDataSync(target)) {
         this.cache.put(target, rollback);
         sender.sendMessage(this.color("&6Квесты &7» &cИзменения не сохранены: ошибка базы данных."));
         return true;
      }

      if (result[4] != 0 && result[3] != 1) {
         sender.sendMessage(this.color("&6Квесты &7» &aПропущено этапов: &6" + result[1] + "&a. Следующий этап: &6" + result[0]));
      } else {
         sender.sendMessage(this.color("&6Квесты &7» &aВы пропустили все этапы квестовой линии \"&6" + category + "&a\" для &6" + args[1] + "&a."));
      }

      return true;
   }

   @Override
   protected boolean handleCompleteAll(CommandSender sender, String[] args) {
      if (args.length < 2) {
         sender.sendMessage(this.color("&6Квесты &7» &cИспользуйте: &6/cloudquests completeall <игрок> [кат]"));
         return true;
      }

      UUID target = this.getTargetUUID(sender, args[1]);
      if (target == null) {
         return true;
      }

      if (args.length >= 3) {
         String category = args[2].toLowerCase(Locale.ROOT);
         if (!CATEGORY_SET.contains(category)) {
            sender.sendMessage(this.color("&6Квесты &7» &cНеизвестная категория: &6" + args[2]));
            return true;
         }

         PlayerData rollback = this.copyPlayerData(this.getPlayerData(target));
         int[] result = this.skipRemainingQuestStages(target, args[1], category);
         if (!this.savePlayerDataSync(target)) {
            this.cache.put(target, rollback);
            sender.sendMessage(this.color("&6Квесты &7» &cИзменения не сохранены: ошибка базы данных."));
            return true;
         }

         sender.sendMessage(
            this.color("&6Квесты &7» &aВы пропустили все этапы квестовой линии \"&6" + category + "&a\" для &6" + args[1] + "&a. Пропущено: &6" + result[1])
         );
      } else {
         PlayerData rollback = this.copyPlayerData(this.getPlayerData(target));
         int skipped = 0;

         for (String category : CATEGORIES) {
            int[] result = this.skipRemainingQuestStages(target, args[1], category);
            skipped += result[1];
         }

         if (!this.savePlayerDataSync(target)) {
            this.cache.put(target, rollback);
            sender.sendMessage(this.color("&6Квесты &7» &cИзменения не сохранены: ошибка базы данных."));
            return true;
         }

         sender.sendMessage(this.color("&6Квесты &7» &aВсе квестовые линии пропущены для &6" + args[1] + "&a. Пропущено этапов: &6" + skipped));
      }

      return true;
   }

   @Override
   protected UUID getTargetUUID(CommandSender sender, String name) {
      Player online = Bukkit.getPlayerExact(name);
      if (online != null) {
         return online.getUniqueId();
      } else {
         OfflinePlayer op = Bukkit.getOfflinePlayer(name);
         if (!op.hasPlayedBefore() && !op.isOnline()) {
            sender.sendMessage(this.color("&6Квесты &7» &cИгрок не найден."));
            return null;
         } else {
            return op.getUniqueId();
         }
      }
   }

   @Override
   protected void sendAdminHelp(CommandSender sender) {
      this.sendMessageList(
         sender,
         "admin-usage",
         Arrays.asList(
            "&6Квесты &7» &f/cloudquests reload",
            "&6Квесты &7» &f/cloudquests generate [all|категория] [id]",
            "&6Квесты &7» &f/cloudquests regen <категория> <id> &7- только один квест",
            "&6Квесты &7» &f/cloudquests info <игрок> <категория>",
            "&6Квесты &7» &f/cloudquests reset <игрок> <категория>",
            "&6Квесты &7» &f/cloudquests resetall",
            "&6Квесты &7» &f/cloudquests resetdb",
            "&6Квесты &7» &f/cloudquests resetdb <игрок>",
            "&6Квесты &7» &f/cloudquests setstage <игрок> <кат> <id>",
            "&6Квесты &7» &f/cloudquests setprogress <игрок> <кат> <значение>",
            "&6Квесты &7» &f/cloudquests setskips <игрок> <кат> <значение>",
            "&6Квесты &7» &f/cloudquests complete <игрок> <кат>",
            "&6Квесты &7» &f/cloudquests completeall <игрок> [кат]"
         )
      );
   }
}
