package cs.cloudstudio.manager;

import cs.cloudstudio.database.DatabaseSettings;
import cs.cloudstudio.database.DatabaseType;
import cs.cloudstudio.database.DriverManagerDataSource;
import cs.cloudstudio.database.MySqlDialect;
import cs.cloudstudio.database.SqliteDialect;
import cs.cloudstudio.manager.model.PlayerData;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import javax.sql.DataSource;
import org.bukkit.Bukkit;

public abstract class DatabaseConnectionModule extends LoadModule {
   @Override
   protected boolean loadData() {
      if (!this.initializeDatabase()) {
         return false;
      }

      this.cache.clear();

      try {
         if (this.yamlStorage) {
            this.loadPlayersFromYamlStorage();
         } else {
            this.loadPlayersFromDatabase();
         }
      } catch (Exception e) {
         this.getLogger().warning("[CloudQuests] Не удалось загрузить данные базы: " + e.getMessage());
         return false;
      }

      if (this.cache.isEmpty() && !this.migrateLegacyYamlData()) {
         return false;
      }

      if (this.autoSaveTask != -1) {
         Bukkit.getScheduler().cancelTask(this.autoSaveTask);
      }

      this.autoSaveTask = Bukkit.getScheduler().runTaskTimer(this, this::saveAllDataAsync, 6000L, 6000L).getTaskId();
      return true;
   }

   @Override
   protected boolean initializeDatabase() {
      if (!this.getDataFolder().exists() && !this.getDataFolder().mkdirs()) {
         return false;
      }

      this.databaseSettings = DatabaseSettings.load(this.getConfig(), this.getDataFolder());
      this.sqlDialect = this.databaseSettings.type == DatabaseType.MYSQL ? new MySqlDialect() : new SqliteDialect();
      this.yamlStorage = false;
      this.yamlStorageFile = new File(this.getDataFolder(), "data.yml");

      try {
         this.dataSource = this.createDataSource(this.databaseSettings);

         try (Connection connection = this.dataSource.getConnection()) {
            this.initializeSchema(connection);
         }

         return true;
      } catch (Exception e) {
         this.getLogger().warning("[CloudQuests] Не удалось открыть базу данных: " + e.getMessage());
         this.closeDatabase();
         this.yamlStorage = false;
         this.dataSource = null;
         return false;
      }
   }

   @Override
   protected DataSource createDataSource(DatabaseSettings settings) throws IOException, ClassNotFoundException {
      try {
         return this.createHikariDataSource(settings);
      } catch (ClassNotFoundException e) {
         this.getLogger().warning("[CloudQuests] HikariCP не найден, используется прямое SQL-подключение");
         return this.createDriverManagerDataSource(settings);
      } catch (ReflectiveOperationException e) {
         this.getLogger().warning("[CloudQuests] HikariCP не удалось инициализировать, используется прямое SQL-подключение: " + e.getMessage());
         return this.createDriverManagerDataSource(settings);
      }
   }

   @Override
   protected DataSource createHikariDataSource(DatabaseSettings settings) throws IOException, ReflectiveOperationException {
      Class<?> configClass = Class.forName("com.zaxxer.hikari.HikariConfig");
      Object config = configClass.getDeclaredConstructor().newInstance();
      this.invoke(config, "setPoolName", new Class[]{String.class}, "CloudQuests-" + settings.type.name());
      this.invoke(config, "setMaximumPoolSize", new Class[]{int.class}, settings.type == DatabaseType.SQLITE ? 1 : 4);
      this.invoke(config, "setMinimumIdle", new Class[]{int.class}, 1);
      this.invoke(config, "setConnectionTimeout", new Class[]{long.class}, 10000L);
      this.invoke(config, "setValidationTimeout", new Class[]{long.class}, 5000L);
      if (settings.type != DatabaseType.SQLITE) {
         this.invoke(config, "setIdleTimeout", new Class[]{long.class}, 60000L);
      }

      this.invoke(config, "setMaxLifetime", new Class[]{long.class}, 1800000L);
      if (settings.type == DatabaseType.SQLITE) {
         File sqliteFile = this.prepareSqliteFile(settings);
         this.invoke(config, "setDriverClassName", new Class[]{String.class}, "org.sqlite.JDBC");
         this.invoke(config, "setJdbcUrl", new Class[]{String.class}, "jdbc:sqlite:" + sqliteFile.getAbsolutePath());
         this.invoke(config, "setConnectionInitSql", new Class[]{String.class}, "PRAGMA foreign_keys=ON");
      } else {
         this.invoke(config, "setDriverClassName", new Class[]{String.class}, "com.mysql.cj.jdbc.Driver");
         this.invoke(config, "setJdbcUrl", new Class[]{String.class}, this.createMySqlUrl(settings));
         this.invoke(config, "setUsername", new Class[]{String.class}, settings.username);
         this.invoke(config, "setPassword", new Class[]{String.class}, settings.password);
         this.invoke(config, "addDataSourceProperty", new Class[]{String.class, String.class}, "cachePrepStmts", "true");
         this.invoke(config, "addDataSourceProperty", new Class[]{String.class, String.class}, "prepStmtCacheSize", "250");
         this.invoke(config, "addDataSourceProperty", new Class[]{String.class, String.class}, "prepStmtCacheSqlLimit", "2048");
         this.invoke(config, "addDataSourceProperty", new Class[]{String.class, String.class}, "rewriteBatchedStatements", "true");
      }

      Class<?> dataSourceClass = Class.forName("com.zaxxer.hikari.HikariDataSource");
      return (DataSource)dataSourceClass.getConstructor(configClass).newInstance(config);
   }

   @Override
   protected Object invoke(Object target, String method, Class<?>[] types, Object... args) throws ReflectiveOperationException {
      return target.getClass().getMethod(method, types).invoke(target, args);
   }

   @Override
   protected DataSource createDriverManagerDataSource(DatabaseSettings settings) throws IOException, ClassNotFoundException {
      if (settings.type == DatabaseType.SQLITE) {
         File sqliteFile = this.prepareSqliteFile(settings);
         Class.forName("org.sqlite.JDBC");
         return new DriverManagerDataSource("jdbc:sqlite:" + sqliteFile.getAbsolutePath(), null, null, "PRAGMA busy_timeout=5000;PRAGMA foreign_keys=ON");
      } else {
         Class.forName("com.mysql.cj.jdbc.Driver");
         return new DriverManagerDataSource(this.createMySqlUrl(settings), settings.username, settings.password, null);
      }
   }

   @Override
   protected File prepareSqliteFile(DatabaseSettings settings) throws IOException {
      File sqliteFile = settings.sqliteFile;
      File legacyFile = new File(this.getDataFolder(), "quests.db");
      if (!sqliteFile.exists() && legacyFile.exists() && !legacyFile.equals(sqliteFile)) {
         Files.copy(legacyFile.toPath(), sqliteFile.toPath(), StandardCopyOption.COPY_ATTRIBUTES);
      }

      return sqliteFile;
   }

   @Override
   protected String createMySqlUrl(DatabaseSettings settings) {
      return "jdbc:mysql://"
         + settings.host
         + ":"
         + settings.port
         + "/"
         + settings.playerDatabase
         + "?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=UTC&createDatabaseIfNotExist=true";
   }

   @Override
   protected void initializeSchema(Connection connection) throws SQLException {
      try (Statement st = connection.createStatement()) {
         if (this.databaseSettings.type == DatabaseType.SQLITE) {
            st.execute("PRAGMA busy_timeout=5000");
            st.execute("PRAGMA journal_mode=WAL");
            st.execute("PRAGMA synchronous=NORMAL");
            st.execute("PRAGMA foreign_keys=ON");
         }

         String[] schema = this.sqlDialect.schemaSql();

         for (int i = 0; i < schema.length; i++) {
            this.executeSchemaStatement(st, schema[i]);
         }
      }
   }

   @Override
   protected void executeSchemaStatement(Statement st, String sql) throws SQLException {
      try {
         st.execute(sql);
      } catch (SQLException e) {
         String message = e.getMessage();
         if (message == null || !message.contains("Duplicate key name") && !message.contains("already exists")) {
            throw e;
         }
      }
   }

   @Override
   protected void loadPlayersFromDatabase() throws SQLException {
      try (Connection connection = this.dataSource.getConnection()) {
         if (this.databaseSettings.type == DatabaseType.SQLITE) {
            this.enableSqliteForeignKeys(connection);
         }

         try (
            PreparedStatement st = connection.prepareStatement("SELECT uuid, name, updated_at FROM players");
            ResultSet rs = st.executeQuery();
         ) {
            while (rs.next()) {
               UUID uuid = this.parseUuid(rs.getString("uuid"));
               if (uuid != null) {
                  PlayerData pd = new PlayerData();
                  pd.playerName = rs.getString("name");
                  pd.updatedAt = rs.getLong("updated_at");
                  pd.modified = false;
                  this.cache.put(uuid, pd);
               }
            }
         }

         try (
            PreparedStatement st = connection.prepareStatement(
               "SELECT uuid, category, stage, progress, legacy_skips, completed, skipped, rewards_received FROM quest_progress"
            );
            ResultSet rs = st.executeQuery();
         ) {
            while (rs.next()) {
               UUID uuid = this.parseUuid(rs.getString("uuid"));
               String category = rs.getString("category");
               if (uuid != null && CATEGORY_SET.contains(category)) {
                  PlayerData pd = this.cache.computeIfAbsent(uuid, k -> new PlayerData());
                  pd.stages.put(category, Math.max(1, rs.getInt("stage")));
                  pd.progress.put(category, Math.max(0, rs.getInt("progress")));
                  pd.skips.put(category, Math.max(0, rs.getInt("legacy_skips")));
                  this.putPositiveCounter(pd.completed, category, rs.getInt("completed"));
                  this.putPositiveCounter(pd.skipped, category, rs.getInt("skipped"));
                  this.putPositiveCounter(pd.rewardClaims, category, rs.getInt("rewards_received"));
                  pd.modified = false;
               }
            }
         }

         this.loadStageSetFromDatabase(connection, "completed_stages");
         this.loadStageSetFromDatabase(connection, "skipped_stages");
         this.loadStageSetFromDatabase(connection, "claimed_rewards");
         this.loadPurchasesFromDatabase(connection);
      }

      for (PlayerData pd : this.cache.values()) {
         pd.modified = false;
      }
   }

   @Override
   protected void enableSqliteForeignKeys(Connection connection) throws SQLException {
      try (Statement st = connection.createStatement()) {
         st.execute("PRAGMA busy_timeout=5000");
         st.execute("PRAGMA foreign_keys=ON");
      }
   }

   @Override
   protected void loadStageSetFromDatabase(Connection connection, String table) throws SQLException {
      try (
         PreparedStatement st = connection.prepareStatement("SELECT uuid, category, stage FROM " + table);
         ResultSet rs = st.executeQuery();
      ) {
         while (rs.next()) {
            UUID uuid = this.parseUuid(rs.getString("uuid"));
            String category = rs.getString("category");
            int stage = rs.getInt("stage");
            if (uuid != null && stage > 0 && CATEGORY_SET.contains(category)) {
               PlayerData pd = this.cache.computeIfAbsent(uuid, k -> new PlayerData());
               Map<String, Set<Integer>> target = this.getStageSetMapByTable(pd, table);
               if (target != null) {
                  this.getStageIdSet(target, category).add(stage);
               }
            }
         }
      }
   }

   @Override
   protected void loadPurchasesFromDatabase(Connection connection) throws SQLException {
      try (
         PreparedStatement st = connection.prepareStatement("SELECT uuid, category, item_id, amount FROM purchases");
         ResultSet rs = st.executeQuery();
      ) {
         while (rs.next()) {
            UUID uuid = this.parseUuid(rs.getString("uuid"));
            String category = rs.getString("category");
            String itemId = rs.getString("item_id");
            int amount = rs.getInt("amount");
            if (uuid != null && itemId != null && !itemId.isEmpty() && amount > 0 && CATEGORY_SET.contains(category)) {
               PlayerData pd = this.cache.computeIfAbsent(uuid, k -> new PlayerData());
               pd.purchases.put(category + ":" + itemId, amount);
            }
         }
      }
   }

   @Override
   protected UUID parseUuid(String value) {
      if (value != null && !value.isEmpty()) {
         try {
            return UUID.fromString(value);
         } catch (IllegalArgumentException ignored) {
            return null;
         }
      } else {
         return null;
      }
   }

   @Override
   protected void putPositiveCounter(Map<String, Integer> target, String category, int value) {
      if (value > 0) {
         target.put(category, value);
      }
   }

   @Override
   protected Map<String, Set<Integer>> getStageSetMapByTable(PlayerData pd, String table) {
      switch (table) {
         case "completed_stages":
            return pd.completedStages;
         case "skipped_stages":
            return pd.skippedStages;
         case "claimed_rewards":
            return pd.claimedRewards;
         default:
            return null;
      }
   }
}
