package cs.cloudstudio.manager;

import cs.cloudstudio.manager.model.ActionType;
import cs.cloudstudio.manager.model.Stage;
import cs.cloudstudio.util.ColorUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public abstract class MessageModule extends DatabaseAdminModule {
   @Override
   protected Map<String, String> createBasePlaceholders(OfflinePlayer p, String category) {
      return this.createBasePlaceholders(p, p != null ? p.getName() : "", category);
   }

   @Override
   protected Map<String, String> createBasePlaceholders(OfflinePlayer p, String playerNameFallback, String category) {
      Map<String, String> ph = new HashMap<>(16);
      String playerName = p != null && p.getName() != null ? p.getName() : (playerNameFallback != null ? playerNameFallback : "");
      ph.put("%player%", playerName);
      ph.put("{player}", playerName);
      ph.put("<player>", playerName);
      String cat = category != null ? category : "";
      ph.put("%category%", cat);
      ph.put("{category}", cat);
      ph.put("<category>", cat);
      return ph;
   }

   @Override
   protected String formatMenuTitle(Player p, String rawTitle, String category) {
      return this.applyDynamicPlaceholders(p, rawTitle, this.createBasePlaceholders(p, category));
   }

   @Override
   protected String applyDynamicPlaceholders(OfflinePlayer p, String text, Map<String, String> ph) {
      String result = this.applyPlaceholders(text, ph);
      if (this.placeholderApiEnabled && p != null && result.indexOf(37) >= 0) {
         result = PlaceholderAPI.setPlaceholders(p, result);
      }

      return result;
   }

   @Override
   protected String prepareCommand(OfflinePlayer p, String playerNameFallback, String category, String command, Stage stage) {
      Map<String, String> ph = this.createBasePlaceholders(p, playerNameFallback, category);
      if (stage != null) {
         String idStr = Integer.toString(stage.id);
         ph.put("%quest_id%", idStr);
         ph.put("<quest_id>", idStr);
         String title = stage.itemName != null ? stage.itemName : "";
         ph.put("%quest_title%", title);
         ph.put("<quest_title>", title);
      }

      return this.applyDynamicPlaceholders(p, command, ph).trim();
   }

   @Override
   protected boolean dispatchRewardCommands(OfflinePlayer target, String name, String category, Stage stage) {
      return stage != null && stage.rewardCommands != null && !stage.rewardCommands.isEmpty()
         ? this.dispatchConfiguredCommands(target, name, category, stage.rewardCommands, stage)
         : false;
   }

   @Override
   protected boolean dispatchConfiguredCommands(OfflinePlayer target, String name, String category, List<String> commands, Stage stage) {
      if (commands != null && !commands.isEmpty()) {
         int i = 0;

         for (int n = commands.size(); i < n; i++) {
            if (!this.dispatchConfiguredCommand(this.prepareCommand(target, name, category, commands.get(i), stage))) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   @Override
   protected boolean areConfiguredCommandsResolvable(OfflinePlayer target, String name, String category, List<String> commands, Stage stage) {
      if (commands != null && !commands.isEmpty()) {
         int i = 0;

         for (int n = commands.size(); i < n; i++) {
            if (!this.isConsoleCommandResolvable(this.prepareCommand(target, name, category, commands.get(i), stage))) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   @Override
   protected boolean dispatchConfiguredCommand(String command) {
      String c = this.normalizeConsoleCommand(command);
      return !c.isEmpty() && Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c);
   }

   @Override
   protected boolean isConsoleCommandResolvable(String command) {
      String c = this.normalizeConsoleCommand(command);
      if (c.isEmpty()) {
         return false;
      }

      if (this.commandMap == null) {
         return true;
      }

      int end = c.indexOf(32);
      String root = end >= 0 ? c.substring(0, end) : c;
      return this.commandMap.getCommand(root.toLowerCase(Locale.ROOT)) != null;
   }

   @Override
   protected String normalizeConsoleCommand(String command) {
      if (command == null) {
         return "";
      }

      String c = command.trim();
      int start = 0;

      while (start < c.length() && c.charAt(start) == '/') {
         start++;
      }

      return start > 0 ? c.substring(start).trim() : c;
   }

   @Override
   protected List<String> getMsgLines(String key, Map<String, String> ph) {
      List<String> raw = this.msgCache.get(key);
      if (raw == null) {
         raw = this.colorList(this.getConfig().getStringList("messages." + key));
         if (raw.isEmpty() && "quest_not_completed_no_skips_description".equals(key)) {
            raw = this.colorList(
               Arrays.asList(
                  "",
                  "&7Для выполнения данного квеста",
                  "&7Вам нужно <quest_type>:",
                  "&6<quest_target>",
                  "",
                  "&7Прогресс: &6<quest_progress>&7/&6<quest_requirement>",
                  "&7Статус: &cНе выполнено",
                  "",
                  "&7Вы можете пропустить квест с помощью &6RW+",
                  "&cВы больше не можете пропустить квест"
               )
            );
         }

         raw = this.restoreLegacyBoxMessageIfNeeded(key, raw);
         this.msgCache.put(key, raw);
      }

      List<String> result = new ArrayList<>(raw.size());
      int i = 0;

      for (int n = raw.size(); i < n; i++) {
         result.add(this.applyPlaceholders(raw.get(i), ph));
      }

      return result;
   }

   @Override
   protected List<String> restoreLegacyBoxMessageIfNeeded(String key, List<String> raw) {
      if ("ready_to_complete".equals(key)) {
         if (raw == null || raw.isEmpty() || raw.size() == 1 && raw.get(0).contains("Задание выполнено, следующий квест разблокирован")) {
            return this.colorList(Arrays.asList("&6&l┎", "&6&l┃ &lЗАДАНИЕ ВЫПОЛНЕНО", "&6&l┃ &fСледующее задание разблокировано.", "&6&l┖"));
         }
      } else if ("quest_skipped".equals(key)
         && (raw == null || raw.isEmpty() || raw.size() == 1 && raw.get(0).contains("Квест пропущен, следующий квест разблокирован"))) {
         return this.colorList(Arrays.asList("&6&l┏", "&6&l┃ &lЗАДАНИЕ ПРОПУЩЕНО", "&6&l┃ &fСледующее задание разблокировано.", "&6&l┖"));
      }

      return raw != null ? raw : Collections.emptyList();
   }

   @Override
   protected void sendMsg(Player p, String key) {
      this.sendMsg(p, key, null);
   }

   @Override
   protected void sendMsg(Player p, String key, String category) {
      Map<String, String> ph = category != null ? this.createBasePlaceholders(p, category) : null;
      List<String> lines = this.getMsgLines(key, ph);
      int i = 0;

      for (int n = lines.size(); i < n; i++) {
         String line = lines.get(i);
         if (!line.isEmpty()) {
            p.sendMessage(line);
         }
      }
   }

   @Override
   protected String applyPlaceholders(String text, Map<String, String> ph) {
      if (text == null) {
         return "";
      }

      if (ph == null) {
         return text;
      }

      for (Entry<String, String> e : ph.entrySet()) {
         String v = e.getValue();
         if (v != null) {
            text = text.replace(e.getKey(), v);
         }
      }

      return text;
   }

   protected String getActionName(ActionType action) {
      ActionType resolved = action == null ? ActionType.BRING : action;
      String value = this.getConfig().getString("action-names." + resolved.name());
      if (value != null && !value.trim().isEmpty()) {
         return value;
      }

      switch (resolved) {
         case BREAK:
            return "сломать";
         case CRAFT:
            return "скрафтить";
         case KILL:
            return "убить";
         case BRING:
         default:
            return "принести";
      }
   }

   protected void sendMessageLine(CommandSender sender, String key, String fallback) {
      String value = this.getConfig().getString("messages." + key);
      if (value == null || value.trim().isEmpty()) {
         List<String> lines = this.getConfig().getStringList("messages." + key);
         value = lines != null && !lines.isEmpty() ? lines.get(0) : fallback;
      }

      sender.sendMessage(this.color(value));
   }

   protected void sendMessageList(CommandSender sender, String key, List<String> fallback) {
      List<String> lines = this.getConfig().getStringList("messages." + key);
      if (lines == null || lines.isEmpty()) {
         lines = fallback;
      }

      for (String line : lines) {
         if (line != null && !line.isEmpty()) {
            sender.sendMessage(this.color(line));
         }
      }
   }

   @Override
   protected String color(String text) {
      return ColorUtil.color(text);
   }
}
