package cs.cloudstudio.manager;

import cs.cloudstudio.manager.model.ActionType;
import cs.cloudstudio.manager.model.QuestTemplate;
import cs.cloudstudio.util.ItemNameTranslator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;

public abstract class GeneratorTemplateModule extends ProgressModule {
   @Override
   protected List<QuestTemplate> buildGeneratorTemplates(String category) {
      List<QuestTemplate> templates = new ArrayList<>();
      this.addDefaultGeneratorTemplates(templates);
      this.addCustomGeneratorTemplates(templates, category);

      for (int i = templates.size() - 1; i >= 0; i--) {
         QuestTemplate template = templates.get(i);
         if (!template.supports(category)
            || template.material == null
            || template.material == Material.AIR
            || template.action == ActionType.CRAFT && !this.isCraftQuestMaterialSupported(template.material)
            || template.action == ActionType.KILL && !this.isKillQuestEntitySupported(template.entity)
            || this.getSafeQuestAmountLimit(category, template.action, template.material, template.entity) <= 0) {
            templates.remove(i);
         }
      }

      if (templates.isEmpty()) {
         templates.add(new QuestTemplate(new String[]{category}, ActionType.BRING, Material.STONE, null, null, null, 64, "Камень", 1.0));
      }

      return templates;
   }

   @Override
   protected void addDefaultGeneratorTemplates(List<QuestTemplate> templates) {
      this.addTaskTemplate(templates, "easy,medium,hard,wood", ActionType.BREAK, "OAK_LOG", null, 64, "Дубовые Брёвна", 1.0);
      this.addTaskTemplate(templates, "easy,medium,hard,wood", ActionType.BREAK, "BIRCH_LOG", null, 64, "Берёзовые Брёвна", 1.0);
      this.addTaskTemplate(templates, "easy,medium,hard,wood", ActionType.BREAK, "SPRUCE_LOG", null, 64, "Еловые Брёвна", 1.0);
      this.addTaskTemplate(templates, "easy,medium,hard,wood", ActionType.BREAK, "DARK_OAK_LOG", null, 64, "Тёмно-дубовые Брёвна", 1.0);
      this.addTaskTemplate(templates, "medium,hard,wood", ActionType.BREAK, "JUNGLE_LOG", null, 96, "Тропические Брёвна", 1.1);
      this.addTaskTemplate(templates, "medium,hard,wood", ActionType.BREAK, "ACACIA_LOG", null, 96, "Акациевые Брёвна", 1.1);
      this.addTaskTemplate(templates, "medium,hard,wood", ActionType.BREAK, "CRIMSON_STEM", null, 64, "Багровые Стебли", 1.4);
      this.addTaskTemplate(templates, "medium,hard,wood", ActionType.BREAK, "WARPED_STEM", null, 64, "Искажённые Стебли", 1.4);
      this.addTaskTemplate(templates, "easy,medium,hard,wood", ActionType.BRING, "OAK_PLANKS", null, 128, "Дубовые Доски", 0.8);
      this.addTaskTemplate(templates, "easy,medium,hard,wood", ActionType.CRAFT, "STICK", null, 128, "Палки", 0.7);
      this.addTaskTemplate(templates, "easy,medium,hard,wood", ActionType.CRAFT, "CHEST", null, 16, "Сундуки", 1.1);
      this.addTaskTemplate(templates, "easy,medium,hard,wood", ActionType.CRAFT, "CRAFTING_TABLE", null, 16, "Верстаки", 0.8);
      this.addTaskTemplate(templates, "medium,hard,wood", ActionType.CRAFT, "BARREL", null, 16, "Бочки", 1.2);
      this.addTaskTemplate(templates, "easy,medium,hard,wood", ActionType.BRING, "APPLE", null, 16, "Яблоки", 2.0);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BREAK, "COBBLESTONE", null, 256, "Булыжник", 1.0);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BREAK, "STONE", null, 256, "Камень", 1.0);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BREAK, "DIRT", null, 128, "Земля", 0.8);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BREAK, "GRAVEL", null, 128, "Гравий", 0.9);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BREAK, "SAND", null, 128, "Песок", 0.9);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BREAK, "COAL_ORE", null, 32, "Угольная Руда", 2.0);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BREAK, "IRON_ORE", null, 32, "Железная Руда", 2.5);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "GOLD_ORE", null, 24, "Золотая Руда", 3.0);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "REDSTONE_ORE", null, 32, "Редстоуновая Руда", 3.0);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "LAPIS_ORE", null, 24, "Лазуритовая Руда", 3.2);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "DIAMOND_ORE", null, 8, "Алмазная Руда", 6.5);
      this.addTaskTemplate(templates, "hard,mine", ActionType.BREAK, "EMERALD_ORE", null, 6, "Изумрудная Руда", 8.0);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "NETHERRACK", null, 512, "Незерак", 0.8);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "NETHER_QUARTZ_ORE", null, 48, "Кварцевая Руда", 3.2);
      this.addTaskTemplate(templates, "hard,mine", ActionType.BREAK, "ANCIENT_DEBRIS", null, 4, "Древние Обломки", 12.0);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "OBSIDIAN", null, 16, "Обсидиан", 5.0);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BRING, "COBBLESTONE", null, 256, "Булыжник", 1.0);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BRING, "COAL", null, 64, "Уголь", 1.4);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BRING, "IRON_INGOT", null, 32, "Железные Слитки", 2.6);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BRING, "GOLD_INGOT", null, 24, "Золотые Слитки", 3.0);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BRING, "REDSTONE", null, 96, "Редстоун", 1.6);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BRING, "LAPIS_LAZULI", null, 48, "Лазурит", 2.4);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BRING, "DIAMOND", null, 8, "Алмазы", 7.0);
      this.addTaskTemplate(templates, "hard,mine", ActionType.BRING, "EMERALD", null, 8, "Изумруды", 7.5);
      this.addTaskTemplate(templates, "hard,mine", ActionType.BRING, "NETHERITE_SCRAP", null, 4, "Незеритовый Лом", 12.0);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.CRAFT, "FURNACE", null, 16, "Печки", 1.1);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.CRAFT, "IRON_BLOCK", null, 4, "Железные Блоки", 4.0);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.CRAFT, "GOLD_BLOCK", null, 4, "Золотые Блоки", 4.5);
      this.addTaskTemplate(templates, "hard,mine", ActionType.CRAFT, "DIAMOND_BLOCK", null, 1, "Алмазные Блоки", 9.0);
      this.addTaskTemplate(templates, "hard,mine", ActionType.CRAFT, "ANVIL", null, 1, "Наковальни", 8.0);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.BRING, "WHEAT", null, 128, "Пшеница", 0.9);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.BRING, "CARROT", null, 96, "Морковь", 0.9);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.BRING, "POTATO", null, 96, "Картошка", 0.9);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.BRING, "BEETROOT", null, 64, "Свёкла", 1.0);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.BREAK, "WHEAT", null, 128, "Пшеница", 0.8);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.BREAK, "CARROT", null, 96, "Морковь", 0.8);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.BREAK, "POTATO", null, 96, "Картошка", 0.8);
      this.addTaskTemplate(templates, "medium,hard,farm,alch", ActionType.BRING, "NETHER_WART", null, 128, "Незер Нарост", 1.4);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.BRING, "MELON_SLICE", null, 128, "Ломтики Арбуза", 0.8);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.BRING, "PUMPKIN", null, 32, "Тыквы", 1.1);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.BRING, "SUGAR_CANE", null, 128, "Сахарный Тростник", 0.9);
      this.addTaskTemplate(templates, "medium,hard,farm", ActionType.BRING, "BAMBOO", null, 128, "Бамбук", 0.9);
      this.addTaskTemplate(templates, "medium,hard,farm", ActionType.BRING, "CACTUS", null, 64, "Кактусы", 1.2);
      this.addTaskTemplate(templates, "easy,medium,hard,farm", ActionType.CRAFT, "BREAD", null, 32, "Хлеб", 1.1);
      this.addTaskTemplate(templates, "medium,hard,farm", ActionType.CRAFT, "CAKE", null, 2, "Торты", 3.5);
      this.addTaskTemplate(templates, "medium,hard,farm", ActionType.CRAFT, "COOKIE", null, 64, "Печенье", 1.4);
      this.addTaskTemplate(templates, "medium,hard,farm", ActionType.CRAFT, "HAY_BLOCK", null, 16, "Блоки Сена", 1.5);
      this.addTaskTemplate(templates, "medium,hard,farm,alch", ActionType.CRAFT, "GOLDEN_CARROT", null, 16, "Золотая Морковь", 4.0);
      this.addTaskTemplate(templates, "fish", ActionType.BRING, "COD", null, 64, "Треска", 1.0);
      this.addTaskTemplate(templates, "fish", ActionType.BRING, "SALMON", null, 48, "Лосось", 1.1);
      this.addTaskTemplate(templates, "fish", ActionType.BRING, "TROPICAL_FISH", null, 16, "Тропическая Рыба", 2.5);
      this.addTaskTemplate(templates, "fish,alch", ActionType.BRING, "PUFFERFISH", null, 16, "Иглобрюх", 2.3);
      this.addTaskTemplate(templates, "fish", ActionType.BRING, "NAUTILUS_SHELL", null, 2, "Раковины Наутилуса", 7.0);
      this.addTaskTemplate(templates, "fish", ActionType.BRING, "PRISMARINE_SHARD", null, 32, "Призмариновый Осколок", 3.2);
      this.addTaskTemplate(templates, "fish", ActionType.BRING, "PRISMARINE_CRYSTALS", null, 16, "Призмариновые Кристаллы", 3.6);
      this.addTaskTemplate(templates, "fish", ActionType.CRAFT, "FISHING_ROD", null, 4, "Удочки", 1.5);
      this.addTaskTemplate(templates, "fish", ActionType.CRAFT, "SEA_LANTERN", null, 8, "Морские Фонари", 4.0);
      this.addKillTemplate(templates, "fish", "DROWNED", "TRIDENT", 24, "Убить Утопленников", 2.5);
      this.addKillTemplate(templates, "fish", "GUARDIAN", "PRISMARINE_SHARD", 16, "Убить Стражей", 4.0);
      this.addKillTemplate(templates, "fish", "SQUID", "INK_SAC", 24, "Убить Спрутов", 1.4);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "BLAZE_POWDER", null, 32, "Огненный Порошок", 2.5);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "BLAZE_ROD", null, 16, "Огненные Стержни", 3.2);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "SPIDER_EYE", null, 32, "Паучий Глаз", 1.8);
      this.addTaskTemplate(templates, "alch", ActionType.CRAFT, "FERMENTED_SPIDER_EYE", null, 16, "Брожённый Паучий Глаз", 2.5);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "GHAST_TEAR", null, 4, "Слёзы Гаста", 7.0);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "MAGMA_CREAM", null, 16, "Сгустки Магмы", 3.5);
      this.addTaskTemplate(templates, "alch", ActionType.CRAFT, "GLISTERING_MELON_SLICE", null, 16, "Сверкающий Арбуз", 2.8);
      this.addTaskTemplate(templates, "alch", ActionType.CRAFT, "BREWING_STAND", null, 2, "Варочные Стойки", 3.0);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "POTION", null, 16, "Зелья", 2.0);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "SPLASH_POTION", null, 16, "Взрывные Зелья", 2.8);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "LINGERING_POTION", null, 8, "Туманные Зелья", 4.5);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "REDSTONE", null, 64, "Редстоун", 1.2);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "GLOWSTONE_DUST", null, 32, "Светопыль", 2.0);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "GUNPOWDER", null, 32, "Порох", 2.0);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "DRAGON_BREATH", null, 4, "Дыхание Дракона", 8.0);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "RABBIT_FOOT", null, 4, "Кроличья Лапка", 5.5);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "PHANTOM_MEMBRANE", null, 8, "Мембрана Фантома", 4.5);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "SUGAR", null, 64, "Сахар", 1.0);
      this.addTaskTemplate(templates, "alch", ActionType.BRING, "TURTLE_HELMET", null, 1, "Черепашьи Шлемы", 9.0);
      this.addTaskTemplate(templates, "hard,alch", ActionType.BRING, "WITHER_SKELETON_SKULL", null, 1, "Черепа Визер-Скелетов", 12.0);
      this.addTaskTemplate(templates, "hard,alch", ActionType.BRING, "TOTEM_OF_UNDYING", null, 1, "Тотемы Бессмертия", 11.0);
      this.addTaskTemplate(templates, "hard,alch", ActionType.BRING, "NETHER_STAR", null, 1, "Звёзды Незера", 14.0);
      this.addTaskTemplate(templates, "hard,alch", ActionType.CRAFT, "END_CRYSTAL", null, 2, "Кристаллы Энда", 8.0);
      this.addTaskTemplate(templates, "hard,alch", ActionType.CRAFT, "BEACON", null, 1, "Маяки", 14.0);
      this.addTaskTemplate(templates, "easy,medium,hard", ActionType.CRAFT, "TORCH", null, 64, "Факелы", 0.8);
      this.addTaskTemplate(templates, "easy,medium,hard", ActionType.CRAFT, "PAPER", null, 64, "Бумага", 1.0);
      this.addKillTemplate(templates, "easy,medium,hard", "ZOMBIE", "ZOMBIE_HEAD", 24, "Убить Зомби", 1.5);
      this.addKillTemplate(templates, "easy,medium,hard", "SKELETON", "SKELETON_SKULL", 24, "Убить Скелетов", 1.7);
      this.addKillTemplate(templates, "easy,medium,hard", "SPIDER", "SPIDER_EYE", 20, "Убить Пауков", 1.5);
      this.addKillTemplate(templates, "easy,medium,hard", "CREEPER", "CREEPER_HEAD", 12, "Убить Криперов", 2.5);
      this.addKillTemplate(templates, "medium,hard", "ENDERMAN", "ENDER_PEARL", 12, "Убить Эндерменов", 3.8);
      this.addKillTemplate(templates, "medium,hard,alch", "BLAZE", "BLAZE_ROD", 16, "Убить Ифритов", 3.5);
      this.addKillTemplate(templates, "hard,alch", "WITHER_SKELETON", "WITHER_SKELETON_SKULL", 8, "Убить Визер-Скелетов", 7.0);
      this.addKillTemplate(templates, "medium,hard", "SLIME", "SLIME_BALL", 16, "Убить Слаймов", 2.8);
      this.addKillTemplate(templates, "medium,hard", "PHANTOM", "PHANTOM_MEMBRANE", 8, "Убить Фантомов", 4.5);
      this.addKillTemplate(templates, "hard", "PIGLIN", "GOLD_INGOT", 16, "Убить Пиглинов", 4.5);
      this.addKillTemplate(templates, "hard", "HOGLIN", "PORKCHOP", 12, "Убить Хоглинов", 4.5);
      this.addModernContentTemplates(templates);
   }

   protected void addModernContentTemplates(List<QuestTemplate> templates) {
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BRING, "RAW_COPPER", null, 96, "Сырая Медь", 1.5);
      this.addTaskTemplate(templates, "easy,medium,hard,mine", ActionType.BRING, "RAW_IRON", null, 64, "Сырое Железо", 2.2);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BRING, "RAW_GOLD", null, 48, "Сырое Золото", 2.8);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BRING, "AMETHYST_SHARD", null, 32, "Аметистовые Осколки", 3.4);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "DEEPSLATE", null, 256, "Глубинный Сланец", 1.2);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "TUFF", null, 128, "Туф", 1.3);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "CALCITE", null, 64, "Кальцит", 2.0);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.BREAK, "DRIPSTONE_BLOCK", null, 64, "Капельник", 1.8);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.CRAFT, "COPPER_BLOCK", null, 16, "Медные Блоки", 3.0);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.CRAFT, "SPYGLASS", null, 4, "Подзорные Трубы", 3.6);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.CRAFT, "LIGHTNING_ROD", null, 8, "Громоотводы", 3.0);
      this.addTaskTemplate(templates, "medium,hard,farm", ActionType.BRING, "GLOW_BERRIES", null, 64, "Светящиеся Ягоды", 1.6);
      this.addTaskTemplate(templates, "medium,hard,farm", ActionType.BRING, "MOSS_BLOCK", null, 64, "Блоки Мха", 1.8);
      this.addTaskTemplate(templates, "fish", ActionType.BRING, "GLOW_INK_SAC", null, 32, "Светящиеся Мешочки", 3.0);
      this.addKillTemplate(templates, "fish", "GLOW_SQUID", "GLOW_INK_SAC", 24, "Убить Светящихся Спрутов", 2.2);
      this.addKillTemplate(templates, "medium,hard", "GOAT", "MUTTON", 12, "Убить Коз", 3.0);
      this.addTaskTemplate(templates, "hard,mine", ActionType.BREAK, "SCULK", null, 64, "Скальк", 4.5);
      this.addTaskTemplate(templates, "hard,mine", ActionType.BRING, "ECHO_SHARD", null, 8, "Осколки Эха", 9.0);
      this.addTaskTemplate(templates, "hard,mine", ActionType.CRAFT, "RECOVERY_COMPASS", null, 1, "Компас Возвращения", 12.0);
      this.addTaskTemplate(templates, "medium,hard,wood", ActionType.BREAK, "MANGROVE_LOG", null, 128, "Мангровые Брёвна", 1.4);
      this.addTaskTemplate(templates, "medium,hard,farm", ActionType.BRING, "MUD", null, 64, "Грязь", 1.2);
      this.addTaskTemplate(templates, "medium,hard", ActionType.CRAFT, "MUD_BRICKS", null, 64, "Грязевые Кирпичи", 1.6);
      this.addTaskTemplate(templates, "hard", ActionType.BRING, "OCHRE_FROGLIGHT", null, 8, "Охряный Лягушкосвет", 6.0);
      this.addKillTemplate(templates, "medium,hard", "FROG", "SLIME_BALL", 12, "Убить Лягушек", 2.4);
      this.addTaskTemplate(templates, "medium,hard,wood", ActionType.BREAK, "CHERRY_LOG", null, 128, "Вишнёвые Брёвна", 1.5);
      this.addTaskTemplate(templates, "medium,hard,wood", ActionType.CRAFT, "BAMBOO_PLANKS", null, 128, "Бамбуковые Доски", 1.3);
      this.addTaskTemplate(templates, "medium,hard,wood", ActionType.CRAFT, "BAMBOO_BLOCK", null, 32, "Бамбуковые Блоки", 1.6);
      this.addTaskTemplate(templates, "medium,hard", ActionType.CRAFT, "BRUSH", null, 4, "Кисточки", 3.2);
      this.addTaskTemplate(templates, "hard,farm", ActionType.BRING, "TORCHFLOWER", null, 8, "Факельник", 7.0);
      this.addKillTemplate(templates, "medium,hard", "CAMEL", "LEATHER", 6, "Убить Верблюдов", 3.6);
      this.addTaskTemplate(templates, "medium,hard", ActionType.BRING, "ARMADILLO_SCUTE", null, 16, "Щитки Броненосца", 3.8);
      this.addTaskTemplate(templates, "hard", ActionType.CRAFT, "WOLF_ARMOR", null, 2, "Броня для Волка", 6.5);
      this.addTaskTemplate(templates, "hard", ActionType.BRING, "WIND_CHARGE", null, 32, "Заряды Ветра", 5.0);
      this.addTaskTemplate(templates, "hard", ActionType.BRING, "HEAVY_CORE", null, 1, "Тяжёлое Ядро", 14.0);
      this.addTaskTemplate(templates, "hard", ActionType.BRING, "TRIAL_KEY", null, 4, "Ключи Испытаний", 8.0);
      this.addTaskTemplate(templates, "medium,hard", ActionType.CRAFT, "CRAFTER", null, 4, "Автоверстаки", 4.5);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.CRAFT, "COPPER_BULB", null, 16, "Медные Лампы", 3.2);
      this.addTaskTemplate(templates, "medium,hard,mine", ActionType.CRAFT, "TUFF_BRICKS", null, 64, "Туфовые Кирпичи", 1.7);
      this.addKillTemplate(templates, "hard", "BREEZE", "WIND_CHARGE", 8, "Убить Вихрей", 7.5);
      this.addKillTemplate(templates, "hard", "BOGGED", "ARROW", 16, "Убить Трясинников", 4.0);
      this.addKillTemplate(templates, "medium,hard", "ARMADILLO", "ARMADILLO_SCUTE", 12, "Убить Броненосцев", 3.0);
      this.addTaskTemplate(templates, "medium,hard,wood", ActionType.BREAK, "PALE_OAK_LOG", null, 96, "Бледный Дуб", 2.2);
      this.addTaskTemplate(templates, "hard,wood", ActionType.BRING, "RESIN_CLUMP", null, 32, "Комки Смолы", 4.5);
      this.addTaskTemplate(templates, "hard,wood", ActionType.CRAFT, "RESIN_BRICK", null, 32, "Смоляные Кирпичи", 4.0);
      this.addKillTemplate(templates, "hard", "CREAKING", "RESIN_CLUMP", 6, "Убить Скрипунов", 8.0);
   }

   @Override
   protected void addCustomGeneratorTemplates(List<QuestTemplate> templates, String category) {
      ConfigurationSection section = this.getCategoryQuestsConfig(category).getConfigurationSection("generator.custom-pool");
      if (section == null) {
         section = this.getQuestsConfig().getConfigurationSection("generator.custom-pool");
      }

      if (section != null) {
         for (String key : section.getKeys(false)) {
            ConfigurationSection q = section.getConfigurationSection(key);
            if (q != null) {
               String actionRaw = q.getString("action", "BRING").toUpperCase(Locale.ROOT);

               ActionType action;
               try {
                  action = ActionType.valueOf(actionRaw);
               } catch (IllegalArgumentException ignored) {
                  continue;
               }

               String categoriesRaw;
               if (q.isList("categories")) {
                  categoriesRaw = this.joinStrings(q.getStringList("categories"));
               } else {
                  categoriesRaw = q.getString("categories", q.getString("category", "easy,medium,hard"));
               }

               String materialName = q.getString("material", "STONE");
               String name = q.getString("name", ItemNameTranslator.of(Material.matchMaterial(materialName)));
               int amount = Math.max(1, q.getInt("base-amount", q.getInt("amount", 64)));
               double difficulty = Math.max(0.1, q.getDouble("difficulty", 1.0));
               if (action == ActionType.KILL) {
                  this.addKillTemplate(templates, categoriesRaw, q.getString("entity", "ZOMBIE"), materialName, amount, name, difficulty);
               } else {
                  this.addTaskTemplate(templates, categoriesRaw, action, materialName, q.getString("weapon", null), amount, name, difficulty);
               }
            }
         }
      }
   }

   protected static boolean isGlassMaterial(Material material) {
      if (material == null) {
         return false;
      }

      String name = material.name();
      return name.equals("SPYGLASS") ? false : name.contains("GLASS");
   }

   @Override
   protected void addTaskTemplate(
      List<QuestTemplate> templates,
      String categories,
      ActionType action,
      String materialName,
      String weaponName,
      int baseAmount,
      String name,
      double difficulty
   ) {
      Material material = Material.matchMaterial(materialName);
      if (material != null && material != Material.AIR) {
         if (!isGlassMaterial(material)) {
            Material weapon = weaponName != null && !weaponName.trim().isEmpty() ? Material.matchMaterial(weaponName) : null;
            action = this.resolveObtainAction(action, material);
            if (action != ActionType.CRAFT || this.isCraftQuestMaterialSupported(material)) {
               templates.add(new QuestTemplate(this.splitCategories(categories), action, material, null, weapon, material, baseAmount, name, difficulty));
            }
         }
      }
   }

   @Override
   protected void addKillTemplate(
      List<QuestTemplate> templates, String categories, String entityName, String materialName, int baseAmount, String name, double difficulty
   ) {
      EntityType entity;
      try {
         entity = EntityType.valueOf(entityName.toUpperCase(Locale.ROOT));
      } catch (IllegalArgumentException ignored) {
         return;
      }

      if (this.isKillQuestEntitySupported(entity)) {
         Material material = Material.matchMaterial(materialName);
         if (material == null || material == Material.AIR) {
            material = Material.STONE;
         }

         templates.add(new QuestTemplate(this.splitCategories(categories), ActionType.KILL, material, entity, null, material, baseAmount, name, difficulty));
      }
   }

   @Override
   protected QuestTemplate selectQuestTemplate(List<QuestTemplate> templates, Set<String> rowTargets, String category, int row, int col, int totalRows) {
      List<QuestTemplate> shuffled = new ArrayList<>(templates);
      Collections.shuffle(shuffled, ThreadLocalRandom.current());
      double min = this.getRowMinScore(category, row, totalRows);
      double max = this.getRowMaxScore(category, row, totalRows);
      QuestTemplate fallback = null;
      QuestTemplate softFallback = null;
      double bestDistance = Double.MAX_VALUE;
      double bestSoftDistance = Double.MAX_VALUE;
      int i = 0;

      for (int n = shuffled.size(); i < n; i++) {
         QuestTemplate template = shuffled.get(i);
         boolean repeatedInRow = rowTargets != null && rowTargets.contains(template.uniqueKey());
         int amount = this.calculateGeneratedAmount(category, template, row, col, totalRows);
         double score = this.estimateQuestDifficulty(template, amount);
         double distance = score < min ? min - score : (score > max ? score - max : 0.0);
         if (!repeatedInRow && distance < bestDistance) {
            fallback = template;
            bestDistance = distance;
         }

         if (distance < bestSoftDistance) {
            softFallback = template;
            bestSoftDistance = distance;
         }

         if (!repeatedInRow && score >= min && score <= max) {
            return template;
         }
      }

      if (fallback != null) {
         return fallback;
      } else {
         return softFallback != null ? softFallback : shuffled.get(0);
      }
   }

   @Override
   protected int calculateGeneratedAmount(String category, QuestTemplate template, int row, int col, int totalRows) {
      double multiplier = this.getGeneratorAmountMultiplier(category);
      double rowFactor = totalRows <= 1 ? 1.0 : 0.42 + 1.58 * Math.max(0, row) / Math.max(1, totalRows - 1);
      double columnFactor = 0.92 + 0.16 * Math.max(0, col) / 7.0;
      int amount = this.roundQuestAmount((int)Math.ceil(template.baseAmount * multiplier * rowFactor * columnFactor));
      return this.clampQuestAmount(category, template, this.fitQuestAmountToDifficulty(category, template, amount, row, totalRows));
   }

   @Override
   protected int fitQuestAmountToDifficulty(String category, QuestTemplate template, int amount, int row, int totalRows) {
      double min = this.getRowMinScore(category, row, totalRows);
      double max = this.getRowMaxScore(category, row, totalRows);
      amount = this.clampQuestAmount(category, template, amount);

      for (int i = 0; i < 10; i++) {
         double score = this.estimateQuestDifficulty(template, amount);
         if (score > max && amount > 1) {
            int next = this.roundQuestAmount((int)Math.floor(amount * Math.max(0.15, max / Math.max(score, 0.01))));
            if (next >= amount) {
               next = amount - 1;
            }

            amount = this.clampQuestAmount(category, template, next);
         } else {
            if (!(score < min)) {
               break;
            }

            int next = this.roundQuestAmount((int)Math.ceil(amount * Math.min(4.0, min / Math.max(score, 0.01))));
            if (next <= amount) {
               next = amount + 1;
            }

            int clamped = this.clampQuestAmount(category, template, next);
            if (clamped == amount) {
               break;
            }

            amount = clamped;
         }
      }

      return this.clampQuestAmount(category, template, amount);
   }

   protected int clampQuestAmount(String category, QuestTemplate template, int amount) {
      int limit = this.getSafeQuestAmountLimit(category, template.action, template.material, template.entity);
      return limit <= 0 ? 1 : Math.max(1, Math.min(limit, amount));
   }

   @Override
   protected int clampQuestAmount(int amount) {
      return Math.max(1, Math.min(this.getGeneratorMaxAmount(), amount));
   }

   @Override
   protected int getGeneratorMaxAmount() {
      int configured = 3000;

      for (String cat : CATEGORIES) {
         configured = Math.min(configured, this.getCategoryQuestsConfig(cat).getInt("settings.max-amount-per-task", configured));
      }

      configured = this.getQuestsConfig().getInt("settings.max-amount-per-task", configured);
      return Math.max(1, Math.min(3000, configured));
   }

   @Override
   protected int getGeneratorMaxAmount(String category) {
      int configured = this.getCategoryQuestsConfig(category)
         .getInt("settings.max-amount-per-task", this.getQuestsConfig().getInt("settings.max-amount-per-task", 3000));
      return Math.max(1, Math.min(3000, configured));
   }

   @Override
   protected int roundQuestAmount(int amount) {
      if (amount <= 16) {
         return Math.max(1, amount);
      }

      int step;
      if (amount <= 128) {
         step = 8;
      } else if (amount <= 512) {
         step = 16;
      } else if (amount <= 2048) {
         step = 64;
      } else {
         step = 128;
      }

      return Math.max(1, (amount + step - 1) / step * step);
   }

   @Override
   protected double estimateQuestDifficulty(QuestTemplate template, int amount) {
      double base = template.difficulty;

      return base * switch (template.action) {
         case BREAK -> 0.85;
         case CRAFT -> 1.25;
         case KILL -> 1.5;
         default -> 1.0;
      } * Math.max(1.0, amount / 64.0);
   }

   @Override
   protected int getGeneratorTotalRows() {
      int menuRows = this.getConfig().getInt("settings.menu_rows", 6);
      if (menuRows < 1) {
         menuRows = 1;
      }

      if (menuRows > 6) {
         menuRows = 6;
      }

      int rows = menuRows;

      for (String cat : CATEGORIES) {
         rows = Math.min(rows, this.getGeneratorTotalRows(cat));
      }

      if (rows < 1) {
         rows = 1;
      }

      if (rows > menuRows) {
         rows = menuRows;
      }

      if (rows > 6) {
         rows = 6;
      }

      return rows;
   }

   @Override
   protected int getGeneratorTotalRows(String category) {
      int menuRows = this.getConfig().getInt("settings.menu_rows", 6);
      if (menuRows < 1) {
         menuRows = 1;
      }

      if (menuRows > 6) {
         menuRows = 6;
      }

      FileConfiguration catCfg = this.getCategoryQuestsConfig(category);
      int rows = catCfg.getInt("settings.rows", this.getQuestsConfig().getInt("settings.rows", this.getQuestsConfig().getInt("settings.menu-rows", menuRows)));
      if (rows < 1) {
         rows = 1;
      }

      if (rows > menuRows) {
         rows = menuRows;
      }

      if (rows > 6) {
         rows = 6;
      }

      return rows;
   }

   @Override
   protected int getGeneratorTotalRowsForConfig(FileConfiguration cfg, String category) {
      int menuRows = this.getConfig().getInt("settings.menu_rows", 6);
      if (menuRows < 1) {
         menuRows = 1;
      }

      if (menuRows > 6) {
         menuRows = 6;
      }

      int rows = cfg == null ? 5 : cfg.getInt("settings.rows", cfg.getInt("settings.menu-rows", menuRows));
      if (rows < 1) {
         rows = 1;
      }

      if (rows > menuRows) {
         rows = menuRows;
      }

      if (rows > 6) {
         rows = 6;
      }

      return rows;
   }

   @Override
   protected double getRowMinScore(String category, int row, int totalRows) {
      double min = this.getGeneratorMinScore(category);
      double max = this.getGeneratorMaxScore(category);
      if (totalRows <= 1) {
         return min;
      }

      double step = Math.max(0.1, (max - min) / totalRows);
      return Math.max(0.0, min + step * row * 0.85);
   }

   @Override
   protected double getRowMaxScore(String category, int row, int totalRows) {
      double min = this.getGeneratorMinScore(category);
      double max = this.getGeneratorMaxScore(category);
      if (totalRows <= 1) {
         return max;
      }

      double step = Math.max(0.1, (max - min) / totalRows);
      double value = min + step * (row + 1.35);
      return Math.max(this.getRowMinScore(category, row, totalRows) + 0.1, Math.min(max, value));
   }

   @Override
   protected double getGeneratorAmountMultiplier(String category) {
      double def = this.getDefaultGeneratorAmountMultiplier(category);
      return Math.max(
         0.1,
         this.getCategoryQuestsConfig(category)
            .getDouble("generator.amount-multiplier", this.getQuestsConfig().getDouble("generator.categories." + category + ".amount-multiplier", def))
      );
   }

   @Override
   protected double getGeneratorMinScore(String category) {
      double def = this.getDefaultGeneratorMinScore(category);
      return Math.max(
         0.0,
         this.getCategoryQuestsConfig(category)
            .getDouble("generator.min-score", this.getQuestsConfig().getDouble("generator.categories." + category + ".min-score", def))
      );
   }

   @Override
   protected double getGeneratorMaxScore(String category) {
      double def = this.getDefaultGeneratorMaxScore(category);
      return Math.max(
         0.1,
         this.getCategoryQuestsConfig(category)
            .getDouble("generator.max-score", this.getQuestsConfig().getDouble("generator.categories." + category + ".max-score", def))
      );
   }

   @Override
   protected double getDefaultGeneratorAmountMultiplier(String category) {
      switch (category) {
         case "easy":
            return 1.0;
         case "medium":
            return 6.5;
         case "hard":
            return 14.0;
         case "fish":
            return 3.0;
         case "mine":
            return 5.2;
         case "wood":
            return 4.3;
         case "farm":
            return 3.4;
         case "alch":
            return 3.5;
         default:
            return 1.0;
      }
   }

   @Override
   protected double getDefaultGeneratorMinScore(String category) {
      switch (category) {
         case "medium":
            return 4.0;
         case "hard":
            return 14.0;
         case "mine":
            return 3.0;
         case "wood":
            return 3.0;
         case "farm":
            return 3.0;
         case "alch":
            return 4.0;
         default:
            return 0.0;
      }
   }

   @Override
   protected double getDefaultGeneratorMaxScore(String category) {
      switch (category) {
         case "easy":
            return 14.0;
         case "medium":
            return 48.0;
         case "hard":
            return 150.0;
         case "fish":
            return 48.0;
         case "mine":
            return 76.0;
         case "wood":
            return 68.0;
         case "farm":
            return 60.0;
         case "alch":
            return 90.0;
         default:
            return 48.0;
      }
   }
}
