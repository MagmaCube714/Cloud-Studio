package cs.cloudstudio.manager;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import cs.cloudstudio.cache.PlayerCache;
import cs.cloudstudio.database.DatabaseSettings;
import cs.cloudstudio.database.SqlDialect;
import cs.cloudstudio.manager.model.ActionType;
import cs.cloudstudio.manager.model.GeneratedReward;
import cs.cloudstudio.manager.model.PlayerData;
import cs.cloudstudio.manager.model.QuestTemplate;
import cs.cloudstudio.manager.model.SellerItem;
import cs.cloudstudio.manager.model.SellerMenu;
import cs.cloudstudio.manager.model.Stage;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import javax.sql.DataSource;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.event.server.PluginEnableEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.java.JavaPlugin;

public abstract class PluginBase extends JavaPlugin {
   protected static final String[] CATEGORIES = new String[]{"easy", "medium", "hard", "fish", "mine", "wood", "farm", "alch"};
   protected static final Set<String> CATEGORY_SET;
   protected static final Map<String, String> CATEGORY_PREREQ;
   protected static final String[] ADMIN_SUB_COMMANDS = new String[]{
      "reload", "generate", "regen", "info", "reset", "resetall", "resetdb", "setstage", "setprogress", "setskips", "complete", "completeall", "help"
   };
   protected static final String[] GENERATOR_TARGETS = new String[]{"all", "easy", "medium", "hard", "fish", "mine", "wood", "farm", "alch"};
   protected static final String[] REWARD_TEMPLATE_KEYS = new String[]{"unlock-reward", "already-given", "locked-reward"};
   protected static final int HARD_GENERATOR_MAX_AMOUNT = 3000;
   protected static final ItemFlag[] ALL_ITEM_FLAGS = ItemFlag.values();
   protected static final Set<Material> AGEABLE_BREAK_MATERIALS;
   protected static final Set<String> DISALLOWED_KILL_ENTITIES;
   protected DatabaseSettings databaseSettings;
   protected DataSource dataSource;
   protected boolean yamlStorage;
   protected File yamlStorageFile;
   protected SqlDialect sqlDialect;
   protected int autoSaveTask = -1;
   protected volatile boolean asyncSaveRunning;
   protected volatile long databaseGeneration = 0L;
   protected final Object databaseLock = new Object();
   protected Economy econ;
   protected boolean placeholderApiEnabled;
   protected final PlayerCache cache = new PlayerCache();
   protected final Set<UUID> activeTransactions = Collections.newSetFromMap(new ConcurrentHashMap<>());
   protected final Map<Material, List<String>> breakIndex = new EnumMap<>(Material.class);
   protected final Map<Material, List<String>> craftIndex = new EnumMap<>(Material.class);
   protected final Map<EntityType, List<String>> killIndex = new EnumMap<>(EntityType.class);
   protected final Map<String, List<Stage>> categoryStages = new LinkedHashMap<>();
   protected final Map<String, Map<Integer, Stage>> stagesByCategoryAndId = new HashMap<>();
   protected final Map<String, List<Stage>> rewardStagesByCategory = new HashMap<>();
   protected final Map<String, Map<Integer, Stage>> stagesBySlot = new HashMap<>();
   protected final Map<String, Integer> lastStageIdCache = new HashMap<>();
   protected int menuSize;
   protected String menuName;
   protected final Map<String, SellerMenu> sellerMenus = new HashMap<>();
   protected final Map<String, List<String>> msgCache = new HashMap<>();
   protected final Map<String, String> rewardNameCache = new HashMap<>();
   protected final Map<String, List<String>> rewardLoreCache = new HashMap<>();
   protected CommandMap commandMap;
   protected File questsFile;
   protected FileConfiguration questsConfig;
   protected File questsFolder;
   protected final Map<String, File> categoryQuestFiles = new HashMap<>();
   protected final Map<String, FileConfiguration> categoryQuestConfigs = new HashMap<>();
   protected final Map<String, File> categoryRewardFiles = new HashMap<>();
   protected final Map<String, FileConfiguration> categoryRewardConfigs = new HashMap<>();
   protected final Map<String, File> categorySellerFiles = new HashMap<>();

   protected static void addMaterialIfExists(Set<Material> result, String materialName) {
      Material m = Material.matchMaterial(materialName);
      if (m != null) {
         result.add(m);
      }
   }

   protected static String formatPrice(double v) {
      long whole = (long)v;
      long frac = Math.round((v - whole) * 10.0);
      if (frac < 0L) {
         frac = 0L;
      }

      if (frac >= 10L) {
         whole++;
         frac = 0L;
      }

      return whole + "." + frac;
   }

   protected static void applySkullTexture(SkullMeta meta, String texture) {
      if (meta != null && texture != null && !texture.isEmpty()) {
         PlayerProfile profile = Bukkit.createProfile(UUID.nameUUIDFromBytes(texture.getBytes(StandardCharsets.UTF_8)), null);
         profile.setProperty(new ProfileProperty("textures", texture));
         meta.setPlayerProfile(profile);
      }
   }

   protected boolean isCraftQuestMaterialSupported(Material material) {
      if (material != null && material != Material.AIR) {
         try {
            List<Recipe> recipes = Bukkit.getRecipesFor(new ItemStack(material));
            if (recipes != null && !recipes.isEmpty()) {
               int i = 0;

               for (int n = recipes.size(); i < n; i++) {
                  Recipe recipe = recipes.get(i);
                  if (recipe instanceof ShapedRecipe || recipe instanceof ShapelessRecipe) {
                     ItemStack result = recipe.getResult();
                     if (result != null && result.getType() == material && result.getAmount() > 0) {
                        return true;
                     }
                  }
               }

               return false;
            } else {
               return false;
            }
         } catch (Throwable ignored) {
            return false;
         }
      } else {
         return false;
      }
   }

   protected ActionType resolveObtainAction(ActionType requested, Material material) {
      if (material == null || material == Material.AIR) {
         return requested;
      } else {
         return requested == ActionType.CRAFT && !this.isCraftQuestMaterialSupported(material) ? ActionType.BRING : requested;
      }
   }

   protected boolean isKillQuestEntitySupported(EntityType entity) {
      return entity != null && entity.isAlive() && entity.isSpawnable()
         ? !DISALLOWED_KILL_ENTITIES.contains(entity.getKey().getKey().toUpperCase(Locale.ROOT))
         : false;
   }

   protected int getSafeKillQuestAmountLimit(EntityType entity) {
      if (!this.isKillQuestEntitySupported(entity)) {
         return 0;
      } else {
         String name = entity.name();
         if ("RAVAGER".equals(name)) {
            return 8;
         } else if ("EVOKER".equals(name) || "VEX".equals(name)) {
            return 16;
         } else if ("PHANTOM".equals(name) || "GHAST".equals(name) || "SHULKER".equals(name) || "ENDERMITE".equals(name)) {
            return 32;
         } else if ("WITHER_SKELETON".equals(name) || "WITCH".equals(name) || "VINDICATOR".equals(name)) {
            return 48;
         } else if ("GUARDIAN".equals(name) || "DROWNED".equals(name) || "BLAZE".equals(name) || "ENDERMAN".equals(name) || "PILLAGER".equals(name)) {
            return 64;
         } else {
            return !"CREEPER".equals(name) && !"HOGLIN".equals(name) && !"PIGLIN".equals(name) && !"SLIME".equals(name) && !"MAGMA_CUBE".equals(name)
               ? 128
               : 96;
         }
      }
   }

   protected int getSafeQuestAmountLimit(String category, ActionType action, Material material, EntityType entity) {
      int limit = Math.max(1, Math.min(3000, this.getGeneratorMaxAmount(category)));
      if (action == null) {
         return limit;
      }

      if (action == ActionType.KILL) {
         int killLimit = this.getSafeKillQuestAmountLimit(entity);
         return killLimit <= 0 ? 0 : Math.min(limit, killLimit);
      }

      if (material != null && material != Material.AIR) {
         String name = material.name();
         if (action == ActionType.CRAFT) {
            if (!this.isCraftQuestMaterialSupported(material)) {
               return 0;
            } else if ("BEACON".equals(name)) {
               return Math.min(limit, 1);
            } else if ("END_CRYSTAL".equals(name)) {
               return Math.min(limit, 8);
            } else if ("ANVIL".equals(name) || "BREWING_STAND".equals(name)) {
               return Math.min(limit, 8);
            } else if ("DIAMOND_BLOCK".equals(name)) {
               return Math.min(limit, 16);
            } else if ("GOLD_BLOCK".equals(name)) {
               return Math.min(limit, 32);
            } else {
               return "IRON_BLOCK".equals(name) ? Math.min(limit, 64) : Math.min(limit, 512);
            }
         } else {
            if (action == ActionType.BRING) {
               if ("NETHER_STAR".equals(name)) {
                  return Math.min(limit, 1);
               }

               if ("TOTEM_OF_UNDYING".equals(name)) {
                  return Math.min(limit, 4);
               }

               if ("WITHER_SKELETON_SKULL".equals(name)) {
                  return Math.min(limit, 8);
               }

               if ("TURTLE_HELMET".equals(name)) {
                  return Math.min(limit, 2);
               }

               if ("NETHERITE_SCRAP".equals(name)) {
                  return Math.min(limit, 16);
               }
            }

            return action == ActionType.BREAK && "ANCIENT_DEBRIS".equals(name) ? Math.min(limit, 24) : limit;
         }
      } else {
         return 0;
      }
   }

   protected boolean isQuestConfigurationSensible(String category, ConfigurationSection section) {
      if (section == null) {
         return false;
      }

      String actionRaw = section.getString("action", "BRING").toUpperCase(Locale.ROOT);

      ActionType action;
      try {
         action = ActionType.valueOf(actionRaw);
      } catch (IllegalArgumentException ex) {
         return false;
      }

      Material material = Material.matchMaterial(section.getString("material", ""));
      EntityType entity = null;
      if (action == ActionType.KILL) {
         String entityRaw = section.getString("entity", "");

         try {
            entity = EntityType.valueOf(entityRaw.toUpperCase(Locale.ROOT));
         } catch (IllegalArgumentException ex) {
            return false;
         }

         if (!this.isKillQuestEntitySupported(entity)) {
            return false;
         }
      }

      if (action == ActionType.CRAFT && !this.isCraftQuestMaterialSupported(material)) {
         return false;
      }

      int limit = this.getSafeQuestAmountLimit(category, action, material, entity);
      int amount = Math.max(1, section.getInt("amount", 1));
      return limit > 0 && amount <= limit;
   }

   protected static boolean subRequiresPlayerArg(String sub) {
      return "info".equals(sub)
         || "reset".equals(sub)
         || "resetdb".equals(sub)
         || "setstage".equals(sub)
         || "setprogress".equals(sub)
         || "setskips".equals(sub)
         || "complete".equals(sub)
         || "completeall".equals(sub);
   }

   protected static boolean subRequiresCategoryArg(String sub) {
      return "info".equals(sub)
         || "reset".equals(sub)
         || "setstage".equals(sub)
         || "setprogress".equals(sub)
         || "setskips".equals(sub)
         || "complete".equals(sub)
         || "completeall".equals(sub);
   }

   public void reloadPluginConfig() {
      this.reloadConfig();
   }

   public String[] getCategories() {
      return CATEGORIES;
   }

   public Set<String> getCategorySet() {
      return CATEGORY_SET;
   }

   protected abstract boolean safeLoadAllDataOnStartup();

   public abstract void onPluginEnable(PluginEnableEvent var1);

   public abstract void onPluginDisable(PluginDisableEvent var1);

   protected abstract CommandMap resolveCommandMap();

   protected abstract boolean setupEconomy();

   protected abstract void saveDefaultSellers();

   protected abstract void ensureCategoryFilesReady();

   protected abstract FileConfiguration loadBundledQuestsDefaults();

   protected abstract void createDefaultCategoryQuestsFile(String var1, File var2, FileConfiguration var3, FileConfiguration var4);

   protected abstract void createDefaultCategoryRewardsFile(String var1, File var2, FileConfiguration var3, FileConfiguration var4);

   protected abstract void createDefaultCategorySellerFile(String var1, File var2);

   protected abstract boolean copyResourceFile(String var1, File var2);

   protected abstract void saveYamlFile(FileConfiguration var1, File var2, String var3);

   protected abstract void loadAllData();

   protected abstract void loadSellers();

   protected abstract void loadQuests();

   protected abstract void reloadQuestsConfig();

   protected abstract FileConfiguration getQuestsConfig();

   protected abstract File getCategorySellerFile(String var1);

   protected abstract FileConfiguration getCategoryQuestsConfig(String var1);

   protected abstract FileConfiguration getCategoryRewardsConfig(String var1);

   protected abstract void saveQuestsConfig();

   protected abstract void ensureStartupQuestsGenerated();

   protected abstract void preloadMessageCache(FileConfiguration var1);

   protected abstract void preloadRewardTemplates(FileConfiguration var1);

   protected abstract List<String> colorList(List<String> var1);

   protected abstract <K> void deduplicateIndex(Map<K, List<String>> var1);

   protected abstract Material getBlockMaterial(Material var1);

   protected abstract Material safeMaterial(String var1);

   protected abstract Set<Material> getBreakMaterialAliases(Material var1);

   protected abstract void addModernMiningAliases(Set<Material> var1, Material var2);

   protected abstract Material parseMaterial(String var1);

   protected abstract int normalizeInventorySize(int var1);

   protected abstract int sanitizeDisplayAmount(Material var1, int var2);

   protected abstract double sanitizePrice(double var1);

   protected abstract void handleMenuOpen(Player var1, String var2);

   protected abstract boolean hasUnclaimedReadyReward(UUID var1, String var2);

   protected abstract void openSellerMenu(Player var1, String var2);

   protected abstract ItemStack buildSellerItemStack(Player var1, String var2, SellerItem var3, int var4);

   protected abstract void openQuestMenu(Player var1, String var2);

   protected abstract ItemStack buildLockedItem(Map<String, String> var1);

   protected abstract ItemStack buildItem(Material var1, String var2, String var3, Map<String, String> var4);

   protected abstract ItemStack buildRewardItem(Material var1, String var2, Map<String, String> var3);

   public abstract void onClick(InventoryClickEvent var1);

   public abstract void onDrag(InventoryDragEvent var1);

   public abstract void onDrop(PlayerDropItemEvent var1);

   public abstract void onSwapHand(PlayerSwapHandItemsEvent var1);

   public abstract void onQuit(PlayerQuitEvent var1);

   public abstract void onKick(PlayerKickEvent var1);

   public abstract boolean hasPluginMenuOpen(Player var1);

   protected abstract boolean shouldOpenSellerAfterRewardClaim(UUID var1, String var2);

   protected abstract void handleSellerClick(Player var1, String var2, int var3);

   protected abstract void handleQuestClick(Player var1, String var2, int var3);

   public abstract void onBlockBreak(BlockBreakEvent var1);

   public abstract boolean isFullyGrown(Block var1);

   public abstract void onCraftItem(CraftItemEvent var1);

   public abstract void onEntityDeath(EntityDeathEvent var1);

   public abstract void addTaskProgress(Player var1, String var2, Stage var3, int var4);

   public abstract Stage getActiveStage(Player var1, String var2);

   protected abstract Stage getStage(String var1, int var2);

   protected abstract Stage getStageBySlot(String var1, int var2);

   protected abstract int calculateCraftAmount(CraftItemEvent var1);

   public abstract boolean executeCommand(CommandSender var1, Command var2, String var3, String[] var4);

   public abstract List<String> tabCompleteCommand(CommandSender var1, Command var2, String var3, String[] var4);

   protected abstract void addMatching(List<String> var1, String[] var2, String var3);

   protected abstract boolean handleAdmin(CommandSender var1, String[] var2);

   protected abstract boolean handleInfo(CommandSender var1, String[] var2);

   protected abstract boolean handleReset(CommandSender var1, String[] var2);

   protected abstract boolean handleResetDb(CommandSender var1, String[] var2);

   protected abstract boolean handleSetStage(CommandSender var1, String[] var2);

   protected abstract boolean handleSetProgress(CommandSender var1, String[] var2);

   protected abstract boolean handleSetSkips(CommandSender var1, String[] var2);

   protected abstract boolean handleComplete(CommandSender var1, String[] var2);

   protected abstract boolean handleCompleteAll(CommandSender var1, String[] var2);

   protected abstract boolean handleGenerate(CommandSender var1, String[] var2);

   protected abstract int generateQuestCategory(String var1);

   protected abstract void ensureCategoryRewards(String var1, int var2, int var3);

   protected abstract ConfigurationSection recreateConfigurationSection(FileConfiguration var1, String var2);

   protected abstract Map<Integer, GeneratedReward> readGeneratedRewards(String var1, int var2, int var3);

   protected abstract void readRewardTemplateSection(Map<Integer, GeneratedReward> var1, ConfigurationSection var2, String var3, int var4, int var5);

   protected abstract void readRewardSection(Map<Integer, GeneratedReward> var1, ConfigurationSection var2, String var3, int var4, int var5);

   protected abstract GeneratedReward createDefaultGeneratedReward(String var1, int var2);

   protected abstract Material defaultRewardMaterial(int var1);

   protected abstract List<QuestTemplate> buildGeneratorTemplates(String var1);

   protected abstract void addDefaultGeneratorTemplates(List<QuestTemplate> var1);

   protected abstract void addCustomGeneratorTemplates(List<QuestTemplate> var1, String var2);

   protected abstract String joinStrings(List<String> var1);

   protected abstract void addTaskTemplate(List<QuestTemplate> var1, String var2, ActionType var3, String var4, String var5, int var6, String var7, double var8);

   protected abstract void addKillTemplate(List<QuestTemplate> var1, String var2, String var3, String var4, int var5, String var6, double var7);

   protected abstract String[] splitCategories(String var1);

   protected abstract QuestTemplate selectQuestTemplate(List<QuestTemplate> var1, Set<String> var2, String var3, int var4, int var5, int var6);

   protected abstract int calculateGeneratedAmount(String var1, QuestTemplate var2, int var3, int var4, int var5);

   protected abstract int fitQuestAmountToDifficulty(String var1, QuestTemplate var2, int var3, int var4, int var5);

   protected abstract int clampQuestAmount(int var1);

   protected abstract int getGeneratorMaxAmount();

   protected abstract int getGeneratorMaxAmount(String var1);

   protected abstract int roundQuestAmount(int var1);

   protected abstract double estimateQuestDifficulty(QuestTemplate var1, int var2);

   protected abstract int getGeneratorTotalRows();

   protected abstract int getGeneratorTotalRows(String var1);

   protected abstract int getGeneratorTotalRowsForConfig(FileConfiguration var1, String var2);

   protected abstract double getRowMinScore(String var1, int var2, int var3);

   protected abstract double getRowMaxScore(String var1, int var2, int var3);

   protected abstract double getGeneratorAmountMultiplier(String var1);

   protected abstract double getGeneratorMinScore(String var1);

   protected abstract double getGeneratorMaxScore(String var1);

   protected abstract double getDefaultGeneratorAmountMultiplier(String var1);

   protected abstract double getDefaultGeneratorMinScore(String var1);

   protected abstract double getDefaultGeneratorMaxScore(String var1);

   protected abstract boolean shouldResetProgressOnGenerate(List<String> var1);

   protected abstract void resetGeneratedProgress(List<String> var1);

   protected abstract void closeQuestMenus();

   protected abstract UUID getTargetUUID(CommandSender var1, String var2);

   protected abstract void sendAdminHelp(CommandSender var1);

   protected abstract void handleSkip(Player var1, String var2);

   protected abstract Integer getOptionalInt(ConfigurationSection var1, String... var2);

   protected abstract List<String> getConfiguredCommands(ConfigurationSection var1);

   protected abstract void addConfiguredCommandValue(ConfigurationSection var1, List<String> var2, String var3);

   protected abstract int[] skipSingleStage(UUID var1, String var2, String var3);

   protected abstract int[] skipCurrentQuestLine(UUID var1, String var2, String var3);

   protected abstract int[] skipRemainingQuestStages(UUID var1, String var2, String var3);

   protected abstract int[] skipQuestStages(UUID var1, String var2, String var3, boolean var4, boolean var5);

   protected abstract void recordTaskCompletion(UUID var1, String var2, Stage var3);

   protected abstract void recordStageSkip(UUID var1, String var2, Stage var3);

   protected abstract boolean hasClaimedReward(UUID var1, String var2, Stage var3);

   protected abstract boolean recordRewardClaim(UUID var1, String var2, Stage var3);

   protected abstract void incrementCounter(Map<String, Integer> var1, String var2, int var3);

   protected abstract void markPlayerDataModified(PlayerData var1);

   protected abstract Set<Integer> getStageIdSet(Map<String, Set<Integer>> var1, String var2);

   protected abstract void updatePlayerIdentity(UUID var1, String var2);

   protected abstract Map<String, String> createBasePlaceholders(OfflinePlayer var1, String var2);

   protected abstract Map<String, String> createBasePlaceholders(OfflinePlayer var1, String var2, String var3);

   protected abstract String formatMenuTitle(Player var1, String var2, String var3);

   protected abstract String applyDynamicPlaceholders(OfflinePlayer var1, String var2, Map<String, String> var3);

   protected abstract String prepareCommand(OfflinePlayer var1, String var2, String var3, String var4, Stage var5);

   protected abstract boolean dispatchRewardCommands(OfflinePlayer var1, String var2, String var3, Stage var4);

   protected abstract boolean dispatchConfiguredCommands(OfflinePlayer var1, String var2, String var3, List<String> var4, Stage var5);

   protected abstract boolean areConfiguredCommandsResolvable(OfflinePlayer var1, String var2, String var3, List<String> var4, Stage var5);

   protected abstract boolean dispatchConfiguredCommand(String var1);

   protected abstract boolean isConsoleCommandResolvable(String var1);

   protected abstract String normalizeConsoleCommand(String var1);

   protected abstract List<String> getMsgLines(String var1, Map<String, String> var2);

   protected abstract List<String> restoreLegacyBoxMessageIfNeeded(String var1, List<String> var2);

   protected abstract void sendMsg(Player var1, String var2);

   protected abstract void sendMsg(Player var1, String var2, String var3);

   protected abstract String applyPlaceholders(String var1, Map<String, String> var2);

   protected abstract String color(String var1);

   protected abstract int getNextValidStageId(String var1, int var2);

   protected abstract int getNextProgressStageId(String var1, int var2);

   protected abstract int skipRewardStages(String var1, int var2);

   protected abstract int normalizePlayerStageAfterRewards(UUID var1, String var2);

   protected abstract int getLastStageId(String var1);

   protected abstract int getAmount(Player var1, Material var2);

   protected abstract int removeItems(Player var1, Material var2, int var3);

   protected abstract boolean isQuestConsumableItem(ItemStack var1, Material var2);

   protected abstract void giveItemsSafely(Player var1, Material var2, int var3);

   protected abstract boolean loadData();

   protected abstract boolean initializeDatabase();

   protected abstract DataSource createDataSource(DatabaseSettings var1) throws IOException, ClassNotFoundException;

   protected abstract DataSource createHikariDataSource(DatabaseSettings var1) throws IOException, ReflectiveOperationException;

   protected abstract Object invoke(Object var1, String var2, Class<?>[] var3, Object... var4) throws ReflectiveOperationException;

   protected abstract DataSource createDriverManagerDataSource(DatabaseSettings var1) throws IOException, ClassNotFoundException;

   protected abstract File prepareSqliteFile(DatabaseSettings var1) throws IOException;

   protected abstract String createMySqlUrl(DatabaseSettings var1);

   protected abstract void initializeSchema(Connection var1) throws SQLException;

   protected abstract void executeSchemaStatement(Statement var1, String var2) throws SQLException;

   protected abstract void loadPlayersFromDatabase() throws SQLException;

   protected abstract void enableSqliteForeignKeys(Connection var1) throws SQLException;

   protected abstract void loadStageSetFromDatabase(Connection var1, String var2) throws SQLException;

   protected abstract void loadPurchasesFromDatabase(Connection var1) throws SQLException;

   protected abstract UUID parseUuid(String var1);

   protected abstract void putPositiveCounter(Map<String, Integer> var1, String var2, int var3);

   protected abstract Map<String, Set<Integer>> getStageSetMapByTable(PlayerData var1, String var2);

   protected abstract boolean migrateLegacyYamlData();

   protected abstract void loadPlayersFromYamlStorage();

   protected abstract boolean savePlayerSnapshotsToYaml(Map<UUID, PlayerData> var1);

   protected abstract void writePlayerDataToYaml(ConfigurationSection var1, PlayerData var2);

   protected abstract void writeStageIdSetToYaml(ConfigurationSection var1, Set<Integer> var2);

   protected abstract PlayerData readPlayerDataFromYaml(ConfigurationSection var1);

   protected abstract PlayerData readLegacyPlayerDataFromYaml(ConfigurationSection var1);

   protected abstract void loadCounterFromYaml(ConfigurationSection var1, Map<String, Integer> var2, String var3, String var4);

   protected abstract void loadPurchasesFromYaml(ConfigurationSection var1, PlayerData var2);

   protected abstract void loadStageIdSetFromYaml(ConfigurationSection var1, Map<String, Set<Integer>> var2, String var3);

   protected abstract void saveAllDataAsync();

   protected abstract void saveAllDataSync();

   protected abstract boolean savePlayerDataSync(UUID var1);

   protected abstract void savePlayerDataAsync(UUID var1);

   protected abstract Map<UUID, PlayerData> collectPlayerSnapshots(boolean var1);

   protected abstract void markSnapshotsSaved(Map<UUID, PlayerData> var1);

   protected abstract void markSnapshotsDirty(Map<UUID, PlayerData> var1);

   protected abstract PlayerData copyPlayerData(PlayerData var1);

   protected abstract void copyStageSets(Map<String, Set<Integer>> var1, Map<String, Set<Integer>> var2);

   protected abstract boolean savePlayerSnapshots(Map<UUID, PlayerData> var1, long var2);

   protected abstract void savePlayerSnapshot(
      UUID var1,
      PlayerData var2,
      PreparedStatement var3,
      PreparedStatement var4,
      PreparedStatement var5,
      PreparedStatement var6,
      PreparedStatement var7,
      PreparedStatement var8,
      PreparedStatement var9,
      PreparedStatement var10,
      PreparedStatement var11,
      PreparedStatement var12,
      PreparedStatement var13
   ) throws SQLException;

   protected abstract void deletePlayerChildRows(
      String var1, PreparedStatement var2, PreparedStatement var3, PreparedStatement var4, PreparedStatement var5, PreparedStatement var6
   ) throws SQLException;

   protected abstract void executeDelete(PreparedStatement var1, String var2) throws SQLException;

   protected abstract void insertQuestProgressRows(String var1, PlayerData var2, PreparedStatement var3) throws SQLException;

   protected abstract boolean hasCategoryData(PlayerData var1, String var2);

   protected abstract boolean hasStageSet(Map<String, Set<Integer>> var1, String var2);

   protected abstract void insertStageRows(PreparedStatement var1, String var2, Map<String, Set<Integer>> var3) throws SQLException;

   protected abstract void insertPurchaseRows(String var1, PlayerData var2, PreparedStatement var3) throws SQLException;

   protected abstract void rollbackConnection(Connection var1);

   protected abstract void restoreAutoCommit(Connection var1);

   protected abstract void resetPlayerCategory(UUID var1, String var2);

   protected abstract void resetAllProgressOnly();

   protected abstract void resetPlayerDatabase(UUID var1);

   protected abstract void resetDatabase();

   protected abstract void deletePlayerFromDatabase(String var1) throws SQLException;

   protected abstract void clearDatabaseTables(Connection var1) throws SQLException;

   protected abstract void closeDatabase();

   protected abstract PlayerData getPlayerData(UUID var1);

   protected abstract int getPlayerStage(UUID var1, String var2);

   protected abstract void setPlayerStage(UUID var1, String var2, int var3);

   protected abstract int getPlayerProgress(UUID var1, String var2);

   protected abstract void setPlayerProgress(UUID var1, String var2, int var3);

   protected abstract int getSkipsLeft(UUID var1, String var2);

   protected abstract void setSkipsLeft(UUID var1, String var2, int var3);

   protected abstract int getPurchases(UUID var1, String var2, String var3);

   protected abstract void addPurchase(UUID var1, String var2, String var3);

   protected abstract void removePurchase(UUID var1, String var2, String var3);

   static {
      Set<String> set = new HashSet<>(CATEGORIES.length * 2);
      Collections.addAll(set, CATEGORIES);
      CATEGORY_SET = set;
      Map<String, String> prereq = new HashMap<>();
      prereq.put("medium", "easy");
      prereq.put("hard", "medium");
      CATEGORY_PREREQ = prereq;
      Set<Material> ageable = EnumSet.noneOf(Material.class);
      addMaterialIfExists(ageable, "WHEAT");
      addMaterialIfExists(ageable, "CARROTS");
      addMaterialIfExists(ageable, "POTATOES");
      addMaterialIfExists(ageable, "BEETROOTS");
      addMaterialIfExists(ageable, "NETHER_WART");
      addMaterialIfExists(ageable, "COCOA");
      addMaterialIfExists(ageable, "SWEET_BERRY_BUSH");
      AGEABLE_BREAK_MATERIALS = Collections.unmodifiableSet(ageable);
      Set<String> disallowedKillEntities = new HashSet<>();
      Collections.addAll(disallowedKillEntities, "ENDER_DRAGON", "WITHER", "ELDER_GUARDIAN", "GIANT", "ILLUSIONER", "WARDEN", "PLAYER");
      DISALLOWED_KILL_ENTITIES = Collections.unmodifiableSet(disallowedKillEntities);
   }
}
