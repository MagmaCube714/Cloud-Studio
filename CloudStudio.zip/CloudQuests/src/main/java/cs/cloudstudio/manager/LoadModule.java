package cs.cloudstudio.manager;

import cs.cloudstudio.manager.model.ActionType;
import cs.cloudstudio.manager.model.SellerItem;
import cs.cloudstudio.manager.model.SellerMenu;
import cs.cloudstudio.manager.model.Stage;
import cs.cloudstudio.manager.model.StageType;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;

public abstract class LoadModule extends FileModule {
   @Override
   protected void loadAllData() {
      this.loadQuests();
      this.loadSellers();
   }

   @Override
   protected void loadSellers() {
      this.sellerMenus.clear();
      this.ensureCategoryFilesReady();

      for (String cat : CATEGORIES) {
         File file = this.getCategorySellerFile(cat);
         if (file != null && file.exists()) {
            FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);
            SellerMenu menu = new SellerMenu();
            menu.title = this.color(cfg.getString("menu.title", "&fЯрмарка " + cat));
            menu.size = this.normalizeInventorySize(cfg.getInt("menu.size", 54));
            menu.msgSuccess = this.color(cfg.getString("messages.success_purchase", "&fУспешная покупка"));
            menu.msgNoMoney = this.color(cfg.getString("messages.not_enough_money", "&cНедостаточно монет"));
            menu.msgLimit = this.color(cfg.getString("messages.limit_reached", "&cВы достигли лимита"));
            ConfigurationSection itemsSec = cfg.getConfigurationSection("items");
            if (itemsSec != null) {
               for (String key : itemsSec.getKeys(false)) {
                  ConfigurationSection itemCfg = itemsSec.getConfigurationSection(key);
                  if (itemCfg != null) {
                     SellerItem item = new SellerItem();
                     item.id = key;
                     item.slot = itemCfg.getInt("slot");
                     item.material = this.parseMaterial(itemCfg.getString("material", "STONE"));
                     item.amount = this.sanitizeDisplayAmount(item.material, itemCfg.getInt("amount", 1));
                     item.ench = itemCfg.getBoolean("ench", false);
                     item.texture = itemCfg.getString("texture", "");
                     item.name = this.color(itemCfg.getString("name", "&fПредмет"));
                     item.lore = this.colorList(itemCfg.getStringList("lore"));
                     item.price = this.sanitizePrice(itemCfg.getDouble("price", 0.0));
                     item.limit = Math.max(0, itemCfg.getInt("limit", 1));
                     item.modelData = this.getOptionalInt(itemCfg, "modeldata", "model_data", "custom_model_data", "custom-model-data");
                     item.commands = this.getConfiguredCommands(itemCfg);
                     if (item.slot >= 0 && item.slot < menu.size) {
                        menu.items.put(item.slot, item);
                     }
                  }
               }
            }

            this.sellerMenus.put(cat, menu);
         }
      }
   }

   @Override
   protected void loadQuests() {
      this.categoryStages.clear();
      this.stagesByCategoryAndId.clear();
      this.rewardStagesByCategory.clear();
      this.stagesBySlot.clear();
      this.lastStageIdCache.clear();
      this.breakIndex.clear();
      this.craftIndex.clear();
      this.killIndex.clear();
      this.msgCache.clear();
      this.rewardNameCache.clear();
      this.rewardLoreCache.clear();
      this.reloadPluginConfig();
      this.reloadQuestsConfig();
      FileConfiguration cfg = this.getConfig();
      int rows = cfg.getInt("settings.menu_rows", 6);
      if (rows < 1) {
         rows = 1;
      }

      if (rows > 6) {
         rows = 6;
      }

      this.menuSize = rows * 9;
      this.menuName = this.color(cfg.getString("settings.menu_name", "&fМеню"));
      this.preloadMessageCache(cfg);
      this.preloadRewardTemplates(cfg);
      this.ensureStartupQuestsGenerated();

      for (String cat : CATEGORIES) {
         FileConfiguration questCfg = this.getCategoryQuestsConfig(cat);
         FileConfiguration rewardCfg = this.getCategoryRewardsConfig(cat);
         ConfigurationSection qSection = questCfg.getConfigurationSection("quests");
         List<Stage> stages = new ArrayList<>();
         List<Stage> rewardList = new ArrayList<>();
         Map<Integer, Stage> byId = new HashMap<>();
         Map<Integer, Stage> bySlot = new HashMap<>();
         if (qSection != null) {
            Iterator rewards = qSection.getKeys(false).iterator();

            label138:
            while (true) {
               String key;
               int id;
               while (true) {
                  if (!rewards.hasNext()) {
                     break label138;
                  }

                  key = (String)rewards.next();

                  try {
                     id = Integer.parseInt(key);
                     break;
                  } catch (NumberFormatException e) {
                  }
               }

               ConfigurationSection s = qSection.getConfigurationSection(key);
               if (s != null && !"REWARD".equalsIgnoreCase(s.getString("type", ""))) {
                  int slot = s.getInt("slot");
                  if (slot >= 0 && slot < this.menuSize) {
                     Stage stage = new Stage();
                     stage.id = id;
                     stage.category = cat;
                     stage.slot = slot;
                     stage.itemName = s.getString("name", "Предмет");
                     stage.type = StageType.TASK;
                     stage.reqAmount = this.clampQuestAmount(Math.max(1, s.getInt("amount", 1)));
                     stage.reqMaterial = this.parseMaterial(s.getString("material", "STONE"));
                     stage.displayMaterial = stage.reqMaterial;
                     String actionStr = s.getString("action", "BRING").toUpperCase(Locale.ROOT);
                     if (!"SMELT".equals(actionStr)) {
                        try {
                           stage.action = ActionType.valueOf(actionStr);
                        } catch (IllegalArgumentException ex) {
                           stage.action = ActionType.BRING;
                        }

                        stage.action = this.resolveObtainAction(stage.action, stage.reqMaterial);
                        if (stage.action == ActionType.KILL) {
                           String entStr = s.getString("entity");
                           if (entStr != null) {
                              try {
                                 stage.targetEntity = EntityType.valueOf(entStr.toUpperCase(Locale.ROOT));
                              } catch (IllegalArgumentException var23) {
                              }
                           }

                           String wepStr = s.getString("weapon");
                           if (wepStr != null) {
                              stage.reqWeapon = this.parseMaterial(wepStr);
                           }
                        }

                        if (stage.action == ActionType.BREAK && stage.reqMaterial != null) {
                           stage.breakMaterials = this.getBreakMaterialAliases(stage.reqMaterial);

                           for (Material m : stage.breakMaterials) {
                              this.breakIndex.computeIfAbsent(m, k -> new ArrayList<>()).add(cat);
                           }
                        }

                        if (stage.action == ActionType.CRAFT && stage.reqMaterial != null) {
                           this.craftIndex.computeIfAbsent(stage.reqMaterial, k -> new ArrayList<>()).add(cat);
                        }

                        if (stage.action == ActionType.KILL && stage.targetEntity != null) {
                           this.killIndex.computeIfAbsent(stage.targetEntity, k -> new ArrayList<>()).add(cat);
                        }

                        stages.add(stage);
                        byId.put(id, stage);
                        bySlot.put(slot, stage);
                     }
                  }
               }
            }
         }

         ConfigurationSection rewards = rewardCfg.getConfigurationSection("rewards");
         if (rewards != null) {
            for (String key : rewards.getKeys(false)) {
               int rewardNumber;
               try {
                  rewardNumber = Integer.parseInt(key);
               } catch (NumberFormatException e) {
                  continue;
               }

               ConfigurationSection s = rewards.getConfigurationSection(key);
               if (s != null) {
                  int slot = s.getInt("slot", rewardNumber * 9 - 1);
                  if (slot >= 0 && slot < this.menuSize) {
                     int id = s.getInt("id", slot + 1);
                     Stage stage = new Stage();
                     stage.id = id;
                     stage.category = cat;
                     stage.slot = slot;
                     stage.itemName = s.getString("name", "Награда");
                     stage.type = StageType.REWARD;
                     stage.rewardCommands = s.getStringList("commands");
                     stage.displayMaterial = this.parseMaterial(s.getString("material", this.defaultRewardMaterial(rewardNumber).name()));
                     stages.add(stage);
                     rewardList.add(stage);
                     byId.put(id, stage);
                     bySlot.put(slot, stage);
                  }
               }
            }
         }

         stages.sort((a, b) -> Integer.compare(a.id, b.id));
         this.categoryStages.put(cat, stages);
         this.stagesByCategoryAndId.put(cat, byId);
         this.stagesBySlot.put(cat, bySlot);
         if (!rewardList.isEmpty()) {
            this.rewardStagesByCategory.put(cat, rewardList);
         }

         if (!stages.isEmpty()) {
            this.lastStageIdCache.put(cat, stages.get(stages.size() - 1).id);
         }
      }

      this.deduplicateIndex(this.breakIndex);
      this.deduplicateIndex(this.craftIndex);
      this.deduplicateIndex(this.killIndex);
   }

   @Override
   protected void reloadQuestsConfig() {
      this.ensureCategoryFilesReady();
   }

   @Override
   protected FileConfiguration getQuestsConfig() {
      if (this.questsConfig == null) {
         this.reloadQuestsConfig();
      }

      return (FileConfiguration)(this.questsConfig == null ? new YamlConfiguration() : this.questsConfig);
   }

   @Override
   protected File getCategorySellerFile(String category) {
      if (!this.categorySellerFiles.containsKey(category)) {
         this.ensureCategoryFilesReady();
      }

      return this.categorySellerFiles.get(category);
   }

   @Override
   protected FileConfiguration getCategoryQuestsConfig(String category) {
      FileConfiguration cfg = this.categoryQuestConfigs.get(category);
      if (cfg == null) {
         this.ensureCategoryFilesReady();
         cfg = this.categoryQuestConfigs.get(category);
      }

      return (FileConfiguration)(cfg == null ? new YamlConfiguration() : cfg);
   }

   @Override
   protected FileConfiguration getCategoryRewardsConfig(String category) {
      FileConfiguration cfg = this.categoryRewardConfigs.get(category);
      if (cfg == null) {
         this.ensureCategoryFilesReady();
         cfg = this.categoryRewardConfigs.get(category);
      }

      return (FileConfiguration)(cfg == null ? new YamlConfiguration() : cfg);
   }

   @Override
   protected void saveQuestsConfig() {
      for (String cat : CATEGORIES) {
         FileConfiguration questCfg = this.categoryQuestConfigs.get(cat);
         File questFile = this.categoryQuestFiles.get(cat);
         if (questCfg != null && questFile != null) {
            this.saveYamlFile(questCfg, questFile, "quests/" + cat + "/quests.yml");
         }

         FileConfiguration rewardCfg = this.categoryRewardConfigs.get(cat);
         File rewardFile = this.categoryRewardFiles.get(cat);
         if (rewardCfg != null && rewardFile != null) {
            this.saveYamlFile(rewardCfg, rewardFile, "quests/" + cat + "/rewards.yml");
         }
      }
   }

   @Override
   protected void ensureStartupQuestsGenerated() {
      boolean generated = false;

      for (String cat : CATEGORIES) {
         FileConfiguration questCfg = this.getCategoryQuestsConfig(cat);
         boolean regenerateEveryStart = questCfg.getBoolean(
            "settings.regenerate-on-every-startup", this.getQuestsConfig().getBoolean("settings.regenerate-on-every-startup", false)
         );
         boolean generateOnStartup = questCfg.getBoolean(
            "settings.generate-on-startup", this.getQuestsConfig().getBoolean("settings.generate-on-startup", true)
         );
         if (generateOnStartup || regenerateEveryStart) {
            ConfigurationSection qSection = questCfg.getConfigurationSection("quests");
            boolean empty = qSection == null || qSection.getKeys(false).isEmpty();
            boolean unsafe = !empty && this.hasUnsafeGeneratedQuests(cat, qSection);
            if (regenerateEveryStart || empty || unsafe) {
               try {
                  this.generateQuestCategory(cat);
                  generated = true;
                  if (unsafe && this.shouldResetProgressOnGenerate(Collections.singletonList(cat))) {
                     this.resetGeneratedProgress(Collections.singletonList(cat));
                  }

                  if (unsafe) {
                     this.getLogger()
                        .warning("[CloudQuests] Категория " + cat + " содержала невозможные/абсурдные задания и была автоматически перегенерирована.");
                  }
               } catch (Throwable t) {
                  this.getLogger().warning("[CloudQuests] Не удалось безопасно сгенерировать квесты категории " + cat + ": " + t.getMessage());
               }
            }
         }
      }

      if (generated) {
         this.saveQuestsConfig();
      }
   }

   protected boolean hasUnsafeGeneratedQuests(String category, ConfigurationSection quests) {
      if (quests == null) {
         return false;
      }

      for (String key : quests.getKeys(false)) {
         ConfigurationSection section = quests.getConfigurationSection(key);
         if (section != null && !"REWARD".equalsIgnoreCase(section.getString("type", "")) && !this.isQuestConfigurationSensible(category, section)) {
            return true;
         }
      }

      return false;
   }

   @Override
   protected void preloadMessageCache(FileConfiguration cfg) {
      ConfigurationSection messages = cfg.getConfigurationSection("messages");
      if (messages != null) {
         for (String key : messages.getKeys(false)) {
            List<String> raw = this.colorList(messages.getStringList(key));
            raw = this.restoreLegacyBoxMessageIfNeeded(key, raw);
            this.msgCache.put(key, raw);
         }
      }
   }

   @Override
   protected void preloadRewardTemplates(FileConfiguration cfg) {
      FileConfiguration rewardCfg = this.getCategoryRewardsConfig("easy");

      for (int i = 0; i < REWARD_TEMPLATE_KEYS.length; i++) {
         String key = REWARD_TEMPLATE_KEYS[i];
         String name = rewardCfg.getString(
            "reward-items." + key + ".name",
            this.getQuestsConfig().getString("reward-items." + key + ".name", cfg.getString("rewards." + key + ".name", "&b&lНаграда"))
         );
         List<String> lore = rewardCfg.getStringList("reward-items." + key + ".lore");
         if (lore == null || lore.isEmpty()) {
            lore = this.getQuestsConfig().getStringList("reward-items." + key + ".lore");
         }

         if (lore == null || lore.isEmpty()) {
            lore = cfg.getStringList("rewards." + key + ".lore");
         }

         this.rewardNameCache.put(key, this.color(name));
         this.rewardLoreCache.put(key, this.colorList(lore));
      }
   }

   @Override
   protected List<String> colorList(List<String> input) {
      if (input != null && !input.isEmpty()) {
         List<String> result = new ArrayList<>(input.size());
         int i = 0;

         for (int n = input.size(); i < n; i++) {
            result.add(this.color(input.get(i)));
         }

         return result;
      } else {
         return Collections.emptyList();
      }
   }

   @Override
   protected <K> void deduplicateIndex(Map<K, List<String>> idx) {
      for (Entry<K, List<String>> e : idx.entrySet()) {
         List<String> list = e.getValue();
         if (list.size() > 1) {
            Set<String> seen = new HashSet<>(list);
            if (seen.size() < list.size()) {
               list.clear();
               list.addAll(seen);
            }
         }
      }
   }

   @Override
   protected Material getBlockMaterial(Material itemMat) {
      if (itemMat == null) {
         return null;
      }

      switch (itemMat.name()) {
         case "CARROT":
            return this.safeMaterial("CARROTS");
         case "POTATO":
            return this.safeMaterial("POTATOES");
         case "BEETROOT":
            return this.safeMaterial("BEETROOTS");
         case "COCOA_BEANS":
            return this.safeMaterial("COCOA");
         case "SWEET_BERRIES":
            return this.safeMaterial("SWEET_BERRY_BUSH");
         case "MELON_SLICE":
            return this.safeMaterial("MELON");
         case "COBBLESTONE":
            return this.safeMaterial("STONE");
         default:
            return itemMat;
      }
   }

   @Override
   protected Material safeMaterial(String name) {
      try {
         return Material.valueOf(name);
      } catch (IllegalArgumentException e) {
         return null;
      }
   }

   @Override
   protected Set<Material> getBreakMaterialAliases(Material configuredMaterial) {
      Set<Material> result = EnumSet.noneOf(Material.class);
      if (configuredMaterial == null) {
         return result;
      }

      result.add(configuredMaterial);
      Material blockMaterial = this.getBlockMaterial(configuredMaterial);
      if (blockMaterial != null) {
         result.add(blockMaterial);
      }

      this.addModernMiningAliases(result, configuredMaterial);
      this.addModernMiningAliases(result, blockMaterial);
      return result;
   }

   @Override
   protected void addModernMiningAliases(Set<Material> result, Material material) {
      if (material != null && "COBBLESTONE".equals(material.name())) {
         addMaterialIfExists(result, "STONE");
      }
   }

   @Override
   protected Material parseMaterial(String name) {
      if (name != null && !name.trim().isEmpty()) {
         Material m = Material.matchMaterial(name.trim());
         return m != null && m != Material.AIR ? m : Material.STONE;
      } else {
         return Material.STONE;
      }
   }

   @Override
   protected int normalizeInventorySize(int size) {
      if (size < 9) {
         return 9;
      } else {
         return size > 54 ? 54 : size / 9 * 9;
      }
   }

   @Override
   protected int sanitizeDisplayAmount(Material material, int amount) {
      if (amount <= 0) {
         return 1;
      }

      int max = material != null ? material.getMaxStackSize() : 64;
      return Math.min(amount, Math.max(1, max));
   }

   @Override
   protected double sanitizePrice(double price) {
      return Double.isFinite(price) && price > 0.0 ? price : 0.0;
   }

   @Override
   protected String joinStrings(List<String> list) {
      if (list != null && !list.isEmpty()) {
         StringBuilder sb = new StringBuilder();
         int i = 0;

         for (int n = list.size(); i < n; i++) {
            if (i > 0) {
               sb.append(',');
            }

            sb.append(list.get(i));
         }

         return sb.toString();
      } else {
         return "";
      }
   }

   @Override
   protected String[] splitCategories(String categories) {
      if (categories != null && !categories.trim().isEmpty()) {
         String[] raw = categories.split(",");
         List<String> result = new ArrayList<>();
         int i = 0;

         for (int n = raw.length; i < n; i++) {
            String value = raw[i].trim().toLowerCase(Locale.ROOT);
            if (!value.isEmpty()) {
               result.add(value);
            }
         }

         return result.toArray(new String[0]);
      } else {
         return new String[0];
      }
   }

   @Override
   protected Integer getOptionalInt(ConfigurationSection cfg, String... keys) {
      if (cfg != null && keys != null) {
         for (int i = 0; i < keys.length; i++) {
            if (cfg.contains(keys[i])) {
               return cfg.getInt(keys[i]);
            }
         }

         return null;
      } else {
         return null;
      }
   }

   @Override
   protected List<String> getConfiguredCommands(ConfigurationSection cfg) {
      List<String> result = new ArrayList<>();
      this.addConfiguredCommandValue(cfg, result, "commands");
      if (result.isEmpty()) {
         this.addConfiguredCommandValue(cfg, result, "command");
      }

      for (int i = result.size() - 1; i >= 0; i--) {
         String cmd = result.get(i);
         if (cmd != null && !cmd.trim().isEmpty()) {
            result.set(i, cmd.trim());
         } else {
            result.remove(i);
         }
      }

      return result;
   }

   @Override
   protected void addConfiguredCommandValue(ConfigurationSection cfg, List<String> result, String key) {
      if (cfg != null && cfg.contains(key)) {
         if (cfg.isList(key)) {
            result.addAll(cfg.getStringList(key));
         } else {
            String single = cfg.getString(key, "");
            if (single != null && !single.trim().isEmpty()) {
               result.add(single);
            }
         }
      }
   }
}
