package cs.cloudstudio.manager.model;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;

public class GeneratedReward {
   public Material material;
   public List<String> commands = new ArrayList<>();
}
