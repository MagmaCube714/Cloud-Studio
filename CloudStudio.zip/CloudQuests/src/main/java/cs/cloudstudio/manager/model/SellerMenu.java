package cs.cloudstudio.manager.model;

import java.util.HashMap;
import java.util.Map;

public class SellerMenu {
   public String title;
   public int size;
   public final Map<Integer, SellerItem> items = new HashMap<>();
   public String msgSuccess;
   public String msgNoMoney;
   public String msgLimit;
}
