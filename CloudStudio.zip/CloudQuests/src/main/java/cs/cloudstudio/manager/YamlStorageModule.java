package cs.cloudstudio.manager;

import cs.cloudstudio.manager.model.PlayerData;
import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public abstract class YamlStorageModule extends DatabaseConnectionModule {
   @Override
   protected boolean migrateLegacyYamlData() {
      File legacyFile = new File(this.getDataFolder(), "data.yml");
      if (legacyFile.exists() && legacyFile.length() > 0L) {
         FileConfiguration legacyConfig = YamlConfiguration.loadConfiguration(legacyFile);
         Map<UUID, PlayerData> migrated = new LinkedHashMap<>();
         ConfigurationSection players = legacyConfig.getConfigurationSection("players");
         if (players != null) {
            for (String key : players.getKeys(false)) {
               UUID uuid = this.parseUuid(key);
               ConfigurationSection section = players.getConfigurationSection(key);
               if (uuid != null && section != null) {
                  migrated.put(uuid, this.readPlayerDataFromYaml(section));
               }
            }
         } else {
            for (String key : legacyConfig.getKeys(false)) {
               UUID uuid = this.parseUuid(key);
               ConfigurationSection section = legacyConfig.getConfigurationSection(key);
               if (uuid != null && section != null) {
                  migrated.put(uuid, this.readLegacyPlayerDataFromYaml(section));
               }
            }
         }

         if (migrated.isEmpty()) {
            return true;
         }

         this.cache.putAll(migrated);
         if (!this.savePlayerSnapshots(migrated, this.databaseGeneration)) {
            return false;
         }

         for (PlayerData pd : this.cache.values()) {
            pd.modified = false;
         }

         return true;
      } else {
         return true;
      }
   }

   @Override
   protected void loadPlayersFromYamlStorage() {
      if (this.yamlStorageFile != null && this.yamlStorageFile.exists() && this.yamlStorageFile.length() > 0L) {
         FileConfiguration data = YamlConfiguration.loadConfiguration(this.yamlStorageFile);
         ConfigurationSection players = data.getConfigurationSection("players");
         if (players != null) {
            for (String key : players.getKeys(false)) {
               UUID uuid = this.parseUuid(key);
               ConfigurationSection section = players.getConfigurationSection(key);
               if (uuid != null && section != null) {
                  this.cache.put(uuid, this.readPlayerDataFromYaml(section));
               }
            }

            for (PlayerData pd : this.cache.values()) {
               pd.modified = false;
            }
         }
      }
   }

   @Override
   protected boolean savePlayerSnapshotsToYaml(Map<UUID, PlayerData> snapshots) {
      if (this.yamlStorageFile == null) {
         this.yamlStorageFile = new File(this.getDataFolder(), "data.yml");
      }

      synchronized (this.databaseLock) {
         boolean var10000;
         try {
            FileConfiguration data = this.yamlStorageFile.exists() ? YamlConfiguration.loadConfiguration(this.yamlStorageFile) : new YamlConfiguration();

            for (Entry<UUID, PlayerData> entry : snapshots.entrySet()) {
               String path = "players." + entry.getKey().toString();
               data.set(path, null);
               this.writePlayerDataToYaml(data.createSection(path), entry.getValue());
            }

            data.save(this.yamlStorageFile);
            var10000 = true;
         } catch (Exception e) {
            return false;
         }

         return var10000;
      }
   }

   @Override
   protected void writePlayerDataToYaml(ConfigurationSection section, PlayerData pd) {
      section.set("name", pd.playerName != null ? pd.playerName : "");
      section.set("updated", pd.updatedAt);
      ConfigurationSection quests = section.createSection("quests");

      for (String category : CATEGORIES) {
         ConfigurationSection q = quests.createSection(category);
         q.set("stage", pd.stages.getOrDefault(category, 1));
         q.set("progress", pd.progress.getOrDefault(category, 0));
         q.set("skips", pd.skips.getOrDefault(category, 3));
         q.set("completed", pd.completed.getOrDefault(category, 0));
         q.set("skipped", pd.skipped.getOrDefault(category, 0));
         q.set("rewards_received", pd.rewardClaims.getOrDefault(category, 0));
         this.writeStageIdSetToYaml(q.createSection("completed_stages"), pd.completedStages.get(category));
         this.writeStageIdSetToYaml(q.createSection("skipped_stages"), pd.skippedStages.get(category));
         this.writeStageIdSetToYaml(q.createSection("claimed_rewards"), pd.claimedRewards.get(category));
      }

      ConfigurationSection purchases = section.createSection("purchases");

      for (Entry<String, Integer> entry : pd.purchases.entrySet()) {
         int split = entry.getKey().indexOf(58);
         if (split > 0 && split < entry.getKey().length() - 1 && entry.getValue() > 0) {
            String category = entry.getKey().substring(0, split);
            String itemId = entry.getKey().substring(split + 1);
            if (CATEGORY_SET.contains(category)) {
               purchases.set(category + "." + itemId, entry.getValue());
            }
         }
      }
   }

   @Override
   protected void writeStageIdSetToYaml(ConfigurationSection section, Set<Integer> stages) {
      if (stages != null && !stages.isEmpty()) {
         for (Integer stage : stages) {
            if (stage != null && stage > 0) {
               section.set(String.valueOf(stage), true);
            }
         }
      }
   }

   @Override
   protected PlayerData readPlayerDataFromYaml(ConfigurationSection section) {
      PlayerData pd = new PlayerData();
      pd.playerName = section.getString("name", "");
      pd.updatedAt = section.getLong("updated", 0L);
      ConfigurationSection quests = section.getConfigurationSection("quests");
      if (quests != null) {
         for (String category : CATEGORIES) {
            ConfigurationSection q = quests.getConfigurationSection(category);
            if (q != null) {
               if (q.contains("stage") || q.contains("st")) {
                  pd.stages.put(category, q.getInt("stage", q.getInt("st", 1)));
               }

               if (q.contains("progress") || q.contains("pr")) {
                  pd.progress.put(category, q.getInt("progress", q.getInt("pr", 0)));
               }

               if (q.contains("skips") || q.contains("sk")) {
                  pd.skips.put(category, q.getInt("skips", q.getInt("sk", 3)));
               }

               this.loadCounterFromYaml(q, pd.completed, category, "completed");
               this.loadCounterFromYaml(q, pd.skipped, category, "skipped");
               this.loadCounterFromYaml(q, pd.rewardClaims, category, "rewards_received");
               this.loadStageIdSetFromYaml(q.getConfigurationSection("completed_stages"), pd.completedStages, category);
               this.loadStageIdSetFromYaml(q.getConfigurationSection("skipped_stages"), pd.skippedStages, category);
               this.loadStageIdSetFromYaml(q.getConfigurationSection("claimed_rewards"), pd.claimedRewards, category);
            }
         }
      }

      this.loadPurchasesFromYaml(section.getConfigurationSection("purchases"), pd);
      pd.modified = false;
      return pd;
   }

   @Override
   protected PlayerData readLegacyPlayerDataFromYaml(ConfigurationSection section) {
      PlayerData pd = new PlayerData();

      for (String category : CATEGORIES) {
         ConfigurationSection q = section.getConfigurationSection(category);
         if (q != null) {
            pd.stages.put(category, q.getInt("st", 1));
            pd.progress.put(category, q.getInt("pr", 0));
            pd.skips.put(category, q.getInt("sk", 3));
         }
      }

      this.loadPurchasesFromYaml(section.getConfigurationSection("purchases"), pd);
      pd.modified = false;
      return pd;
   }

   @Override
   protected void loadCounterFromYaml(ConfigurationSection section, Map<String, Integer> target, String category, String key) {
      if (section.contains(key)) {
         target.put(category, Math.max(0, section.getInt(key, 0)));
      }
   }

   @Override
   protected void loadPurchasesFromYaml(ConfigurationSection purchases, PlayerData pd) {
      if (purchases != null) {
         for (String category : purchases.getKeys(false)) {
            ConfigurationSection catSec = purchases.getConfigurationSection(category);
            if (catSec != null) {
               for (String itemKey : catSec.getKeys(false)) {
                  int count = catSec.getInt(itemKey, 0);
                  if (count > 0) {
                     pd.purchases.put(category + ":" + itemKey, count);
                  }
               }
            }
         }
      }
   }

   @Override
   protected void loadStageIdSetFromYaml(ConfigurationSection section, Map<String, Set<Integer>> target, String category) {
      if (section != null) {
         Set<Integer> result = this.getStageIdSet(target, category);

         for (String key : section.getKeys(false)) {
            try {
               if (section.getBoolean(key, true)) {
                  result.add(Integer.parseInt(key));
               }
            } catch (NumberFormatException var8) {
            }
         }

         if (result.isEmpty()) {
            target.remove(category);
         }
      }
   }
}
