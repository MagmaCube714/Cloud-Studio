package cs.cloudstudio.manager.model;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;

public class QuestTemplate {
   public final Set<String> categories = new HashSet<>();
   public final ActionType action;
   public final Material material;
   public final EntityType entity;
   public final Material weapon;
   public final Material displayMaterial;
   public final int baseAmount;
   public final String name;
   public final double difficulty;

   public QuestTemplate(
      String[] categories,
      ActionType action,
      Material material,
      EntityType entity,
      Material weapon,
      Material displayMaterial,
      int baseAmount,
      String name,
      double difficulty
   ) {
      if (categories != null) {
         Collections.addAll(this.categories, categories);
      }

      this.action = action;
      this.material = material;
      this.entity = entity;
      this.weapon = weapon;
      this.displayMaterial = displayMaterial;
      this.baseAmount = Math.max(1, baseAmount);
      this.name = name != null && !name.trim().isEmpty() ? name : material.name();
      this.difficulty = Math.max(0.1, difficulty);
   }

   public boolean supports(String category) {
      return this.categories.contains(category) || this.categories.contains("all");
   }

   public String uniqueKey() {
      return this.action.name() + ":" + this.material.name() + ":" + (this.entity == null ? "" : this.entity.name());
   }

   public boolean sameTarget(QuestTemplate other) {
      if (other == null) {
         return false;
      } else if (this.action != other.action) {
         return false;
      } else {
         return this.material != other.material ? false : this.entity == other.entity;
      }
   }
}
