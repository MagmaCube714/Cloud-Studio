package cs.cloudstudio.manager.model;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Material;

public class SellerItem {
   public String id;
   public int slot;
   public Material material;
   public int amount;
   public boolean ench;
   public String texture;
   public String name;
   public List<String> lore;
   public double price;
   public int limit;
   public Integer modelData;
   public List<String> commands = new ArrayList<>();
}
