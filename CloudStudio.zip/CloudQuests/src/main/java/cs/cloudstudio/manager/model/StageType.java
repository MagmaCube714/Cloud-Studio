package cs.cloudstudio.manager.model;

public enum StageType {
   TASK,
   REWARD;
}
