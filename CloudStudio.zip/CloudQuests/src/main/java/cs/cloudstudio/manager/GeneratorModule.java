package cs.cloudstudio.manager;

import cs.cloudstudio.manager.model.ActionType;
import cs.cloudstudio.manager.model.GeneratedReward;
import cs.cloudstudio.manager.model.PlayerData;
import cs.cloudstudio.manager.model.QuestTemplate;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public abstract class GeneratorModule extends GeneratorTemplateModule {
   @Override
   protected boolean handleGenerate(CommandSender sender, String[] args) {
      String target = args.length < 2 ? "all" : args[1].toLowerCase(Locale.ROOT);
      if (args.length >= 3) {
         if (!CATEGORY_SET.contains(target)) {
            sender.sendMessage(this.color("&6Квесты &7» &cДля точечной генерации укажи категорию: &6/cloudquests regen <категория> <id>"));
            return true;
         }

         int questId;
         try {
            questId = Integer.parseInt(args[2]);
         } catch (NumberFormatException ex) {
            sender.sendMessage(this.color("&6Квесты &7» &cID квеста должен быть числом: &6/cloudquests regen " + target + " <id>"));
            return true;
         }

         this.reloadPluginConfig();
         this.reloadQuestsConfig();
         int totalStages = this.getGeneratorTotalRows(target) * 9;
         if (questId >= 1 && questId <= totalStages) {
            if ((questId - 1) % 9 == 8) {
               sender.sendMessage(this.color("&6Квесты &7» &cЭтап &6" + questId + " &cявляется наградой строки и не может быть сгенерирован как квест."));
               return true;
            }

            try {
               this.generateSingleQuest(target, questId);
               this.saveQuestsConfig();
               if (this.shouldResetProgressOnGenerate(Collections.singletonList(target))) {
                  this.resetGeneratedQuestProgress(target, questId);
               }

               this.loadAllData();
               this.closeQuestMenus();
               sender.sendMessage(this.color("&6Квесты &7» &aКвест &6" + target + " #" + questId + " &aперегенерирован. Остальная линия не изменена."));
            } catch (Throwable t) {
               this.getLogger().warning("[CloudQuests] Не удалось перегенерировать квест " + target + " #" + questId + ": " + t.getMessage());
               sender.sendMessage(this.color("&6Квесты &7» &cНе удалось перегенерировать квест &6" + target + " #" + questId + "&c. Проверь консоль."));
            }

            return true;
         } else {
            sender.sendMessage(this.color("&6Квесты &7» &cID квеста должен быть от &61 &cдо &6" + totalStages + "&c."));
            return true;
         }
      } else {
         List<String> targets = new ArrayList<>();
         if ("all".equals(target)) {
            Collections.addAll(targets, CATEGORIES);
         } else {
            if (!CATEGORY_SET.contains(target)) {
               sender.sendMessage(this.color("&6Квесты &7» &cНеизвестная категория: &6" + args[1]));
               return true;
            }

            targets.add(target);
         }

         this.reloadPluginConfig();
         this.reloadQuestsConfig();
         int stages = 0;
         List<String> failed = new ArrayList<>();
         int i = 0;

         for (int n = targets.size(); i < n; i++) {
            String category = targets.get(i);

            try {
               stages += this.generateQuestCategory(category);
            } catch (Throwable t) {
               failed.add(category);
            }
         }

         if (stages <= 0) {
            sender.sendMessage(this.color("&6Квесты &7» &cКвесты не были перегенерированы. Подробности смотри в консоли."));
            return true;
         }

         this.saveQuestsConfig();
         List<String> generatedTargets = new ArrayList<>(targets);
         generatedTargets.removeAll(failed);
         if (this.shouldResetProgressOnGenerate(generatedTargets)) {
            this.resetGeneratedProgress(generatedTargets);
         }

         try {
            this.loadAllData();
         } catch (Throwable t) {
            sender.sendMessage(this.color("&6Квесты &7» &cКвесты сохранены, но reload данных не прошёл. Перезапусти сервер и проверь консоль."));
            return true;
         }

         this.closeQuestMenus();
         String label = targets.size() == CATEGORIES.length ? "all" : targets.get(0);
         if (failed.isEmpty()) {
            sender.sendMessage(this.color("&6Квесты &7» &aКвесты перегенерированы: &6" + label + "&a. Этапов: &6" + stages));
         } else {
            sender.sendMessage(
               this.color("&6Квесты &7» &cКвесты перегенерированы частично: &6" + label + "&c. Этапов: &6" + stages + "&c. Ошибки: &6" + failed)
            );
         }

         return true;
      }
   }

   protected void generateSingleQuest(String category, int id) {
      FileConfiguration questCfg = this.getCategoryQuestsConfig(category);
      int rows = this.getGeneratorTotalRows(category);
      int totalStages = rows * 9;
      if (id >= 1 && id <= totalStages) {
         int slot = id - 1;
         int row = slot / 9;
         int col = slot % 9;
         if (col == 8) {
            throw new IllegalArgumentException("Reward stage cannot be generated as quest: " + id);
         }

         this.ensureCategoryRewards(category, 9, totalStages);
         ConfigurationSection section = questCfg.getConfigurationSection("quests");
         if (section == null) {
            section = questCfg.createSection("quests");
         }

         Set<String> rowTargets = new HashSet<>();
         int firstId = row * 9 + 1;
         int lastId = firstId + 7;

         for (int rowId = firstId; rowId <= lastId; rowId++) {
            ConfigurationSection existing = section.getConfigurationSection(Integer.toString(rowId));
            String key = this.configuredQuestTargetKey(existing);
            if (key != null) {
               rowTargets.add(key);
            }
         }

         List<QuestTemplate> templates = this.buildGeneratorTemplates(category);
         if (templates != null && !templates.isEmpty()) {
            QuestTemplate template = this.selectQuestTemplate(templates, rowTargets, category, row, col, rows);
            if (template == null) {
               throw new IllegalStateException("No suitable quest template for " + category + " #" + id);
            }

            int amount = this.calculateGeneratedAmount(category, template, row, col, rows);
            String path = Integer.toString(id);
            section.set(path, null);
            ConfigurationSection q = section.createSection(path);
            q.set("slot", slot);
            q.set("type", "TASK");
            q.set("action", template.action.name());
            q.set("material", template.material.name());
            q.set("amount", amount);
            q.set("name", template.name);
            if (template.action == ActionType.KILL && template.entity != null) {
               q.set("entity", template.entity.name());
            }

            if (template.weapon != null) {
               q.set("weapon", template.weapon.name());
            }
         } else {
            throw new IllegalStateException("No generator templates for category " + category);
         }
      } else {
         throw new IllegalArgumentException("Quest id out of range: " + id);
      }
   }

   protected String configuredQuestTargetKey(ConfigurationSection q) {
      if (q == null) {
         return null;
      }

      String action = q.getString("action", "BRING");
      String material = q.getString("material", "STONE");
      if (action != null && material != null) {
         action = action.toUpperCase(Locale.ROOT);
         material = material.toUpperCase(Locale.ROOT);
         String entity = q.getString("entity", "");
         if (entity == null) {
            entity = "";
         }

         entity = entity.toUpperCase(Locale.ROOT);
         return action + ":" + material + ":" + entity;
      } else {
         return null;
      }
   }

   protected void resetGeneratedQuestProgress(String category, int stageId) {
      for (PlayerData data : this.cache.values()) {
         if (data.stages.getOrDefault(category, 1) == stageId && data.progress.getOrDefault(category, 0) != 0) {
            data.progress.put(category, 0);
            this.markPlayerDataModified(data);
         }
      }

      if (this.dataSource != null) {
         try (
            Connection conn = this.dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement("UPDATE quest_progress SET progress = 0 WHERE category = ? AND stage = ?");
         ) {
            ps.setString(1, category);
            ps.setInt(2, stageId);
            ps.executeUpdate();
         } catch (SQLException e) {
            this.getLogger().warning("[CloudQuests] Не удалось сбросить прогресс точечно для " + category + " #" + stageId + ": " + e.getMessage());
         }
      }
   }

   @Override
   protected int generateQuestCategory(String category) {
      FileConfiguration questCfg = this.getCategoryQuestsConfig(category);
      int rows = this.getGeneratorTotalRows(category);
      int totalStages = rows * 9;
      int rewardInterval = 9;
      this.ensureCategoryRewards(category, rewardInterval, totalStages);
      ConfigurationSection section = this.recreateConfigurationSection(questCfg, "quests");
      List<QuestTemplate> templates = this.buildGeneratorTemplates(category);
      int created = 0;

      for (int row = 0; row < rows; row++) {
         Set<String> rowTargets = new HashSet<>();

         for (int col = 0; col < 9; col++) {
            int slot = row * 9 + col;
            int id = slot + 1;
            if (col == 8) {
               created++;
            } else {
               ConfigurationSection q = section.createSection(Integer.toString(id));
               q.set("slot", slot);
               QuestTemplate template = this.selectQuestTemplate(templates, rowTargets, category, row, col, rows);
               rowTargets.add(template.uniqueKey());
               int amount = this.calculateGeneratedAmount(category, template, row, col, rows);
               q.set("type", "TASK");
               q.set("action", template.action.name());
               q.set("material", template.material.name());
               q.set("amount", amount);
               q.set("name", template.name);
               if (template.action == ActionType.KILL && template.entity != null) {
                  q.set("entity", template.entity.name());
               }

               if (template.weapon != null) {
                  q.set("weapon", template.weapon.name());
               }

               created++;
            }
         }
      }

      return created;
   }

   @Override
   protected void ensureCategoryRewards(String category, int rewardInterval, int totalStages) {
      FileConfiguration rewardCfg = this.getCategoryRewardsConfig(category);
      ConfigurationSection rewards = rewardCfg.getConfigurationSection("rewards");
      if (rewards == null) {
         rewards = rewardCfg.createSection("rewards");
      }

      int rows = totalStages / rewardInterval;

      for (int row = 1; row <= rows; row++) {
         String key = Integer.toString(row);
         ConfigurationSection reward = rewards.getConfigurationSection(key);
         if (reward == null) {
            GeneratedReward generated = this.createDefaultGeneratedReward(category, row);
            reward = rewards.createSection(key);
            reward.set("slot", row * rewardInterval - 1);
            reward.set("material", generated.material.name());
            reward.set("commands", generated.commands);
         } else if (!reward.isSet("slot")) {
            reward.set("slot", row * rewardInterval - 1);
         }
      }
   }

   @Override
   protected ConfigurationSection recreateConfigurationSection(FileConfiguration cfg, String path) {
      cfg.set(path, null);
      ConfigurationSection section = cfg.getConfigurationSection(path);
      if (section != null) {
         return section;
      }

      String[] parts = path.split("\\.");
      ConfigurationSection current = cfg;

      for (int i = 0; i < parts.length; i++) {
         String part = parts[i];
         ConfigurationSection next = current.getConfigurationSection(part);
         if (next == null) {
            next = current.createSection(part);
         }

         current = next;
      }

      return current;
   }

   @Override
   protected Map<Integer, GeneratedReward> readGeneratedRewards(String category, int rewardInterval, int totalStages) {
      Map<Integer, GeneratedReward> result = new HashMap<>();
      FileConfiguration questCfg = this.getQuestsConfig();
      this.readRewardSection(result, questCfg.getConfigurationSection("menus." + category + ".quests"), category, rewardInterval, totalStages);
      this.readRewardTemplateSection(result, questCfg.getConfigurationSection("rewards." + category), category, rewardInterval, totalStages);
      if (result.isEmpty()) {
         this.readRewardSection(result, this.getConfig().getConfigurationSection("menus." + category + ".quests"), category, rewardInterval, totalStages);
      }

      for (int row = 1; row <= totalStages / rewardInterval; row++) {
         int id = row * rewardInterval;
         if (!result.containsKey(id)) {
            result.put(id, this.createDefaultGeneratedReward(category, row));
         }
      }

      return result;
   }

   @Override
   protected void readRewardTemplateSection(
      Map<Integer, GeneratedReward> result, ConfigurationSection section, String category, int rewardInterval, int totalStages
   ) {
      if (section != null) {
         for (String key : section.getKeys(false)) {
            int number;
            try {
               number = Integer.parseInt(key);
            } catch (NumberFormatException ignored) {
               continue;
            }

            int id = number * rewardInterval;
            if (id > 0 && id <= totalStages) {
               ConfigurationSection q = section.getConfigurationSection(key);
               if (q != null) {
                  GeneratedReward reward = new GeneratedReward();
                  reward.material = this.parseMaterial(q.getString("material", this.defaultRewardMaterial(number).name()));
                  reward.commands = q.getStringList("commands");
                  if (reward.commands == null || reward.commands.isEmpty()) {
                     reward.commands = this.createDefaultGeneratedReward(category, number).commands;
                  }

                  result.put(id, reward);
               }
            }
         }
      }
   }

   @Override
   protected void readRewardSection(Map<Integer, GeneratedReward> result, ConfigurationSection section, String category, int rewardInterval, int totalStages) {
      if (section != null) {
         for (String key : section.getKeys(false)) {
            int id;
            try {
               id = Integer.parseInt(key);
            } catch (NumberFormatException ignored) {
               continue;
            }

            if (id > 0 && id <= totalStages && id % rewardInterval == 0) {
               ConfigurationSection q = section.getConfigurationSection(key);
               if (q != null && "REWARD".equalsIgnoreCase(q.getString("type", ""))) {
                  GeneratedReward reward = new GeneratedReward();
                  reward.material = this.parseMaterial(q.getString("material", this.defaultRewardMaterial(id / rewardInterval).name()));
                  reward.commands = q.getStringList("commands");
                  if (reward.commands == null || reward.commands.isEmpty()) {
                     reward.commands = this.createDefaultGeneratedReward(category, id / rewardInterval).commands;
                  }

                  result.put(id, reward);
               }
            }
         }
      }
   }

   @Override
   protected GeneratedReward createDefaultGeneratedReward(String category, int number) {
      GeneratedReward reward = new GeneratedReward();
      reward.material = this.defaultRewardMaterial(number);
      reward.commands = new ArrayList<>();
      reward.commands.add("si give " + category + "_" + number + " 1 %player%");
      return reward;
   }

   @Override
   protected Material defaultRewardMaterial(int number) {
      switch (number) {
         case 1:
            return this.parseMaterial("PINK_SHULKER_BOX");
         case 2:
            return this.parseMaterial("LIME_SHULKER_BOX");
         case 3:
            return this.parseMaterial("YELLOW_SHULKER_BOX");
         case 4:
            return this.parseMaterial("LIGHT_BLUE_SHULKER_BOX");
         default:
            return this.parseMaterial("RED_SHULKER_BOX");
      }
   }

   @Override
   protected boolean shouldResetProgressOnGenerate(List<String> categories) {
      if (categories != null && !categories.isEmpty()) {
         for (String category : categories) {
            if (!this.getCategoryQuestsConfig(category)
               .getBoolean("settings.reset-progress-on-generate", this.getQuestsConfig().getBoolean("settings.reset-progress-on-generate", true))) {
               return false;
            }
         }

         return true;
      } else {
         return true;
      }
   }

   @Override
   protected void resetGeneratedProgress(List<String> categories) {
      if (categories != null && !categories.isEmpty()) {
         Set<String> set = new HashSet<>(categories);

         for (PlayerData data : this.cache.values()) {
            boolean changed = false;

            for (String category : set) {
               if (data.progress.getOrDefault(category, 0) != 0) {
                  data.progress.put(category, 0);
                  changed = true;
               }
            }

            if (changed) {
               this.markPlayerDataModified(data);
            }
         }

         if (this.dataSource != null) {
            try (
               Connection conn = this.dataSource.getConnection();
               PreparedStatement ps = conn.prepareStatement("UPDATE quest_progress SET progress = 0 WHERE category = ?");
            ) {
               for (String category : set) {
                  ps.setString(1, category);
                  ps.addBatch();
               }

               ps.executeBatch();
            } catch (SQLException var12) {
            }
         }
      }
   }
}
