package cs.cloudstudio.manager;

import cs.cloudstudio.manager.model.PlayerData;
import cs.cloudstudio.manager.model.Stage;
import cs.cloudstudio.manager.model.StageType;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public abstract class ProgressModule extends MessageModule {
   @Override
   public void addTaskProgress(Player p, String category, Stage activeStage, int amountToAdd) {
      if (amountToAdd > 0 && this.isCategoryUnlocked(p.getUniqueId(), category)) {
         UUID uuid = p.getUniqueId();
         int required = Math.max(1, activeStage.reqAmount);
         int current = this.getPlayerProgress(uuid, category);
         if (current < required) {
            long summed = (long)current + amountToAdd;
            int newProgress = summed >= 2147483647L ? Integer.MAX_VALUE : (int)summed;
            if (newProgress >= required) {
               int nextStageId = this.getNextProgressStageId(category, activeStage.id);
               this.recordTaskCompletion(uuid, category, activeStage);
               this.setPlayerStage(uuid, category, nextStageId);
               this.sendMsg(p, "ready_to_complete");
            } else {
               this.setPlayerProgress(uuid, category, newProgress);
            }
         }
      }
   }

   @Override
   public Stage getActiveStage(Player p, String category) {
      UUID uuid = p.getUniqueId();
      if (!this.isCategoryUnlocked(uuid, category)) {
         return null;
      }

      int stageId = this.normalizePlayerStageAfterRewards(uuid, category);
      return this.getStage(category, stageId);
   }

   protected boolean isCategoryUnlocked(UUID uuid, String category) {
      String requiredCategory = CATEGORY_PREREQ.get(category);
      if (requiredCategory == null) {
         return true;
      }

      if (!this.isCategoryUnlocked(uuid, requiredCategory)) {
         return false;
      }

      int requiredLastStageId = this.getLastStageId(requiredCategory);
      return requiredLastStageId > 0 && this.getPlayerStage(uuid, requiredCategory) > requiredLastStageId;
   }

   protected boolean ensureCategoryUnlocked(Player player, String category) {
      if (this.isCategoryUnlocked(player.getUniqueId(), category)) {
         return true;
      }

      this.sendMsg(player, "quests_no_ready");
      return false;
   }

   @Override
   protected Stage getStage(String category, int stageId) {
      Map<Integer, Stage> stages = this.stagesByCategoryAndId.get(category);
      return stages != null ? stages.get(stageId) : null;
   }

   @Override
   protected Stage getStageBySlot(String category, int slot) {
      Map<Integer, Stage> bySlot = this.stagesBySlot.get(category);
      return bySlot != null ? bySlot.get(slot) : null;
   }

   @Override
   protected void handleSkip(Player p, String category) {
      if (this.ensureCategoryUnlocked(p, category)) {
         UUID uuid = p.getUniqueId();
         int skips = this.getSkipsLeft(uuid, category);
         if (skips <= 0) {
            this.sendMsg(p, "quest_no_skips");
         } else {
            PlayerData rollback = this.copyPlayerData(this.getPlayerData(uuid));
            int[] result = this.skipSingleStage(uuid, p.getName(), category);
            if (result[4] == 0) {
               this.sendMsg(p, "quest_line_all_skipped", category);
            } else {
               this.setSkipsLeft(uuid, category, skips - 1);
               if (!this.savePlayerDataSync(uuid)) {
                  this.cache.put(uuid, rollback);
                  p.sendMessage(this.color("&6Квесты &7» &cКвест не был пропущен: не удалось сохранить данные. Попробуйте позже."));
               } else {
                  if (result[3] == 1) {
                     this.sendMsg(p, "quest_line_all_skipped", category);
                  } else {
                     this.sendMsg(p, "quest_skipped");
                  }
               }
            }
         }
      }
   }

   @Override
   protected int[] skipSingleStage(UUID target, String name, String category) {
      return this.skipQuestStages(target, name, category, false, false);
   }

   @Override
   protected int[] skipCurrentQuestLine(UUID target, String name, String category) {
      return this.skipQuestStages(target, name, category, true, false);
   }

   @Override
   protected int[] skipRemainingQuestStages(UUID target, String name, String category) {
      return this.skipQuestStages(target, name, category, false, true);
   }

   @Override
   protected int[] skipQuestStages(UUID target, String playerNameFallback, String category, boolean stopAtReward, boolean allRemaining) {
      this.updatePlayerIdentity(target, playerNameFallback);
      int currentStageId = this.getPlayerStage(target, category);
      List<Stage> stages = this.categoryStages.get(category);
      if (stages != null && !stages.isEmpty()) {
         int lastStageId = stages.get(stages.size() - 1).id;
         if (currentStageId > lastStageId) {
            return new int[]{currentStageId, 0, 0, 1, 0};
         }

         int taskSkips = 0;
         int lastSkippedId = currentStageId;
         boolean skippedAny = false;
         int i = 0;

         for (int n = stages.size(); i < n; i++) {
            Stage stage = stages.get(i);
            if (stage.id >= currentStageId) {
               skippedAny = true;
               lastSkippedId = stage.id;
               if (stage.type == StageType.REWARD) {
                  if (stopAtReward && !allRemaining) {
                     break;
                  }
               } else {
                  this.recordStageSkip(target, category, stage);
                  taskSkips++;
               }

               if (!allRemaining && !stopAtReward) {
                  break;
               }
            }
         }

         if (!skippedAny) {
            this.setPlayerStage(target, category, lastStageId + 1);
            return new int[]{lastStageId + 1, 0, 0, 1, 0};
         } else {
            i = allRemaining ? lastStageId + 1 : this.getNextProgressStageId(category, lastSkippedId);
            this.setPlayerStage(target, category, i);
            return new int[]{i, taskSkips, 0, i > lastStageId ? 1 : 0, 1};
         }
      } else {
         return new int[]{currentStageId, 0, 0, 1, 0};
      }
   }

   @Override
   protected void recordTaskCompletion(UUID u, String category, Stage stage) {
      PlayerData pd = this.getPlayerData(u);
      if (stage != null && this.getStageIdSet(pd.completedStages, category).add(stage.id)) {
         this.incrementCounter(pd.completed, category, 1);
      } else if (stage == null) {
         this.incrementCounter(pd.completed, category, 1);
      }

      this.markPlayerDataModified(pd);
   }

   @Override
   protected void recordStageSkip(UUID u, String category, Stage stage) {
      PlayerData pd = this.getPlayerData(u);
      if (stage != null && this.getStageIdSet(pd.skippedStages, category).add(stage.id)) {
         this.incrementCounter(pd.skipped, category, 1);
      } else if (stage == null) {
         this.incrementCounter(pd.skipped, category, 1);
      }

      this.markPlayerDataModified(pd);
   }

   @Override
   protected boolean hasClaimedReward(UUID u, String category, Stage stage) {
      if (stage == null) {
         return false;
      }

      Set<Integer> set = this.getPlayerData(u).claimedRewards.get(category);
      return set != null && set.contains(stage.id);
   }

   @Override
   protected boolean recordRewardClaim(UUID u, String category, Stage stage) {
      if (stage == null) {
         return false;
      } else {
         PlayerData pd = this.getPlayerData(u);
         if (this.getStageIdSet(pd.claimedRewards, category).add(stage.id)) {
            this.incrementCounter(pd.rewardClaims, category, 1);
            this.markPlayerDataModified(pd);
            return true;
         } else {
            return false;
         }
      }
   }

   @Override
   protected void incrementCounter(Map<String, Integer> map, String category, int value) {
      if (value > 0) {
         long next = (long)map.getOrDefault(category, 0).intValue() + value;
         map.put(category, next >= 2147483647L ? Integer.MAX_VALUE : (int)next);
      }
   }

   @Override
   protected void markPlayerDataModified(PlayerData pd) {
      pd.modified = true;
      pd.dirtyEpoch++;
   }

   @Override
   protected Set<Integer> getStageIdSet(Map<String, Set<Integer>> map, String category) {
      Set<Integer> set = map.get(category);
      if (set == null) {
         set = new HashSet<>();
         map.put(category, set);
      }

      return set;
   }

   @Override
   protected void updatePlayerIdentity(UUID uuid, String playerName) {
      if (uuid != null && playerName != null && !playerName.isEmpty()) {
         PlayerData pd = this.getPlayerData(uuid);
         if (!playerName.equals(pd.playerName)) {
            pd.playerName = playerName;
            this.markPlayerDataModified(pd);
         }
      }
   }

   @Override
   protected int getNextValidStageId(String category, int currentId) {
      List<Stage> stages = this.categoryStages.get(category);
      if (stages == null) {
         return currentId + 1;
      }

      boolean found = false;
      int i = 0;

      for (int n = stages.size(); i < n; i++) {
         Stage s = stages.get(i);
         if (found) {
            return s.id;
         }

         if (s.id == currentId) {
            found = true;
         }
      }

      return currentId + 1;
   }

   @Override
   protected int getNextProgressStageId(String category, int currentId) {
      return this.skipRewardStages(category, this.getNextValidStageId(category, currentId));
   }

   @Override
   protected int skipRewardStages(String category, int stageId) {
      int nextId = stageId;

      for (Stage stage = this.getStage(category, nextId); stage != null && stage.type == StageType.REWARD; stage = this.getStage(category, nextId)) {
         nextId = this.getNextValidStageId(category, nextId);
      }

      return nextId;
   }

   @Override
   protected int normalizePlayerStageAfterRewards(UUID uuid, String category) {
      int currentStageId = this.getPlayerStage(uuid, category);
      int normalized = this.skipRewardStages(category, currentStageId);
      if (normalized != currentStageId) {
         this.setPlayerStage(uuid, category, normalized);
      }

      return normalized;
   }

   @Override
   protected int getLastStageId(String category) {
      Integer v = this.lastStageIdCache.get(category);
      return v != null ? v : 0;
   }

   @Override
   protected int getAmount(Player p, Material m) {
      if (m == null) {
         return 0;
      }

      int total = 0;
      ItemStack[] storage = p.getInventory().getStorageContents();
      int i = 0;

      for (int n = storage.length; i < n; i++) {
         ItemStack it = storage[i];
         if (this.isQuestConsumableItem(it, m)) {
            total += it.getAmount();
         }
      }

      return total;
   }

   @Override
   protected int removeItems(Player p, Material m, int amountToRemove) {
      if (m != null && amountToRemove > 0) {
         Inventory inv = p.getInventory();
         ItemStack[] storage = inv.getStorageContents();
         int size = storage.length;
         int requested = amountToRemove;
         boolean mutated = false;

         for (int i = 0; i < size && amountToRemove > 0; i++) {
            ItemStack item = storage[i];
            if (this.isQuestConsumableItem(item, m)) {
               int amt = item.getAmount();
               if (amt > amountToRemove) {
                  item.setAmount(amt - amountToRemove);
                  amountToRemove = 0;
               } else {
                  storage[i] = null;
                  amountToRemove -= amt;
               }

               mutated = true;
            }
         }

         if (mutated) {
            inv.setStorageContents(storage);
         }

         return requested - amountToRemove;
      } else {
         return 0;
      }
   }

   @Override
   protected boolean isQuestConsumableItem(ItemStack item, Material material) {
      if (item == null || item.getType() != material || item.getAmount() <= 0) {
         return false;
      }

      if (!this.getQuestsConfig().getBoolean("settings.ignore-custom-items", true)) {
         return true;
      }

      if (!item.hasItemMeta()) {
         return true;
      }

      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return true;
      }

      if (!meta.hasDisplayName() && !meta.hasLore() && !meta.hasEnchants()) {
         try {
            if (meta.hasCustomModelData()) {
               return false;
            }
         } catch (Throwable var5) {
         }

         return true;
      } else {
         return false;
      }
   }

   @Override
   protected void giveItemsSafely(Player p, Material material, int amount) {
      if (p != null && material != null && amount > 0) {
         int max = Math.max(1, material.getMaxStackSize());

         while (amount > 0) {
            int stackAmount = Math.min(max, amount);
            Map<Integer, ItemStack> leftovers = p.getInventory().addItem(new ItemStack[]{new ItemStack(material, stackAmount)});
            if (!leftovers.isEmpty()) {
               for (ItemStack left : leftovers.values()) {
                  if (left != null && left.getType() != Material.AIR && left.getAmount() > 0) {
                     p.getWorld().dropItemNaturally(p.getLocation(), left);
                  }
               }
            }

            amount -= stackAmount;
         }
      }
   }

   @Override
   protected PlayerData getPlayerData(UUID u) {
      PlayerData pd = this.cache.get(u);
      return pd != null ? pd : this.cache.computeIfAbsent(u, k -> new PlayerData());
   }

   @Override
   protected int getPlayerStage(UUID u, String category) {
      PlayerData pd = this.cache.get(u);
      if (pd == null) {
         return 1;
      }

      Integer v = pd.stages.get(category);
      return v != null ? v : 1;
   }

   @Override
   protected void setPlayerStage(UUID u, String category, int value) {
      PlayerData pd = this.getPlayerData(u);
      int sanitized = Math.max(1, value);
      Integer oldStage = pd.stages.put(category, sanitized);
      Integer oldProgress = pd.progress.put(category, 0);
      if (oldStage == null || oldStage != sanitized || oldProgress == null || oldProgress != 0) {
         this.markPlayerDataModified(pd);
      }
   }

   @Override
   protected int getPlayerProgress(UUID u, String category) {
      PlayerData pd = this.cache.get(u);
      if (pd == null) {
         return 0;
      }

      Integer v = pd.progress.get(category);
      return v != null ? v : 0;
   }

   @Override
   protected void setPlayerProgress(UUID u, String category, int value) {
      PlayerData pd = this.getPlayerData(u);
      int sanitized = Math.max(0, value);
      Integer old = pd.progress.put(category, sanitized);
      if (old == null || old != sanitized) {
         this.markPlayerDataModified(pd);
      }
   }

   @Override
   protected int getSkipsLeft(UUID u, String category) {
      PlayerData pd = this.cache.get(u);
      if (pd == null) {
         return 3;
      }

      Integer v = pd.skips.get(category);
      return v != null ? v : 3;
   }

   @Override
   protected void setSkipsLeft(UUID u, String category, int value) {
      PlayerData pd = this.getPlayerData(u);
      int sanitized = Math.max(0, value);
      Integer old = pd.skips.put(category, sanitized);
      if (old == null || old != sanitized) {
         this.markPlayerDataModified(pd);
      }
   }

   @Override
   protected int getPurchases(UUID u, String category, String itemId) {
      PlayerData pd = this.cache.get(u);
      if (pd == null) {
         return 0;
      }

      Integer v = pd.purchases.get(category + ":" + itemId);
      return v != null ? v : 0;
   }

   @Override
   protected void addPurchase(UUID u, String category, String itemId) {
      PlayerData pd = this.getPlayerData(u);
      String key = category + ":" + itemId;
      int current = pd.purchases.getOrDefault(key, 0);
      pd.purchases.put(key, current < Integer.MAX_VALUE ? current + 1 : Integer.MAX_VALUE);
      this.markPlayerDataModified(pd);
   }

   @Override
   protected void removePurchase(UUID u, String category, String itemId) {
      PlayerData pd = this.getPlayerData(u);
      String key = category + ":" + itemId;
      int current = pd.purchases.getOrDefault(key, 0);
      if (current <= 1) {
         pd.purchases.remove(key);
      } else {
         pd.purchases.put(key, current - 1);
      }

      this.markPlayerDataModified(pd);
   }
}
