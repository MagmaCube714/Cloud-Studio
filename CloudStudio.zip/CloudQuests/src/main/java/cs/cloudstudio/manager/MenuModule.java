package cs.cloudstudio.manager;

import cs.cloudstudio.manager.model.ActionType;
import cs.cloudstudio.manager.model.PlayerData;
import cs.cloudstudio.manager.model.SellerItem;
import cs.cloudstudio.manager.model.SellerMenu;
import cs.cloudstudio.manager.model.Stage;
import cs.cloudstudio.manager.model.StageType;
import cs.cloudstudio.menu.QuestMenuHolder;
import cs.cloudstudio.menu.SellerMenuHolder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

public abstract class MenuModule extends GeneratorModule {
   @Override
   protected void handleMenuOpen(Player p, String category) {
      if (!this.categoryStages.containsKey(category)) {
         p.sendMessage(this.color("&6Квесты &7» &cКатегория " + category + " не найдена"));
      } else if (this.ensureCategoryUnlocked(p, category)) {
         UUID uuid = p.getUniqueId();
         int currentStageId = this.getPlayerStage(uuid, category);
         int lastId = this.getLastStageId(category);
         if (lastId > 0 && currentStageId > lastId && !this.hasUnclaimedReadyReward(uuid, category)) {
            this.openSellerMenu(p, category);
         } else {
            this.openQuestMenu(p, category);
         }
      }
   }

   @Override
   protected boolean hasUnclaimedReadyReward(UUID uuid, String category) {
      List<Stage> rewards = this.rewardStagesByCategory.get(category);
      if (rewards != null && !rewards.isEmpty()) {
         int currentStageId = this.getPlayerStage(uuid, category);
         PlayerData pd = this.getPlayerData(uuid);
         Set<Integer> claimed = pd.claimedRewards.get(category);
         int i = 0;

         for (int n = rewards.size(); i < n; i++) {
            Stage stage = rewards.get(i);
            if (stage.id <= currentStageId && (claimed == null || !claimed.contains(stage.id))) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   @Override
   protected void openSellerMenu(Player p, String category) {
      if (this.ensureCategoryUnlocked(p, category)) {
         SellerMenu sm = this.sellerMenus.get(category);
         if (sm == null) {
            p.sendMessage(this.color("&6Квесты &7» &cФайл quests/" + category + "/seller.yml не настроен"));
         } else {
            Inventory inv = Bukkit.createInventory(new SellerMenuHolder(category), sm.size, this.formatMenuTitle(p, sm.title, category));
            UUID uuid = p.getUniqueId();

            for (SellerItem item : sm.items.values()) {
               int purchased = this.getPurchases(uuid, category, item.id);
               inv.setItem(item.slot, this.buildSellerItemStack(p, category, item, purchased));
            }

            p.openInventory(inv);
         }
      }
   }

   @Override
   protected ItemStack buildSellerItemStack(Player p, String category, SellerItem item, int purchased) {
      ItemStack is = new ItemStack(item.material, item.amount);
      ItemMeta meta = is.getItemMeta();
      if (meta == null) {
         return is;
      }

      Map<String, String> ph = this.createBasePlaceholders(p, category);
      meta.setDisplayName(this.applyDynamicPlaceholders(p, item.name, ph));
      String formattedPrice = formatPrice(item.price);
      String purchasedStr = Integer.toString(purchased);
      String limitStr = Integer.toString(item.limit);
      List<String> rawLore = item.lore;
      List<String> lore = new ArrayList<>(rawLore.size());
      int i = 0;

      for (int n = rawLore.size(); i < n; i++) {
         String line = rawLore.get(i);
         if (line.indexOf(123) >= 0) {
            line = line.replace("{price}", formattedPrice).replace("{purchased}", purchasedStr).replace("{limit}", limitStr);
         }

         lore.add(this.applyDynamicPlaceholders(p, line, ph));
      }

      meta.setLore(lore);
      if (item.modelData != null) {
         meta.setCustomModelData(item.modelData);
      }

      if (item.ench) {
         meta.addEnchant(Enchantment.UNBREAKING, 1, true);
      }

      meta.addItemFlags(ALL_ITEM_FLAGS);
      if (item.material == Material.PLAYER_HEAD && item.texture != null && !item.texture.isEmpty() && meta instanceof SkullMeta) {
         applySkullTexture((SkullMeta)meta, item.texture);
      }

      is.setItemMeta(meta);
      return is;
   }

   @Override
   protected void openQuestMenu(Player p, String category) {
      if (this.ensureCategoryUnlocked(p, category)) {
         List<Stage> stages = this.categoryStages.get(category);
         if (stages != null && !stages.isEmpty()) {
            UUID uuid = p.getUniqueId();
            int currentStageId = this.getPlayerStage(uuid, category);
            int firstStageId = stages.get(0).id;
            if (currentStageId < firstStageId) {
               this.setPlayerStage(uuid, category, firstStageId);
            }

            currentStageId = this.normalizePlayerStageAfterRewards(uuid, category);
            Inventory inv = Bukkit.createInventory(new QuestMenuHolder(category), this.menuSize, this.formatMenuTitle(p, this.menuName, category));
            int currentProgress = this.getPlayerProgress(uuid, category);
            int skipsLeft = this.getSkipsLeft(uuid, category);
            String skipsStr = Integer.toString(skipsLeft);
            Map<String, String> ph = this.createBasePlaceholders(p, category);
            int i = 0;

            for (int n = stages.size(); i < n; i++) {
               Stage s = stages.get(i);
               if (s.slot < this.menuSize) {
                  boolean isCompleted = s.id < currentStageId;
                  boolean isActive = s.id == currentStageId;
                  boolean isLocked = s.id > currentStageId;
                  String actionTranslation = s.type == StageType.TASK ? this.getActionName(s.action) : this.getActionName(ActionType.BRING);
                  ph.put("<quest_target>", s.itemName);
                  ph.put("<quest_type>", actionTranslation);
                  String reqStr = Integer.toString(s.reqAmount);
                  ph.put("<quest_requirement>", reqStr);
                  ph.put("<quest_progress>", isActive ? Integer.toString(currentProgress) : (isCompleted ? reqStr : "0"));
                  ph.put("<quest_skip>", skipsStr);
                  ph.put("<enchantments>", "");
                  ph.put("<quest_title>", s.itemName);
                  ph.put("%id%", category);
                  ph.put("%quest_id%", Integer.toString(s.id));
                  ItemStack item;
                  if (s.type == StageType.TASK) {
                     if (isLocked) {
                        item = this.buildLockedItem(ph);
                     } else if (isCompleted) {
                        item = this.buildItem(s.displayMaterial, "quest_title", "quest_completed_description", ph);
                     } else {
                        String lorePath = skipsLeft <= 0 ? "quest_not_completed_no_skips_description" : "quest_not_completed_description";
                        item = this.buildItem(s.displayMaterial, "quest_title", lorePath, ph);
                     }
                  } else {
                     boolean rewardClaimed = this.hasClaimedReward(uuid, category, s);
                     if (rewardClaimed) {
                        item = this.buildRewardItem(s.displayMaterial, "already-given", ph);
                     } else if (!isActive && !isCompleted) {
                        item = this.buildRewardItem(s.displayMaterial, "locked-reward", ph);
                     } else {
                        item = this.buildRewardItem(s.displayMaterial, "unlock-reward", ph);
                     }
                  }

                  inv.setItem(s.slot, item);
               }
            }

            p.openInventory(inv);
         }
      }
   }

   @Override
   protected ItemStack buildLockedItem(Map<String, String> ph) {
      ItemStack item = new ItemStack(Material.BARRIER);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      List<String> titleLines = this.getMsgLines("quest_not_opened_title", ph);
      List<String> descLines = this.getMsgLines("quest_not_opened", ph);
      meta.setDisplayName(!titleLines.isEmpty() ? titleLines.get(0) : "§c§lНЕДОСТУПНО");
      List<String> lore = new ArrayList<>(titleLines.size() + descLines.size());
      int i = 1;

      for (int n = titleLines.size(); i < n; i++) {
         lore.add(titleLines.get(i));
      }

      lore.addAll(descLines);
      meta.setLore(lore);
      meta.addItemFlags(ALL_ITEM_FLAGS);
      item.setItemMeta(meta);
      return item;
   }

   @Override
   protected ItemStack buildItem(Material mat, String namePath, String lorePath, Map<String, String> ph) {
      ItemStack item = new ItemStack(mat);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      List<String> nameLines = this.getMsgLines(namePath, ph);
      List<String> loreLines = this.getMsgLines(lorePath, ph);
      meta.setDisplayName(!nameLines.isEmpty() ? nameLines.get(0) : "");
      meta.setLore(loreLines);
      meta.addItemFlags(ALL_ITEM_FLAGS);
      item.setItemMeta(meta);
      return item;
   }

   @Override
   protected ItemStack buildRewardItem(Material mat, String rewardKey, Map<String, String> ph) {
      ItemStack item = new ItemStack(mat);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      String name = this.rewardNameCache.get(rewardKey);
      if (name == null) {
         name = "§b§lНаграда";
      }

      List<String> loreRaw = this.rewardLoreCache.get(rewardKey);
      if (loreRaw == null) {
         loreRaw = Collections.emptyList();
      }

      meta.setDisplayName(this.applyPlaceholders(name, ph));
      List<String> lore = new ArrayList<>(loreRaw.size());
      int i = 0;

      for (int n = loreRaw.size(); i < n; i++) {
         lore.add(this.applyPlaceholders(loreRaw.get(i), ph));
      }

      meta.setLore(lore);
      meta.addItemFlags(ALL_ITEM_FLAGS);
      item.setItemMeta(meta);
      return item;
   }

   @Override
   public boolean hasPluginMenuOpen(Player player) {
      Inventory topInventory = player.getOpenInventory().getTopInventory();
      if (topInventory == null) {
         return false;
      }

      InventoryHolder holder = topInventory.getHolder();
      return holder instanceof QuestMenuHolder || holder instanceof SellerMenuHolder;
   }

   @Override
   protected boolean shouldOpenSellerAfterRewardClaim(UUID uuid, String category) {
      int lastStageId = this.getLastStageId(category);
      return lastStageId > 0 && this.getPlayerStage(uuid, category) > lastStageId && !this.hasUnclaimedReadyReward(uuid, category);
   }

   @Override
   protected void handleSellerClick(Player p, String category, int slot) {
      if (this.ensureCategoryUnlocked(p, category)) {
         SellerMenu menu = this.sellerMenus.get(category);
         if (menu != null) {
            SellerItem item = menu.items.get(slot);
            if (item != null) {
               UUID uuid = p.getUniqueId();
               int purchased = this.getPurchases(uuid, category, item.id);
               if (item.limit <= 0 || purchased >= item.limit) {
                  p.sendMessage(menu.msgLimit);
               } else if (item.commands != null && !item.commands.isEmpty()) {
                  if (item.price > 0.0) {
                     if (this.econ == null) {
                        p.sendMessage(this.color("&6Квесты &7» &cЭкономика временно недоступна."));
                        return;
                     }

                     if (this.econ.getBalance(p) < item.price) {
                        p.sendMessage(menu.msgNoMoney);
                        return;
                     }

                     EconomyResponse response = this.econ.withdrawPlayer(p, item.price);
                     if (!response.transactionSuccess()) {
                        p.sendMessage(this.color("&6Квесты &7» &cОшибка при оплате: " + response.errorMessage));
                        return;
                     }
                  }

                  this.addPurchase(uuid, category, item.id);
                  if (!this.savePlayerDataSync(uuid)) {
                     this.removePurchase(uuid, category, item.id);
                     if (item.price > 0.0 && this.econ != null) {
                        this.econ.depositPlayer(p, item.price);
                     }

                     p.sendMessage(this.color("&6Квесты &7» &cПокупка отменена: не удалось сохранить данные. Попробуйте позже."));
                  } else if (!this.dispatchConfiguredCommands(p, p.getName(), category, item.commands, null)) {
                     p.sendMessage(this.color("&6Квесты &7» &cПокупка сохранена, но команда выдачи вернула ошибку. Обратитесь к администратору."));
                  } else {
                     p.sendMessage(menu.msgSuccess);
                     int newPurchased = purchased < Integer.MAX_VALUE ? purchased + 1 : Integer.MAX_VALUE;
                     Inventory top = p.getOpenInventory().getTopInventory();
                     if (top != null && top.getHolder() instanceof SellerMenuHolder && ((SellerMenuHolder)top.getHolder()).category.equals(category)) {
                        top.setItem(item.slot, this.buildSellerItemStack(p, category, item, newPurchased));
                     } else {
                        this.openSellerMenu(p, category);
                     }
                  }
               } else {
                  p.sendMessage(this.color("&6Квесты &7» &cПокупка недоступна: команда выдачи предмета не настроена."));
               }
            }
         }
      }
   }

   @Override
   protected void handleQuestClick(Player p, String category, int slot) {
      if (this.ensureCategoryUnlocked(p, category)) {
         if (slot >= 0 && slot < this.menuSize) {
            UUID uuid = p.getUniqueId();
            int currentStageId = this.getPlayerStage(uuid, category);
            Stage clickedStage = this.getStageBySlot(category, slot);
            if (clickedStage != null) {
               if (clickedStage.type == StageType.REWARD) {
                  if (!this.hasClaimedReward(uuid, category, clickedStage)) {
                     if (clickedStage.id > currentStageId) {
                        this.sendMsg(p, "reward_not_ready");
                     } else if (clickedStage.rewardCommands != null && !clickedStage.rewardCommands.isEmpty()) {
                        PlayerData rollback = this.copyPlayerData(this.getPlayerData(uuid));
                        this.recordRewardClaim(uuid, category, clickedStage);
                        if (clickedStage.id == currentStageId) {
                           this.setPlayerStage(uuid, category, this.getNextProgressStageId(category, currentStageId));
                        }

                        if (!this.savePlayerDataSync(uuid)) {
                           this.cache.put(uuid, rollback);
                           p.sendMessage(this.color("&6Квесты &7» &cНаграда не была выдана: не удалось сохранить данные. Попробуйте позже."));
                        } else {
                           if (!this.dispatchRewardCommands(p, p.getName(), category, clickedStage)) {
                              p.sendMessage(
                                 this.color(
                                    "&6Квесты &7» &cНаграда уже сохранена как полученная, но команда выдачи вернула ошибку. Обратитесь к администратору."
                                 )
                              );
                           } else {
                              this.sendMsg(p, "successful_reward");
                           }

                           if (this.shouldOpenSellerAfterRewardClaim(uuid, category)) {
                              this.openSellerMenu(p, category);
                           } else {
                              this.handleMenuOpen(p, category);
                           }
                        }
                     } else {
                        p.sendMessage(this.color("&6Квесты &7» &cНаграда не была выдана: commands у reward-этапа пустые."));
                     }
                  }
               } else if (clickedStage.id == currentStageId && clickedStage.type == StageType.TASK) {
                  if (clickedStage.action == ActionType.BRING) {
                     int current = this.getPlayerProgress(uuid, category);
                     int has = this.getAmount(p, clickedStage.reqMaterial);
                     if (has > 0) {
                        int needed = Math.max(1, clickedStage.reqAmount) - current;
                        if (needed > 0) {
                           int take = Math.min(needed, has);
                           PlayerData rollback = this.copyPlayerData(this.getPlayerData(uuid));
                           int removed = this.removeItems(p, clickedStage.reqMaterial, take);
                           if (removed > 0) {
                              int newProgress = current + removed;
                              if (newProgress >= Math.max(1, clickedStage.reqAmount)) {
                                 this.recordTaskCompletion(uuid, category, clickedStage);
                                 this.setPlayerStage(uuid, category, this.getNextProgressStageId(category, currentStageId));
                                 if (!this.savePlayerDataSync(uuid)) {
                                    this.cache.put(uuid, rollback);
                                    this.giveItemsSafely(p, clickedStage.reqMaterial, removed);
                                    p.sendMessage(this.color("&6Квесты &7» &cПредметы возвращены: не удалось сохранить прогресс. Попробуйте позже."));
                                    return;
                                 }

                                 this.sendMsg(p, "ready_to_complete");
                              } else {
                                 this.setPlayerProgress(uuid, category, newProgress);
                                 if (!this.savePlayerDataSync(uuid)) {
                                    this.cache.put(uuid, rollback);
                                    this.giveItemsSafely(p, clickedStage.reqMaterial, removed);
                                    p.sendMessage(this.color("&6Квесты &7» &cПредметы возвращены: не удалось сохранить прогресс. Попробуйте позже."));
                                    return;
                                 }
                              }

                              this.handleMenuOpen(p, category);
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   protected void closeQuestMenus() {
      for (Player player : Bukkit.getOnlinePlayers()) {
         Inventory top = player.getOpenInventory().getTopInventory();
         if (top != null) {
            InventoryHolder holder = top.getHolder();
            if (holder instanceof QuestMenuHolder || holder instanceof SellerMenuHolder) {
               player.closeInventory();
            }
         }
      }
   }
}
