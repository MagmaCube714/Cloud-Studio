package cs.cloudstudio.database;

public final class SqliteDialect implements SqlDialect {
   @Override
   public String[] schemaSql() {
      return new String[]{
         "CREATE TABLE IF NOT EXISTS players (uuid TEXT PRIMARY KEY NOT NULL, name TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL DEFAULT 0)",
         "CREATE TABLE IF NOT EXISTS quest_progress (uuid TEXT NOT NULL, category TEXT NOT NULL, stage INTEGER NOT NULL DEFAULT 1, progress INTEGER NOT NULL DEFAULT 0, legacy_skips INTEGER NOT NULL DEFAULT 3, completed INTEGER NOT NULL DEFAULT 0, skipped INTEGER NOT NULL DEFAULT 0, rewards_received INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(uuid, category), FOREIGN KEY(uuid) REFERENCES players(uuid) ON DELETE CASCADE)",
         "CREATE TABLE IF NOT EXISTS completed_stages (uuid TEXT NOT NULL, category TEXT NOT NULL, stage INTEGER NOT NULL, PRIMARY KEY(uuid, category, stage), FOREIGN KEY(uuid) REFERENCES players(uuid) ON DELETE CASCADE)",
         "CREATE TABLE IF NOT EXISTS skipped_stages (uuid TEXT NOT NULL, category TEXT NOT NULL, stage INTEGER NOT NULL, PRIMARY KEY(uuid, category, stage), FOREIGN KEY(uuid) REFERENCES players(uuid) ON DELETE CASCADE)",
         "CREATE TABLE IF NOT EXISTS claimed_rewards (uuid TEXT NOT NULL, category TEXT NOT NULL, stage INTEGER NOT NULL, PRIMARY KEY(uuid, category, stage), FOREIGN KEY(uuid) REFERENCES players(uuid) ON DELETE CASCADE)",
         "DROP TABLE IF EXISTS skipped_rewards",
         "CREATE TABLE IF NOT EXISTS purchases (uuid TEXT NOT NULL, category TEXT NOT NULL, item_id TEXT NOT NULL, amount INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(uuid, category, item_id), FOREIGN KEY(uuid) REFERENCES players(uuid) ON DELETE CASCADE)",
         "CREATE INDEX IF NOT EXISTS idx_quest_progress_category ON quest_progress(category)",
         "CREATE INDEX IF NOT EXISTS idx_purchases_category ON purchases(category)"
      };
   }

   @Override
   public String upsertPlayerSql() {
      return "INSERT INTO players(uuid, name, updated_at) VALUES(?, ?, ?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name, updated_at=excluded.updated_at";
   }
}
