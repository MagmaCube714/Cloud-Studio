package cs.cloudstudio.database;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.Statement;
import java.util.logging.Logger;
import javax.sql.DataSource;

public final class DriverManagerDataSource implements DataSource {
   private final String url;
   private final String username;
   private final String password;
   private final String connectionInitSql;
   private PrintWriter logWriter;
   private int loginTimeout;

   public DriverManagerDataSource(String url, String username, String password, String connectionInitSql) {
      this.url = url;
      this.username = username;
      this.password = password;
      this.connectionInitSql = connectionInitSql;
   }

   @Override
   public Connection getConnection() throws SQLException {
      Connection connection = this.username == null
         ? DriverManager.getConnection(this.url)
         : DriverManager.getConnection(this.url, this.username, this.password);
      this.initializeConnection(connection);
      return connection;
   }

   @Override
   public Connection getConnection(String username, String password) throws SQLException {
      Connection connection = DriverManager.getConnection(this.url, username, password);
      this.initializeConnection(connection);
      return connection;
   }

   private void initializeConnection(Connection connection) throws SQLException {
      if (this.connectionInitSql != null && !this.connectionInitSql.isEmpty()) {
         try (Statement statement = connection.createStatement()) {
            String[] statements = this.connectionInitSql.split(";");

            for (int i = 0; i < statements.length; i++) {
               String sql = statements[i].trim();
               if (!sql.isEmpty()) {
                  statement.execute(sql);
               }
            }
         }
      }
   }

   @Override
   public PrintWriter getLogWriter() {
      return this.logWriter;
   }

   @Override
   public void setLogWriter(PrintWriter out) {
      this.logWriter = out;
   }

   @Override
   public void setLoginTimeout(int seconds) {
      this.loginTimeout = seconds;
      DriverManager.setLoginTimeout(seconds);
   }

   @Override
   public int getLoginTimeout() {
      return this.loginTimeout;
   }

   @Override
   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
      throw new SQLFeatureNotSupportedException();
   }

   @Override
   public <T> T unwrap(Class<T> iface) throws SQLException {
      if (iface.isInstance(this)) {
         return iface.cast(this);
      } else {
         throw new SQLException("Not a wrapper for " + iface);
      }
   }

   @Override
   public boolean isWrapperFor(Class<?> iface) {
      return iface.isInstance(this);
   }
}
