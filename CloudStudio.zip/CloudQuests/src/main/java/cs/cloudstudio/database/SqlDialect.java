package cs.cloudstudio.database;

public interface SqlDialect {
   String[] schemaSql();

   String upsertPlayerSql();
}
