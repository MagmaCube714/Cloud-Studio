package cs.cloudstudio.database;

import java.io.File;
import org.bukkit.configuration.file.FileConfiguration;

public final class DatabaseSettings {
   public final DatabaseType type;
   public final String host;
   public final int port;
   public final String username;
   public final String password;
   public final String playerDatabase;
   public final File sqliteFile;

   private DatabaseSettings(DatabaseType type, String host, int port, String username, String password, String playerDatabase, File sqliteFile) {
      this.type = type;
      this.host = host;
      this.port = port;
      this.username = username;
      this.password = password;
      this.playerDatabase = playerDatabase;
      this.sqliteFile = sqliteFile;
   }

   public static DatabaseSettings load(FileConfiguration config, File dataFolder) {
      String typeRaw = config.getString("database.type", "SQLite");
      DatabaseType type = "MYSQL".equalsIgnoreCase(typeRaw) ? DatabaseType.MYSQL : DatabaseType.SQLITE;
      String databaseName = sanitizeDatabaseName(config.getString("database.playerDatabase", "data"));
      File sqliteFile = new File(dataFolder, databaseName + ".db");
      return new DatabaseSettings(
         type,
         config.getString("database.host", "localhost"),
         Math.max(1, Math.min(65535, config.getInt("database.port", 3306))),
         config.getString("database.username", "admin"),
         config.getString("database.password", "admin"),
         databaseName,
         sqliteFile
      );
   }

   private static String sanitizeDatabaseName(String input) {
      if (input == null) {
         return "data";
      }

      String trimmed = input.trim();
      if (trimmed.endsWith(".db")) {
         trimmed = trimmed.substring(0, trimmed.length() - 3);
      }

      StringBuilder builder = new StringBuilder(trimmed.length());
      int i = 0;

      for (int n = trimmed.length(); i < n; i++) {
         char c = trimmed.charAt(i);
         if (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_' || c == '-') {
            builder.append(c);
         }
      }

      return builder.length() == 0 ? "data" : builder.toString();
   }
}
