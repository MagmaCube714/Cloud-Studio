package cs.cloudstudio.database;

public enum DatabaseType {
   SQLITE,
   MYSQL;
}
