package cs.cloudstudio.database;

public final class MySqlDialect implements SqlDialect {
   @Override
   public String[] schemaSql() {
      return new String[]{
         "CREATE TABLE IF NOT EXISTS players (uuid VARCHAR(36) PRIMARY KEY NOT NULL, name VARCHAR(16) NOT NULL DEFAULT '', updated_at BIGINT NOT NULL DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
         "CREATE TABLE IF NOT EXISTS quest_progress (uuid VARCHAR(36) NOT NULL, category VARCHAR(32) NOT NULL, stage INT NOT NULL DEFAULT 1, progress INT NOT NULL DEFAULT 0, legacy_skips INT NOT NULL DEFAULT 3, completed INT NOT NULL DEFAULT 0, skipped INT NOT NULL DEFAULT 0, rewards_received INT NOT NULL DEFAULT 0, PRIMARY KEY(uuid, category), CONSTRAINT fk_cloudquests_qp_player FOREIGN KEY(uuid) REFERENCES players(uuid) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
         "CREATE TABLE IF NOT EXISTS completed_stages (uuid VARCHAR(36) NOT NULL, category VARCHAR(32) NOT NULL, stage INT NOT NULL, PRIMARY KEY(uuid, category, stage), CONSTRAINT fk_cloudquests_completed_player FOREIGN KEY(uuid) REFERENCES players(uuid) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
         "CREATE TABLE IF NOT EXISTS skipped_stages (uuid VARCHAR(36) NOT NULL, category VARCHAR(32) NOT NULL, stage INT NOT NULL, PRIMARY KEY(uuid, category, stage), CONSTRAINT fk_cloudquests_skipped_player FOREIGN KEY(uuid) REFERENCES players(uuid) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
         "CREATE TABLE IF NOT EXISTS claimed_rewards (uuid VARCHAR(36) NOT NULL, category VARCHAR(32) NOT NULL, stage INT NOT NULL, PRIMARY KEY(uuid, category, stage), CONSTRAINT fk_cloudquests_rewards_player FOREIGN KEY(uuid) REFERENCES players(uuid) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
         "DROP TABLE IF EXISTS skipped_rewards",
         "CREATE TABLE IF NOT EXISTS purchases (uuid VARCHAR(36) NOT NULL, category VARCHAR(32) NOT NULL, item_id VARCHAR(128) NOT NULL, amount INT NOT NULL DEFAULT 0, PRIMARY KEY(uuid, category, item_id), CONSTRAINT fk_cloudquests_purchases_player FOREIGN KEY(uuid) REFERENCES players(uuid) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
         "CREATE INDEX idx_quest_progress_category ON quest_progress(category)",
         "CREATE INDEX idx_purchases_category ON purchases(category)"
      };
   }

   @Override
   public String upsertPlayerSql() {
      return "INSERT INTO players(uuid, name, updated_at) VALUES(?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), updated_at=VALUES(updated_at)";
   }
}
