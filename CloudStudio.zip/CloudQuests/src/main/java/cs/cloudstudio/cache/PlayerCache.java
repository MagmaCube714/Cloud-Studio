package cs.cloudstudio.cache;

import cs.cloudstudio.manager.model.PlayerData;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerCache extends ConcurrentHashMap<UUID, PlayerData> {
}
