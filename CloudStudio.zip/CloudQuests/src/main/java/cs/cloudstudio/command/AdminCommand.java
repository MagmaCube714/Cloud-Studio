package cs.cloudstudio.command;

import cs.cloudstudio.CloudQuests;
import cs.cloudstudio.command.sub.CompleteAllSubCommand;
import cs.cloudstudio.command.sub.CompleteSubCommand;
import cs.cloudstudio.command.sub.GenerateSubCommand;
import cs.cloudstudio.command.sub.HelpSubCommand;
import cs.cloudstudio.command.sub.InfoSubCommand;
import cs.cloudstudio.command.sub.RegenSubCommand;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import cs.cloudstudio.command.sub.ResetAllSubCommand;
import cs.cloudstudio.command.sub.ResetDbSubCommand;
import cs.cloudstudio.command.sub.ResetSubCommand;
import cs.cloudstudio.command.sub.SetProgressSubCommand;
import cs.cloudstudio.command.sub.SetSkipsSubCommand;
import cs.cloudstudio.command.sub.SetStageSubCommand;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public final class AdminCommand extends BaseCommand {
   private final Map<String, SubCommand> subCommands = new HashMap<>();

   public AdminCommand(CloudQuests plugin) {
      super(plugin);
      this.register(new ReloadSubCommand(plugin));
      this.register(new GenerateSubCommand(plugin));
      this.register(new RegenSubCommand(plugin));
      this.register(new InfoSubCommand(plugin));
      this.register(new ResetSubCommand(plugin));
      this.register(new ResetAllSubCommand(plugin));
      this.register(new ResetDbSubCommand(plugin));
      this.register(new SetStageSubCommand(plugin));
      this.register(new SetProgressSubCommand(plugin));
      this.register(new SetSkipsSubCommand(plugin));
      this.register(new CompleteSubCommand(plugin));
      this.register(new CompleteAllSubCommand(plugin));
      this.register(new HelpSubCommand(plugin));
   }

   private void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.name(), subCommand);

      for (String alias : subCommand.aliases()) {
         this.subCommands.put(alias.toLowerCase(Locale.ROOT), subCommand);
      }
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (args.length == 0) {
         return this.subCommands.get("help").execute(sender, command, args);
      }

      SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
      return subCommand == null ? this.subCommands.get("help").execute(sender, command, args) : subCommand.execute(sender, command, args);
   }

   @Override
   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return this.plugin.tabCompleteCommand(sender, command, "cloudquests", args);
   }
}
