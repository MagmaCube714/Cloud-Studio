package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudQuests;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public final class SetSkipsSubCommand implements SubCommand {
   private final CloudQuests plugin;

   public SetSkipsSubCommand(CloudQuests plugin) {
      this.plugin = plugin;
   }

   @Override
   public String name() {
      return "setskips";
   }

   @Override
   public boolean execute(CommandSender sender, Command command, String[] args) {
      return this.plugin.executeCommand(sender, command, "cloudquests", args);
   }
}
