package cs.cloudstudio.command;

import cs.cloudstudio.CloudQuests;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public final class QuestCommand extends BaseCommand {
   public QuestCommand(CloudQuests plugin) {
      super(plugin);
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      return this.plugin.executeCommand(sender, command, "quest", args);
   }

   @Override
   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return this.plugin.tabCompleteCommand(sender, command, "quest", args);
   }
}
