package cs.cloudstudio.command;

import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public interface SubCommand {
   String name();

   default List<String> aliases() {
      return Collections.emptyList();
   }

   boolean execute(CommandSender var1, Command var2, String[] var3);
}
