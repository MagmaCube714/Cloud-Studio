package cs.cloudstudio.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.ChatColor;

public final class ColorUtil {
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

   private ColorUtil() {
   }

   public static String color(String text) {
      if (text == null) {
         return "";
      }

      Matcher matcher = HEX_PATTERN.matcher(text);
      StringBuffer buffer = new StringBuffer();

      while (matcher.find()) {
         String hex = matcher.group(1);
         StringBuilder replacement = new StringBuilder("§x");

         for (int i = 0; i < hex.length(); i++) {
            replacement.append('§').append(hex.charAt(i));
         }

         matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement.toString()));
      }

      matcher.appendTail(buffer);
      return ChatColor.translateAlternateColorCodes('&', buffer.toString());
   }

   public static List<String> color(List<String> lines) {
      List<String> result = new ArrayList<>();
      if (lines == null) {
         return result;
      }

      for (String line : lines) {
         result.add(color(line));
      }

      return result;
   }
}
