package cs.cloudstudio.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.Plugin;

public final class ItemNameTranslator {
   private static final String LANG_VERSION = resolveLangVersion();
   private static final String RU_LANG_SOURCE = "https://raw.githubusercontent.com/InventivetalentDev/minecraft-assets/"
      + LANG_VERSION
      + "/assets/minecraft/lang/ru_ru.json";
   private static final long REFRESH_INTERVAL_MILLIS = 604800000L;
   private static final int CONNECT_TIMEOUT_MILLIS = 10000;
   private static final Map<String, String> TRANSLATIONS = new HashMap<>();
   private static volatile boolean ready;
   private static File cacheFile;

   private ItemNameTranslator() {
   }

   public static void init(Plugin plugin) {
      cacheFile = new File(plugin.getDataFolder(), "item_names-" + LANG_VERSION + ".json");
      loadFromFile();
      if (isCacheStale()) {
         Bukkit.getScheduler().runTaskAsynchronously(plugin, ItemNameTranslator::download);
      }
   }

   public static String of(Material material) {
      if (material == null) {
         return "";
      }

      String name = material.name().toLowerCase(Locale.ROOT);
      String translated = ready
         ? lookup(
            material.isBlock()
               ? new String[]{"block.minecraft." + name, "item.minecraft." + name}
               : new String[]{"item.minecraft." + name, "block.minecraft." + name}
         )
         : null;
      return translated != null ? capitalize(translated) : capitalize(name.replace('_', ' '));
   }

   public static String of(EntityType entity) {
      if (entity == null) {
         return "";
      }

      String key = entity.getKey().getKey().toLowerCase(Locale.ROOT);
      String translated = ready ? lookup(new String[]{"entity.minecraft." + key}) : null;
      return translated != null ? capitalize(translated) : capitalize(key.replace('_', ' '));
   }

   private static String lookup(String[] keys) {
      synchronized (TRANSLATIONS) {
         for (String key : keys) {
            String value = TRANSLATIONS.get(key);
            if (value != null && !value.isEmpty()) {
               return value;
            }
         }

         return null;
      }
   }

   private static String capitalize(String text) {
      if (text != null && !text.isEmpty()) {
         char first = Character.toUpperCase(text.charAt(0));
         return text.length() == 1 ? String.valueOf(first) : first + text.substring(1);
      } else {
         return "";
      }
   }

   private static boolean isCacheStale() {
      return cacheFile == null || !cacheFile.exists() || System.currentTimeMillis() - cacheFile.lastModified() > 604800000L;
   }

   private static void loadFromFile() {
      if (cacheFile != null && cacheFile.exists()) {
         try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(cacheFile), StandardCharsets.UTF_8))) {
            store(parse(readAll(reader)));
         } catch (Exception var5) {
         }
      }

      if (!ready) {
         loadBundled();
      }
   }

   private static void loadBundled() {
      try (InputStream stream = ItemNameTranslator.class.getResourceAsStream("/item_names.json")) {
         if (stream != null) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
               store(parse(readAll(reader)));
            }
         }
      } catch (Exception var8) {
      }
   }

   private static void download() {
      try {
         HttpURLConnection connection = (HttpURLConnection)new URL(RU_LANG_SOURCE).openConnection();
         connection.setConnectTimeout(10000);
         connection.setReadTimeout(10000);
         connection.setRequestProperty("User-Agent", "CloudQuests");

         String body;
         try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
            body = readAll(reader);
         } finally {
            connection.disconnect();
         }

         Map<String, String> parsed = parse(body);
         if (parsed.isEmpty()) {
            return;
         }

         store(parsed);
         saveToFile(body);
      } catch (Exception var13) {
      }
   }

   private static void saveToFile(String body) {
      if (cacheFile != null) {
         try {
            File parent = cacheFile.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
               return;
            }

            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(cacheFile), StandardCharsets.UTF_8))) {
               writer.write(body);
            }
         } catch (Exception var7) {
         }
      }
   }

   private static void store(Map<String, String> parsed) {
      if (!parsed.isEmpty()) {
         synchronized (TRANSLATIONS) {
            TRANSLATIONS.clear();
            TRANSLATIONS.putAll(parsed);
         }

         ready = true;
      }
   }

   private static String readAll(BufferedReader reader) throws Exception {
      StringBuilder builder = new StringBuilder(65536);
      char[] buffer = new char[8192];

      int read;
      while ((read = reader.read(buffer)) != -1) {
         builder.append(buffer, 0, read);
      }

      return builder.toString();
   }

   private static Map<String, String> parse(String json) {
      Map<String, String> result = new HashMap<>(4096);
      if (json != null && !json.isEmpty()) {
         int i = 0;
         int length = json.length();

         while (i < length) {
            int keyStart = json.indexOf(34, i);
            if (keyStart < 0) {
               break;
            }

            int keyEnd = closingQuote(json, keyStart + 1);
            if (keyEnd < 0) {
               break;
            }

            int colon = json.indexOf(58, keyEnd + 1);
            if (colon < 0) {
               break;
            }

            int valueStart = json.indexOf(34, colon + 1);
            if (valueStart < 0) {
               break;
            }

            int valueEnd = closingQuote(json, valueStart + 1);
            if (valueEnd < 0) {
               break;
            }

            String key = unescape(json.substring(keyStart + 1, keyEnd));
            if (key.startsWith("item.minecraft.") || key.startsWith("block.minecraft.") || key.startsWith("entity.minecraft.")) {
               result.put(key, unescape(json.substring(valueStart + 1, valueEnd)));
            }

            i = valueEnd + 1;
         }

         return result;
      } else {
         return result;
      }
   }

   private static int closingQuote(String text, int from) {
      for (int i = from; i < text.length(); i++) {
         char c = text.charAt(i);
         if (c == '\\') {
            i++;
         } else if (c == '"') {
            return i;
         }
      }

      return -1;
   }

   private static String unescape(String text) {
      if (text.indexOf(92) < 0) {
         return text;
      }

      StringBuilder builder = new StringBuilder(text.length());

      for (int i = 0; i < text.length(); i++) {
         char c = text.charAt(i);
         if (c == '\\' && i + 1 < text.length()) {
            char next = text.charAt(++i);
            switch (next) {
               case 'n':
                  builder.append('\n');
                  break;
               case 'o':
               case 'p':
               case 'q':
               case 's':
               default:
                  builder.append(next);
                  break;
               case 'r':
                  builder.append('\r');
                  break;
               case 't':
                  builder.append('\t');
                  break;
               case 'u':
                  if (i + 4 < text.length()) {
                     builder.append((char)Integer.parseInt(text.substring(i + 1, i + 5), 16));
                     i += 4;
                  }
            }
         } else {
            builder.append(c);
         }
      }

      return builder.toString();
   }

   private static String resolveLangVersion() {
      try {
         String version = Bukkit.getMinecraftVersion();
         if (version != null && !version.isEmpty()) {
            return version;
         }
      } catch (Throwable var1) {
      }

      return "1.21.11";
   }
}
