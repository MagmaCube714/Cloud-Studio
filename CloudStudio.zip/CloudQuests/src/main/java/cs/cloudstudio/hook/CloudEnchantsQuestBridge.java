package cs.cloudstudio.hook;

import cs.cloudstudio.CloudQuests;
import cs.cloudstudio.api.enchants.EnchantedBlockBrokenEvent;
import cs.cloudstudio.api.enchants.ManagedBlockBreakEvent;
import java.util.function.Predicate;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

public final class CloudEnchantsQuestBridge implements Listener, Predicate<BlockBreakEvent> {
   private final CloudQuests plugin;

   public CloudEnchantsQuestBridge(CloudQuests plugin) {
      this.plugin = plugin;
   }

   public boolean test(BlockBreakEvent event) {
      return event instanceof ManagedBlockBreakEvent;
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onBlockBroken(EnchantedBlockBrokenEvent event) {
      this.plugin.onBlockBroken(event.getPlayer(), event.getMaterial(), event.isFullyGrown());
   }
}
