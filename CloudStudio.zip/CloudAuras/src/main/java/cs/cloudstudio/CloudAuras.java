package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.listener.ArmorAuraListener;
import cs.cloudstudio.listener.AuraItemUseListener;
import cs.cloudstudio.listener.CrystalProtectionAuraListener;
import cs.cloudstudio.listener.FallProtectionAuraListener;
import cs.cloudstudio.listener.HunterAuraListener;
import cs.cloudstudio.listener.MoneyFromMobsListener;
import cs.cloudstudio.listener.TeleportAuraListener;
import cs.cloudstudio.manager.ItemManager;
import cs.cloudstudio.manager.MoneyManager;
import cs.cloudstudio.manager.TeleportManager;
import cs.cloudstudio.util.AuraUtil;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudAuras extends JavaPlugin {
   private ConfigManager configManager;
   private ItemManager itemManager;
   private MoneyManager moneyManager;
   private TeleportManager teleportManager;
   private NamespacedKey itemKey;

   public void onEnable() {
      this.itemKey = new NamespacedKey(this, "cloudauras-item");
      this.saveDefaultConfig();
      this.loadPlugin();
      this.registerCommands();
      this.console("&fCloudAuras &aуспешно загружен!");
   }

   public void onDisable() {
      AuraUtil.clearCache();
      this.getServer().getScheduler().cancelTasks(this);
      HandlerList.unregisterAll(this);
      this.itemManager = null;
      this.moneyManager = null;
      this.teleportManager = null;
      this.configManager = null;
      this.itemKey = null;
      this.console("&fCloudAuras &cуспешно выгружен!");
   }

   public void reloadPlugin() {
      AuraUtil.clearCache();
      this.getServer().getScheduler().cancelTasks(this);
      HandlerList.unregisterAll(this);
      this.reloadConfig();
      this.loadPlugin();
   }

   private void loadPlugin() {
      this.configManager = new ConfigManager(this);
      this.itemManager = new ItemManager(this);
      this.moneyManager = new MoneyManager(this, this.itemManager.getAuraManager());
      this.teleportManager = new TeleportManager(this.itemManager.getAuraManager());
      this.registerListeners();
   }

   private void registerCommands() {
      PluginCommand command = this.getCommand("cloudauras");
      if (command == null) {
         this.warning("Команда cloudauras не найдена в plugin.yml");
      } else {
         AdminCommand adminCommand = new AdminCommand(this);
         command.setExecutor(adminCommand);
         command.setTabCompleter(adminCommand);
      }
   }

   private void registerListeners() {
      PluginManager pluginManager = this.getServer().getPluginManager();
      pluginManager.registerEvents(new AuraItemUseListener(this.itemManager.getAuraManager()), this);
      pluginManager.registerEvents(new HunterAuraListener(this.itemManager.getAuraManager()), this);
      pluginManager.registerEvents(new ArmorAuraListener(this.itemManager.getAuraManager()), this);
      pluginManager.registerEvents(new FallProtectionAuraListener(this.itemManager.getAuraManager()), this);
      pluginManager.registerEvents(new CrystalProtectionAuraListener(this.itemManager.getAuraManager()), this);
      pluginManager.registerEvents(new MoneyFromMobsListener(this.moneyManager), this);
      pluginManager.registerEvents(new TeleportAuraListener(this.teleportManager), this);
   }

   public void console(String message) {
      Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', message));
   }

   public void warning(String message) {
      this.getLogger().warning("[CloudAuras] " + message);
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public ItemManager getItemManager() {
      return this.itemManager;
   }

   public NamespacedKey getItemKey() {
      return this.itemKey;
   }
}
