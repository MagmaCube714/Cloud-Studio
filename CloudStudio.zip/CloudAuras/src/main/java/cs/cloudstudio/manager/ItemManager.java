package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAuras;
import cs.cloudstudio.util.BaseItem;
import java.util.Collection;

public final class ItemManager {
   private final AuraManager auraManager;

   public ItemManager(CloudAuras plugin) {
      this.auraManager = new AuraManager(plugin);
   }

   public AuraManager getAuraManager() {
      return this.auraManager;
   }

   public BaseItem getByKey(String key) {
      return this.auraManager.getByKey(key);
   }

   public Collection<? extends BaseItem> getAll() {
      return this.auraManager.getAll();
   }

   public Collection<String> getKeys() {
      return this.auraManager.getKeys();
   }
}
