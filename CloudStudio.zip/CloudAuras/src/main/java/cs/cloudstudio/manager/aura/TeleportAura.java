package cs.cloudstudio.manager.aura;

import cs.cloudstudio.util.ColorUtil;
import org.bukkit.configuration.ConfigurationSection;

public final class TeleportAura extends Aura {
   private static final int MIN_RADIUS = 1;
   private static final int MAX_RADIUS = 64;
   public final int teleportRadius;
   public final String teleportMessage;

   public TeleportAura(ConfigurationSection cfg) {
      super("teleport_aura", cfg);
      ConfigurationSection settings = cfg.getConfigurationSection("settings");
      int radius = settings != null ? settings.getInt("teleportRadius", 16) : 16;
      this.teleportRadius = Math.max(1, Math.min(64, radius));
      this.teleportMessage = ColorUtil.color(settings != null ? settings.getString("teleportMessage", "") : "");
   }
}
