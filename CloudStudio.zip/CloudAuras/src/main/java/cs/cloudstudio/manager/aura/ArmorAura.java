package cs.cloudstudio.manager.aura;

import org.bukkit.configuration.ConfigurationSection;

public final class ArmorAura extends Aura {
   public final double damageReduction;

   public ArmorAura(ConfigurationSection cfg) {
      super("armor_aura", cfg);
      ConfigurationSection settings = cfg.getConfigurationSection("settings");
      this.damageReduction = clamp01(settings != null ? settings.getDouble("damageReduction", 0.3) : 0.3);
   }
}
