package cs.cloudstudio.manager;

import cs.cloudstudio.manager.aura.TeleportAura;
import cs.cloudstudio.util.AuraUtil;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class TeleportManager {
   private static final int MAX_ATTEMPTS = 16;
   private static final double FULL_CIRCLE = Math.PI * 2;
   private final AuraManager auraManager;

   public TeleportManager(AuraManager auraManager) {
      this.auraManager = auraManager;
   }

   public void handleChorusEat(PlayerItemConsumeEvent event) {
      ItemStack consumed = event.getItem();
      if (consumed != null && consumed.getType() == Material.CHORUS_FRUIT) {
         Player player = event.getPlayer();
         TeleportAura aura = AuraUtil.getActiveAura(player, this.auraManager, TeleportAura.class);
         if (aura != null) {
            EquipmentSlot hand = this.findConsumedHand(player, consumed);
            if (hand != null) {
               Location from = player.getLocation();
               Location target = this.findSafeTeleport(from, Math.max(1, aura.teleportRadius / 2), Math.max(2, aura.teleportRadius));
               if (target != null) {
                  event.setCancelled(true);
                  target.setYaw(from.getYaw());
                  target.setPitch(from.getPitch());
                  if (player.teleport(target)) {
                     this.consumeOne(player, hand);
                     player.setFoodLevel(Math.min(player.getFoodLevel() + 4, 20));
                     player.setSaturation(Math.min(player.getSaturation() + 2.4F, 20.0F));
                     if (!aura.teleportMessage.isEmpty()) {
                        player.sendMessage(aura.teleportMessage);
                     }
                  }
               }
            }
         }
      }
   }

   private EquipmentSlot findConsumedHand(Player player, ItemStack consumedItem) {
      ItemStack mainHand = player.getInventory().getItemInMainHand();
      if (this.isSameConsumable(mainHand, consumedItem)) {
         return EquipmentSlot.HAND;
      }

      ItemStack offHand = player.getInventory().getItemInOffHand();
      return this.isSameConsumable(offHand, consumedItem) ? EquipmentSlot.OFF_HAND : null;
   }

   private boolean isSameConsumable(ItemStack handItem, ItemStack consumedItem) {
      return handItem != null
         && consumedItem != null
         && handItem.getAmount() > 0
         && handItem.getType() == Material.CHORUS_FRUIT
         && handItem.isSimilar(consumedItem);
   }

   private ItemStack getHandItem(Player player, EquipmentSlot hand) {
      return hand == EquipmentSlot.OFF_HAND ? player.getInventory().getItemInOffHand() : player.getInventory().getItemInMainHand();
   }

   private void consumeOne(Player player, EquipmentSlot hand) {
      ItemStack item = this.getHandItem(player, hand);
      if (item != null && item.getAmount() > 0) {
         item.setAmount(item.getAmount() - 1);
      }
   }

   private Location findSafeTeleport(Location center, int minRadius, int maxRadius) {
      World world = center.getWorld();
      if (world == null) {
         return null;
      }

      int maxY = world.getMaxHeight() - 2;
      ThreadLocalRandom random = ThreadLocalRandom.current();

      for (int attempt = 0; attempt < 16; attempt++) {
         double angle = random.nextDouble(0.0, Math.PI * 2);
         double distance = random.nextDouble(minRadius, maxRadius + 1.0);
         double x = center.getX() + Math.cos(angle) * distance;
         double z = center.getZ() + Math.sin(angle) * distance;
         double y = Math.max(1.0, Math.min(maxY, center.getY() + random.nextDouble(-4.0, 4.0)));
         if (this.isSafe(world, x, y, z)) {
            return new Location(world, x, y, z);
         }
      }

      return null;
   }

   private boolean isSafe(World world, double x, double y, double z) {
      Block feet = world.getBlockAt((int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z));
      Block head = feet.getRelative(0, 1, 0);
      Block ground = feet.getRelative(0, -1, 0);
      return this.isSafeAir(feet.getType()) && this.isSafeAir(head.getType()) && ground.getType().isSolid();
   }

   private boolean isSafeAir(Material material) {
      return material.isAir() || material == Material.CAVE_AIR || material == Material.VOID_AIR;
   }
}
