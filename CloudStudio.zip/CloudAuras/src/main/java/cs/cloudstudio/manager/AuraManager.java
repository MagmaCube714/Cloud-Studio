package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAuras;
import cs.cloudstudio.manager.aura.ArmorAura;
import cs.cloudstudio.manager.aura.Aura;
import cs.cloudstudio.manager.aura.CrystalProtectionAura;
import cs.cloudstudio.manager.aura.FallProtectionAura;
import cs.cloudstudio.manager.aura.HunterAura;
import cs.cloudstudio.manager.aura.RichAura;
import cs.cloudstudio.manager.aura.TeleportAura;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public final class AuraManager {
   private final Map<String, Aura> auras = new LinkedHashMap<>(8);
   private final Set<Material> auraMaterials = EnumSet.noneOf(Material.class);
   private final NamespacedKey itemKey;

   public AuraManager(CloudAuras plugin) {
      this.itemKey = plugin.getItemKey();
      this.register("hunter_aura", HunterAura::new, plugin);
      this.register("armor_aura", ArmorAura::new, plugin);
      this.register("teleport_aura", TeleportAura::new, plugin);
      this.register("rich_aura", RichAura::new, plugin);
      this.register("fall_protection_aura", FallProtectionAura::new, plugin);
      this.register("crystal_protection_aura", CrystalProtectionAura::new, plugin);
   }

   private void register(String key, Function<ConfigurationSection, Aura> factory, CloudAuras plugin) {
      ConfigurationSection cfg = plugin.getConfig().getConfigurationSection("items." + key);
      if (cfg != null) {
         Aura aura = factory.apply(cfg);
         aura.init(this.itemKey);
         this.auras.put(key, aura);
         Material material = aura.getMaterial();
         if (material != null) {
            this.auraMaterials.add(material);
         }
      }
   }

   public Aura getByKey(String key) {
      return this.auras.get(key);
   }

   public Aura matchItem(ItemStack item) {
      if (item != null && this.auraMaterials.contains(item.getType())) {
         String storedKey = (String)item.getPersistentDataContainer().get(this.itemKey, PersistentDataType.STRING);
         if (storedKey == null) {
            return null;
         }

         Aura aura = this.auras.get(storedKey);
         return aura != null && aura.getMaterial() == item.getType() ? aura : null;
      } else {
         return null;
      }
   }

   public Collection<Aura> getAll() {
      return Collections.unmodifiableCollection(this.auras.values());
   }

   public Collection<String> getKeys() {
      return Collections.unmodifiableSet(this.auras.keySet());
   }
}
