package cs.cloudstudio.manager.aura;

import org.bukkit.configuration.ConfigurationSection;

public final class RichAura extends Aura {
   public RichAura(ConfigurationSection cfg) {
      super("rich_aura", cfg);
   }
}
