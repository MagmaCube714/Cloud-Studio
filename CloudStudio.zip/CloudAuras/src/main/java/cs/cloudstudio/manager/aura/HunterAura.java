package cs.cloudstudio.manager.aura;

import org.bukkit.configuration.ConfigurationSection;

public final class HunterAura extends Aura {
   public HunterAura(ConfigurationSection cfg) {
      super("hunter_aura", cfg);
   }
}
