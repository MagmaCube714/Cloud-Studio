package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAuras;
import cs.cloudstudio.manager.aura.RichAura;
import cs.cloudstudio.util.AuraUtil;
import cs.cloudstudio.util.ColorUtil;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.GameMode;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class MoneyManager {
   private static final DecimalFormat MONEY_FORMAT = new DecimalFormat("0.00", DecimalFormatSymbols.getInstance(Locale.US));
   private final AuraManager auraManager;
   private final Economy economy;
   private final Map<EntityType, MoneyManager.MobMoney> mobMoney = new EnumMap<>(EntityType.class);
   private final MoneyManager.GroupMultiplier[] groupMultipliers;
   private final MoneyManager.MobMoney defaultMobMoney;
   private final String earnMessage;

   public MoneyManager(CloudAuras plugin, AuraManager auraManager) {
      this.auraManager = auraManager;
      this.economy = this.setupEconomy(plugin);
      ConfigurationSection cfg = plugin.getConfig().getConfigurationSection("settings.money-from-mobs");
      if (cfg == null) {
         this.earnMessage = "";
         this.defaultMobMoney = new MoneyManager.MobMoney(1.0, 5.0);
         this.groupMultipliers = new MoneyManager.GroupMultiplier[0];
      } else {
         this.earnMessage = ColorUtil.color(cfg.getString("earn-message", ""));
         this.defaultMobMoney = this.loadMoneyRange(cfg.getConfigurationSection("default-mob-money"), 1.0, 5.0);
         this.groupMultipliers = this.loadGroups(cfg.getConfigurationSection("group-multipliers"));
         this.loadMobs(cfg.getConfigurationSection("mobs"));
      }
   }

   public void handleDeath(EntityDeathEvent event) {
      if (this.economy != null) {
         LivingEntity entity = event.getEntity();
         if (!(entity instanceof Player) && !(entity instanceof ArmorStand)) {
            Player killer = entity.getKiller();
            if (killer != null && !isFarmedKill(killer, entity)) {
               MoneyManager.MobMoney money = this.getMobMoney(entity.getType());
               double amount = sanitize(money.randomAmount() * this.getMultiplier(killer));
               if (!(amount <= 0.0)) {
                  EconomyResponse response = this.economy.depositPlayer(killer, amount);
                  if (response != null && response.transactionSuccess()) {
                     if (!this.earnMessage.isEmpty()) {
                        killer.sendMessage(this.earnMessage.replace("%amount%", MONEY_FORMAT.format(amount)));
                     }
                  }
               }
            }
         }
      }
   }

   private Economy setupEconomy(CloudAuras plugin) {
      if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
         plugin.console("&fCloudAuras &eэкономика Vault не подключена, выдача денег за мобов отключена");
         return null;
      } else {
         RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
         if (rsp == null) {
            plugin.warning("Vault найден, но экономика не подключена");
            return null;
         } else {
            return (Economy)rsp.getProvider();
         }
      }
   }

   private MoneyManager.GroupMultiplier[] loadGroups(ConfigurationSection groups) {
      if (groups == null) {
         return new MoneyManager.GroupMultiplier[0];
      }

      List<MoneyManager.GroupMultiplier> loaded = new ArrayList<>(groups.getKeys(false).size());

      for (String key : groups.getKeys(false)) {
         double multiplier = sanitize(groups.getDouble(key));
         if (multiplier > 1.0) {
            loaded.add(new MoneyManager.GroupMultiplier("cloudauras.money." + key.toLowerCase(Locale.ROOT), multiplier));
         }
      }

      if (loaded.isEmpty()) {
         return new MoneyManager.GroupMultiplier[0];
      }

      Collections.sort(loaded, new Comparator<MoneyManager.GroupMultiplier>() {
         public int compare(MoneyManager.GroupMultiplier first, MoneyManager.GroupMultiplier second) {
            return Double.compare(second.multiplier, first.multiplier);
         }
      });
      return loaded.toArray(new MoneyManager.GroupMultiplier[loaded.size()]);
   }

   private void loadMobs(ConfigurationSection mobs) {
      if (mobs != null) {
         for (String key : mobs.getKeys(false)) {
            EntityType type = this.parseEntityType(key);
            if (type != null) {
               ConfigurationSection mobCfg = mobs.getConfigurationSection(key);
               if (mobCfg != null) {
                  MoneyManager.MobMoney money = this.loadMoneyRange(mobCfg, 1.0, 5.0);
                  if (money.max > 0.0) {
                     this.mobMoney.put(type, money);
                  }
               }
            }
         }
      }
   }

   private EntityType parseEntityType(String key) {
      try {
         return EntityType.valueOf(key.toUpperCase(Locale.ROOT));
      } catch (IllegalArgumentException ignored) {
         return null;
      }
   }

   private MoneyManager.MobMoney loadMoneyRange(ConfigurationSection section, double fallbackMin, double fallbackMax) {
      double min = fallbackMin;
      double max = fallbackMax;
      if (section != null) {
         min = section.getDouble("min", fallbackMin);
         max = section.getDouble("max", fallbackMax);
      }

      min = Math.max(0.0, sanitize(min));
      max = Math.max(0.0, sanitize(max));
      if (max < min) {
         double tmp = min;
         min = max;
         max = tmp;
      }

      return new MoneyManager.MobMoney(min, max);
   }

   private MoneyManager.MobMoney getMobMoney(EntityType type) {
      MoneyManager.MobMoney money = this.mobMoney.get(type);
      return money != null ? money : this.defaultMobMoney;
   }

   private double getMultiplier(Player killer) {
      double multiplier = 1.0;

      for (MoneyManager.GroupMultiplier group : this.groupMultipliers) {
         if (killer.hasPermission(group.permission)) {
            multiplier = group.multiplier;
            break;
         }
      }

      if (AuraUtil.getActiveAura(killer, this.auraManager, RichAura.class) != null) {
         multiplier *= 2.0;
      }

      return multiplier;
   }

   private static boolean isFarmedKill(Player killer, LivingEntity entity) {
      GameMode mode = killer.getGameMode();
      if (mode == GameMode.CREATIVE || mode == GameMode.SPECTATOR) {
         return true;
      }

      SpawnReason reason = entity.getEntitySpawnReason();
      return reason == SpawnReason.SPAWNER_EGG || reason == SpawnReason.DISPENSE_EGG;
   }

   private static double sanitize(double value) {
      return Double.isFinite(value) ? value : 0.0;
   }

   private static final class GroupMultiplier {
      private final String permission;
      private final double multiplier;

      private GroupMultiplier(String permission, double multiplier) {
         this.permission = permission;
         this.multiplier = multiplier;
      }
   }

   private static final class MobMoney {
      private final double min;
      private final double max;

      private MobMoney(double min, double max) {
         this.min = min;
         this.max = max;
      }

      private double randomAmount() {
         return this.max <= this.min ? this.min : ThreadLocalRandom.current().nextDouble(this.min, this.max);
      }
   }
}
