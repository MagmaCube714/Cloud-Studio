package cs.cloudstudio.manager.aura;

import org.bukkit.configuration.ConfigurationSection;

public final class FallProtectionAura extends Aura {
   public final double damageReduction;

   public FallProtectionAura(ConfigurationSection cfg) {
      super("fall_protection_aura", cfg);
      ConfigurationSection settings = cfg.getConfigurationSection("settings");
      this.damageReduction = clamp01(settings != null ? settings.getDouble("damageReduction", 0.8) : 0.8);
   }
}
