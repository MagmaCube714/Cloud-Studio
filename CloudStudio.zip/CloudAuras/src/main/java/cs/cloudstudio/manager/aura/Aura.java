package cs.cloudstudio.manager.aura;

import cs.cloudstudio.util.BaseItem;
import org.bukkit.configuration.ConfigurationSection;

public abstract class Aura extends BaseItem {
   protected Aura(String configKey, ConfigurationSection cfg) {
      super(configKey, cfg);
   }

   protected static double clamp01(double value) {
      return Double.isFinite(value) && !(value <= 0.0) ? Math.min(value, 1.0) : 0.0;
   }
}
