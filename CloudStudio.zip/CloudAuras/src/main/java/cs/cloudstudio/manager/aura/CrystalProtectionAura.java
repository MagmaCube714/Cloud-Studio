package cs.cloudstudio.manager.aura;

import org.bukkit.configuration.ConfigurationSection;

public final class CrystalProtectionAura extends Aura {
   public final double damageReduction;

   public CrystalProtectionAura(ConfigurationSection cfg) {
      super("crystal_protection_aura", cfg);
      ConfigurationSection settings = cfg.getConfigurationSection("settings");
      this.damageReduction = clamp01(settings != null ? settings.getDouble("damageReduction", 0.2) : 0.2);
   }
}
