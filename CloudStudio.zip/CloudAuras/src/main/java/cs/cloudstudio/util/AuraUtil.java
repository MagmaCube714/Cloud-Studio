package cs.cloudstudio.util;

import cs.cloudstudio.manager.AuraManager;
import cs.cloudstudio.manager.aura.Aura;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public final class AuraUtil {
   private static final int MAX_PLAYER_INVENTORY_SLOT = 40;
   private static final int MAX_CACHE_ENTRIES = 512;
   private static final Map<UUID, AuraUtil.CachedAura> TICK_CACHE = new HashMap<>();

   private AuraUtil() {
   }

   public static Aura getActiveAura(Player player, AuraManager manager) {
      if (player == null || manager == null) {
         return null;
      }

      if (!Bukkit.isPrimaryThread()) {
         return scanInventory(player, manager);
      }

      int tick = Bukkit.getCurrentTick();
      UUID playerId = player.getUniqueId();
      AuraUtil.CachedAura cached = TICK_CACHE.get(playerId);
      if (cached != null && cached.tick == tick && cached.manager == manager) {
         return cached.aura;
      }

      Aura aura = scanInventory(player, manager);
      if (TICK_CACHE.size() >= 512) {
         TICK_CACHE.clear();
      }

      if (cached != null && cached.manager == manager) {
         cached.tick = tick;
         cached.aura = aura;
      } else {
         TICK_CACHE.put(playerId, new AuraUtil.CachedAura(tick, manager, aura));
      }

      return aura;
   }

   private static Aura scanInventory(Player player, AuraManager manager) {
      PlayerInventory inventory = player.getInventory();
      int lastSlot = Math.min(40, inventory.getSize() - 1);

      for (int slot = 0; slot <= lastSlot; slot++) {
         ItemStack item = inventory.getItem(slot);
         Aura aura = manager.matchItem(item);
         if (aura != null) {
            return aura;
         }
      }

      return null;
   }

   public static <T extends Aura> T getActiveAura(Player player, AuraManager manager, Class<T> auraClass) {
      Aura aura = getActiveAura(player, manager);
      return auraClass.isInstance(aura) ? auraClass.cast(aura) : null;
   }

   public static void clearCache() {
      TICK_CACHE.clear();
   }

   private static final class CachedAura {
      private int tick;
      private final AuraManager manager;
      private Aura aura;

      private CachedAura(int tick, AuraManager manager, Aura aura) {
         this.tick = tick;
         this.manager = manager;
         this.aura = aura;
      }
   }
}
