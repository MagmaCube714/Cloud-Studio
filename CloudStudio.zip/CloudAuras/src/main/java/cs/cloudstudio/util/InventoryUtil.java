package cs.cloudstudio.util;

import java.util.Map;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class InventoryUtil {
   private InventoryUtil() {
   }

   public static void giveOrDrop(Player player, Location fallbackLocation, ItemStack item) {
      if (player != null && item != null && item.getAmount() > 0) {
         Map<Integer, ItemStack> leftovers = player.getInventory().addItem(new ItemStack[]{item});
         if (!leftovers.isEmpty()) {
            Location dropLocation = fallbackLocation != null && fallbackLocation.getWorld() != null ? fallbackLocation : player.getLocation();
            World world = dropLocation.getWorld();
            if (world != null) {
               for (ItemStack leftover : leftovers.values()) {
                  if (leftover != null && leftover.getAmount() > 0) {
                     world.dropItemNaturally(dropLocation, leftover);
                  }
               }
            }
         }
      }
   }
}
