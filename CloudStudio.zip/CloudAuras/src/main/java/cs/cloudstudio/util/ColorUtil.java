package cs.cloudstudio.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ColorUtil {
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([a-fA-F\\d]{6})");
   private static final char COLOR_CHAR = '§';

   private ColorUtil() {
   }

   public static String color(String message) {
      if (message != null && !message.isEmpty()) {
         Matcher matcher = HEX_PATTERN.matcher(message);
         StringBuffer buffer = new StringBuffer(message.length() + 32);

         while (matcher.find()) {
            String group = matcher.group(1);
            matcher.appendReplacement(
               buffer,
               "§x§" + group.charAt(0) + "§" + group.charAt(1) + "§" + group.charAt(2) + "§" + group.charAt(3) + "§" + group.charAt(4) + "§" + group.charAt(5)
            );
         }

         matcher.appendTail(buffer);
         return translateAlternateColorCodes('&', buffer.toString());
      } else {
         return message;
      }
   }

   private static String translateAlternateColorCodes(char altColorChar, String textToTranslate) {
      char[] chars = textToTranslate.toCharArray();
      int i = 0;

      for (int length = chars.length - 1; i < length; i++) {
         if (chars[i] == altColorChar && isValidColorCharacter(chars[i + 1])) {
            chars[i++] = 167;
            chars[i] = Character.toLowerCase(chars[i]);
         }
      }

      return new String(chars);
   }

   private static boolean isValidColorCharacter(char c) {
      switch (c) {
         case '0':
         case '1':
         case '2':
         case '3':
         case '4':
         case '5':
         case '6':
         case '7':
         case '8':
         case '9':
         case 'A':
         case 'B':
         case 'C':
         case 'D':
         case 'E':
         case 'F':
         case 'K':
         case 'L':
         case 'M':
         case 'N':
         case 'O':
         case 'R':
         case 'X':
         case 'a':
         case 'b':
         case 'c':
         case 'd':
         case 'e':
         case 'f':
         case 'k':
         case 'l':
         case 'm':
         case 'n':
         case 'o':
         case 'r':
         case 'x':
            return true;
         case ':':
         case ';':
         case '<':
         case '=':
         case '>':
         case '?':
         case '@':
         case 'G':
         case 'H':
         case 'I':
         case 'J':
         case 'P':
         case 'Q':
         case 'S':
         case 'T':
         case 'U':
         case 'V':
         case 'W':
         case 'Y':
         case 'Z':
         case '[':
         case '\\':
         case ']':
         case '^':
         case '_':
         case '`':
         case 'g':
         case 'h':
         case 'i':
         case 'j':
         case 'p':
         case 'q':
         case 's':
         case 't':
         case 'u':
         case 'v':
         case 'w':
         default:
            return false;
      }
   }
}
