package cs.cloudstudio.util;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

public abstract class BaseItem {
   protected final String configKey;
   protected final String name;
   protected final int modelData;
   protected final Material material;
   protected final List<String> lore;
   private final PlayerProfile skullProfile;
   private NamespacedKey itemKey;

   protected BaseItem(String configKey, ConfigurationSection cfg) {
      this.configKey = configKey;
      this.name = ColorUtil.color(cfg.getString("name", configKey));
      this.modelData = Math.max(0, cfg.getInt("modelData", 0));
      this.material = resolveMaterial(cfg.getString("material", "PLAYER_HEAD"));
      this.lore = loadLore(cfg);
      this.skullProfile = createSkullProfile(cfg.getString("texture", ""));
   }

   public void init(NamespacedKey itemKey) {
      this.itemKey = itemKey;
   }

   public String getConfigKey() {
      return this.configKey;
   }

   public Material getMaterial() {
      return this.material;
   }

   public ItemStack build() {
      ItemStack item = new ItemStack(this.material);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      meta.setDisplayName(this.name);
      if (!this.lore.isEmpty()) {
         meta.setLore(this.lore);
      }

      if (this.modelData > 0) {
         meta.setCustomModelData(this.modelData);
      }

      if (isPotionLike(this.material)) {
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ADDITIONAL_TOOLTIP});
      }

      this.markAsCustom(meta);
      if (this.skullProfile != null && meta instanceof SkullMeta) {
         applyTexture((SkullMeta)meta, this.skullProfile);
      }

      item.setItemMeta(meta);
      return item;
   }

   public boolean matches(ItemStack item) {
      if (item != null && item.getType() == this.material && item.hasItemMeta() && this.itemKey != null) {
         ItemMeta meta = item.getItemMeta();
         return meta != null && this.configKey.equals(meta.getPersistentDataContainer().get(this.itemKey, PersistentDataType.STRING));
      } else {
         return false;
      }
   }

   protected void markAsCustom(ItemMeta meta) {
      if (this.itemKey != null) {
         meta.getPersistentDataContainer().set(this.itemKey, PersistentDataType.STRING, this.configKey);
      }
   }

   private static List<String> loadLore(ConfigurationSection cfg) {
      List<String> rawLore = cfg.getStringList("lore");
      if (rawLore.isEmpty()) {
         return Collections.emptyList();
      }

      List<String> lines = new ArrayList<>(rawLore.size());

      for (String line : rawLore) {
         lines.add(ColorUtil.color(line));
      }

      return Collections.unmodifiableList(lines);
   }

   private static Material resolveMaterial(String value) {
      if (value == null) {
         return Material.PLAYER_HEAD;
      }

      Material resolved = Material.matchMaterial(value.trim().toUpperCase(Locale.ROOT));
      return resolved != null ? resolved : Material.PLAYER_HEAD;
   }

   private static boolean isPotionLike(Material material) {
      return material == Material.POTION || material == Material.SPLASH_POTION || material == Material.LINGERING_POTION || material == Material.TIPPED_ARROW;
   }

   private static PlayerProfile createSkullProfile(String base64) {
      if (base64 != null && !base64.isEmpty()) {
         UUID uuid = UUID.nameUUIDFromBytes(base64.getBytes(StandardCharsets.UTF_8));
         PlayerProfile profile = Bukkit.createProfile(uuid, null);
         profile.setProperty(new ProfileProperty("textures", base64));
         return profile;
      } else {
         return null;
      }
   }

   private static void applyTexture(SkullMeta meta, PlayerProfile profile) {
      if (profile != null) {
         meta.setPlayerProfile(profile);
      }
   }
}
