package cs.cloudstudio.config;

import cs.cloudstudio.CloudAuras;
import cs.cloudstudio.util.ColorUtil;

public final class ConfigManager {
   private final CloudAuras plugin;

   public ConfigManager(CloudAuras plugin) {
      this.plugin = plugin;
   }

   public String message(String path) {
      return ColorUtil.color(this.plugin.getConfig().getString("messages." + path, "&cСообщение не найдено: " + path));
   }
}
