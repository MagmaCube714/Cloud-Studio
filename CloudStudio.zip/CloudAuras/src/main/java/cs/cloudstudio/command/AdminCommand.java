package cs.cloudstudio.command;

import cs.cloudstudio.CloudAuras;
import cs.cloudstudio.command.sub.GiveSubCommand;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public final class AdminCommand implements CommandExecutor, TabCompleter {
   private static final String PERMISSION = "cloudauras.admin";
   private final CloudAuras plugin;
   private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();

   public AdminCommand(CloudAuras plugin) {
      this.plugin = plugin;
      this.register(new GiveSubCommand(plugin));
      this.register(new ReloadSubCommand(plugin));
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("cloudauras.admin")) {
         sender.sendMessage(this.plugin.getConfigManager().message("no-perm"));
         return true;
      } else if (args.length == 0) {
         sender.sendMessage(this.plugin.getConfigManager().message("admin-usage"));
         return true;
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            sender.sendMessage(this.plugin.getConfigManager().message("admin-usage"));
            return true;
         } else {
            subCommand.execute(sender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.hasPermission("cloudauras.admin")) {
         return Collections.emptyList();
      }

      if (args.length == 1) {
         return this.filter(this.subCommands.keySet(), args[0]);
      }

      SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
      return subCommand == null ? Collections.emptyList() : subCommand.tab(sender, args);
   }

   private void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.getName(), subCommand);
   }

   private List<String> filter(Iterable<String> source, String input) {
      String lower = input == null ? "" : input.toLowerCase(Locale.ROOT);
      List<String> result = new ArrayList<>();

      for (String value : source) {
         if (value.toLowerCase(Locale.ROOT).startsWith(lower)) {
            result.add(value);
         }
      }

      return result;
   }
}
