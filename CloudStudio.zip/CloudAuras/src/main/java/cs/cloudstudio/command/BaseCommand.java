package cs.cloudstudio.command;

import cs.cloudstudio.CloudAuras;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;

public abstract class BaseCommand implements SubCommand {
   protected final CloudAuras plugin;

   protected BaseCommand(CloudAuras plugin) {
      this.plugin = plugin;
   }

   protected void message(CommandSender sender, String key) {
      sender.sendMessage(this.plugin.getConfigManager().message(key));
   }

   protected List<String> filter(Collection<String> source, String input) {
      if (source != null && !source.isEmpty()) {
         String lower = input == null ? "" : input.toLowerCase(Locale.ROOT);
         List<String> result = new ArrayList<>();

         for (String value : source) {
            if (value.toLowerCase(Locale.ROOT).startsWith(lower)) {
               result.add(value);
            }
         }

         return result;
      } else {
         return Collections.emptyList();
      }
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      return Collections.emptyList();
   }
}
