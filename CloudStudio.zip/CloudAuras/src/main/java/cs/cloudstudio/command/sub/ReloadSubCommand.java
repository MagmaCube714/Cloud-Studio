package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAuras;
import cs.cloudstudio.command.BaseCommand;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand extends BaseCommand {
   public ReloadSubCommand(CloudAuras plugin) {
      super(plugin);
   }

   @Override
   public String getName() {
      return "reload";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      this.plugin.reloadPlugin();
      this.message(sender, "reloaded");
   }
}
