package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAuras;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.util.BaseItem;
import cs.cloudstudio.util.InventoryUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class GiveSubCommand extends BaseCommand {
   public GiveSubCommand(CloudAuras plugin) {
      super(plugin);
   }

   @Override
   public String getName() {
      return "give";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      if (args.length < 2) {
         this.message(sender, "give-usage");
      } else {
         Player target;
         if (args.length >= 3) {
            target = this.plugin.getServer().getPlayer(args[2]);
            if (target == null) {
               this.message(sender, "player-not-found");
               return;
            }
         } else if (sender instanceof Player self) {
            target = self;
         } else {
            this.message(sender, "player-required");
            return;
         }

         String itemKey = args[1].toLowerCase(Locale.ROOT);
         BaseItem item = this.plugin.getItemManager().getByKey(itemKey);
         if (item == null) {
            this.message(sender, "unknown-item");
         } else {
            ItemStack itemStack = item.build();
            InventoryUtil.giveOrDrop(target, null, itemStack);
            sender.sendMessage(this.plugin.getConfigManager().message("given").replace("%item%", itemKey).replace("%player%", target.getName()));
         }
      }
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      if (args.length == 2) {
         return this.filter(this.plugin.getItemManager().getKeys(), args[1]);
      }

      if (args.length == 3) {
         String input = args[2].toLowerCase(Locale.ROOT);
         List<String> result = new ArrayList<>();

         for (Player player : this.plugin.getServer().getOnlinePlayers()) {
            String name = player.getName();
            if (name.toLowerCase(Locale.ROOT).startsWith(input)) {
               result.add(name);
            }
         }

         return result;
      } else {
         return Collections.emptyList();
      }
   }
}
