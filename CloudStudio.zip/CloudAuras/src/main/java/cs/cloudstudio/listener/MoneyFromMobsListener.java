package cs.cloudstudio.listener;

import cs.cloudstudio.manager.MoneyManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

public final class MoneyFromMobsListener implements Listener {
   private final MoneyManager moneyManager;

   public MoneyFromMobsListener(MoneyManager moneyManager) {
      this.moneyManager = moneyManager;
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onEntityDeath(EntityDeathEvent event) {
      this.moneyManager.handleDeath(event);
   }
}
