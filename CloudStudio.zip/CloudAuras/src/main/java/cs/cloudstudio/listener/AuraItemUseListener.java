package cs.cloudstudio.listener;

import cs.cloudstudio.manager.AuraManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.Event.Result;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.BrewEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.FurnaceBurnEvent;
import org.bukkit.event.inventory.FurnaceSmeltEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class AuraItemUseListener implements Listener {
   private final AuraManager manager;

   public AuraItemUseListener(AuraManager manager) {
      this.manager = manager;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onBlockPlace(BlockPlaceEvent event) {
      if (this.isAuraItem(event.getItemInHand())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPlayerInteract(PlayerInteractEvent event) {
      if (this.isAuraItem(event.getItem())) {
         event.setUseItemInHand(Result.DENY);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
      Player player = event.getPlayer();
      EquipmentSlot hand = event.getHand();
      ItemStack item = hand == EquipmentSlot.OFF_HAND ? player.getInventory().getItemInOffHand() : player.getInventory().getItemInMainHand();
      if (this.isAuraItem(item)) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onItemConsume(PlayerItemConsumeEvent event) {
      if (this.isAuraItem(event.getItem())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onBlockDispense(BlockDispenseEvent event) {
      if (this.isAuraItem(event.getItem())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
      if (this.isAuraItem(event.getPlayerItem())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onMobPickupAura(EntityPickupItemEvent event) {
      if (!(event.getEntity() instanceof Player) && this.isAuraItem(event.getItem().getItemStack())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPrepareCraft(PrepareItemCraftEvent event) {
      if (this.containsAura(event.getInventory().getMatrix())) {
         event.getInventory().setResult(null);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onCraft(CraftItemEvent event) {
      if (this.containsAura(event.getInventory().getMatrix())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onFurnaceBurn(FurnaceBurnEvent event) {
      if (this.isAuraItem(event.getFuel())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onFurnaceSmelt(FurnaceSmeltEvent event) {
      if (this.isAuraItem(event.getSource())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onBrew(BrewEvent event) {
      if (this.containsAura(event.getContents().getContents())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPrepareAnvil(PrepareAnvilEvent event) {
      if (this.containsAura(event.getInventory().getContents())) {
         event.setResult(null);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onPrepareSmithing(PrepareSmithingEvent event) {
      if (this.containsAura(event.getInventory().getContents())) {
         event.setResult(null);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onInventoryClick(InventoryClickEvent event) {
      Inventory topInventory = event.getView().getTopInventory();
      if (this.isVanillaProcessor(topInventory)) {
         Inventory clickedInventory = event.getClickedInventory();
         boolean clickedTopInventory = topInventory.equals(clickedInventory);
         if (clickedTopInventory && this.isAuraItem(event.getCursor())) {
            event.setCancelled(true);
         } else if (!clickedTopInventory && event.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY && this.isAuraItem(event.getCurrentItem())) {
            event.setCancelled(true);
         } else {
            if (clickedTopInventory && this.isAuraItem(this.getHotbarItem(event))) {
               event.setCancelled(true);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onInventoryDrag(InventoryDragEvent event) {
      Inventory topInventory = event.getView().getTopInventory();
      if (this.isVanillaProcessor(topInventory) && this.isAuraItem(event.getOldCursor())) {
         int topSize = topInventory.getSize();

         for (int rawSlot : event.getRawSlots()) {
            if (rawSlot >= 0 && rawSlot < topSize) {
               event.setCancelled(true);
               return;
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onInventoryMove(InventoryMoveItemEvent event) {
      if (this.isAuraItem(event.getItem()) && this.isVanillaProcessor(event.getDestination())) {
         event.setCancelled(true);
      }
   }

   private ItemStack getHotbarItem(InventoryClickEvent event) {
      int hotbarButton = event.getHotbarButton();
      return hotbarButton >= 0 && event.getWhoClicked() instanceof Player ? ((Player)event.getWhoClicked()).getInventory().getItem(hotbarButton) : null;
   }

   private boolean isVanillaProcessor(Inventory inventory) {
      if (inventory == null) {
         return false;
      }

      switch (inventory.getType()) {
         case DISPENSER:
         case DROPPER:
         case FURNACE:
         case WORKBENCH:
         case CRAFTING:
         case ENCHANTING:
         case BREWING:
         case MERCHANT:
         case ANVIL:
         case SMITHING:
         case BEACON:
         case BLAST_FURNACE:
         case SMOKER:
         case LOOM:
         case CARTOGRAPHY:
         case GRINDSTONE:
         case STONECUTTER:
            return true;
         default:
            return false;
      }
   }

   private boolean containsAura(ItemStack[] items) {
      if (items == null) {
         return false;
      }

      for (ItemStack item : items) {
         if (this.isAuraItem(item)) {
            return true;
         }
      }

      return false;
   }

   private boolean isAuraItem(ItemStack item) {
      return this.manager.matchItem(item) != null;
   }
}
