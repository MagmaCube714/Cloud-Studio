package cs.cloudstudio.listener;

import cs.cloudstudio.manager.AuraManager;
import cs.cloudstudio.manager.aura.CrystalProtectionAura;
import cs.cloudstudio.util.AuraUtil;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public final class CrystalProtectionAuraListener implements Listener {
   private final AuraManager manager;

   public CrystalProtectionAuraListener(AuraManager manager) {
      this.manager = manager;
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onCrystalDamage(EntityDamageByEntityEvent event) {
      if (event.getEntity() instanceof Player && event.getDamager() instanceof EnderCrystal) {
         Player player = (Player)event.getEntity();
         CrystalProtectionAura aura = AuraUtil.getActiveAura(player, this.manager, CrystalProtectionAura.class);
         if (aura != null) {
            event.setDamage(event.getDamage() * (1.0 - aura.damageReduction));
         }
      }
   }
}
