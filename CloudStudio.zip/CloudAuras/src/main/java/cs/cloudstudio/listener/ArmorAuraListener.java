package cs.cloudstudio.listener;

import cs.cloudstudio.manager.AuraManager;
import cs.cloudstudio.manager.aura.ArmorAura;
import cs.cloudstudio.util.AuraUtil;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.projectiles.ProjectileSource;

public final class ArmorAuraListener implements Listener {
   private final AuraManager manager;

   public ArmorAuraListener(AuraManager manager) {
      this.manager = manager;
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onDamage(EntityDamageByEntityEvent event) {
      if (event.getEntity() instanceof Player) {
         Player attacker = this.getAttackingPlayer(event.getDamager());
         if (attacker != null) {
            Player victim = (Player)event.getEntity();
            ArmorAura aura = AuraUtil.getActiveAura(victim, this.manager, ArmorAura.class);
            if (aura != null) {
               event.setDamage(event.getDamage() * (1.0 - aura.damageReduction));
            }
         }
      }
   }

   private Player getAttackingPlayer(Entity damager) {
      if (damager instanceof Player) {
         return (Player)damager;
      }

      if (damager instanceof Projectile) {
         ProjectileSource shooter = ((Projectile)damager).getShooter();
         if (shooter instanceof Player) {
            return (Player)shooter;
         }
      }

      return null;
   }
}
