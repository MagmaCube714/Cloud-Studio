package cs.cloudstudio.listener;

import cs.cloudstudio.manager.AuraManager;
import cs.cloudstudio.manager.aura.HunterAura;
import cs.cloudstudio.util.AuraUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.entity.AbstractHorse;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Steerable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class HunterAuraListener implements Listener {
   private static final int MAX_TRACKED_MOBS = 8192;
   private final AuraManager manager;
   private final Map<UUID, HunterAuraListener.EquipmentSnapshot> spawnEquipment = new LinkedHashMap<>();
   private final Map<UUID, List<ItemStack>> pickedUpItems = new LinkedHashMap<>();

   public HunterAuraListener(AuraManager manager) {
      this.manager = manager;
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onCreatureSpawn(CreatureSpawnEvent event) {
      UUID entityId = event.getEntity().getUniqueId();
      this.spawnEquipment.remove(entityId);
      this.pickedUpItems.remove(entityId);
      if (this.isVanillaSpawn(event.getSpawnReason())) {
         HunterAuraListener.EquipmentSnapshot snapshot = HunterAuraListener.EquipmentSnapshot.capture(event.getEntity());
         if (snapshot != null) {
            this.trackSpawnEquipment(entityId, snapshot);
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onCancelledCreatureSpawn(CreatureSpawnEvent event) {
      if (event.isCancelled()) {
         UUID entityId = event.getEntity().getUniqueId();
         this.spawnEquipment.remove(entityId);
         this.pickedUpItems.remove(entityId);
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onEntityPickupItem(EntityPickupItemEvent event) {
      LivingEntity entity = event.getEntity();
      if (!(entity instanceof Player) && !(entity instanceof ArmorStand)) {
         ItemStack groundItem = event.getItem().getItemStack();
         if (hasItems(groundItem)) {
            int pickedUpAmount = groundItem.getAmount() - event.getRemaining();
            if (pickedUpAmount > 0) {
               ItemStack pickedUpItem = groundItem.clone();
               pickedUpItem.setAmount(pickedUpAmount);
               this.trackPickedUpItem(entity.getUniqueId(), pickedUpItem);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onEntityDeath(EntityDeathEvent event) {
      LivingEntity entity = event.getEntity();
      UUID entityId = entity.getUniqueId();
      HunterAuraListener.EquipmentSnapshot snapshot = this.spawnEquipment.remove(entityId);
      List<ItemStack> pickedUpEquipment = this.pickedUpItems.remove(entityId);
      if (!(entity instanceof Player) && !(entity instanceof ArmorStand)) {
         Player killer = entity.getKiller();
         if (killer != null && AuraUtil.getActiveAura(killer, this.manager, HunterAura.class) != null) {
            List<ItemStack> drops = event.getDrops();
            List<ItemStack> currentAcquiredEquipment = snapshot == null ? this.getAllCurrentEquipment(entity) : snapshot.getAcquiredEquipment(entity);
            List<ItemStack> acquiredEquipment = this.mergeAcquiredEquipment(pickedUpEquipment, currentAcquiredEquipment);
            int[] acquiredAmounts = this.reserveAcquiredEquipmentDrops(drops, acquiredEquipment);
            List<ItemStack> extraDrops = null;
            int i = 0;

            for (int size = drops.size(); i < size; i++) {
               ItemStack drop = drops.get(i);
               int amountToDuplicate = getNonEquipmentAmount(drop, acquiredAmounts[i]);
               if (amountToDuplicate > 0 && this.isSafeToDuplicate(drop)) {
                  if (extraDrops == null) {
                     extraDrops = new ArrayList<>(size - i);
                  }

                  ItemStack extraDrop = drop.clone();
                  extraDrop.setAmount(amountToDuplicate);
                  extraDrops.add(extraDrop);
               }
            }

            if (extraDrops != null) {
               drops.addAll(extraDrops);
            }
         }
      }
   }

   private void trackSpawnEquipment(UUID entityId, HunterAuraListener.EquipmentSnapshot snapshot) {
      this.makeRoomFor(entityId, this.spawnEquipment);
      this.spawnEquipment.put(entityId, snapshot);
   }

   private void trackPickedUpItem(UUID entityId, ItemStack item) {
      List<ItemStack> items = this.pickedUpItems.get(entityId);
      if (items == null) {
         this.makeRoomFor(entityId, this.pickedUpItems);
         items = new ArrayList<>(1);
         this.pickedUpItems.put(entityId, items);
      }

      items.add(item);
   }

   private <T> void makeRoomFor(UUID entityId, Map<UUID, T> entries) {
      if (entries.size() >= 8192 && !entries.containsKey(entityId)) {
         Iterator<UUID> iterator = entries.keySet().iterator();
         if (iterator.hasNext()) {
            iterator.next();
            iterator.remove();
         }
      }
   }

   private boolean isVanillaSpawn(SpawnReason reason) {
      switch (reason) {
         case NATURAL:
         case JOCKEY:
         case CHUNK_GEN:
         case SPAWNER:
         case REINFORCEMENTS:
         case VILLAGE_DEFENSE:
         case VILLAGE_INVASION:
         case TRAP:
         case RAID:
         case PATROL:
         case DEFAULT:
            return true;
         default:
            return false;
      }
   }

   private int[] reserveAcquiredEquipmentDrops(List<ItemStack> drops, List<ItemStack> acquiredEquipment) {
      int[] acquiredAmounts = new int[drops.size()];

      for (int dropIndex = drops.size() - 1; dropIndex >= 0; dropIndex--) {
         ItemStack drop = drops.get(dropIndex);
         if (hasItems(drop)) {
            int remainingDropAmount = drop.getAmount();

            for (ItemStack equipmentItem : acquiredEquipment) {
               if (remainingDropAmount > 0 && hasItems(equipmentItem) && drop.isSimilar(equipmentItem)) {
                  int equipmentAmount = Math.min(remainingDropAmount, equipmentItem.getAmount());
                  acquiredAmounts[dropIndex] += equipmentAmount;
                  remainingDropAmount -= equipmentAmount;
                  equipmentItem.setAmount(equipmentItem.getAmount() - equipmentAmount);
               }
            }
         }
      }

      return acquiredAmounts;
   }

   private List<ItemStack> getAllCurrentEquipment(LivingEntity entity) {
      List<ItemStack> equipmentItems = new ArrayList<>(10);
      addCurrentEquipment(entity, equipmentItems);
      return equipmentItems;
   }

   private List<ItemStack> mergeAcquiredEquipment(List<ItemStack> pickedUpEquipment, List<ItemStack> currentAcquiredEquipment) {
      List<ItemStack> merged = new ArrayList<>();
      if (pickedUpEquipment != null) {
         for (ItemStack item : pickedUpEquipment) {
            addItemCopy(merged, item);
         }
      }

      for (ItemStack item : currentAcquiredEquipment) {
         if (hasItems(item)) {
            int missingAmount = item.getAmount();

            for (ItemStack knownItem : merged) {
               if (knownItem.isSimilar(item)) {
                  missingAmount -= Math.min(missingAmount, knownItem.getAmount());
                  if (missingAmount <= 0) {
                     break;
                  }
               }
            }

            if (missingAmount > 0) {
               ItemStack missingItem = item.clone();
               missingItem.setAmount(missingAmount);
               merged.add(missingItem);
            }
         }
      }

      return merged;
   }

   private static void addCurrentEquipment(LivingEntity entity, List<ItemStack> equipmentItems) {
      EntityEquipment equipment = entity.getEquipment();
      if (equipment != null) {
         addItemCopy(equipmentItems, equipment.getItemInMainHand());
         addItemCopy(equipmentItems, equipment.getItemInOffHand());
         ItemStack[] armorContents = equipment.getArmorContents();
         if (armorContents != null) {
            for (ItemStack armorItem : armorContents) {
               addItemCopy(equipmentItems, armorItem);
            }
         }
      }

      ItemStack[] horseInventory = getHorseInventory(entity);

      for (ItemStack inventoryItem : horseInventory) {
         addItemCopy(equipmentItems, inventoryItem);
      }

      if (entity instanceof Steerable && ((Steerable)entity).hasSaddle()) {
         addItemCopy(equipmentItems, new ItemStack(Material.SADDLE));
      }
   }

   private static ItemStack[] getHorseInventory(LivingEntity entity) {
      if (!(entity instanceof InventoryHolder holder)) {
         return new ItemStack[0];
      }

      ItemStack[] contents = holder.getInventory().getContents();
      return contents != null ? contents : new ItemStack[0];
   }

   private static void addItemCopy(List<ItemStack> items, ItemStack item) {
      if (hasItems(item)) {
         items.add(item.clone());
      }
   }

   private static void addAcquiredItem(List<ItemStack> items, ItemStack currentItem, ItemStack spawnItem, float currentDropChance, float spawnDropChance) {
      if (hasItems(currentItem)) {
         if (hasItems(spawnItem) && currentItem.isSimilar(spawnItem) && Float.compare(currentDropChance, spawnDropChance) == 0) {
            int acquiredAmount = currentItem.getAmount() - spawnItem.getAmount();
            if (acquiredAmount > 0) {
               ItemStack acquiredItem = currentItem.clone();
               acquiredItem.setAmount(acquiredAmount);
               items.add(acquiredItem);
            }
         } else {
            addItemCopy(items, currentItem);
         }
      }
   }

   private static int getNonEquipmentAmount(ItemStack item, int equipmentAmount) {
      return hasItems(item) ? Math.max(0, item.getAmount() - equipmentAmount) : 0;
   }

   private static boolean hasItems(ItemStack item) {
      return item != null && item.getType() != Material.AIR && item.getAmount() > 0;
   }

   private boolean isSafeToDuplicate(ItemStack item) {
      if (!hasItems(item) || this.manager.matchItem(item) != null) {
         return false;
      }

      if (!item.hasItemMeta()) {
         return true;
      }

      ItemMeta meta = item.getItemMeta();
      return meta == null
         ? true
         : !meta.hasDisplayName() && !meta.hasLore() && !meta.hasCustomModelData() && meta.getPersistentDataContainer().getKeys().isEmpty();
   }

   private static final class EquipmentSnapshot {
      private final ItemStack mainHand;
      private final ItemStack offHand;
      private final ItemStack[] armor;
      private final float mainHandDropChance;
      private final float offHandDropChance;
      private final float[] armorDropChances;
      private final ItemStack[] horseInventory;
      private final boolean steerableSaddle;

      private EquipmentSnapshot(
         ItemStack mainHand,
         float mainHandDropChance,
         ItemStack offHand,
         float offHandDropChance,
         ItemStack[] armor,
         float[] armorDropChances,
         ItemStack[] horseInventory,
         boolean steerableSaddle
      ) {
         this.mainHand = copyOrNull(mainHand);
         this.offHand = copyOrNull(offHand);
         this.armor = copyItems(armor);
         this.mainHandDropChance = mainHandDropChance;
         this.offHandDropChance = offHandDropChance;
         this.armorDropChances = armorDropChances != null ? (float[])armorDropChances.clone() : new float[0];
         this.horseInventory = copyItems(horseInventory);
         this.steerableSaddle = steerableSaddle;
      }

      private static HunterAuraListener.EquipmentSnapshot capture(LivingEntity entity) {
         EntityEquipment equipment = entity.getEquipment();
         ItemStack mainHand = equipment != null ? equipment.getItemInMainHand() : null;
         ItemStack offHand = equipment != null ? equipment.getItemInOffHand() : null;
         ItemStack[] armor = equipment != null ? equipment.getArmorContents() : null;
         int armorSize = armor != null ? armor.length : 0;
         HunterAuraListener.EquipmentSnapshot snapshot = new HunterAuraListener.EquipmentSnapshot(
            mainHand,
            equipment != null ? equipment.getItemInMainHandDropChance() : 0.0F,
            offHand,
            equipment != null ? equipment.getItemInOffHandDropChance() : 0.0F,
            armor,
            getArmorDropChances(equipment, armorSize),
            HunterAuraListener.getHorseInventory(entity),
            entity instanceof Steerable && ((Steerable)entity).hasSaddle()
         );
         return snapshot.hasAnyItems() ? snapshot : null;
      }

      private List<ItemStack> getAcquiredEquipment(LivingEntity entity) {
         List<ItemStack> acquiredItems = new ArrayList<>(10);
         EntityEquipment equipment = entity.getEquipment();
         if (equipment != null) {
            HunterAuraListener.addAcquiredItem(
               acquiredItems, equipment.getItemInMainHand(), this.mainHand, equipment.getItemInMainHandDropChance(), this.mainHandDropChance
            );
            HunterAuraListener.addAcquiredItem(
               acquiredItems, equipment.getItemInOffHand(), this.offHand, equipment.getItemInOffHandDropChance(), this.offHandDropChance
            );
            ItemStack[] currentArmor = equipment.getArmorContents();
            int armorSize = currentArmor != null ? currentArmor.length : 0;
            float[] currentArmorDropChances = getArmorDropChances(equipment, armorSize);

            for (int i = 0; i < armorSize; i++) {
               HunterAuraListener.addAcquiredItem(
                  acquiredItems, currentArmor[i], itemAt(this.armor, i), dropChanceAt(currentArmorDropChances, i), dropChanceAt(this.armorDropChances, i)
               );
            }
         }

         ItemStack[] currentHorseInventory = HunterAuraListener.getHorseInventory(entity);

         for (int i = 0; i < currentHorseInventory.length; i++) {
            HunterAuraListener.addAcquiredItem(acquiredItems, currentHorseInventory[i], itemAt(this.horseInventory, i), 0.0F, 0.0F);
         }

         if (entity instanceof Steerable && ((Steerable)entity).hasSaddle() && !this.steerableSaddle) {
            HunterAuraListener.addItemCopy(acquiredItems, new ItemStack(Material.SADDLE));
         }

         return acquiredItems;
      }

      private boolean hasAnyItems() {
         return HunterAuraListener.hasItems(this.mainHand)
            || HunterAuraListener.hasItems(this.offHand)
            || hasItems(this.armor)
            || hasItems(this.horseInventory)
            || this.steerableSaddle;
      }

      private static ItemStack copyOrNull(ItemStack item) {
         return HunterAuraListener.hasItems(item) ? item.clone() : null;
      }

      private static ItemStack[] copyItems(ItemStack[] items) {
         if (items != null && items.length != 0) {
            ItemStack[] copies = new ItemStack[items.length];

            for (int i = 0; i < items.length; i++) {
               copies[i] = copyOrNull(items[i]);
            }

            return copies;
         } else {
            return new ItemStack[0];
         }
      }

      private static ItemStack itemAt(ItemStack[] items, int index) {
         return index >= 0 && index < items.length ? items[index] : null;
      }

      private static float[] getArmorDropChances(EntityEquipment equipment, int armorSize) {
         if (equipment != null && armorSize > 0) {
            float[] chances = new float[armorSize];
            if (armorSize > 0) {
               chances[0] = equipment.getBootsDropChance();
            }

            if (armorSize > 1) {
               chances[1] = equipment.getLeggingsDropChance();
            }

            if (armorSize > 2) {
               chances[2] = equipment.getChestplateDropChance();
            }

            if (armorSize > 3) {
               chances[3] = equipment.getHelmetDropChance();
            }

            return chances;
         } else {
            return new float[0];
         }
      }

      private static float dropChanceAt(float[] dropChances, int index) {
         return index >= 0 && index < dropChances.length ? dropChances[index] : 0.0F;
      }

      private static boolean hasItems(ItemStack[] items) {
         for (ItemStack item : items) {
            if (HunterAuraListener.hasItems(item)) {
               return true;
            }
         }

         return false;
      }
   }
}
