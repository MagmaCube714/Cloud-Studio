package cs.cloudstudio.listener;

import cs.cloudstudio.manager.AuraManager;
import cs.cloudstudio.manager.aura.FallProtectionAura;
import cs.cloudstudio.util.AuraUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public final class FallProtectionAuraListener implements Listener {
   private final AuraManager manager;

   public FallProtectionAuraListener(AuraManager manager) {
      this.manager = manager;
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onFallDamage(EntityDamageEvent event) {
      if (event.getEntity() instanceof Player && event.getCause() == DamageCause.FALL) {
         Player player = (Player)event.getEntity();
         FallProtectionAura aura = AuraUtil.getActiveAura(player, this.manager, FallProtectionAura.class);
         if (aura != null) {
            event.setDamage(event.getDamage() * (1.0 - aura.damageReduction));
         }
      }
   }
}
