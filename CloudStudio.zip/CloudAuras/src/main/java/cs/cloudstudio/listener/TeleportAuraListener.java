package cs.cloudstudio.listener;

import cs.cloudstudio.manager.TeleportManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;

public final class TeleportAuraListener implements Listener {
   private final TeleportManager teleportManager;

   public TeleportAuraListener(TeleportManager teleportManager) {
      this.teleportManager = teleportManager;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onChorusEat(PlayerItemConsumeEvent event) {
      this.teleportManager.handleChorusEat(event);
   }
}
