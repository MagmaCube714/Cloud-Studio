rootProject.name = "CloudAuras"
