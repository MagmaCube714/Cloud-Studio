package cs.cloudstudio.listener;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.manager.LootEditHolder;
import cs.cloudstudio.manager.LootManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class InventoryListener implements Listener {
   private final CloudAirDrop plugin;
   private final LootManager lootManager;

   public InventoryListener(CloudAirDrop plugin, LootManager lootManager) {
      this.plugin = plugin;
      this.lootManager = lootManager;
   }

   @EventHandler
   public void onClose(InventoryCloseEvent event) {
      Inventory inventory = event.getInventory();
      InventoryHolder holder = inventory.getHolder();
      if (holder instanceof LootEditHolder) {
         if (event.getPlayer() instanceof Player) {
            LootEditHolder editHolder = (LootEditHolder)holder;
            this.lootManager.saveEditor((Player)event.getPlayer(), editHolder.getType(), inventory);
         }
      }
   }
}
