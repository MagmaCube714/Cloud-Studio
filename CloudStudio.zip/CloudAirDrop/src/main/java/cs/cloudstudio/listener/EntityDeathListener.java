package cs.cloudstudio.listener;

import cs.cloudstudio.manager.AirDropManager;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;

public final class EntityDeathListener implements Listener {
   private final AirDropManager airDropManager;

   public EntityDeathListener(AirDropManager airDropManager) {
      this.airDropManager = airDropManager;
   }

   @EventHandler(ignoreCancelled = true)
   public void onDamage(EntityDamageEvent event) {
      this.airDropManager.handleBossDamage(event.getEntity(), event.getFinalDamage());
   }

   @EventHandler
   public void onDeath(EntityDeathEvent event) {
      LivingEntity entity = event.getEntity();
      this.airDropManager.handleBossDeath(entity, entity.getKiller());
   }
}
