package cs.cloudstudio.listener;

import cs.cloudstudio.manager.AirDropManager;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerListener implements Listener {
   private final AirDropManager airDropManager;
   private final Map<UUID, Long> flyCheck = new HashMap<>();

   public PlayerListener(AirDropManager airDropManager) {
      this.airDropManager = airDropManager;
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      this.airDropManager.addPlayer(event.getPlayer());
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.flyCheck.remove(event.getPlayer().getUniqueId());
   }

   @EventHandler
   public void onMove(PlayerMoveEvent event) {
      if (this.airDropManager.isStarted()) {
         if (event.getTo() != null) {
            Player player = event.getPlayer();
            if (player.isFlying() && !player.hasPermission("cloudairdrop.fly")) {
               long now = System.currentTimeMillis();
               Long last = this.flyCheck.get(player.getUniqueId());
               if (last == null || now - last >= 500L) {
                  this.flyCheck.put(player.getUniqueId(), now);
                  if (this.airDropManager.isInside(event.getTo())) {
                     player.setFlying(false);
                     player.setAllowFlight(false);
                  }
               }
            }
         }
      }
   }
}
