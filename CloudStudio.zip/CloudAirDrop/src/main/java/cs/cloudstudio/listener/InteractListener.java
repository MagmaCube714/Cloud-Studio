package cs.cloudstudio.listener;

import cs.cloudstudio.manager.AirDropManager;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public final class InteractListener implements Listener {
   private final AirDropManager airDropManager;

   public InteractListener(AirDropManager airDropManager) {
      this.airDropManager = airDropManager;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onInteract(PlayerInteractEvent event) {
      Action action = event.getAction();
      if (action == Action.RIGHT_CLICK_BLOCK || action == Action.LEFT_CLICK_BLOCK) {
         Block block = event.getClickedBlock();
         if (block != null && this.airDropManager.isAirDropBlock(block)) {
            event.setCancelled(true);
            if (action == Action.RIGHT_CLICK_BLOCK) {
               this.airDropManager.handleInteract(event.getPlayer(), block, action);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onBlockDamage(BlockDamageEvent event) {
      if (this.airDropManager.isAirDropBlock(event.getBlock())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onBlockBreak(BlockBreakEvent event) {
      if (this.airDropManager.isAirDropBlock(event.getBlock())) {
         event.setCancelled(true);
      }
   }
}
