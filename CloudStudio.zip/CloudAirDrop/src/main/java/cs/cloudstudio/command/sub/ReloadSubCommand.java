package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.command.BaseCommand;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand extends BaseCommand {
   private final CloudAirDrop plugin;

   public ReloadSubCommand(CloudAirDrop plugin) {
      this.plugin = plugin;
   }

   @Override
   public String name() {
      return "reload";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      this.plugin.reloadPlugin();
      sender.sendMessage(this.plugin.message("reloaded"));
      return true;
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      return Collections.emptyList();
   }
}
