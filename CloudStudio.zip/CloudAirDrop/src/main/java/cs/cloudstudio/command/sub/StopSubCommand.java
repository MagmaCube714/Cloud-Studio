package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.manager.AirDropManager;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.CommandSender;

public final class StopSubCommand extends BaseCommand {
   private final CloudAirDrop plugin;
   private final AirDropManager airDropManager;

   public StopSubCommand(CloudAirDrop plugin, AirDropManager airDropManager) {
      this.plugin = plugin;
      this.airDropManager = airDropManager;
   }

   @Override
   public String name() {
      return "stop";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      if (!this.airDropManager.isStarted()) {
         sender.sendMessage(this.plugin.message("not-started"));
         return true;
      } else {
         this.airDropManager.stop(false);
         sender.sendMessage(this.plugin.message("stopped"));
         return true;
      }
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      return Collections.emptyList();
   }
}
