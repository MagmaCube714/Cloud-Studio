package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.manager.AirDropManager;
import cs.cloudstudio.manager.AirDropType;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.CommandSender;

public final class StartSubCommand extends BaseCommand {
   private final CloudAirDrop plugin;
   private final AirDropManager airDropManager;

   public StartSubCommand(CloudAirDrop plugin, AirDropManager airDropManager) {
      this.plugin = plugin;
      this.airDropManager = airDropManager;
   }

   @Override
   public String name() {
      return "start";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      AirDropType type = args.length > 1 ? AirDropType.parse(args[1]) : this.airDropManager.randomType();
      if (args.length > 1 && type == null) {
         sender.sendMessage(this.plugin.message("wrong-type"));
         return true;
      }

      if (this.airDropManager.isStarted()) {
         sender.sendMessage(this.plugin.message("already-started"));
         return true;
      }

      if (this.airDropManager.start(type)) {
         sender.sendMessage(this.plugin.message("started"));
      }

      return true;
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      return args.length == 2 ? this.types(args[1]) : Collections.emptyList();
   }
}
