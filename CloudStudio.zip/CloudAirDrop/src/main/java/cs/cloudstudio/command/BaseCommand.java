package cs.cloudstudio.command;

import cs.cloudstudio.manager.AirDropType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public abstract class BaseCommand implements SubCommand {
   protected List<String> filter(List<String> values, String token) {
      if (values != null && !values.isEmpty()) {
         String lower = token == null ? "" : token.toLowerCase(Locale.ROOT);
         List<String> result = new ArrayList<>();

         for (String value : values) {
            if (value.toLowerCase(Locale.ROOT).startsWith(lower)) {
               result.add(value);
            }
         }

         return result;
      } else {
         return Collections.emptyList();
      }
   }

   protected List<String> types(String token) {
      List<String> values = new ArrayList<>();

      for (AirDropType type : AirDropType.values()) {
         values.add(type.name().toLowerCase(Locale.ROOT));
      }

      return this.filter(values, token);
   }
}
