package cs.cloudstudio.command;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.command.sub.AddSubCommand;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import cs.cloudstudio.command.sub.StartSubCommand;
import cs.cloudstudio.command.sub.StopSubCommand;
import cs.cloudstudio.manager.AirDropManager;
import cs.cloudstudio.manager.LootManager;
import cs.cloudstudio.manager.ScheduleManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public final class AdminCommand implements CommandExecutor, TabCompleter {
   private final CloudAirDrop plugin;
   private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();

   public AdminCommand(CloudAirDrop plugin, AirDropManager airDropManager, LootManager lootManager, ScheduleManager scheduleManager) {
      this.plugin = plugin;
      this.register(new ReloadSubCommand(plugin));
      this.register(new StartSubCommand(plugin, airDropManager));
      this.register(new StopSubCommand(plugin, airDropManager));
      this.register(new AddSubCommand(plugin, lootManager));
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("cloudairdrop.admin")) {
         sender.sendMessage(this.plugin.message("no-perm"));
         return true;
      } else if (args.length == 0) {
         this.usage(sender);
         return true;
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            this.usage(sender);
            return true;
         } else {
            return subCommand.execute(sender, args);
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.hasPermission("cloudairdrop.admin")) {
         return Collections.emptyList();
      }

      if (args.length == 1) {
         return this.filter(new ArrayList<>(this.subCommands.keySet()), args[0]);
      }

      SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
      return subCommand == null ? Collections.emptyList() : subCommand.tab(sender, args);
   }

   private void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.name(), subCommand);
   }

   private void usage(CommandSender sender) {
      for (String line : this.plugin.messageList("admin-usage", this.plugin.defaultAdminUsage())) {
         sender.sendMessage(line);
      }
   }

   private List<String> filter(List<String> values, String token) {
      String lower = token == null ? "" : token.toLowerCase(Locale.ROOT);
      List<String> result = new ArrayList<>();

      for (String value : values) {
         if (value.toLowerCase(Locale.ROOT).startsWith(lower)) {
            result.add(value);
         }
      }

      return result;
   }
}
