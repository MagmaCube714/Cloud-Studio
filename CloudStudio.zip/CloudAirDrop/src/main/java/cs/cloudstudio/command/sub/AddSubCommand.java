package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.manager.AirDropType;
import cs.cloudstudio.manager.LootManager;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class AddSubCommand extends BaseCommand {
   private final CloudAirDrop plugin;
   private final LootManager lootManager;

   public AddSubCommand(CloudAirDrop plugin, LootManager lootManager) {
      this.plugin = plugin;
      this.lootManager = lootManager;
   }

   @Override
   public String name() {
      return "add";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage(this.plugin.message("only-player"));
         return true;
      } else if (args.length < 2) {
         sender.sendMessage(this.plugin.message("wrong-type"));
         return true;
      } else {
         AirDropType type = AirDropType.parse(args[1]);
         if (type == null) {
            sender.sendMessage(this.plugin.message("wrong-type"));
            return true;
         } else {
            this.lootManager.openEditor((Player)sender, type);
            return true;
         }
      }
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      return args.length == 2 ? this.types(args[1]) : Collections.emptyList();
   }
}
