package cs.cloudstudio.util;

import cs.cloudstudio.CloudAirDrop;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public final class DropItemUtil {
   private final CloudAirDrop plugin;
   private BukkitTask dropTask;

   public DropItemUtil(CloudAirDrop plugin) {
      this.plugin = plugin;
   }

   public void blowItems(Location location, List<ItemStack> items, final Runnable onComplete) {
      this.cancelDrops();
      if (location != null && location.getWorld() != null && items != null && !items.isEmpty()) {
         final List<ItemStack> prepared = new ArrayList<>(items.size());

         for (ItemStack item : items) {
            if (!ItemUtil.isEmpty(item)) {
               prepared.add(item.clone());
            }
         }

         if (prepared.isEmpty()) {
            onComplete.run();
         } else {
            Collections.shuffle(prepared, ThreadLocalRandom.current());
            final World world = location.getWorld();
            final Location center = location.clone();
            this.playOpenEffects(world, center);
            final int[] index = new int[]{0};
            this.dropTask = this.plugin
               .getServer()
               .getScheduler()
               .runTaskTimer(
                  this.plugin,
                  new Runnable() {
                     @Override
                     public void run() {
                        if (index[0] < prepared.size() && world != null) {
                           ThreadLocalRandom random = ThreadLocalRandom.current();
                           double angle = random.nextDouble() * Math.PI * 2.0;
                           double distance = random.nextDouble(2.0, 10.0);
                           Location drop = new Location(
                              world, center.getX() + distance * Math.cos(angle), center.getY() + 10.0, center.getZ() + distance * Math.sin(angle)
                           );

                           try {
                              world.playSound(center, Sound.ENTITY_ITEM_PICKUP, 1.0F, 1.0F);
                           } catch (Throwable var10) {
                           }

                           Item entity = world.dropItem(drop, prepared.get(index[0]++));

                           try {
                              entity.setGlowing(true);
                           } catch (Throwable var9x) {
                           }

                           if (index[0] >= prepared.size()) {
                              DropItemUtil.this.cancelDrops();
                              onComplete.run();
                           }
                        } else {
                           DropItemUtil.this.cancelDrops();
                           onComplete.run();
                        }
                     }
                  },
                  5L,
                  5L
               );
         }
      } else {
         onComplete.run();
      }
   }

   public void cancelDrops() {
      if (this.dropTask != null && !this.dropTask.isCancelled()) {
         this.dropTask.cancel();
      }

      this.dropTask = null;
   }

   private void playOpenEffects(World world, Location center) {
      if (world != null && center != null) {
         try {
            world.playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.0F, 1.0F);
            world.spawnParticle(Particle.EXPLOSION_EMITTER, center, 4);
            world.spawnParticle(Particle.EXPLOSION, center, 10);
         } catch (Throwable var6) {
         }

         try {
            for (Player player : world.getNearbyEntitiesByType(Player.class, center, 10.0, 5.0, 10.0)) {
               Vector vector = player.getLocation().toVector().subtract(center.toVector());
               if (vector.lengthSquared() > 0.0) {
                  player.setVelocity(vector.normalize().multiply(0.8));
               }
            }
         } catch (Throwable var7) {
         }
      }
   }
}
