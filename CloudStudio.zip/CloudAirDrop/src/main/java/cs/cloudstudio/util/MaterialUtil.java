package cs.cloudstudio.util;

import org.bukkit.Material;

public final class MaterialUtil {
   private MaterialUtil() {
   }

   public static Material material(String value, Material def) {
      if (value != null && !value.trim().isEmpty()) {
         Material material = Material.matchMaterial(value.trim().toUpperCase());
         return material == null ? def : material;
      } else {
         return def;
      }
   }
}
