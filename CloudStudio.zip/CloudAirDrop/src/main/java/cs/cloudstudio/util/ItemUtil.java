package cs.cloudstudio.util;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ItemUtil {
   private ItemUtil() {
   }

   public static boolean isEmpty(ItemStack item) {
      return item == null || item.getType() == Material.AIR || item.getAmount() <= 0;
   }

   public static String displayName(ItemStack item) {
      if (isEmpty(item)) {
         return "";
      }

      ItemMeta meta = item.hasItemMeta() ? item.getItemMeta() : null;
      return meta != null && meta.hasDisplayName() ? ColorUtil.legacy(meta.displayName()) : "&f" + ItemNameTranslator.of(item.getType());
   }
}
