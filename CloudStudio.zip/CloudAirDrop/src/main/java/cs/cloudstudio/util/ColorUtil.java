package cs.cloudstudio.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class ColorUtil {
   private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");
   private static final String COLOR_CODES = "0123456789AaBbCcDdEeFfKkLlMmNnOoRrXx";
   private static final LegacyComponentSerializer SECTION = LegacyComponentSerializer.builder()
      .character('§')
      .hexColors()
      .useUnusualXRepeatedCharacterHexFormat()
      .build();

   private ColorUtil() {
   }

   public static String color(String text) {
      if (text == null) {
         return "";
      }

      Matcher matcher = HEX.matcher(text);
      StringBuffer buffer = new StringBuffer();

      while (matcher.find()) {
         String hex = matcher.group(1);
         StringBuilder replacement = new StringBuilder("§x");

         for (char c : hex.toCharArray()) {
            replacement.append('§').append(c);
         }

         matcher.appendReplacement(buffer, replacement.toString());
      }

      matcher.appendTail(buffer);
      return translateAlternateColorCodes(buffer.toString());
   }

   public static List<String> color(List<String> lines) {
      List<String> result = new ArrayList<>();
      if (lines == null) {
         return result;
      }

      for (String line : lines) {
         result.add(color(line));
      }

      return result;
   }

   public static String translateAlternateColorCodes(String text) {
      if (text == null || text.indexOf('&') < 0) {
         return text;
      }

      char[] chars = text.toCharArray();

      for (int i = 0; i < chars.length - 1; i++) {
         if (chars[i] == '&' && COLOR_CODES.indexOf(chars[i + 1]) > -1) {
            chars[i] = '§';
            chars[i + 1] = Character.toLowerCase(chars[i + 1]);
         }
      }

      return new String(chars);
   }

   public static Component component(String legacy) {
      return legacy == null || legacy.isEmpty() ? Component.empty() : SECTION.deserialize(legacy);
   }

   public static String legacy(Component component) {
      return component == null ? "" : SECTION.serialize(component);
   }
}
