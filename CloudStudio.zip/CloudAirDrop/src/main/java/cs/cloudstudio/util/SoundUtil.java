package cs.cloudstudio.util;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;

public final class SoundUtil {
   private static volatile Map<String, Sound> index;

   private SoundUtil() {
   }

   public static Sound parse(String value) {
      if (value == null) {
         return null;
      }

      String trimmed = value.trim();
      if (!trimmed.isEmpty() && !"null".equalsIgnoreCase(trimmed)) {
         NamespacedKey key = NamespacedKey.fromString(trimmed.toLowerCase(Locale.ROOT));
         if (key != null) {
            Sound direct = (Sound)Registry.SOUNDS.get(key);
            if (direct != null) {
               return direct;
            }
         }

         return index().get(normalize(trimmed));
      } else {
         return null;
      }
   }

   public static Sound parse(String value, Sound fallback) {
      Sound parsed = parse(value);
      return parsed == null ? fallback : parsed;
   }

   private static Map<String, Sound> index() {
      Map<String, Sound> local = index;
      if (local != null) {
         return local;
      }

      synchronized (SoundUtil.class) {
         if (index != null) {
            return index;
         }

         Map<String, Sound> built = new HashMap<>(1536);

         for (Sound sound : Registry.SOUNDS) {
            built.put(normalize(Registry.SOUNDS.getKey(sound).getKey()), sound);
         }

         index = built;
         return built;
      }
   }

   private static String normalize(String raw) {
      StringBuilder builder = new StringBuilder(raw.length());

      for (int i = 0; i < raw.length(); i++) {
         char c = raw.charAt(i);
         if (Character.isLetterOrDigit(c)) {
            builder.append(Character.toLowerCase(c));
         }
      }

      return builder.toString();
   }
}
