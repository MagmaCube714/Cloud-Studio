package cs.cloudstudio.util;

public final class TimeUtil {
   private TimeUtil() {
   }

   public static String format(int seconds) {
      if (seconds < 0) {
         seconds = 0;
      }

      int minutes = seconds / 60;
      int left = seconds % 60;
      if (minutes <= 0) {
         return left + "с";
      } else {
         return left == 0 ? minutes + "м" : minutes + "м " + left + "с";
      }
   }
}
