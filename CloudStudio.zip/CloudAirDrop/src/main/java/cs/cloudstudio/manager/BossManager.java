package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAirDrop;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.Location;

public final class BossManager {
   private final CloudAirDrop plugin;

   public BossManager(CloudAirDrop plugin) {
      this.plugin = plugin;
   }

   public void spawn(Location location) {
      if (location != null && location.getWorld() != null) {
         Location spawnLocation = location.clone();
         int chunkX = spawnLocation.getBlockX() >> 4;
         int chunkZ = spawnLocation.getBlockZ() >> 4;
         if (spawnLocation.getWorld().isChunkLoaded(chunkX, chunkZ)) {
            this.dispatchSpawn(spawnLocation);
         } else {
            try {
               spawnLocation.getWorld().getChunkAtAsync(chunkX, chunkZ, true, false).whenComplete((chunk, throwable) -> {
                  Runnable continuation = new Runnable() {
                     @Override
                     public void run() {
                        if (throwable == null && chunk != null) {
                           BossManager.this.dispatchSpawn(spawnLocation);
                        } else {
                           BossManager.this.plugin.warn("Босс не создан: чанк не загружен асинхронно");
                        }
                     }
                  };
                  if (Bukkit.isPrimaryThread()) {
                     continuation.run();
                  } else if (this.plugin.isEnabled()) {
                     Bukkit.getScheduler().runTask(this.plugin, continuation);
                  }
               });
            } catch (Throwable ex) {
               this.plugin.warn("Босс не создан: асинхронная загрузка чанка недоступна");
            }
         }
      } else {
         this.plugin.warn("Босс не создан: локация не найдена");
      }
   }

   private void dispatchSpawn(Location location) {
      String command = this.plugin.getConfig().getString("bosses.goblin.command", "mm mobs spawn goblin_3 1 %world%,%x%,%y%,%z%");
      command = this.format(command, location);

      try {
         boolean success = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), this.stripSlash(command));
         if (!success && command.startsWith("mm ")) {
            success = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), this.stripSlash(command.replaceFirst("^mm ", "mythicmobs ")));
         }

         if (!success) {
            this.plugin.warn("Босс не создан: команда не выполнена: " + command);
         }
      } catch (Throwable ex) {
         this.plugin.warn("Босс не создан: MythicMobs недоступен");
      }
   }

   private String format(String command, Location location) {
      return command.replace("%world%", location.getWorld().getName())
         .replace("%x%", this.format(location.getX()))
         .replace("%y%", this.format(location.getY()))
         .replace("%z%", this.format(location.getZ()))
         .replace("%blockX%", Integer.toString(location.getBlockX()))
         .replace("%blockY%", Integer.toString(location.getBlockY()))
         .replace("%blockZ%", Integer.toString(location.getBlockZ()));
   }

   private String format(double value) {
      return Math.abs(value - Math.rint(value)) < 1.0E-4 ? Integer.toString((int)Math.rint(value)) : String.format(Locale.US, "%.2f", value);
   }

   private String stripSlash(String command) {
      String value = command == null ? "" : command.trim();

      while (value.startsWith("/")) {
         value = value.substring(1);
      }

      return value;
   }
}
