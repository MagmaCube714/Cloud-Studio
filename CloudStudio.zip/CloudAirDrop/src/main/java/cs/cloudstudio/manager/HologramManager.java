package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.util.ColorUtil;
import eu.decentsoftware.holograms.api.DHAPI;
import eu.decentsoftware.holograms.api.holograms.Hologram;
import java.util.List;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class HologramManager {
   private static final String HOLOGRAM_NAME = "cloudairdrop_runtime";
   private final CloudAirDrop plugin;
   private Hologram hologram;
   private Location anchor;
   private List<String> renderedLines = List.of();
   private boolean dependencyAvailable;
   private boolean absenceReported;
   private boolean failureReported;

   public HologramManager(CloudAirDrop plugin) {
      this.plugin = plugin;
      this.remove();
   }

   public void create(Location location, List<String> lines) {
      this.remove();
      if (this.available() && this.plugin.isEnabled() && location != null && location.getWorld() != null) {
         World world = location.getWorld();
         if (world.isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4)) {
            Location nextAnchor = location.clone();
            List<String> nextLines = this.render(lines);

            try {
               Hologram created = DHAPI.createHologram("cloudairdrop_runtime", hologramLocation(location), nextLines);
               if (created == null) {
                  throw new IllegalStateException("DecentHolograms returned no hologram");
               }

               this.hologram = created;
               this.anchor = nextAnchor;
               this.renderedLines = nextLines;
               this.failureReported = false;
            } catch (RuntimeException | LinkageError error) {
               this.handleFailure("create", error);
            }
         }
      }
   }

   public void update(Location location, List<String> lines) {
      if (this.available() && location != null && location.getWorld() != null) {
         try {
            Hologram current = this.hologram;
            if (current == null || !this.sameAnchor(location)) {
               this.create(location, lines);
               return;
            }

            List<String> updatedLines = this.render(lines);
            if (updatedLines.size() != this.renderedLines.size()) {
               DHAPI.setHologramLines(current, updatedLines);
            } else {
               for (int line = 0; line < updatedLines.size(); line++) {
                  String updated = updatedLines.get(line);
                  if (!updated.equals(this.renderedLines.get(line))) {
                     DHAPI.setHologramLine(current, line, updated);
                  }
               }
            }

            this.renderedLines = updatedLines;
            this.failureReported = false;
         } catch (RuntimeException | LinkageError error) {
            this.handleFailure("update", error);
         }
      }
   }

   public void remove() {
      if (this.available()) {
         try {
            DHAPI.removeHologram("cloudairdrop_runtime");
         } catch (RuntimeException | LinkageError error) {
            this.handleFailure("remove", error);
         }
      }

      this.hologram = null;
      this.anchor = null;
      this.renderedLines = List.of();
   }

   public List<String> lines(String title, String bottom) {
      return List.of(title == null ? "" : title, bottom == null ? "" : bottom);
   }

   private boolean available() {
      if (this.dependencyAvailable) {
         return true;
      }

      this.dependencyAvailable = Bukkit.getPluginManager().isPluginEnabled("DecentHolograms");
      if (this.dependencyAvailable) {
         return true;
      }

      if (!this.absenceReported) {
         this.absenceReported = true;
         this.plugin.getLogger().warning("DecentHolograms не найден — голограмма аирдропа отключена");
      }

      return false;
   }

   private boolean sameAnchor(Location location) {
      return this.anchor != null
         && location.getWorld().equals(this.anchor.getWorld())
         && location.getBlockX() == this.anchor.getBlockX()
         && location.getBlockY() == this.anchor.getBlockY()
         && location.getBlockZ() == this.anchor.getBlockZ();
   }

   private List<String> render(List<String> lines) {
      if (lines != null && !lines.isEmpty()) {
         return lines.size() == 2 ? List.of(ColorUtil.color(lines.get(0)), ColorUtil.color(lines.get(1))) : List.copyOf(ColorUtil.color(lines));
      } else {
         return List.of();
      }
   }

   private static Location hologramLocation(Location location) {
      return location.clone().add(0.5, 1.73, 0.5);
   }

   private void handleFailure(String operation, Throwable error) {
      this.hologram = null;
      this.anchor = null;
      this.renderedLines = List.of();
      this.dependencyAvailable = Bukkit.getPluginManager().isPluginEnabled("DecentHolograms");
      if (!this.failureReported) {
         this.failureReported = true;
         this.plugin.getLogger().log(Level.WARNING, "Ошибка DecentHolograms при операции " + operation, error);
      }
   }
}
