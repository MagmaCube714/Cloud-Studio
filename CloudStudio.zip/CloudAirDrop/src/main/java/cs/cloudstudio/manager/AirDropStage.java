package cs.cloudstudio.manager;

public enum AirDropStage {
   CLOSED,
   BOSS,
   OPENING,
   OPEN;
}
