package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAirDrop;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

public final class ScheduleManager {
   private final CloudAirDrop plugin;
   private final AirDropManager airDropManager;
   private final Map<DayOfWeek, List<LocalTime>> schedule = new EnumMap<>(DayOfWeek.class);
   private BukkitTask task;
   private ZoneId zoneId;
   private boolean running;
   private long generation;

   public ScheduleManager(CloudAirDrop plugin, AirDropManager airDropManager) {
      this.plugin = plugin;
      this.airDropManager = airDropManager;
      this.reload();
   }

   public void reload() {
      this.zoneId = this.resolveZone();
      this.schedule.clear();

      for (DayOfWeek day : DayOfWeek.values()) {
         List<LocalTime> parsed = new ArrayList<>();

         for (String value : this.plugin.getConfig().getStringList("schedule." + dayName(day))) {
            LocalTime time = this.parseTime(dayName(day), value);
            if (time != null && !parsed.contains(time)) {
               parsed.add(time);
            }
         }

         if (!parsed.isEmpty()) {
            parsed.sort(Comparator.naturalOrder());
            this.schedule.put(day, List.copyOf(parsed));
         }
      }

      if (this.running) {
         this.generation++;
         this.armNext(ZonedDateTime.now(this.zoneId));
      }
   }

   public void start() {
      if (!this.running) {
         this.running = true;
         this.generation++;
         this.armNext(ZonedDateTime.now(this.zoneId));
      }
   }

   public void stop() {
      this.running = false;
      this.generation++;
      this.cancelTask();
   }

   private void armNext(ZonedDateTime reference) {
      this.cancelTask();
      if (this.running && this.plugin.isEnabled() && !this.schedule.isEmpty()) {
         ZonedDateTime target = this.nextSchedule(reference);
         if (target != null) {
            long expectedGeneration = this.generation;
            this.task = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               this.task = null;
               if (this.running && this.plugin.isEnabled() && this.generation == expectedGeneration) {
                  ZonedDateTime now = ZonedDateTime.now(this.zoneId);
                  if (now.isBefore(target)) {
                     this.armNext(now);
                  } else {
                     if (!this.airDropManager.isStarted()) {
                        this.airDropManager.start(this.airDropManager.randomType());
                     }

                     this.armNext(target.plusMinutes(1L));
                  }
               }
            }, ticksUntil(reference, target));
         }
      }
   }

   private ZonedDateTime nextSchedule(ZonedDateTime reference) {
      ZonedDateTime best = null;
      LocalDate startDate = reference.toLocalDate();

      for (int dayOffset = 0; dayOffset <= 7; dayOffset++) {
         LocalDate date = startDate.plusDays(dayOffset);
         List<LocalTime> times = this.schedule.get(date.getDayOfWeek());
         if (times != null) {
            for (LocalTime time : times) {
               ZonedDateTime candidate = ZonedDateTime.of(date, time, this.zoneId);
               if (candidate.plusMinutes(1L).isAfter(reference) && (best == null || candidate.isBefore(best))) {
                  best = candidate;
               }
            }

            if (best != null) {
               break;
            }
         }
      }

      return best;
   }

   private static long ticksUntil(ZonedDateTime from, ZonedDateTime target) {
      long millis = Math.max(0L, Duration.between(from, target).toMillis());
      return Math.max(1L, (millis + 49L) / 50L);
   }

   private void cancelTask() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }
   }

   private LocalTime parseTime(String day, String value) {
      if (value == null) {
         return null;
      }

      try {
         String[] split = value.trim().split(":", -1);
         if (split.length != 2) {
            throw new IllegalArgumentException();
         }

         int hour = Integer.parseInt(split[0]);
         int minute = Integer.parseInt(split[1]);
         return LocalTime.of(hour, minute);
      } catch (RuntimeException exception) {
         this.plugin.warn("Расписание " + day + " содержит неверное время: " + value);
         return null;
      }
   }

   private ZoneId resolveZone() {
      String timezone = this.plugin.getConfig().getString("schedule.timezone", "Europe/Moscow");

      try {
         return ZoneId.of(timezone);
      } catch (RuntimeException exception) {
         this.plugin.warn("Неверный timezone в schedule: Europe/Moscow используется по умолчанию");
         return ZoneId.of("Europe/Moscow");
      }
   }

   private static String dayName(DayOfWeek day) {
      return day.name().toLowerCase(Locale.ROOT);
   }
}
