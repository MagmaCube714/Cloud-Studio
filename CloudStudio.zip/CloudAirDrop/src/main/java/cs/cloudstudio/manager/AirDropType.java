package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.util.ColorUtil;

public enum AirDropType {
   LEGENDARY("legendaryName", "legendaryChance", "legendaryLootCount", 13),
   MYTHIC("mythicName", "mythicChance", "mythicLootCount", 11),
   EPIC("epicName", "epicChance", "epicLootCount", 9),
   RARE("rareName", "rareChance", "rareLootCount", 7),
   COMMON("commonName", "commonChance", "commonLootCount", 5);

   private final String namePath;
   private final String chancePath;
   private final String lootCountPath;
   private final int defaultLootCount;

   AirDropType(String namePath, String chancePath, String lootCountPath, int defaultLootCount) {
      this.namePath = namePath;
      this.chancePath = chancePath;
      this.lootCountPath = lootCountPath;
      this.defaultLootCount = defaultLootCount;
   }

   public String getDisplayName(CloudAirDrop plugin) {
      return ColorUtil.color(plugin.getConfig().getString("airDrops." + this.namePath, this.name()));
   }

   public int getChance(CloudAirDrop plugin) {
      return Math.max(0, plugin.getConfig().getInt("airDrops." + this.chancePath, 0));
   }

   public int getLootCount(CloudAirDrop plugin) {
      return Math.max(0, plugin.getConfig().getInt("airDrops." + this.lootCountPath, this.defaultLootCount));
   }

   public static AirDropType parse(String value) {
      if (value == null) {
         return null;
      }

      try {
         return valueOf(value.trim().toUpperCase());
      } catch (IllegalArgumentException ex) {
         return null;
      }
   }
}
