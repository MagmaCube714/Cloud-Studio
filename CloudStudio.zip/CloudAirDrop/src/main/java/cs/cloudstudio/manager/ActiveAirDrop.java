package cs.cloudstudio.manager;

import java.util.List;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;

public final class ActiveAirDrop {
   private final AirDropType type;
   private final Location location;
   private final String regionName;
   private final List<ItemStack> loot;
   private AirDropStage stage;
   private int timeLeft;

   public ActiveAirDrop(AirDropType type, Location location, String regionName, List<ItemStack> loot) {
      this.type = type;
      this.location = location;
      this.regionName = regionName;
      this.loot = loot;
      this.stage = AirDropStage.CLOSED;
   }

   public AirDropType getType() {
      return this.type;
   }

   public Location getLocation() {
      return this.location;
   }

   public String getRegionName() {
      return this.regionName;
   }

   public List<ItemStack> getLoot() {
      return this.loot;
   }

   public AirDropStage getStage() {
      return this.stage;
   }

   public void setStage(AirDropStage stage) {
      this.stage = stage;
   }

   public int getTimeLeft() {
      return this.timeLeft;
   }

   public void setTimeLeft(int timeLeft) {
      this.timeLeft = timeLeft;
   }
}
