package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.CloudClans;
import cs.cloudstudio.database.model.Clan;
import cs.cloudstudio.util.ColorUtil;
import org.bukkit.entity.Player;

public final class ClanRewardManager {
   private final CloudAirDrop plugin;

   public ClanRewardManager(CloudAirDrop plugin) {
      this.plugin = plugin;
   }

   public void reward(Player player) {
      if (player != null) {
         int exp = Math.max(0, this.plugin.getConfig().getInt("clans.expReward", 0));
         int points = Math.max(0, this.plugin.getConfig().getInt("clans.pointsReward", 0));
         if (exp > 0 || points > 0) {
            CloudClans cloudClans = CloudClans.getInstance();
            if (cloudClans != null && cloudClans.isEnabled() && cloudClans.getClanManager() != null && cloudClans.getDatabase() != null) {
               Clan clan = cloudClans.getClanManager().getPlayerClan(player);
               if (clan != null) {
                  synchronized (clan) {
                     double oldExp = clan.getExp();
                     double oldPoints = clan.getPoints();
                     clan.setExp(oldExp + exp);
                     clan.setPoints(oldPoints + points);
                     if (!cloudClans.getDatabase().saveClanNow(clan)) {
                        clan.setExp(oldExp);
                        clan.setPoints(oldPoints);
                        this.plugin.warn("Награда клану '" + clan.getName() + "' не сохранена в базе данных");
                        return;
                     }
                  }

                  for (String message : this.plugin.getConfig().getStringList("clans.rewardMessage")) {
                     player.sendMessage(ColorUtil.color(message.replace("%exp%", Integer.toString(exp)).replace("%points%", Integer.toString(points))));
                  }
               }
            } else {
               this.plugin.warn("Награда клану не выдана: CloudClans не готов к работе");
            }
         }
      }
   }
}
