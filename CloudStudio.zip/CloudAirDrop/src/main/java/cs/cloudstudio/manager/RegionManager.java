package cs.cloudstudio.manager;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import cs.cloudstudio.CloudAirDrop;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Location;

public final class RegionManager {
   private final CloudAirDrop plugin;

   public RegionManager(CloudAirDrop plugin) {
      this.plugin = plugin;
   }

   public void create(String name, Location center) {
      if (name == null || center == null || center.getWorld() == null) {
         return;
      }
      if (!Bukkit.getPluginManager().isPluginEnabled("WorldGuard")) {
         this.plugin.warn("Регион аирдропа " + name + " не создан: WorldGuard не установлен");
         return;
      }
      try {
         int radius = Math.max(1, this.plugin.getConfig().getInt("settings.schematicRadius", 35));
         WorldGuardRegions.create(this.plugin, name, center, radius);
      } catch (RuntimeException | LinkageError exception) {
         this.plugin.warn("Регион аирдропа " + name + " не создан: " + exception);
      }
   }

   public void remove(String name, Location center) {
      if (name == null || center == null || center.getWorld() == null || !Bukkit.getPluginManager().isPluginEnabled("WorldGuard")) {
         return;
      }
      try {
         WorldGuardRegions.remove(name, center);
      } catch (RuntimeException | LinkageError exception) {
         this.plugin.warn("Регион аирдропа " + name + " не удалён: " + exception);
      }
   }

   private static final class WorldGuardRegions {
      private static com.sk89q.worldguard.protection.managers.RegionManager manager(Location location) {
         return WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(location.getWorld()));
      }

      static void create(CloudAirDrop plugin, String name, Location center, int radius) {
         com.sk89q.worldguard.protection.managers.RegionManager manager = manager(center);
         if (manager == null) {
            plugin.warn("Регион аирдропа " + name + " не создан: для мира нет менеджера регионов WorldGuard");
            return;
         }
         BlockVector3 min = BlockVector3.at(center.getBlockX() - radius, center.getBlockY() - radius, center.getBlockZ() - radius);
         BlockVector3 max = BlockVector3.at(center.getBlockX() + radius, center.getBlockY() + radius, center.getBlockZ() + radius);
         ProtectedRegion region = new ProtectedCuboidRegion(name, min, max);
         applyFlags(plugin, region, plugin.getConfig().getStringList("region.allowedFlags"), StateFlag.State.ALLOW);
         applyFlags(plugin, region, plugin.getConfig().getStringList("region.denyFlags"), StateFlag.State.DENY);
         applyFlags(plugin, region, List.of("block-break", "block-place"), StateFlag.State.DENY);
         applyFlags(plugin, region, List.of("interact"), StateFlag.State.ALLOW);
         manager.addRegion(region);
      }

      static void remove(String name, Location center) {
         com.sk89q.worldguard.protection.managers.RegionManager manager = manager(center);
         if (manager != null) {
            manager.removeRegion(name);
         }
      }

      private static void applyFlags(CloudAirDrop plugin, ProtectedRegion region, List<String> names, StateFlag.State state) {
         if (names == null) {
            return;
         }
         for (String name : names) {
            if (name == null || name.isBlank()) {
               continue;
            }
            Flag<?> flag = Flags.fuzzyMatchFlag(WorldGuard.getInstance().getFlagRegistry(), name.trim());
            if (flag instanceof StateFlag stateFlag) {
               region.setFlag(stateFlag, state);
            } else {
               plugin.warn("Флаг региона аирдропа не найден или не является state-флагом: " + name);
            }
         }
      }
   }
}
