package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.DropItemUtil;
import cs.cloudstudio.util.ItemUtil;
import cs.cloudstudio.util.MaterialUtil;
import cs.cloudstudio.util.SoundUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

public final class AirDropManager {
   private static final int HOLOGRAM_UPDATE_INTERVAL_SECONDS = 30;
   private static final int REWARD_LIFETIME_SECONDS = 120;
   private final CloudAirDrop plugin;
   private final LootManager lootManager;
   private final SchematicManager schematicManager;
   private final HologramManager hologramManager;
   private final BossBarManager bossBarManager;
   private final BossManager bossManager;
   private final LocationManager locationManager;
   private final RegionManager regionManager;
   private final ClanRewardManager clanRewardManager;
   private ActiveAirDrop active;
   private BukkitTask mainTask;
   private BukkitTask deleteTask;
   private BukkitTask openTask;
   private BukkitTask bossFindTask;
   private final DropItemUtil dropItemUtil;
   private Material activateMaterial;
   private UUID bossEntityId;
   private double lastBossProgress = 1.0;
   private boolean starting;
   private long startSequence;

   public AirDropManager(
      CloudAirDrop plugin,
      LootManager lootManager,
      SchematicManager schematicManager,
      HologramManager hologramManager,
      BossBarManager bossBarManager,
      BossManager bossManager,
      LocationManager locationManager,
      RegionManager regionManager,
      ClanRewardManager clanRewardManager
   ) {
      this.plugin = plugin;
      this.lootManager = lootManager;
      this.schematicManager = schematicManager;
      this.hologramManager = hologramManager;
      this.bossBarManager = bossBarManager;
      this.bossManager = bossManager;
      this.locationManager = locationManager;
      this.regionManager = regionManager;
      this.clanRewardManager = clanRewardManager;
      this.dropItemUtil = new DropItemUtil(plugin);
      this.refreshConfig();
   }

   public void refreshConfig() {
      this.activateMaterial = MaterialUtil.material(this.plugin.getConfig().getString("settings.activateMaterial", "RESPAWN_ANCHOR"), Material.RESPAWN_ANCHOR);
   }

   public boolean start(AirDropType type) {
      if (this.active == null && !this.starting) {
         final AirDropType selectedType = type == null ? this.randomType() : type;
         final List<ItemStack> loot = this.lootManager.getRandom(selectedType);
         if (loot.isEmpty()) {
            this.plugin.warn("Аирдроп " + selectedType.name() + " запущен без наград: награды не настроены");
         }

         this.starting = true;
         final long request = ++this.startSequence;
         this.locationManager.findLocationAsync(new Consumer<Location>() {
            public void accept(Location location) {
               if (AirDropManager.this.isCurrentStart(request)) {
                  if (location == null) {
                     AirDropManager.this.starting = false;
                  } else {
                     AirDropManager.this.prepareAtLocation(request, selectedType, loot, location);
                  }
               }
            }
         });
         return true;
      } else {
         return false;
      }
   }

   private void prepareAtLocation(final long request, final AirDropType type, final List<ItemStack> loot, final Location location) {
      if (this.isCurrentStart(request)) {
         this.schematicManager.holdLocationChunk(location);
         File schematic = this.schematicManager.resolveFile();
         this.schematicManager.pasteAsync(location, schematic, () -> this.isCurrentStart(request), new Consumer<Boolean>() {
            public void accept(Boolean pastedValue) {
               if (AirDropManager.this.isCurrentStart(request)) {
                  boolean pasted = pastedValue != null && pastedValue;
                  AirDropManager.this.finishStart(request, type, loot, location, pasted);
               }
            }
         });
      }
   }

   private void finishStart(long request, AirDropType type, List<ItemStack> loot, Location location, boolean pasted) {
      if (this.isCurrentStart(request)) {
         try {
            if (!pasted) {
               this.plugin.warn("Аирдроп не создан: схематика не была вставлена");
               this.starting = false;
               this.schematicManager.restore();
               return;
            }

            Block activateBlock = this.schematicManager.findActivateBlock(location, this.activateMaterial, 10);
            if (activateBlock == null) {
               this.plugin.warn("Аирдроп не создан: в схематике не найден блок активации " + this.activateMaterial);
               this.starting = false;
               this.schematicManager.restore();
               return;
            }

            this.schematicManager.clearAbove(activateBlock);
            Location airLocation = activateBlock.getLocation();
            this.active = new ActiveAirDrop(type, airLocation, "cloudairdrop_" + UUID.randomUUID().toString().replace("-", ""), loot);
            this.starting = false;
            this.regionManager.create(this.active.getRegionName(), this.active.getLocation());
            this.createClosedVisuals();
            this.notifyPlayers();
            this.startMainTask();
         } catch (Throwable ex) {
            this.starting = false;
            this.active = null;
            this.schematicManager.restore();
            this.plugin.warn("Аирдроп не создан: " + this.safeMessage(ex));
         }
      }
   }

   private boolean isCurrentStart(long request) {
      return this.plugin.isEnabled() && this.starting && request == this.startSequence && this.active == null;
   }

   private String safeMessage(Throwable throwable) {
      Throwable current = throwable;

      while (current.getCause() != null && (current.getMessage() == null || current.getMessage().trim().isEmpty())) {
         current = current.getCause();
      }

      String message = current.getMessage();
      return message != null && !message.trim().isEmpty() ? message : current.getClass().getSimpleName();
   }

   public void stop(boolean sendLog) {
      this.startSequence++;
      this.starting = false;
      this.cancelTasks();

      try {
         this.bossBarManager.remove();
      } catch (RuntimeException ex) {
         this.plugin.warn("Не удалось удалить bossbar аирдропа: " + this.safeMessage(ex));
      }

      this.hologramManager.remove();
      this.removeBossEntity();
      this.lastBossProgress = 1.0;
      this.dropItemUtil.cancelDrops();
      if (this.active != null) {
         this.regionManager.remove(this.active.getRegionName(), this.active.getLocation());
      }

      this.schematicManager.restore();
      this.active = null;
      if (sendLog) {
         this.plugin.log("&fCloudAirDrop &cаирдроп остановлен");
      }
   }

   public void shutdown() {
      this.stop(false);
      this.bossBarManager.shutdown();
   }

   public boolean isStarted() {
      return this.active != null || this.starting;
   }

   public ActiveAirDrop getActive() {
      return this.active;
   }

   public void handleInteract(Player player, Block block, Action action) {
      if (this.active != null && player != null && block != null) {
         if (this.isAirDropBlock(block)) {
            if (this.active.getStage() == AirDropStage.CLOSED) {
               this.activate(player);
            } else if (this.active.getStage() != AirDropStage.BOSS) {
               if (this.active.getStage() != AirDropStage.OPENING) {
                  if (this.active.getStage() != AirDropStage.OPEN) {
                     ;
                  }
               }
            }
         }
      }
   }

   public void handleBossDeath(Entity entity, Player killer) {
      if (this.active != null && this.active.getStage() == AirDropStage.BOSS && entity != null) {
         if (this.isCurrentBossEntity(entity)) {
            this.bossEntityId = null;
            this.lastBossProgress = 0.0;
            this.bossBarManager
               .update(
                  this.format(this.plugin.configString("bossbars.bossDontKilled", "%airType% &8| &cБосс не убит &8| &bx: &7%xCord% &bz: &7%zCord%"), 0), 0.0
               );
            if (killer != null) {
               this.broadcast(this.plugin.message("bossKilled").replace("%killer%", killer.getName()));
               this.clanRewardManager.reward(killer);
            }

            this.startOpening();
         }
      }
   }

   public void handleBossDamage(Entity entity, double finalDamage) {
      if (this.active != null && this.active.getStage() == AirDropStage.BOSS && entity instanceof LivingEntity) {
         if (this.isCurrentBossEntity(entity)) {
            LivingEntity living = (LivingEntity)entity;
            double maxHealth = Math.max(1.0, this.maxHealth(living));
            double health = Math.max(0.0, living.getHealth() - Math.max(0.0, finalDamage));
            double progress = Math.max(0.0, Math.min(1.0, health / maxHealth));
            if (!(Math.abs(progress - this.lastBossProgress) < 0.01) || !(progress > 0.0)) {
               this.lastBossProgress = progress;
               this.bossBarManager
                  .update(
                     this.format(this.plugin.configString("bossbars.bossDontKilled", "%airType% &8| &cБосс не убит &8| &bx: &7%xCord% &bz: &7%zCord%"), 0),
                     progress
                  );
            }
         }
      }
   }

   public void addPlayer(Player player) {
      this.bossBarManager.add(player);
   }

   public boolean isInside(Location location) {
      if (this.active != null && location != null && location.getWorld() != null && this.active.getLocation().getWorld() != null) {
         if (!location.getWorld().equals(this.active.getLocation().getWorld())) {
            return false;
         }

         int radius = Math.max(1, this.plugin.getConfig().getInt("settings.schematicRadius", 35));
         return location.distanceSquared(this.active.getLocation()) <= radius * radius;
      } else {
         return false;
      }
   }

   private void activate(Player player) {
      this.cancelDeleteTask();
      this.active.setStage(AirDropStage.BOSS);
      this.broadcast(this.plugin.message("activateAir").replace("%player%", player.getName()));
      this.bossEntityId = null;
      this.lastBossProgress = 1.0;
      Location spawn = this.active.getLocation().clone().add(0.0, 5.0, 0.0);
      this.bossManager.spawn(spawn);
      this.updateHologram(
         this.plugin.configString("hologram.closedTitle", "%airType%: &cзакрыт"),
         this.plugin.configString("hologram.killBoss", "&7Для открытия победите босса")
      );
      this.bossBarManager
         .show(
            this.format(this.plugin.configString("bossbars.bossDontKilled", "%airType% &8| &cБосс не убит &8| &bx: &7%xCord% &bz: &7%zCord%"), 0),
            "bossbars.bossBarColor",
            "bossbars.bossBarStyle",
            1.0
         );
      this.startBossFindTask();
   }

   private void startOpening() {
      this.cancelDeleteTask();
      this.cancelBossFindTask();
      this.bossEntityId = null;
      this.active.setStage(AirDropStage.OPENING);
      int seconds = Math.max(0, this.plugin.getConfig().getInt("settings.openCooldown", 300));
      this.active.setTimeLeft(seconds);
      this.bossBarManager
         .show(
            this.format(
               this.plugin.configString("bossbars.tickingName", "%airType% &8| &eОткрытие через &7%time% &eсек &8| &bx: &7%xCord% &bz: &7%zCord%"), seconds
            ),
            "bossbars.tickingBarColor",
            "bossbars.tickingBarStyle",
            1.0
         );
      this.updateHologram(
         this.plugin.configString("hologram.closedTitle", "%airType%: &cзакрыт"),
         this.plugin.configString("hologram.killedBoss", "&7Открытие через &e%time% &7сек").replace("%time%", Integer.toString(seconds))
      );
      this.openTask = Bukkit.getScheduler()
         .runTaskTimer(
            this.plugin,
            new Runnable() {
               @Override
               public void run() {
                  if (AirDropManager.this.active != null && AirDropManager.this.active.getStage() == AirDropStage.OPENING) {
                     int left = AirDropManager.this.active.getTimeLeft();
                     if (left <= 0) {
                        AirDropManager.this.openAirDrop();
                     } else {
                        int nextLeft = left - 1;
                        AirDropManager.this.active.setTimeLeft(nextLeft);
                        int max = Math.max(1, AirDropManager.this.plugin.getConfig().getInt("settings.openCooldown", 300));
                        AirDropManager.this.bossBarManager
                           .update(
                              AirDropManager.this.format(
                                 AirDropManager.this.plugin
                                    .configString("bossbars.tickingName", "%airType% &8| &eОткрытие через &7%time% &eсек &8| &bx: &7%xCord% &bz: &7%zCord%"),
                                 left
                              ),
                              Math.max(0.0, Math.min(1.0, (double)left / max))
                           );
                        if (nextLeft > 0 && nextLeft % 30 == 0) {
                           AirDropManager.this.updateHologram(
                              AirDropManager.this.plugin.configString("hologram.closedTitle", "%airType%: &cзакрыт"),
                              AirDropManager.this.plugin
                                 .configString("hologram.killedBoss", "&7Открытие через &e%time% &7сек")
                                 .replace("%time%", Integer.toString(nextLeft))
                           );
                        }
                     }
                  } else {
                     AirDropManager.this.cancelOpenTask();
                  }
               }
            },
            20L,
            20L
         );
   }

   private void openAirDrop() {
      this.cancelOpenTask();
      if (this.active != null) {
         this.active.setStage(AirDropStage.OPEN);
         this.bossBarManager.show(this.openedBossBarTitle(120), "bossbars.openBarColor", "bossbars.openBarStyle", 1.0);
         this.updateHologram(
            this.plugin.configString("hologram.openedTitle", "%airType%: &aоткрыт"), this.plugin.configString("hologram.openedAir", "&7Соберите награды")
         );
         final ActiveAirDrop openedDrop = this.active;
         this.dropItemUtil.blowItems(this.active.getLocation(), this.active.getLoot(), new Runnable() {
            @Override
            public void run() {
               if (AirDropManager.this.active == openedDrop && AirDropManager.this.active.getStage() == AirDropStage.OPEN) {
                  AirDropManager.this.startDeleteTask(openedDrop);
               }
            }
         });
      }
   }

   private void createClosedVisuals() {
      this.updateHologram(
         this.plugin.configString("hologram.closedTitle", "%airType%: &cзакрыт"), this.plugin.configString("hologram.airdropClosed", "&7Нажмите для активации")
      );
      this.bossBarManager
         .show(
            this.format(this.plugin.configString("bossbars.spawnName", "%airType% &8| &cНе активирован &8| &bx: &7%xCord% &bz: &7%zCord%"), 0),
            "bossbars.spawnBarColor",
            "bossbars.spawnBarStyle",
            1.0
         );
   }

   private void updateHologram(String title, String bottom) {
      if (this.active != null) {
         this.hologramManager
            .update(
               this.active.getLocation(),
               this.hologramManager.lines(this.format(title, this.active.getTimeLeft()), this.format(bottom, this.active.getTimeLeft()))
            );
      }
   }

   private void notifyPlayers() {
      if (this.active != null) {
         boolean soundEnabled = this.plugin.getConfig().getBoolean("notification.sound", true);
         boolean messageEnabled = this.plugin.getConfig().getBoolean("notification.message", true);
         Sound sound = this.parseSound(this.plugin.getConfig().getString("notification.soundType", "ENTITY_EXPERIENCE_ORB_PICKUP"));
         List<String> lines = this.buildNotification();

         for (Player player : Bukkit.getOnlinePlayers()) {
            if (soundEnabled && sound != null) {
               player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
            }

            if (messageEnabled) {
               for (String line : lines) {
                  player.sendMessage(line);
               }
            }
         }
      }
   }

   private List<String> buildNotification() {
      List<String> result = new ArrayList<>();
      List<String> configured = this.plugin.getConfig().getStringList("notification.messageText");
      if (configured == null || configured.isEmpty()) {
         configured = new ArrayList<>();
         configured.add("&6АирДроп &7» &fПоявился %airType%&f!");
         configured.add("&6АирДроп &7» &fНаграда за открытие:");
         configured.add("%loot%");
         configured.add("&6АирДроп &7» &fКоординаты: &8[&6%xCord%&8; &6%zCord%&8]");
      }

      List<String> loot = this.formatLoot();

      for (String line : configured) {
         if (line != null) {
            if (line.equalsIgnoreCase("%loot%")) {
               result.addAll(loot);
            } else {
               result.add(this.formatNotificationLine(line));
            }
         }
      }

      return result;
   }

   private List<String> formatLoot() {
      List<String> lines = new ArrayList<>();
      if (this.active != null && this.active.getLoot() != null && !this.active.getLoot().isEmpty()) {
         List<ItemStack> heads = new ArrayList<>();
         List<ItemStack> other = new ArrayList<>();

         for (ItemStack item : this.active.getLoot()) {
            if (!ItemUtil.isEmpty(item)) {
               if (item.getType() == Material.PLAYER_HEAD) {
                  heads.add(item);
               } else {
                  other.add(item);
               }
            }
         }

         int total = heads.size() + other.size();
         int limit = Math.min(3, total);

         for (int i = 0; i < limit; i++) {
            ItemStack item = i < heads.size() ? heads.get(i) : other.get(i - heads.size());
            lines.add(ColorUtil.color("&6Аирдроп &7» " + ItemUtil.displayName(item) + " &7x&6" + item.getAmount()));
         }

         if (total > 3) {
            lines.add(ColorUtil.color("&6Аирдроп &7» &fИ еще &6" + (total - 3) + " &fнаград!"));
         }

         return lines;
      } else {
         return lines;
      }
   }

   private void startMainTask() {
      this.cancelMainTask();
      this.mainTask = Bukkit.getScheduler()
         .runTaskTimer(
            this.plugin,
            new Runnable() {
               @Override
               public void run() {
                  if (AirDropManager.this.active == null) {
                     AirDropManager.this.cancelMainTask();
                  } else {
                     if (AirDropManager.this.active.getStage() == AirDropStage.CLOSED) {
                        AirDropManager.this.bossBarManager
                           .update(
                              AirDropManager.this.format(
                                 AirDropManager.this.plugin
                                    .configString("bossbars.spawnName", "%airType% &8| &cНе активирован &8| &bx: &7%xCord% &bz: &7%zCord%"),
                                 0
                              ),
                              1.0
                           );
                     }
                  }
               }
            },
            20L,
            100L
         );
   }

   private String openedBossBarTitle(int seconds) {
      String template = this.plugin.configString("bossbars.openedName", "%airType% &8| &aОткрыт &8| &bx: &7%xCord% &bz: &7%zCord%");
      if (!template.contains("%time%")) {
         template = template + " &8| &eДо завершения: &7%time% &eсек";
      }

      return this.format(template, seconds);
   }

   private void startDeleteTask(final ActiveAirDrop openedDrop) {
      this.cancelDeleteTask();
      openedDrop.setTimeLeft(120);
      this.bossBarManager.update(this.openedBossBarTitle(120), 1.0);
      this.deleteTask = Bukkit.getScheduler().runTaskTimer(this.plugin, new Runnable() {
         @Override
         public void run() {
            if (AirDropManager.this.active == openedDrop && AirDropManager.this.active.getStage() == AirDropStage.OPEN) {
               int seconds = openedDrop.getTimeLeft() - 1;
               openedDrop.setTimeLeft(seconds);
               if (seconds <= 0) {
                  AirDropManager.this.stop(false);
               } else {
                  AirDropManager.this.bossBarManager.update(AirDropManager.this.openedBossBarTitle(seconds), seconds / 120.0);
               }
            } else {
               AirDropManager.this.cancelDeleteTask();
            }
         }
      }, 20L, 20L);
   }

   private void cancelTasks() {
      this.cancelMainTask();
      this.cancelDeleteTask();
      this.cancelOpenTask();
      this.cancelBossFindTask();
   }

   private void cancelMainTask() {
      if (this.mainTask != null) {
         this.mainTask.cancel();
         this.mainTask = null;
      }
   }

   private void cancelDeleteTask() {
      if (this.deleteTask != null) {
         this.deleteTask.cancel();
         this.deleteTask = null;
      }
   }

   private void cancelOpenTask() {
      if (this.openTask != null) {
         this.openTask.cancel();
         this.openTask = null;
      }
   }

   private void startBossFindTask() {
      this.cancelBossFindTask();
      this.bossFindTask = Bukkit.getScheduler()
         .runTaskTimer(
            this.plugin,
            new Runnable() {
               private int attempts;

               @Override
               public void run() {
                  if (AirDropManager.this.active != null && AirDropManager.this.active.getStage() == AirDropStage.BOSS) {
                     LivingEntity found = AirDropManager.this.findNearestBossEntity();
                     if (found != null) {
                        AirDropManager.this.bossEntityId = found.getUniqueId();
                        AirDropManager.this.lastBossProgress = 1.0;
                        AirDropManager.this.bossBarManager
                           .update(
                              AirDropManager.this.format(
                                 AirDropManager.this.plugin
                                    .configString("bossbars.bossDontKilled", "%airType% &8| &cБосс не убит &8| &bx: &7%xCord% &bz: &7%zCord%"),
                                 0
                              ),
                              1.0
                           );
                        AirDropManager.this.cancelBossFindTask();
                     } else {
                        this.attempts++;
                        if (this.attempts >= 40) {
                           AirDropManager.this.cancelBossFindTask();
                        }
                     }
                  } else {
                     AirDropManager.this.cancelBossFindTask();
                  }
               }
            },
            2L,
            5L
         );
   }

   private void cancelBossFindTask() {
      if (this.bossFindTask != null) {
         this.bossFindTask.cancel();
         this.bossFindTask = null;
      }
   }

   private void removeBossEntity() {
      UUID id = this.bossEntityId;
      this.bossEntityId = null;
      if (id != null) {
         Entity entity = Bukkit.getEntity(id);
         if (entity != null && !(entity instanceof Player) && !entity.isDead()) {
            entity.remove();
         }
      }
   }

   private LivingEntity findNearestBossEntity() {
      if (this.active != null && this.active.getLocation().getWorld() != null) {
         LivingEntity result = null;
         double best = Double.MAX_VALUE;
         Location center = this.active.getLocation().clone().add(0.0, 5.0, 0.0);

         for (Entity entity : this.active.getLocation().getWorld().getNearbyEntities(center, 16.0, 16.0, 16.0)) {
            if (entity instanceof LivingEntity && !(entity instanceof Player) && !(entity instanceof ArmorStand) && !entity.isDead()) {
               double distance = entity.getLocation().distanceSquared(center);
               if (distance < best) {
                  best = distance;
                  result = (LivingEntity)entity;
               }
            }
         }

         return result;
      } else {
         return null;
      }
   }

   private boolean isCurrentBossEntity(Entity entity) {
      if (this.active != null
         && entity != null
         && entity.getLocation() != null
         && entity.getLocation().getWorld() != null
         && this.active.getLocation().getWorld() != null) {
         if (!entity.getLocation().getWorld().equals(this.active.getLocation().getWorld())) {
            return false;
         }

         if (this.bossEntityId != null) {
            return this.bossEntityId.equals(entity.getUniqueId());
         }

         if (!(entity instanceof Player) && !(entity instanceof ArmorStand)) {
            if (entity.getLocation().distanceSquared(this.active.getLocation()) > 2500.0) {
               return false;
            } else if (entity instanceof LivingEntity) {
               this.bossEntityId = entity.getUniqueId();
               return true;
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private double maxHealth(LivingEntity entity) {
      try {
         return entity.getMaxHealth();
      } catch (Throwable ex) {
         return 1.0;
      }
   }

   public boolean isAirDropBlock(Block block) {
      if (this.active != null && block != null) {
         Location a = this.active.getLocation();
         Location b = block.getLocation();
         return a.getWorld() != null
            && a.getWorld().equals(b.getWorld())
            && a.getBlockX() == b.getBlockX()
            && a.getBlockY() == b.getBlockY()
            && a.getBlockZ() == b.getBlockZ();
      } else {
         return false;
      }
   }

   private String formatNotificationLine(String text) {
      return this.active == null
         ? ColorUtil.color(text)
         : ColorUtil.color(text)
            .replace("%xCord%", Integer.toString(this.active.getLocation().getBlockX()))
            .replace("%zCord%", Integer.toString(this.active.getLocation().getBlockZ()))
            .replace("%airType%", this.active.getType().getDisplayName(this.plugin))
            .replace(
               "%exp%", Integer.toString(Math.max(0, this.plugin.getConfig().getInt("clans.expReward", this.plugin.getConfig().getInt("clanExpReward", 0))))
            )
            .replace(
               "%points%",
               Integer.toString(Math.max(0, this.plugin.getConfig().getInt("clans.pointsReward", this.plugin.getConfig().getInt("clanPointsReward", 0))))
            );
   }

   private String format(String text, int time) {
      return this.active == null
         ? ColorUtil.color(text)
         : ColorUtil.color(
            text.replace("%airType%", this.active.getType().getDisplayName(this.plugin))
               .replace("%xCord%", Integer.toString(this.active.getLocation().getBlockX()))
               .replace("%zCord%", Integer.toString(this.active.getLocation().getBlockZ()))
               .replace("%time%", Integer.toString(time))
               .replace("%region%", this.active.getRegionName())
         );
   }

   private void broadcast(String message) {
      Bukkit.broadcastMessage(ColorUtil.color(message));
   }

   private Sound parseSound(String value) {
      return SoundUtil.parse(value, Sound.ENTITY_EXPERIENCE_ORB_PICKUP);
   }

   public AirDropType randomType() {
      int total = 0;

      for (AirDropType type : AirDropType.values()) {
         total += type.getChance(this.plugin);
      }

      if (total <= 0) {
         return AirDropType.COMMON;
      }

      int value = ThreadLocalRandom.current().nextInt(total) + 1;
      int current = 0;

      for (AirDropType type : AirDropType.values()) {
         current += type.getChance(this.plugin);
         if (value <= current) {
            return type;
         }
      }

      return AirDropType.COMMON;
   }
}
