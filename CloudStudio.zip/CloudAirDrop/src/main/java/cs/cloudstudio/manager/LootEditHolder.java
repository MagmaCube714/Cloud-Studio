package cs.cloudstudio.manager;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class LootEditHolder implements InventoryHolder {
   private final AirDropType type;

   public LootEditHolder(AirDropType type) {
      this.type = type;
   }

   public AirDropType getType() {
      return this.type;
   }

   public Inventory getInventory() {
      return null;
   }
}
