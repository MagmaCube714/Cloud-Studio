package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.ItemUtil;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class LootManager {
   private final CloudAirDrop plugin;
   private final File file;
   private FileConfiguration config;
   private final Object saveLock = new Object();
   private final AtomicInteger saveVersion = new AtomicInteger();

   public LootManager(CloudAirDrop plugin) {
      this.plugin = plugin;
      this.file = new File(plugin.getDataFolder(), "airdrop_items.yml");
      this.reload();
   }

   public void reload() {
      if (!this.file.exists()) {
         File parent = this.file.getParentFile();
         if (parent != null && !parent.exists()) {
            parent.mkdirs();
         }

         try {
            this.file.createNewFile();
         } catch (IOException ex) {
            this.plugin.warn("Файл airdrop_items.yml не создан: " + ex.getMessage());
         }
      }

      this.config = YamlConfiguration.loadConfiguration(this.file);
   }

   public void openEditor(Player player, AirDropType type) {
      Inventory inventory = Bukkit.createInventory(
         new LootEditHolder(type), 54, ColorUtil.component(this.plugin.message("edit-title").replace("%type%", type.name().toLowerCase(Locale.ROOT)))
      );
      List<ItemStack> items = this.getAll(type);

      for (int i = 0; i < items.size() && i < inventory.getSize(); i++) {
         inventory.setItem(i, items.get(i));
      }

      player.openInventory(inventory);
      player.sendMessage(this.plugin.message("editor-opened"));
   }

   public void saveEditor(Player player, AirDropType type, Inventory inventory) {
      List<ItemStack> oldItems = this.getAll(type);
      List<ItemStack> items = new ArrayList<>();
      ItemStack[] contents = inventory.getContents();

      for (ItemStack item : contents) {
         if (!ItemUtil.isEmpty(item)) {
            items.add(item.clone());
         }
      }

      String lower = type.name().toLowerCase(Locale.ROOT);
      boolean alreadyCanonical = this.config.isSet(lower) && !this.config.isSet(type.name());
      if (alreadyCanonical && this.sameItems(oldItems, items)) {
         player.sendMessage(this.plugin.message("editor-saved"));
      } else {
         this.config.set(lower, items);
         this.config.set(type.name(), null);
         this.save();
         player.sendMessage(this.plugin.message("editor-saved"));
      }
   }

   public List<ItemStack> getRandom(AirDropType type) {
      List<ItemStack> items = this.getAll(type);
      if (items.isEmpty()) {
         return items;
      }

      Collections.shuffle(items);
      int count = Math.min(type.getLootCount(this.plugin), items.size());
      return new ArrayList<>(items.subList(0, count));
   }

   public List<ItemStack> getAll(AirDropType type) {
      List<ItemStack> items = new ArrayList<>();
      if (this.config != null && type != null) {
         for (String path : this.paths(type)) {
            List<?> list = this.config.getList(path);
            if (list != null && !list.isEmpty()) {
               for (Object object : list) {
                  ItemStack item = this.readItem(object);
                  if (!ItemUtil.isEmpty(item)) {
                     items.add(item);
                  }
               }

               if (!items.isEmpty()) {
                  return items;
               }
            }
         }

         return items;
      } else {
         return items;
      }
   }

   private List<String> paths(AirDropType type) {
      List<String> paths = new ArrayList<>();
      String upper = type.name();
      String lower = type.name().toLowerCase(Locale.ROOT);
      paths.add(lower);
      paths.add(upper);
      paths.add("items." + lower);
      paths.add("items." + upper);
      paths.add("loot." + lower);
      paths.add("loot." + upper);
      paths.add("rewards." + lower);
      paths.add("rewards." + upper);
      paths.add("airDrops." + lower + ".items");
      paths.add("airDrops." + upper + ".items");
      return paths;
   }

   private ItemStack readItem(Object object) {
      if (object instanceof ItemStack) {
         return ((ItemStack)object).clone();
      }

      if (object instanceof Map) {
         try {
            Object item = ItemStack.deserialize((Map)object);
            if (item instanceof ItemStack) {
               return (ItemStack)item;
            }
         } catch (RuntimeException exception) {
            this.plugin.warn("Награда аирдропа не прочитана из airdrop_items.yml: " + exception.getMessage());
         }
      }

      return new ItemStack(Material.AIR);
   }

   private boolean sameItems(List<ItemStack> first, List<ItemStack> second) {
      if (first != null && second != null && first.size() == second.size()) {
         for (int i = 0; i < first.size(); i++) {
            ItemStack left = first.get(i);
            ItemStack right = second.get(i);
            if ((left != null || right != null) && (left == null || right == null || !left.equals(right))) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public void save() {
      this.saveAsync();
   }

   public void saveNow() {
      this.saveVersion.incrementAndGet();
      synchronized (this.saveLock) {
         try {
            this.config.save(this.file);
         } catch (IOException ex) {
            this.plugin.warn("Награды не сохранены: " + ex.getMessage());
         }
      }
   }

   private void saveAsync() {
      final int version = this.saveVersion.incrementAndGet();
      final YamlConfiguration snapshot = new YamlConfiguration();

      for (String key : this.config.getKeys(false)) {
         snapshot.set(key, this.config.get(key));
      }

      Bukkit.getScheduler().runTaskAsynchronously(this.plugin, new Runnable() {
         @Override
         public void run() {
            try {
               String contents = snapshot.saveToString();
               synchronized (LootManager.this.saveLock) {
                  if (version != LootManager.this.saveVersion.get()) {
                     return;
                  }

                  File parent = LootManager.this.file.getParentFile();
                  if (parent != null && !parent.exists()) {
                     parent.mkdirs();
                  }

                  Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(LootManager.this.file), StandardCharsets.UTF_8));

                  try {
                     writer.write(contents);
                  } finally {
                     writer.close();
                  }
               }
            } catch (Throwable ex) {
               LootManager.this.plugin.warn("Награды не сохранены: " + ex.getMessage());
            }
         }
      });
   }
}
