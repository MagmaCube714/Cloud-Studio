package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAirDrop;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SplittableRandom;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

public final class LocationManager {
   private static final int RECENT_LOCATION_LIMIT = 32;
   private static final int BLOCK_CHECKS_PER_CHUNK = 8;
   private static final int MAX_ASYNC_CHUNK_ATTEMPTS = 64;
   private static final int MAX_LOADED_CHUNK_CANDIDATES = 64;
   private final CloudAirDrop plugin;
   private final Deque<Long> recentQueue = new ArrayDeque<>();
   private final Set<Long> recentSet = new HashSet<>();

   public LocationManager(CloudAirDrop plugin) {
      this.plugin = plugin;
   }

   public void findLocationAsync(Consumer<Location> callback) {
      if (callback != null) {
         if (!Bukkit.isPrimaryThread()) {
            final Consumer<Location> safeCallback = callback;
            Bukkit.getScheduler().runTask(this.plugin, new Runnable() {
               @Override
               public void run() {
                  LocationManager.this.findLocationAsync(safeCallback);
               }
            });
         } else {
            String worldName = this.string("settings.worldName", "world");
            World world = Bukkit.getWorld(worldName);
            if (world == null) {
               this.plugin.warn("Аирдроп не создан: мир " + worldName + " не найден");
               callback.accept(null);
            } else {
               int xRadius = Math.max(1, this.plugin.getConfig().getInt("settings.xCords", 2000));
               int zRadius = Math.max(1, this.plugin.getConfig().getInt("settings.zCords", 2000));
               int attempts = Math.max(1, this.plugin.getConfig().getInt("settings.locationAttempts", 64));
               attempts = Math.min(64, attempts);
               int loadedAttempts = Math.max(0, this.plugin.getConfig().getInt("settings.loadedChunkAttempts", 32));
               loadedAttempts = Math.min(64, loadedAttempts);
               int margin = Math.max(0, Math.min(7, this.plugin.getConfig().getInt("settings.locationChunkMargin", 4)));
               boolean generateChunks = this.plugin.getConfig().getBoolean("settings.generateNewChunks", false);
               SplittableRandom random = new SplittableRandom(this.createSeed(world));
               List<LocationManager.ChunkCoordinate> loadedCandidates = this.collectLoadedCandidates(world, xRadius, zRadius, loadedAttempts, random);
               LocationManager.Search search = new LocationManager.Search(
                  world, xRadius, zRadius, attempts, margin, generateChunks, random, loadedCandidates, callback
               );
               search.next();
            }
         }
      }
   }

   private List<LocationManager.ChunkCoordinate> collectLoadedCandidates(World world, int xRadius, int zRadius, int limit, SplittableRandom random) {
      List<LocationManager.ChunkCoordinate> candidates = new ArrayList<>(Math.max(0, limit));
      if (limit > 0 && this.plugin.getConfig().getBoolean("settings.preferLoadedChunks", true)) {
         Chunk[] loaded = world.getLoadedChunks();
         int seen = 0;

         for (Chunk chunk : loaded) {
            int chunkX = chunk.getX();
            int chunkZ = chunk.getZ();
            int centerX = (chunkX << 4) + 8;
            int centerZ = (chunkZ << 4) + 8;
            if (Math.abs(centerX) <= xRadius && Math.abs(centerZ) <= zRadius) {
               long key = this.locationKey(world, chunkX, chunkZ);
               if (!this.recentSet.contains(key)) {
                  seen++;
                  LocationManager.ChunkCoordinate coordinate = new LocationManager.ChunkCoordinate(chunkX, chunkZ);
                  if (candidates.size() < limit) {
                     candidates.add(coordinate);
                  } else {
                     int replace = random.nextInt(seen);
                     if (replace < limit) {
                        candidates.set(replace, coordinate);
                     }
                  }
               }
            }
         }

         return candidates;
      } else {
         return candidates;
      }
   }

   private Location findSafeBlock(World world, int x, int z) {
      int y = world.getHighestBlockYAt(x, z);
      if (y > 1 && y < world.getMaxHeight() - 2) {
         Block ground = world.getBlockAt(x, y - 1, z);
         Block feet = world.getBlockAt(x, y, z);
         Block head = world.getBlockAt(x, y + 1, z);
         return this.isSafeGround(ground.getType()) && this.isPassable(feet) && this.isPassable(head) ? new Location(world, x + 0.5, y, z + 0.5) : null;
      } else {
         return null;
      }
   }

   private Location findSafeLocationInLoadedChunk(World world, int chunkX, int chunkZ, int margin, SplittableRandom random) {
      int width = 16 - margin * 2;

      for (int i = 0; i < 8; i++) {
         int x = (chunkX << 4) + margin + random.nextInt(width);
         int z = (chunkZ << 4) + margin + random.nextInt(width);
         Location location = this.findSafeBlock(world, x, z);
         if (location != null) {
            return location;
         }
      }

      return null;
   }

   private boolean isSafeGround(Material material) {
      if (material != null && material.isSolid()) {
         String name = material.name();
         return !name.contains("WATER")
            && !name.contains("LAVA")
            && !name.contains("ICE")
            && !name.contains("LEAVES")
            && !name.contains("FIRE")
            && !name.contains("CACTUS");
      } else {
         return false;
      }
   }

   private boolean isPassable(Block block) {
      try {
         return block.isPassable();
      } catch (Throwable ignored) {
         return block.getType() == Material.AIR;
      }
   }

   private int randomCoordinate(SplittableRandom random, int radius) {
      int value = random.nextInt(radius) + 1;
      return random.nextBoolean() ? value : -value;
   }

   private long createSeed(World world) {
      long seed = System.nanoTime();
      seed ^= System.currentTimeMillis() << 21;
      seed ^= Thread.currentThread().threadId() << 7;
      if (world != null) {
         seed ^= world.getUID().getMostSignificantBits();
         seed ^= Long.rotateLeft(world.getUID().getLeastSignificantBits(), 17);
         seed ^= world.getFullTime() << 3;
      }

      return this.mix(seed);
   }

   private long mix(long value) {
      value ^= value >>> 33;
      value *= -49064778989728563L;
      value ^= value >>> 33;
      value *= -4265267296055464877L;
      return value ^ value >>> 33;
   }

   private long locationKey(World world, int chunkX, int chunkZ) {
      long worldHash = world == null ? 0L : world.getUID().getMostSignificantBits() ^ world.getUID().getLeastSignificantBits();
      long key = this.mix(worldHash);
      key ^= (chunkX & 4294967295L) << 32;
      return key ^ chunkZ & 4294967295L;
   }

   private long locationKey(Location location) {
      return location != null && location.getWorld() != null ? this.locationKey(location.getWorld(), location.getBlockX() >> 4, location.getBlockZ() >> 4) : 0L;
   }

   private void rememberLocation(long key) {
      if (key != 0L) {
         if (this.recentSet.add(key)) {
            this.recentQueue.addLast(key);
         }

         while (this.recentQueue.size() > 32) {
            Long oldest = this.recentQueue.pollFirst();
            if (oldest != null) {
               this.recentSet.remove(oldest);
            }
         }
      }
   }

   private String string(String path, String def) {
      String value = this.plugin.getConfig().getString(path);
      return value != null && !value.trim().isEmpty() ? value : def;
   }

   private static final class ChunkCoordinate {
      private final int x;
      private final int z;

      private ChunkCoordinate(int x, int z) {
         this.x = x;
         this.z = z;
      }
   }

   private final class Search {
      private final World world;
      private final int xRadius;
      private final int zRadius;
      private final int maxAttempts;
      private final int margin;
      private final boolean generateChunks;
      private final SplittableRandom random;
      private final List<LocationManager.ChunkCoordinate> loadedCandidates;
      private final Consumer<Location> callback;
      private final Set<Long> checkedChunks = new HashSet<>();
      private int loadedIndex;
      private int attempts;
      private boolean completed;

      private Search(
         World world,
         int xRadius,
         int zRadius,
         int maxAttempts,
         int margin,
         boolean generateChunks,
         SplittableRandom random,
         List<LocationManager.ChunkCoordinate> loadedCandidates,
         Consumer<Location> callback
      ) {
         this.world = world;
         this.xRadius = xRadius;
         this.zRadius = zRadius;
         this.maxAttempts = maxAttempts;
         this.margin = margin;
         this.generateChunks = generateChunks;
         this.random = random;
         this.loadedCandidates = loadedCandidates;
         this.callback = callback;
      }

      private void next() {
         if (!this.completed && LocationManager.this.plugin.isEnabled()) {
            LocationManager.ChunkCoordinate candidate = this.nextCandidate();
            if (candidate == null) {
               this.trySpawnFallback();
            } else {
               long key = LocationManager.this.locationKey(this.world, candidate.x, candidate.z);
               if (LocationManager.this.recentSet.contains(key) || !this.checkedChunks.add(key)) {
                  this.scheduleNext();
               } else if (this.world.isChunkLoaded(candidate.x, candidate.z)) {
                  this.inspectLoaded(candidate.x, candidate.z, key, false);
               } else {
                  int chunkX = candidate.x;
                  int chunkZ = candidate.z;
                  long chunkKey = key;

                  CompletableFuture<Chunk> future;
                  try {
                     future = this.world.getChunkAtAsync(chunkX, chunkZ, this.generateChunks, false);
                  } catch (Throwable ex) {
                     LocationManager.this.plugin.warn("Асинхронная загрузка чанка недоступна: требуется Paper 1.16.5+");
                     this.finish(null);
                     return;
                  }

                  future.whenComplete((chunk, throwable) -> this.runSync(new Runnable() {
                     @Override
                     public void run() {
                        if (!Search.this.completed && LocationManager.this.plugin.isEnabled()) {
                           if (throwable == null && chunk != null && Search.this.world.isChunkLoaded(chunkX, chunkZ)) {
                              Search.this.inspectLoaded(chunkX, chunkZ, chunkKey, true);
                           } else {
                              Search.this.scheduleNext();
                           }
                        }
                     }
                  }));
               }
            }
         }
      }

      private LocationManager.ChunkCoordinate nextCandidate() {
         if (this.loadedIndex < this.loadedCandidates.size()) {
            return this.loadedCandidates.get(this.loadedIndex++);
         } else if (this.attempts < this.maxAttempts) {
            this.attempts++;
            int x = LocationManager.this.randomCoordinate(this.random, this.xRadius);
            int z = LocationManager.this.randomCoordinate(this.random, this.zRadius);
            return new LocationManager.ChunkCoordinate(x >> 4, z >> 4);
         } else {
            return null;
         }
      }

      private void inspectLoaded(int chunkX, int chunkZ, long key, boolean temporaryChunk) {
         Location location = LocationManager.this.findSafeLocationInLoadedChunk(this.world, chunkX, chunkZ, this.margin, this.random);
         if (location != null) {
            LocationManager.this.rememberLocation(key);
            this.finish(location);
         } else {
            if (temporaryChunk) {
               this.world.unloadChunkRequest(chunkX, chunkZ);
            }

            this.scheduleNext();
         }
      }

      private void trySpawnFallback() {
         Location spawn = this.world.getSpawnLocation();
         int chunkX = spawn.getBlockX() >> 4;
         int chunkZ = spawn.getBlockZ() >> 4;
         if (this.world.isChunkLoaded(chunkX, chunkZ)) {
            this.finishSpawn(spawn);
         } else {
            CompletableFuture<Chunk> future;
            try {
               future = this.world.getChunkAtAsync(chunkX, chunkZ, true, false);
            } catch (Throwable ex) {
               LocationManager.this.plugin.warn("Аирдроп не создан: безопасная локация не найдена");
               this.finish(null);
               return;
            }

            future.whenComplete((chunk, throwable) -> this.runSync(new Runnable() {
               @Override
               public void run() {
                  if (throwable == null && chunk != null) {
                     Search.this.finishSpawn(Search.this.world.getSpawnLocation());
                  } else {
                     LocationManager.this.plugin.warn("Аирдроп не создан: безопасная локация не найдена");
                     Search.this.finish(null);
                  }
               }
            }));
         }
      }

      private void finishSpawn(Location spawn) {
         Location safe = LocationManager.this.findSafeBlock(this.world, spawn.getBlockX(), spawn.getBlockZ());
         if (safe == null) {
            LocationManager.this.plugin.warn("Аирдроп не создан: безопасная локация не найдена");
            this.finish(null);
         } else {
            LocationManager.this.rememberLocation(LocationManager.this.locationKey(safe));
            this.finish(safe);
         }
      }

      private void scheduleNext() {
         if (!this.completed && LocationManager.this.plugin.isEnabled()) {
            Bukkit.getScheduler().runTaskLater(LocationManager.this.plugin, new Runnable() {
               @Override
               public void run() {
                  Search.this.next();
               }
            }, 1L);
         }
      }

      private void finish(Location location) {
         if (!this.completed) {
            this.completed = true;
            this.callback.accept(location);
         }
      }

      private void runSync(Runnable runnable) {
         if (Bukkit.isPrimaryThread()) {
            runnable.run();
         } else if (LocationManager.this.plugin.isEnabled()) {
            Bukkit.getScheduler().runTask(LocationManager.this.plugin, runnable);
         }
      }
   }
}
