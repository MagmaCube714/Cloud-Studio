package cs.cloudstudio.manager;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.ForwardExtentCopy;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.session.ClipboardHolder;
import cs.cloudstudio.CloudAirDrop;
import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;

public final class SchematicManager {
   private final CloudAirDrop plugin;
   private final Map<String, SchematicManager.CachedClipboard> cache = new ConcurrentHashMap<>();
   private final Set<SchematicManager.HeldChunk> heldChunks = new HashSet<>();
   private SchematicManager.RestoreState restoreState;
   private final List<SchematicManager.SavedBlock> fallbackBackup = new ArrayList<>();

   public SchematicManager(CloudAirDrop plugin) {
      this.plugin = plugin;
   }

   public File resolveFile() {
      List<File> files = new ArrayList<>();
      String configured = this.plugin.getConfig().getString("settings.schematicPath", "plugins/CloudAirDrop/airdrop.schem");
      if (configured != null && !configured.trim().isEmpty()) {
         File configuredFile = new File(configured);
         files.add(configuredFile);
         if (!configuredFile.isAbsolute()) {
            files.add(new File(this.plugin.getDataFolder(), configured));
         }
      }

      File folder = this.plugin.getDataFolder();
      files.add(new File(folder, "airdrop.schem"));
      files.add(new File(folder, "airdrop.schematic"));
      files.add(new File(folder, "schematics/airdrop.schem"));
      files.add(new File(folder, "schematics/airdrop.schematic"));

      for (File file : files) {
         if (file.exists() && file.canRead()) {
            return file;
         }
      }

      return files.isEmpty() ? null : files.get(0);
   }

   public void holdLocationChunk(Location location) {
      if (location != null && location.getWorld() != null) {
         World world = location.getWorld();
         int chunkX = location.getBlockX() >> 4;
         int chunkZ = location.getBlockZ() >> 4;
         if (world.isChunkLoaded(chunkX, chunkZ)) {
            this.holdChunk(world, chunkX, chunkZ);
         }
      }
   }

   public void pasteAsync(final Location location, final File file, final BooleanSupplier stillCurrent, final Consumer<Boolean> callback) {
      if (callback != null) {
         if (location == null || location.getWorld() == null) {
            callback.accept(Boolean.FALSE);
         } else if (file != null && file.exists() && file.canRead()) {
            Bukkit.getScheduler().runTaskAsynchronously(this.plugin, new Runnable() {
               @Override
               public void run() {
                  Clipboard loaded = null;
                  Throwable failure = null;

                  try {
                     loaded = SchematicManager.this.loadClipboard(file);
                  } catch (Throwable ex) {
                     failure = ex;
                  }

                  final Clipboard clipboard = loaded;
                  final Throwable loadFailure = failure;
                  if (SchematicManager.this.plugin.isEnabled()) {
                     Bukkit.getScheduler().runTask(SchematicManager.this.plugin, new Runnable() {
                        @Override
                        public void run() {
                           if (!stillCurrent.getAsBoolean()) {
                              callback.accept(Boolean.FALSE);
                           } else if (loadFailure != null) {
                              SchematicManager.this.plugin.warn("Схематика " + file.getName() + " не загружена: " + SchematicManager.this.safe(loadFailure));
                              callback.accept(Boolean.FALSE);
                           } else if (clipboard == null) {
                              SchematicManager.this.plugin.warn("Схематика " + file.getName() + " не загружена: формат не поддерживается");
                              callback.accept(Boolean.FALSE);
                           } else {
                              SchematicManager.this.preparePaste(location, file, clipboard, stillCurrent, callback);
                           }
                        }
                     });
                  }
               }
            });
         } else {
            this.plugin.warn("Схематика не загружена: файл не найден");
            callback.accept(Boolean.FALSE);
         }
      }
   }

   private void preparePaste(
      final Location location, final File file, final Clipboard clipboard, final BooleanSupplier stillCurrent, final Consumer<Boolean> callback
   ) {
      World world = location.getWorld();
      BlockVector3 pasteLocation = BlockVector3.at(location.getBlockX(), location.getBlockY(), location.getBlockZ());
      BlockVector3 origin = clipboard.getOrigin();
      BlockVector3 affectedMin = this.translate(clipboard.getMinimumPoint(), origin, pasteLocation);
      BlockVector3 affectedMax = this.translate(clipboard.getMaximumPoint(), origin, pasteLocation);
      BlockVector3 backupMin = this.min(this.min(affectedMin, affectedMax), pasteLocation);
      BlockVector3 backupMax = this.max(this.max(affectedMin, affectedMax), pasteLocation);
      long volume = this.volume(backupMin, backupMax);
      int maxBlocks = Math.max(27, this.plugin.getConfig().getInt("settings.maxSchematicBlocks", 4096));
      if (volume > maxBlocks) {
         this.plugin.warn("Схематика " + file.getName() + " не вставлена: размер " + volume + " блоков больше лимита " + maxBlocks);
         callback.accept(Boolean.FALSE);
      } else {
         List<SchematicManager.ChunkCoordinate> chunks = this.affectedChunks(backupMin, backupMax);
         final List<SchematicManager.HeldChunk> newlyHeld = new ArrayList<>();
         this.loadChunksSequentially(world, chunks, 0, newlyHeld, new Runnable() {
            @Override
            public void run() {
               if (!stillCurrent.getAsBoolean()) {
                  SchematicManager.this.releaseChunks(newlyHeld);
                  callback.accept(Boolean.FALSE);
               } else {
                  boolean pasted = SchematicManager.this.pasteClipboard(location, file, clipboard);
                  if (!pasted) {
                     SchematicManager.this.releaseChunks(newlyHeld);
                  }

                  callback.accept(pasted);
               }
            }
         }, new Consumer<Throwable>() {
            public void accept(Throwable throwable) {
               SchematicManager.this.plugin.warn("Чанки для схематики " + file.getName() + " не загружены: " + SchematicManager.this.safe(throwable));
               callback.accept(Boolean.FALSE);
            }
         });
      }
   }

   private List<SchematicManager.ChunkCoordinate> affectedChunks(BlockVector3 min, BlockVector3 max) {
      List<SchematicManager.ChunkCoordinate> result = new ArrayList<>();
      int minChunkX = min.x() >> 4;
      int maxChunkX = max.x() >> 4;
      int minChunkZ = min.z() >> 4;
      int maxChunkZ = max.z() >> 4;

      for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
         for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
            result.add(new SchematicManager.ChunkCoordinate(chunkX, chunkZ));
         }
      }

      return result;
   }

   private void loadChunksSequentially(
      World world,
      List<SchematicManager.ChunkCoordinate> chunks,
      int index,
      List<SchematicManager.HeldChunk> newlyHeld,
      Runnable success,
      Consumer<Throwable> failure
   ) {
      if (!this.plugin.isEnabled()) {
         this.releaseChunks(newlyHeld);
      } else if (index >= chunks.size()) {
         success.run();
      } else {
         SchematicManager.ChunkCoordinate coordinate = chunks.get(index);
         if (world.isChunkLoaded(coordinate.x, coordinate.z)) {
            SchematicManager.HeldChunk held = this.holdChunk(world, coordinate.x, coordinate.z);
            if (held != null) {
               newlyHeld.add(held);
            }

            this.loadChunksSequentially(world, chunks, index + 1, newlyHeld, success, failure);
         } else {
            CompletableFuture<Chunk> future;
            try {
               future = world.getChunkAtAsync(coordinate.x, coordinate.z, true, false);
            } catch (Throwable ex) {
               this.releaseChunks(newlyHeld);
               failure.accept(ex);
               return;
            }

            future.whenComplete((chunk, throwable) -> {
               Runnable continuation = new Runnable() {
                  @Override
                  public void run() {
                     if (throwable == null && chunk != null && world.isChunkLoaded(coordinate.x, coordinate.z)) {
                        SchematicManager.HeldChunk held = SchematicManager.this.holdChunk(world, coordinate.x, coordinate.z);
                        if (held != null) {
                           newlyHeld.add(held);
                        }

                        Bukkit.getScheduler().runTaskLater(SchematicManager.this.plugin, new Runnable() {
                           @Override
                           public void run() {
                              SchematicManager.this.loadChunksSequentially(world, chunks, index + 1, newlyHeld, success, failure);
                           }
                        }, 1L);
                     } else {
                        SchematicManager.this.releaseChunks(newlyHeld);
                        failure.accept(throwable == null ? new IllegalStateException("chunk " + coordinate.x + "," + coordinate.z) : throwable);
                     }
                  }
               };
               if (Bukkit.isPrimaryThread()) {
                  continuation.run();
               } else if (this.plugin.isEnabled()) {
                  Bukkit.getScheduler().runTask(this.plugin, continuation);
               }
            });
         }
      }
   }

   private Clipboard loadClipboard(File file) throws Exception {
      String key = file.getCanonicalPath();
      long modified = file.lastModified();
      SchematicManager.CachedClipboard cached = this.cache.get(key);
      if (cached != null && cached.modified == modified) {
         return cached.clipboard;
      }

      ClipboardFormat format = ClipboardFormats.findByFile(file);
      if (format == null) {
         return null;
      }

      FileInputStream input = new FileInputStream(file);
      ClipboardReader reader = null;

      try {
         reader = format.getReader(input);
         Clipboard clipboard = reader.read();
         this.cache.put(key, new SchematicManager.CachedClipboard(clipboard, modified));
         return clipboard;
      } finally {
         if (reader != null) {
            reader.close();
         }

         input.close();
      }
   }

   private boolean pasteClipboard(Location location, File file, Clipboard clipboard) {
      World world = location.getWorld();
      BlockVector3 pasteLocation = BlockVector3.at(location.getBlockX(), location.getBlockY(), location.getBlockZ());
      BlockVector3 origin = clipboard.getOrigin();
      BlockVector3 affectedMin = this.translate(clipboard.getMinimumPoint(), origin, pasteLocation);
      BlockVector3 affectedMax = this.translate(clipboard.getMaximumPoint(), origin, pasteLocation);
      BlockVector3 backupMin = this.min(this.min(affectedMin, affectedMax), pasteLocation);
      BlockVector3 backupMax = this.max(this.max(affectedMin, affectedMax), pasteLocation);
      long volume = this.volume(backupMin, backupMax);
      int maxBlocks = Math.max(27, this.plugin.getConfig().getInt("settings.maxSchematicBlocks", 4096));
      if (volume > maxBlocks) {
         this.plugin.warn("Схематика " + file.getName() + " не вставлена: размер " + volume + " блоков больше лимита " + maxBlocks);
         return false;
      }

      SchematicManager.RestoreState backup;
      try {
         backup = this.createBackup(world, backupMin, backupMax);
      } catch (Throwable ex) {
         this.plugin.warn("Область схематики " + file.getName() + " не сохранена: " + this.safe(ex));
         return false;
      }

      EditSession session = null;

      try {
         session = this.createEditSession(world);
         Operation operation = new ClipboardHolder(clipboard).createPaste(session).to(pasteLocation).ignoreAirBlocks(false).build();
         Operations.complete(operation);
         this.flushEditSession(session);
         this.restoreState = backup;
         this.fallbackBackup.clear();
         return true;
      } catch (Throwable ex) {
         this.restoreBackup(backup);
         this.plugin.warn("Схематика " + file.getName() + " не вставлена: " + this.safe(ex));
         return false;
      } finally {
         this.closeEditSession(session);
      }
   }

   public void restore() {
      try {
         if (this.restoreState == null) {
            for (SchematicManager.SavedBlock savedBlock : this.fallbackBackup) {
               try {
                  Block block = savedBlock.location.getBlock();
                  if (savedBlock.data != null) {
                     block.setBlockData(savedBlock.data, false);
                  } else if (savedBlock.material != null) {
                     block.setType(savedBlock.material, false);
                  }
               } catch (Throwable var7) {
               }
            }

            this.fallbackBackup.clear();
            return;
         }

         this.restoreBackup(this.restoreState);
         this.restoreState = null;
         this.fallbackBackup.clear();
      } finally {
         this.releaseAllChunks();
      }
   }

   public Block findNearestBlock(Location location, Material material, int radius) {
      if (location != null && location.getWorld() != null && material != null && radius >= 0) {
         Block center = location.getBlock();
         if (center.getType() == material) {
            return center;
         }

         World world = location.getWorld();
         int baseX = location.getBlockX();
         int baseY = location.getBlockY();
         int baseZ = location.getBlockZ();
         int search = Math.max(1, Math.min(12, radius));

         for (int dy = -2; dy <= Math.max(4, search); dy++) {
            int y = baseY + dy;
            if (y > 0 && y < world.getMaxHeight()) {
               for (int layer = 0; layer <= search; layer++) {
                  for (int dx = -layer; dx <= layer; dx++) {
                     for (int dz = -layer; dz <= layer; dz++) {
                        if (Math.abs(dx) == layer || Math.abs(dz) == layer) {
                           int x = baseX + dx;
                           int z = baseZ + dz;
                           if (world.isChunkLoaded(x >> 4, z >> 4)) {
                              Block block = world.getBlockAt(x, y, z);
                              if (block.getType() == material) {
                                 return block;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public Block findActivateBlock(Location location, Material material, int radius) {
      Block block = this.findNearestBlock(location, material, radius);
      if (block != null) {
         return block;
      }

      if (material != Material.RESPAWN_ANCHOR) {
         block = this.findNearestBlock(location, Material.RESPAWN_ANCHOR, radius);
         if (block != null) {
            return block;
         }
      }

      if (material != Material.BEACON) {
         block = this.findNearestBlock(location, Material.BEACON, radius);
         if (block != null) {
            return block;
         }
      }

      return null;
   }

   public Block placeActivateBlock(Location location, Material material) {
      if (location != null && material != null) {
         Block block = location.getBlock();
         this.rememberFallbackBlock(block);
         block.setType(material, false);
         return block;
      } else {
         return null;
      }
   }

   public void clearAbove(Block block) {
      if (block != null && block.getWorld() != null) {
         for (int y = 1; y <= 3; y++) {
            Block above = block.getRelative(0, y, 0);
            if (above.getType() != Material.AIR && above.getType().isSolid()) {
               this.rememberFallbackBlock(above);
               above.setType(Material.AIR, false);
            }
         }
      }
   }

   public void clearCache() {
      this.cache.clear();
   }

   private void rememberFallbackBlock(Block block) {
      if (block != null && this.restoreState == null) {
         Location location = block.getLocation();

         for (SchematicManager.SavedBlock saved : this.fallbackBackup) {
            if (this.sameBlock(saved.location, location)) {
               return;
            }
         }

         this.fallbackBackup.add(new SchematicManager.SavedBlock(location, block.getType(), block.getBlockData()));
      }
   }

   private boolean sameBlock(Location first, Location second) {
      return first != null
         && second != null
         && first.getWorld() != null
         && first.getWorld().equals(second.getWorld())
         && first.getBlockX() == second.getBlockX()
         && first.getBlockY() == second.getBlockY()
         && first.getBlockZ() == second.getBlockZ();
   }

   private SchematicManager.HeldChunk holdChunk(World world, int chunkX, int chunkZ) {
      if (world != null && world.isChunkLoaded(chunkX, chunkZ)) {
         SchematicManager.HeldChunk held = new SchematicManager.HeldChunk(world, chunkX, chunkZ);
         if (!this.heldChunks.add(held)) {
            return null;
         }

         try {
            world.addPluginChunkTicket(chunkX, chunkZ, this.plugin);
            return held;
         } catch (Throwable ex) {
            this.heldChunks.remove(held);
            this.plugin.warn("Не удалось закрепить чанк " + chunkX + "," + chunkZ + ": " + this.safe(ex));
            return null;
         }
      } else {
         return null;
      }
   }

   private void releaseChunks(List<SchematicManager.HeldChunk> chunks) {
      if (chunks != null && !chunks.isEmpty()) {
         for (SchematicManager.HeldChunk held : new ArrayList<>(chunks)) {
            this.releaseChunk(held);
         }

         chunks.clear();
      }
   }

   private void releaseAllChunks() {
      for (SchematicManager.HeldChunk held : new ArrayList<>(this.heldChunks)) {
         this.releaseChunk(held);
      }

      this.heldChunks.clear();
   }

   private void releaseChunk(SchematicManager.HeldChunk held) {
      if (held != null && this.heldChunks.remove(held)) {
         try {
            held.world.removePluginChunkTicket(held.chunkX, held.chunkZ, this.plugin);
         } catch (Throwable var3) {
         }
      }
   }

   private SchematicManager.RestoreState createBackup(World world, BlockVector3 min, BlockVector3 max) throws Exception {
      com.sk89q.worldedit.world.World adaptedWorld = BukkitAdapter.adapt(world);
      CuboidRegion region = new CuboidRegion(min, max);
      BlockArrayClipboard backup = new BlockArrayClipboard(region);
      backup.setOrigin(min);
      ForwardExtentCopy copy = new ForwardExtentCopy(adaptedWorld, region, backup, min);
      Operations.complete(copy);
      return new SchematicManager.RestoreState(world, backup, min);
   }

   private void restoreBackup(SchematicManager.RestoreState state) {
      if (state != null && state.world != null && state.clipboard != null) {
         EditSession session = null;

         try {
            session = this.createEditSession(state.world);
            Operation operation = new ClipboardHolder(state.clipboard).createPaste(session).to(state.origin).ignoreAirBlocks(false).build();
            Operations.complete(operation);
            this.flushEditSession(session);
         } catch (Throwable ex) {
            this.plugin.warn("Ландшафт после аирдропа не восстановлен: " + this.safe(ex));
         } finally {
            this.closeEditSession(session);
         }
      }
   }

   private EditSession createEditSession(World world) {
      try {
         Object builder = WorldEdit.getInstance().newEditSessionBuilder();
         this.invoke(builder, "world", BukkitAdapter.adapt(world));
         this.invoke(builder, "maxBlocks", -1);
         this.tryInvoke(builder, "fastMode", true);
         this.applySideEffects(builder);
         Object result = this.invoke(builder, "build");
         if (result instanceof EditSession) {
            return (EditSession)result;
         }
      } catch (Throwable var4) {
      }

      return WorldEdit.getInstance().getEditSessionFactory().getEditSession(BukkitAdapter.adapt(world), -1);
   }

   private void applySideEffects(Object builder) {
      try {
         Class<?> sideEffectSet = Class.forName("com.sk89q.worldedit.util.SideEffectSet");
         Method none = sideEffectSet.getMethod("none");
         Object value = none.invoke(null);
         this.tryInvoke(builder, "sideEffectSet", value);
      } catch (Throwable var5) {
      }
   }

   private void tryInvoke(Object target, String name, Object... args) {
      try {
         this.invoke(target, name, args);
      } catch (Throwable var5) {
      }
   }

   private Object invoke(Object target, String name, Object... args) throws Exception {
      Method[] methods = target.getClass().getMethods();

      for (Method method : methods) {
         if (method.getName().equals(name) && method.getParameterTypes().length == args.length) {
            Class<?>[] types = method.getParameterTypes();
            boolean match = true;

            for (int i = 0; i < types.length; i++) {
               if (!this.matches(types[i], args[i])) {
                  match = false;
                  break;
               }
            }

            if (match) {
               return method.invoke(target, args);
            }
         }
      }

      throw new NoSuchMethodException(name);
   }

   private boolean matches(Class<?> type, Object value) {
      if (value == null) {
         return !type.isPrimitive();
      }

      if (type.isPrimitive()) {
         if (type == int.class) {
            return value instanceof Integer;
         } else if (type == boolean.class) {
            return value instanceof Boolean;
         } else if (type == long.class) {
            return value instanceof Long;
         } else if (type == double.class) {
            return value instanceof Double;
         } else if (type == float.class) {
            return value instanceof Float;
         } else if (type == short.class) {
            return value instanceof Short;
         } else if (type == byte.class) {
            return value instanceof Byte;
         } else {
            return type == char.class ? value instanceof Character : false;
         }
      } else {
         return type.isInstance(value);
      }
   }

   private void flushEditSession(EditSession session) {
      if (session != null) {
         this.tryInvoke(session, "flushSession");
         this.tryInvoke(session, "flushQueue");
      }
   }

   private void closeEditSession(EditSession session) {
      if (session != null) {
         this.tryInvoke(session, "close");
      }
   }

   private BlockVector3 translate(BlockVector3 point, BlockVector3 origin, BlockVector3 target) {
      return BlockVector3.at(target.x() + point.x() - origin.x(), target.y() + point.y() - origin.y(), target.z() + point.z() - origin.z());
   }

   private BlockVector3 min(BlockVector3 first, BlockVector3 second) {
      return BlockVector3.at(Math.min(first.x(), second.x()), Math.min(first.y(), second.y()), Math.min(first.z(), second.z()));
   }

   private BlockVector3 max(BlockVector3 first, BlockVector3 second) {
      return BlockVector3.at(Math.max(first.x(), second.x()), Math.max(first.y(), second.y()), Math.max(first.z(), second.z()));
   }

   private long volume(BlockVector3 min, BlockVector3 max) {
      return (long)(max.x() - min.x() + 1) * (max.y() - min.y() + 1) * (max.z() - min.z() + 1);
   }

   private String safe(Throwable throwable) {
      Throwable current = throwable;

      while (current.getCause() != null && (current.getMessage() == null || current.getMessage().trim().isEmpty())) {
         current = current.getCause();
      }

      String message = current.getMessage();
      return message != null && !message.trim().isEmpty() ? message : current.getClass().getSimpleName();
   }

   private static final class CachedClipboard {
      private final Clipboard clipboard;
      private final long modified;

      private CachedClipboard(Clipboard clipboard, long modified) {
         this.clipboard = clipboard;
         this.modified = modified;
      }
   }

   private static final class ChunkCoordinate {
      private final int x;
      private final int z;

      private ChunkCoordinate(int x, int z) {
         this.x = x;
         this.z = z;
      }
   }

   private static final class HeldChunk {
      private final World world;
      private final UUID worldId;
      private final int chunkX;
      private final int chunkZ;

      private HeldChunk(World world, int chunkX, int chunkZ) {
         this.world = world;
         this.worldId = world.getUID();
         this.chunkX = chunkX;
         this.chunkZ = chunkZ;
      }

      @Override
      public boolean equals(Object object) {
         if (this == object) {
            return true;
         } else {
            return !(object instanceof SchematicManager.HeldChunk other)
               ? false
               : this.chunkX == other.chunkX && this.chunkZ == other.chunkZ && this.worldId.equals(other.worldId);
         }
      }

      @Override
      public int hashCode() {
         int result = this.worldId.hashCode();
         result = 31 * result + this.chunkX;
         return 31 * result + this.chunkZ;
      }
   }

   private static final class RestoreState {
      private final World world;
      private final Clipboard clipboard;
      private final BlockVector3 origin;

      private RestoreState(World world, Clipboard clipboard, BlockVector3 origin) {
         this.world = world;
         this.clipboard = clipboard;
         this.origin = origin;
      }
   }

   private static final class SavedBlock {
      private final Location location;
      private final Material material;
      private final BlockData data;

      private SavedBlock(Location location, Material material, BlockData data) {
         this.location = location;
         this.material = material;
         this.data = data;
      }
   }
}
