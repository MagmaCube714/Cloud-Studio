package cs.cloudstudio.manager;

import cs.cloudstudio.CloudAirDrop;
import cs.cloudstudio.util.ColorUtil;
import java.util.ArrayList;
import java.util.Locale;
import java.util.UUID;
import me.neznamy.tab.api.TabAPI;
import me.neznamy.tab.api.TabPlayer;
import me.neznamy.tab.api.bossbar.BarColor;
import me.neznamy.tab.api.bossbar.BarStyle;
import me.neznamy.tab.api.bossbar.BossBar;
import me.neznamy.tab.api.event.EventBus;
import me.neznamy.tab.api.event.EventHandler;
import me.neznamy.tab.api.event.player.PlayerLoadEvent;
import me.neznamy.tab.api.event.plugin.TabLoadEvent;
import org.bukkit.entity.Player;

public final class BossBarManager {
   private static final String DEFAULT_TITLE = "&6АирДроп";
   private final CloudAirDrop plugin;
   private TabAPI tabApi;
   private me.neznamy.tab.api.bossbar.BossBarManager tabBossBars;
   private EventBus tabEventBus;
   private EventHandler<PlayerLoadEvent> playerLoadHandler;
   private EventHandler<TabLoadEvent> tabLoadHandler;
   private BossBar bossBar;
   private String currentTitle = "";
   private double currentProgress = -1.0;
   private BarColor currentColor;
   private BarStyle currentStyle;

   public BossBarManager(CloudAirDrop plugin) {
      this.plugin = plugin;
      this.refreshTabApi();
   }

   public void show(String title, String colorPath, String stylePath, double progress) {
      String safeTitle = this.formatTitle(title);
      double normalizedProgress = this.normalizeProgress(progress);
      BarColor color = this.parseColor(this.plugin.configString(colorPath, "YELLOW"));
      BarStyle style = this.parseStyle(this.plugin.configString(stylePath, "SOLID"));
      if (this.ensureBossBar(safeTitle, normalizedProgress, color, style)) {
         this.setTitle(safeTitle);
         this.setProgress(normalizedProgress);
         this.setColor(color);
         this.setStyle(style);
         this.syncOnlinePlayers();
      }
   }

   public void update(String title, double progress) {
      if (this.bossBar != null) {
         this.setTitle(this.formatTitle(title));
         this.setProgress(this.normalizeProgress(progress));
      }
   }

   public void add(Player player) {
      if (this.bossBar != null && player != null && player.isOnline()) {
         this.addTabPlayer(this.getTabPlayer(player.getUniqueId()));
      }
   }

   public void remove() {
      this.removeRuntimeBar();
      this.resetCachedState();
   }

   public void shutdown() {
      this.remove();
      this.unregisterTabEvents();
      this.tabApi = null;
      this.tabBossBars = null;
   }

   private boolean ensureBossBar(String title, double progress, BarColor color, BarStyle style) {
      if (this.bossBar != null) {
         return true;
      }

      if (!this.isTabReady() && !this.refreshTabApi()) {
         return false;
      }

      try {
         this.bossBar = this.tabBossBars.createBossBar(title, this.toTabProgress(progress), color, style);
         this.currentTitle = title;
         this.currentProgress = progress;
         this.currentColor = color;
         this.currentStyle = style;
         return true;
      } catch (RuntimeException exception) {
         this.bossBar = null;
         this.plugin.warn("TAB не смог создать bossbar: " + exception.getMessage());
         return false;
      }
   }

   private void setTitle(String title) {
      BossBar bar = this.bossBar;
      if (bar != null && !this.currentTitle.equals(title)) {
         bar.setTitle(title);
         this.currentTitle = title;
      }
   }

   private void setProgress(double progress) {
      BossBar bar = this.bossBar;
      if (bar != null && Math.abs(this.currentProgress - progress) >= 5.0E-4) {
         bar.setProgress(this.toTabProgress(progress));
         this.currentProgress = progress;
      }
   }

   private void setColor(BarColor color) {
      BossBar bar = this.bossBar;
      if (bar != null && this.currentColor != color) {
         bar.setColor(color);
         this.currentColor = color;
      }
   }

   private void setStyle(BarStyle style) {
      BossBar bar = this.bossBar;
      if (bar != null && this.currentStyle != style) {
         bar.setStyle(style);
         this.currentStyle = style;
      }
   }

   private void syncOnlinePlayers() {
      BossBar bar = this.bossBar;
      if (bar != null && this.tabApi != null) {
         for (TabPlayer player : new ArrayList<>(bar.getPlayers())) {
            if (player != null && !player.isLoaded()) {
               bar.removePlayer(player);
            }
         }

         for (TabPlayer player : this.tabApi.getOnlinePlayers()) {
            this.addTabPlayer(player);
         }
      }
   }

   private void addTabPlayer(TabPlayer player) {
      BossBar bar = this.bossBar;
      if (bar != null && player != null && player.isLoaded() && !bar.containsPlayer(player)) {
         bar.addPlayer(player);
      }
   }

   private TabPlayer getTabPlayer(UUID uuid) {
      return this.tabApi != null && uuid != null ? this.tabApi.getPlayer(uuid) : null;
   }

   private void removeRuntimeBar() {
      BossBar bar = this.bossBar;
      this.bossBar = null;
      if (bar != null) {
         for (TabPlayer player : new ArrayList<>(bar.getPlayers())) {
            if (player != null) {
               try {
                  bar.removePlayer(player);
               } catch (RuntimeException ex) {
                  this.plugin.warn("Не удалось скрыть bossbar аирдропа: " + ex.getMessage());
               }
            }
         }

         if (this.tabBossBars != null) {
            try {
               this.tabBossBars.removeBossBar(bar);
            } catch (RuntimeException ex) {
               this.plugin.warn("Не удалось удалить bossbar аирдропа из TAB: " + ex.getMessage());
            }
         }
      }
   }

   private void resetCachedState() {
      this.currentTitle = "";
      this.currentProgress = -1.0;
      this.currentColor = null;
      this.currentStyle = null;
   }

   private String formatTitle(String title) {
      String value = title != null && !title.trim().isEmpty() ? title : "&6АирДроп";
      return ColorUtil.color(value);
   }

   private BarColor parseColor(String value) {
      try {
         return BarColor.valueOf(this.normalize(value));
      } catch (IllegalArgumentException exception) {
         return BarColor.YELLOW;
      }
   }

   private BarStyle parseStyle(String value) {
      String normalized = this.normalize(value);
      if ("SOLID".equals(normalized)) {
         normalized = "PROGRESS";
      } else if (normalized.startsWith("SEGMENTED_")) {
         normalized = normalized.replace("SEGMENTED_", "NOTCHED_");
      }

      try {
         return BarStyle.valueOf(normalized);
      } catch (IllegalArgumentException exception) {
         return BarStyle.PROGRESS;
      }
   }

   private String normalize(String value) {
      return value == null ? "" : value.trim().toUpperCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
   }

   private double normalizeProgress(double value) {
      return !Double.isNaN(value) && !Double.isInfinite(value) ? Math.max(0.0, Math.min(1.0, value)) : 0.0;
   }

   private float toTabProgress(double normalizedProgress) {
      return (float)(this.normalizeProgress(normalizedProgress) * 100.0);
   }

   private boolean refreshTabApi() {
      try {
         this.tabApi = TabAPI.getInstance();
         this.tabBossBars = this.tabApi.getBossBarManager();
      } catch (IllegalStateException exception) {
         this.tabApi = null;
         this.tabBossBars = null;
         this.plugin.warn("TAB API 6.1.0 не готов: " + exception.getMessage());
         return false;
      }

      if (this.tabBossBars == null) {
         return false;
      }

      this.registerTabEvents();
      return true;
   }

   private boolean isTabReady() {
      return this.tabApi != null && this.tabBossBars != null;
   }

   private void registerTabEvents() {
      if (this.isTabReady() && this.tabEventBus == null) {
         this.tabEventBus = this.tabApi.getEventBus();
         if (this.tabEventBus != null) {
            this.playerLoadHandler = event -> this.addTabPlayer(event.getPlayer());
            this.tabLoadHandler = event -> this.recreateAfterTabReload();
            this.tabEventBus.register(PlayerLoadEvent.class, this.playerLoadHandler);
            this.tabEventBus.register(TabLoadEvent.class, this.tabLoadHandler);
         }
      }
   }

   private void unregisterTabEvents() {
      if (this.tabEventBus != null) {
         try {
            if (this.playerLoadHandler != null) {
               this.tabEventBus.unregister(this.playerLoadHandler);
            }

            if (this.tabLoadHandler != null) {
               this.tabEventBus.unregister(this.tabLoadHandler);
            }
         } catch (RuntimeException var2) {
         }
      }

      this.tabEventBus = null;
      this.playerLoadHandler = null;
      this.tabLoadHandler = null;
   }

   private void recreateAfterTabReload() {
      boolean restore = this.bossBar != null;
      this.removeRuntimeBar();
      if (restore && this.refreshTabApi()) {
         String title = this.currentTitle;
         double progress = this.currentProgress < 0.0 ? 1.0 : this.currentProgress;
         BarColor color = this.currentColor == null ? BarColor.YELLOW : this.currentColor;
         BarStyle style = this.currentStyle == null ? BarStyle.PROGRESS : this.currentStyle;
         if (this.ensureBossBar(title, progress, color, style)) {
            this.syncOnlinePlayers();
         }
      }
   }
}
