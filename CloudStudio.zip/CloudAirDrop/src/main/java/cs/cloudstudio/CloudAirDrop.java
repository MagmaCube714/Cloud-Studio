package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.listener.EntityDeathListener;
import cs.cloudstudio.listener.InteractListener;
import cs.cloudstudio.listener.InventoryListener;
import cs.cloudstudio.listener.PlayerListener;
import cs.cloudstudio.manager.AirDropManager;
import cs.cloudstudio.manager.BossBarManager;
import cs.cloudstudio.manager.BossManager;
import cs.cloudstudio.manager.ClanRewardManager;
import cs.cloudstudio.manager.HologramManager;
import cs.cloudstudio.manager.LocationManager;
import cs.cloudstudio.manager.LootManager;
import cs.cloudstudio.manager.RegionManager;
import cs.cloudstudio.manager.ScheduleManager;
import cs.cloudstudio.manager.SchematicManager;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.ItemNameTranslator;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudAirDrop extends JavaPlugin {
   private static CloudAirDrop instance;
   private final Map<String, String> messageDefaults = new HashMap<>();
   private LootManager lootManager;
   private SchematicManager schematicManager;
   private HologramManager hologramManager;
   private BossBarManager bossBarManager;
   private BossManager bossManager;
   private LocationManager locationManager;
   private RegionManager regionManager;
   private ClanRewardManager clanRewardManager;
   private AirDropManager airDropManager;
   private ScheduleManager scheduleManager;

   public void onEnable() {
      instance = this;
      ItemNameTranslator.init(this);
      this.loadDefaults();
      this.loadConfiguration();
      this.initManagers();
      this.registerCommand();
      this.registerListeners();
      this.scheduleManager.start();
      this.log("&fCloudAirDrop &aуспешно загружен!");
   }

   public void onDisable() {
      if (this.scheduleManager != null) {
         this.scheduleManager.stop();
      }

      if (this.airDropManager != null) {
         this.airDropManager.shutdown();
      }

      if (this.lootManager != null) {
         this.lootManager.saveNow();
      }

      Bukkit.getScheduler().cancelTasks(this);
      this.log("&fCloudAirDrop &cуспешно выгружен!");
      instance = null;
   }

   private void initManagers() {
      this.lootManager = new LootManager(this);
      this.schematicManager = new SchematicManager(this);
      this.hologramManager = new HologramManager(this);
      this.bossBarManager = new BossBarManager(this);
      this.bossManager = new BossManager(this);
      this.locationManager = new LocationManager(this);
      this.regionManager = new RegionManager(this);
      this.clanRewardManager = new ClanRewardManager(this);
      this.airDropManager = new AirDropManager(
         this,
         this.lootManager,
         this.schematicManager,
         this.hologramManager,
         this.bossBarManager,
         this.bossManager,
         this.locationManager,
         this.regionManager,
         this.clanRewardManager
      );
      this.scheduleManager = new ScheduleManager(this, this.airDropManager);
   }

   private void registerCommand() {
      AdminCommand adminCommand = new AdminCommand(this, this.airDropManager, this.lootManager, this.scheduleManager);
      PluginCommand command = this.getCommand("cloudairdrop");
      if (command != null) {
         command.setExecutor(adminCommand);
         command.setTabCompleter(adminCommand);
      }
   }

   private void registerListeners() {
      Bukkit.getPluginManager().registerEvents(new InteractListener(this.airDropManager), this);
      Bukkit.getPluginManager().registerEvents(new InventoryListener(this, this.lootManager), this);
      Bukkit.getPluginManager().registerEvents(new EntityDeathListener(this.airDropManager), this);
      Bukkit.getPluginManager().registerEvents(new PlayerListener(this.airDropManager), this);
   }

   public void reloadPlugin() {
      this.loadConfiguration();
      this.lootManager.reload();
      this.schematicManager.clearCache();
      this.scheduleManager.reload();
      this.airDropManager.refreshConfig();
   }

   private void loadConfiguration() {
      this.saveDefaultConfig();
      this.reloadConfig();
      this.getConfig().options().copyDefaults(true);
      this.normalizeNotificationMessage();
   }

   private void normalizeNotificationMessage() {
      List<String> lines = this.getConfig().getStringList("notification.messageText");
      if (lines != null && !lines.isEmpty()) {
         String oldLine = "&6АирДроп &7» &fПоявился %airType%&f";
         String newLine = "&6АирДроп &7» &fПоявился %airType%&f!";
         boolean changed = false;

         for (int i = 0; i < lines.size(); i++) {
            if (oldLine.equals(lines.get(i))) {
               lines.set(i, newLine);
               changed = true;
            }
         }

         if (changed) {
            this.getConfig().set("notification.messageText", lines);
         }
      }
   }

   private void loadDefaults() {
      this.messageDefaults.put("no-perm", "&6АирДроп &7» &cУ вас нет прав");
      this.messageDefaults.put("reloaded", "&6АирДроп &7» &aКонфиг перезагружен");
      this.messageDefaults.put("started", "&6АирДроп &7» &aАирдроп запущен");
      this.messageDefaults.put("already-started", "&6АирДроп &7» &cАирдроп уже запущен");
      this.messageDefaults.put("stopped", "&6АирДроп &7» &cАирдроп остановлен");
      this.messageDefaults.put("not-started", "&6АирДроп &7» &cАирдроп не запущен");
      this.messageDefaults.put("wrong-type", "&6АирДроп &7» &cНеверный тип аирдропа");
      this.messageDefaults.put("only-player", "&6АирДроп &7» &cКоманда доступна только от лица игрока");
      this.messageDefaults.put("editor-opened", "&6АирДроп &7» &aРедактор наград открыт");
      this.messageDefaults.put("editor-saved", "&6АирДроп &7» &aНаграды сохранены");
      this.messageDefaults.put("edit-title", "Редактор %type%");
      this.messageDefaults.put("activateAir", "&6АирДроп &7» &fИгрок &6%player% &fоткрыл аирдроп");
      this.messageDefaults.put("bossKilled", "&6АирДроп &7» &fИгрок &6%killer% &fубил босса");
   }

   public String message(String path) {
      String value = this.getConfig().getString("messages." + path);
      if (value == null || value.trim().isEmpty()) {
         value = this.messageDefaults.get(path);
      }

      return ColorUtil.color(value == null ? "" : value);
   }

   public List<String> messageList(String path, List<String> fallback) {
      List<String> lines = this.getConfig().getStringList("messages." + path);
      return lines != null && !lines.isEmpty() ? ColorUtil.color(lines) : ColorUtil.color(fallback);
   }

   public String configString(String path, String fallback) {
      String value = this.getConfig().getString(path);
      if ((value == null || value.trim().isEmpty()) && path.startsWith("bossbars.")) {
         String suffix = path.substring("bossbars.".length());
         value = this.getConfig().getString("bossBars." + suffix);
         if (value == null || value.trim().isEmpty()) {
            value = this.getConfig().getString("bossbar." + suffix);
         }
      }

      if ((value == null || value.trim().isEmpty()) && path.startsWith("hologram.")) {
         String suffix = path.substring("hologram.".length());
         value = this.getConfig().getString("holograms." + suffix);
      }

      return value != null && !value.trim().isEmpty() ? value : fallback;
   }

   public List<String> defaultAdminUsage() {
      return Arrays.asList(
         "&6АирДроп &7» &f/cloudairdrop reload",
         "&6АирДроп &7» &f/cloudairdrop start [common|rare|epic|mythic|legendary]",
         "&6АирДроп &7» &f/cloudairdrop stop",
         "&6АирДроп &7» &f/cloudairdrop add <common|rare|epic|mythic|legendary>"
      );
   }

   public void log(String message) {
      Bukkit.getConsoleSender().sendMessage(ColorUtil.color(message));
   }

   public void warn(String message) {
      this.getLogger().warning(message);
   }

   public static CloudAirDrop getInstance() {
      return instance;
   }

   public AirDropManager getAirDropManager() {
      return this.airDropManager;
   }
}
