plugins {
    java
}

apply(from = "../common.gradle.kts")
