package cs.cloudstudio;

import cs.cloudstudio.cache.ResourcePackCache;
import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.listener.ResourcePackListener;
import cs.cloudstudio.manager.ApiManager;
import cs.cloudstudio.manager.ApiPlaceholder;
import cs.cloudstudio.util.ColorUtil;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudApi extends JavaPlugin {
   private static final String FORCEPACK_STATUS_CHANNEL = "forcepack:status";
   private static CloudApi instance;
   private ConfigManager configManager;
   private ResourcePackCache resourcePackCache;
   private ResourcePackListener resourcePackListener;
   private ApiManager apiManager;
   private final List<ApiPlaceholder> placeholders = new ArrayList<>(2);

   public void onEnable() {
      instance = this;
      this.startPlugin();
   }

   public void onDisable() {
      this.stopPlugin();
      Bukkit.getConsoleSender().sendMessage(ColorUtil.color("&fCloudApi &cуспешно выгружен!"));
      instance = null;
   }

   public void reloadPlugin() {
      if (this.configManager != null) {
         this.configManager.reloadConfig();
         if (this.apiManager != null) {
            this.apiManager.reload();
         }
      }
   }

   private void startPlugin() {
      if (this.checkPlaceholderApi()) {
         this.configManager = new ConfigManager(this);
         this.configManager.loadConfig();
         this.resourcePackCache = new ResourcePackCache();
         this.resourcePackListener = new ResourcePackListener(this.resourcePackCache);
         this.getServer().getMessenger().registerIncomingPluginChannel(this, "forcepack:status", this.resourcePackListener);
         Bukkit.getPluginManager().registerEvents(this.resourcePackListener, this);
         this.apiManager = new ApiManager(this.configManager, this.resourcePackCache);
         this.registerPlaceholders();
         this.registerCommand();
         Bukkit.getConsoleSender().sendMessage(ColorUtil.color("&fCloudApi &aуспешно загружен!"));
      }
   }

   private void stopPlugin() {
      for (ApiPlaceholder placeholder : this.placeholders) {
         placeholder.unregister();
      }

      this.placeholders.clear();
      if (this.resourcePackListener != null) {
         this.getServer().getMessenger().unregisterIncomingPluginChannel(this, "forcepack:status", this.resourcePackListener);
         HandlerList.unregisterAll(this.resourcePackListener);
         this.resourcePackListener = null;
      }

      if (this.resourcePackCache != null) {
         this.resourcePackCache.clear();
         this.resourcePackCache = null;
      }

      this.apiManager = null;
      this.configManager = null;
   }

   private boolean checkPlaceholderApi() {
      Plugin placeholderApi = Bukkit.getPluginManager().getPlugin("PlaceholderAPI");
      if (placeholderApi != null && placeholderApi.isEnabled()) {
         return true;
      }

      Bukkit.getConsoleSender().sendMessage(ColorUtil.color("&fCloudApi &cPlaceholderAPI не найден, плагин отключён"));
      Bukkit.getPluginManager().disablePlugin(this);
      return false;
   }

   private void registerCommand() {
      PluginCommand command = this.getCommand("cloudapi");
      if (command == null) {
         this.getLogger().warning("[CloudApi] Команда cloudapi не найдена в plugin.yml");
      } else {
         AdminCommand adminCommand = new AdminCommand(this);
         command.setExecutor(adminCommand);
         command.setTabCompleter(adminCommand);
      }
   }

   private void registerPlaceholders() {
      ApiPlaceholder cloudPlaceholder = new ApiPlaceholder(this, this.apiManager, "cloudapi");
      cloudPlaceholder.register();
      this.placeholders.add(cloudPlaceholder);
   }

   public static CloudApi getInstance() {
      return instance;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public ApiManager getApiManager() {
      return this.apiManager;
   }
}
