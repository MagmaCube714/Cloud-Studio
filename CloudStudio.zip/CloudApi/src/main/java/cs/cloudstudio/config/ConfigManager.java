package cs.cloudstudio.config;

import cs.cloudstudio.util.ColorUtil;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public final class ConfigManager {
   private static final String DEFAULT_NO_PERMISSION = "&6CloudApi &7» &cУ вас нет прав";
   private static final String DEFAULT_USAGE = "&6CloudApi &7» &f/cloudapi reload";
   private static final String DEFAULT_RELOAD = "&6CloudApi &7» &aКонфиг перезагружен";
   private final JavaPlugin plugin;
   private String noPermissionMessage = "";
   private String usageMessage = "";
   private String reloadMessage = "";

   public ConfigManager(JavaPlugin plugin) {
      this.plugin = plugin;
   }

   public void loadConfig() {
      this.plugin.saveDefaultConfig();
      this.reloadConfig();
   }

   public void reloadConfig() {
      this.plugin.reloadConfig();
      ColorUtil.clearCache();
      this.loadMessages();
   }

   public FileConfiguration getConfig() {
      return this.plugin.getConfig();
   }

   public String getNoPermissionMessage() {
      return this.noPermissionMessage;
   }

   public String getUsageMessage() {
      return this.usageMessage;
   }

   public String getReloadMessage() {
      return this.reloadMessage;
   }

   public String color(String text) {
      return ColorUtil.color(text);
   }

   private void loadMessages() {
      FileConfiguration config = this.plugin.getConfig();
      this.noPermissionMessage = ColorUtil.color(
         config.getString("messages.no-perm", config.getString("admin.messages.no-permission", "&6CloudApi &7» &cУ вас нет прав"))
      );
      this.usageMessage = ColorUtil.color(
         config.getString("messages.admin-usage", config.getString("admin.messages.usage", "&6CloudApi &7» &f/cloudapi reload"))
      );
      this.reloadMessage = ColorUtil.color(
         config.getString("messages.reloaded", config.getString("admin.messages.reload", "&6CloudApi &7» &aКонфиг перезагружен"))
      );
   }
}
