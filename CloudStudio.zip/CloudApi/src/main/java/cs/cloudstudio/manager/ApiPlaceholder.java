package cs.cloudstudio.manager;

import cs.cloudstudio.CloudApi;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.clip.placeholderapi.expansion.Relational;
import org.bukkit.entity.Player;

public final class ApiPlaceholder extends PlaceholderExpansion implements Relational {
   private final CloudApi plugin;
   private final ApiManager apiManager;
   private final String identifier;

   public ApiPlaceholder(CloudApi plugin, ApiManager apiManager, String identifier) {
      this.plugin = plugin;
      this.apiManager = apiManager;
      this.identifier = identifier;
   }

   public String getIdentifier() {
      return this.identifier;
   }

   public String getAuthor() {
      return "CloudStudio";
   }

   public String getVersion() {
      return this.plugin.getPluginMeta().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public String onPlaceholderRequest(Player player, String params) {
      return this.resolve(player, player, params);
   }

   public String onPlaceholderRequest(Player one, Player two, String params) {
      Player viewer = one != null ? one : two;
      Player target = two != null ? two : one;
      return this.resolve(viewer, target, params);
   }

   private String resolve(Player viewer, Player target, String params) {
      return this.apiManager == null ? "" : this.apiManager.resolve(viewer, target, params);
   }
}
