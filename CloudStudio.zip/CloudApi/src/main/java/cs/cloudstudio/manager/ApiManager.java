package cs.cloudstudio.manager;

import cs.cloudstudio.cache.PrefixCache;
import cs.cloudstudio.cache.ResourcePackCache;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.util.PlaceholderUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public final class ApiManager {
   private static final String DEFAULT_PREFIX_PLACEHOLDER = "%change_me%";
   private static final String PREFIX = "prefix";
   private static final String PREFIX_DYNAMIC = "prefix_";
   private static final String SYMBOL_DYNAMIC = "symbol_";
   private static final int MAX_PREFIX_CACHE_SIZE = 1024;
   private final ConfigManager configManager;
   private final ResourcePackCache resourcePackCache;
   private final PrefixCache prefixCache = new PrefixCache(1024);
   private volatile ApiManager.State state = ApiManager.State.empty();

   public ApiManager(ConfigManager configManager, ResourcePackCache resourcePackCache) {
      this.configManager = configManager;
      this.resourcePackCache = resourcePackCache;
      this.reload();
   }

   public void reload() {
      Map<String, ApiManager.SymbolPair> symbols = new HashMap<>(32);
      List<ApiManager.ReplacementPair> replacements = new ArrayList<>(16);
      String prefixPlaceholder = "%change_me%";
      ConfigurationSection symbolsSection = this.configManager.getConfig().getConfigurationSection("symbols");
      if (symbolsSection != null) {
         this.loadSymbols(symbolsSection, symbols);
      }

      ConfigurationSection prefixSection = this.configManager.getConfig().getConfigurationSection("prefix");
      if (prefixSection != null) {
         String configuredPlaceholder = prefixSection.getString("placeholder", "%change_me%");
         if (configuredPlaceholder != null && !configuredPlaceholder.isEmpty()) {
            prefixPlaceholder = configuredPlaceholder;
         }

         this.loadPrefix(prefixSection, replacements);
      }

      this.state = new ApiManager.State(Collections.unmodifiableMap(symbols), Collections.unmodifiableList(replacements), prefixPlaceholder);
      this.prefixCache.clear();
   }

   public String resolve(Player viewer, Player target, String params) {
      if (params != null && !params.isEmpty()) {
         ApiManager.State current = this.state;
         boolean hasResourcePack = this.hasResourcePack(viewer);
         if (params.length() == "prefix".length() && params.regionMatches(true, 0, "prefix", 0, "prefix".length())) {
            return this.processConfiguredPrefix(viewer, target, hasResourcePack, current);
         } else if (this.startsWithIgnoreCase(params, "prefix_")) {
            return this.processDynamicPrefix(viewer, target, hasResourcePack, params.substring("prefix_".length()), current);
         } else {
            return this.startsWithIgnoreCase(params, "symbol_")
               ? this.processSymbol(viewer, target, params.substring("symbol_".length()), hasResourcePack, current)
               : this.processSymbol(viewer, target, params, hasResourcePack, current);
         }
      } else {
         return "";
      }
   }

   private void loadSymbols(ConfigurationSection section, Map<String, ApiManager.SymbolPair> symbols) {
      for (String key : section.getKeys(false)) {
         ConfigurationSection symbolSection = section.getConfigurationSection(key);
         if (symbolSection != null) {
            String enable = this.configManager.color(symbolSection.getString("enable", ""));
            String disable = this.configManager.color(symbolSection.getString("disable", ""));
            symbols.put(key.toLowerCase(Locale.ROOT), new ApiManager.SymbolPair(enable, disable));
         }
      }
   }

   private void loadPrefix(ConfigurationSection prefixSection, List<ApiManager.ReplacementPair> replacements) {
      ConfigurationSection replacementsSection = prefixSection.getConfigurationSection("replacements");
      if (replacementsSection != null) {
         this.loadReplacementSection(replacementsSection, replacements);
      }

      for (String key : prefixSection.getKeys(false)) {
         if (!"placeholder".equalsIgnoreCase(key) && !"replacements".equalsIgnoreCase(key)) {
            ConfigurationSection section = prefixSection.getConfigurationSection(key);
            if (section != null) {
               this.addReplacement(section, replacements);
            }
         }
      }
   }

   private void loadReplacementSection(ConfigurationSection section, List<ApiManager.ReplacementPair> replacements) {
      for (String key : section.getKeys(false)) {
         ConfigurationSection pairSection = section.getConfigurationSection(key);
         if (pairSection != null) {
            this.addReplacement(pairSection, replacements);
         }
      }
   }

   private void addReplacement(ConfigurationSection section, List<ApiManager.ReplacementPair> replacements) {
      String enable = section.getString("enable");
      String disable = section.getString("disable");
      if (enable != null && disable != null && !enable.isEmpty() && !disable.isEmpty()) {
         replacements.add(new ApiManager.ReplacementPair(enable, disable, this.configManager.color(enable), this.configManager.color(disable)));
      }
   }

   private String processSymbol(Player viewer, Player target, String key, boolean hasResourcePack, ApiManager.State current) {
      if (key != null && !key.isEmpty()) {
         ApiManager.SymbolPair pair = current.symbols.get(key.toLowerCase(Locale.ROOT));
         if (pair == null) {
            return "";
         }

         String value = hasResourcePack ? pair.enable : pair.disable;
         String resolved = PlaceholderUtil.apply(viewer, target, value);
         return resolved.indexOf(38) >= 0 ? this.configManager.color(resolved) : resolved;
      } else {
         return "";
      }
   }

   private String processConfiguredPrefix(Player viewer, Player target, boolean hasResourcePack, ApiManager.State current) {
      String raw = PlaceholderUtil.apply(viewer, target, current.prefixPlaceholder);
      return this.processPrefix(raw, hasResourcePack, current);
   }

   private String processDynamicPrefix(Player viewer, Player target, boolean hasResourcePack, String placeholderName, ApiManager.State current) {
      String raw = PlaceholderUtil.apply(viewer, target, this.normalizePlaceholder(placeholderName, current.prefixPlaceholder));
      return this.processPrefix(raw, hasResourcePack, current);
   }

   private String processPrefix(String raw, boolean hasResourcePack, ApiManager.State current) {
      if (raw != null && !raw.isEmpty()) {
         String cacheKey = (hasResourcePack ? "1" : "0") + raw;
         String cached = this.prefixCache.get(cacheKey);
         if (cached != null) {
            return cached;
         }

         String result = this.configManager.color(this.replace(raw, hasResourcePack, current.replacements));
         this.prefixCache.put(cacheKey, result);
         return result;
      } else {
         return "";
      }
   }

   private String replace(String text, boolean hasResourcePack, List<ApiManager.ReplacementPair> replacements) {
      if (replacements.isEmpty()) {
         return text;
      }

      String result = text;

      for (int index = 0; index < replacements.size(); index++) {
         result = replacements.get(index).replace(result, hasResourcePack);
      }

      return result;
   }

   private String normalizePlaceholder(String input, String fallback) {
      if (input == null) {
         return fallback;
      } else {
         String value = input.trim();
         if (value.isEmpty()) {
            return fallback;
         } else {
            return value.startsWith("%") && value.endsWith("%") ? value : "%" + value + "%";
         }
      }
   }

   private boolean hasResourcePack(Player viewer) {
      return this.resourcePackCache != null && this.resourcePackCache.hasResourcePack(viewer);
   }

   private boolean startsWithIgnoreCase(String value, String prefix) {
      return value.length() >= prefix.length() && value.regionMatches(true, 0, prefix, 0, prefix.length());
   }

   private static final class ReplacementPair {
      private final String enable;
      private final String disable;
      private final String coloredEnable;
      private final String coloredDisable;

      private ReplacementPair(String enable, String disable, String coloredEnable, String coloredDisable) {
         this.enable = enable;
         this.disable = disable;
         this.coloredEnable = coloredEnable;
         this.coloredDisable = coloredDisable;
      }

      private String replace(String text, boolean hasResourcePack) {
         return hasResourcePack
            ? this.replace(this.replace(text, this.disable, this.enable), this.coloredDisable, this.coloredEnable)
            : this.replace(this.replace(text, this.enable, this.disable), this.coloredEnable, this.coloredDisable);
      }

      private String replace(String text, String from, String to) {
         return !from.isEmpty() && text.indexOf(from) >= 0 ? text.replace(from, to) : text;
      }
   }

   private static final class State {
      private final Map<String, ApiManager.SymbolPair> symbols;
      private final List<ApiManager.ReplacementPair> replacements;
      private final String prefixPlaceholder;

      private State(Map<String, ApiManager.SymbolPair> symbols, List<ApiManager.ReplacementPair> replacements, String prefixPlaceholder) {
         this.symbols = symbols;
         this.replacements = replacements;
         this.prefixPlaceholder = prefixPlaceholder;
      }

      private static ApiManager.State empty() {
         return new ApiManager.State(Collections.emptyMap(), Collections.emptyList(), "%change_me%");
      }
   }

   private static final class SymbolPair {
      private final String enable;
      private final String disable;

      private SymbolPair(String enable, String disable) {
         this.enable = enable == null ? "" : enable;
         this.disable = disable == null ? "" : disable;
      }
   }
}
