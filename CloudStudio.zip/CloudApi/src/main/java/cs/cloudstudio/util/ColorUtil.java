package cs.cloudstudio.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class ColorUtil {
   private static final String LEGACY_CODES = "0123456789abcdefklmnorx";
   private static final char COLOR_CHAR = '§';
   private static final int MAX_CACHE_SIZE = 512;
   private static final Map<String, String> CACHE = new ConcurrentHashMap<>(128);

   private ColorUtil() {
   }

   public static String color(String text) {
      if (text == null || text.isEmpty()) {
         return "";
      }

      if (text.indexOf(38) < 0) {
         return text;
      }

      String cached = CACHE.get(text);
      if (cached != null) {
         return cached;
      }

      String result = translate(text);
      if (CACHE.size() < 512) {
         CACHE.put(text, result);
      }

      return result;
   }

   public static void clearCache() {
      CACHE.clear();
   }

   private static String translate(String text) {
      StringBuilder builder = null;
      int last = 0;
      int length = text.length();

      for (int index = 0; index < length - 1; index++) {
         if (text.charAt(index) == '&') {
            char next = text.charAt(index + 1);
            if (next == '#' && index + 7 < length && isHex(text, index + 2)) {
               if (builder == null) {
                  builder = new StringBuilder(length + 8);
               }

               builder.append(text, last, index);
               appendHex(builder, text, index + 2);
               index += 7;
               last = index + 1;
            } else if (isColor(next)) {
               if (builder == null) {
                  builder = new StringBuilder(length);
               }

               builder.append(text, last, index);
               builder.append('§').append(Character.toLowerCase(next));
               last = ++index + 1;
            }
         }
      }

      if (builder == null) {
         return text;
      }

      builder.append(text, last, length);
      return builder.toString();
   }

   private static void appendHex(StringBuilder builder, String text, int start) {
      builder.append('§').append('x');

      for (int index = 0; index < 6; index++) {
         builder.append('§').append(Character.toLowerCase(text.charAt(start + index)));
      }
   }

   private static boolean isHex(String text, int start) {
      for (int index = 0; index < 6; index++) {
         char value = text.charAt(start + index);
         if ((value < '0' || value > '9') && (value < 'a' || value > 'f') && (value < 'A' || value > 'F')) {
            return false;
         }
      }

      return true;
   }

   private static boolean isColor(char value) {
      return "0123456789abcdefklmnorx".indexOf(Character.toLowerCase(value)) >= 0;
   }
}
