package cs.cloudstudio.util;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.entity.Player;

public final class PlaceholderUtil {
   private PlaceholderUtil() {
   }

   public static String apply(Player viewer, Player target, String text) {
      if (text == null || text.isEmpty()) {
         return "";
      }

      if (text.indexOf(37) < 0) {
         return text;
      }

      String result = text;
      if (viewer != null && target != null && viewer != target) {
         try {
            result = PlaceholderAPI.setRelationalPlaceholders(viewer, target, result);
         } catch (RuntimeException ignored) {
            result = text;
         }
      }

      if (result != null && result.indexOf(37) >= 0) {
         Player placeholderTarget = target != null ? target : viewer;
         if (placeholderTarget == null) {
            return result;
         }

         try {
            result = PlaceholderAPI.setPlaceholders(placeholderTarget, result);
         } catch (RuntimeException ignored) {
            return result == null ? "" : result;
         }

         return result == null ? "" : result;
      } else {
         return result == null ? "" : result;
      }
   }
}
