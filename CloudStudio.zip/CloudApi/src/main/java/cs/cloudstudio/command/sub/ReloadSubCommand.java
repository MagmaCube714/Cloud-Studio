package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudApi;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand implements SubCommand {
   private final CloudApi plugin;

   public ReloadSubCommand(CloudApi plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "reload";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      this.plugin.reloadPlugin();
      sender.sendMessage(this.plugin.getConfigManager().getReloadMessage());
   }
}
