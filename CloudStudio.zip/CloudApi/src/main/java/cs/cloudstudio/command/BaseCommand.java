package cs.cloudstudio.command;

import cs.cloudstudio.config.ConfigManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public abstract class BaseCommand implements CommandExecutor, TabCompleter {
   private final String permission;
   private final ConfigManager configManager;
   private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();

   protected BaseCommand(String permission, ConfigManager configManager) {
      this.permission = permission;
      this.configManager = configManager;
   }

   protected void registerSubCommand(SubCommand subCommand) {
      this.subCommands.put(subCommand.getName().toLowerCase(Locale.ROOT), subCommand);
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission(this.permission)) {
         sender.sendMessage(this.configManager.getNoPermissionMessage());
         return true;
      } else if (args.length == 0) {
         sender.sendMessage(this.configManager.getUsageMessage());
         return true;
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            sender.sendMessage(this.configManager.getUsageMessage());
            return true;
         } else {
            subCommand.execute(sender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.hasPermission(this.permission)) {
         return Collections.emptyList();
      }

      if (args.length == 1) {
         return this.filter(args[0], new ArrayList<>(this.subCommands.keySet()));
      }

      SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
      return subCommand == null ? Collections.emptyList() : subCommand.tabComplete(sender, args);
   }

   private List<String> filter(String input, List<String> values) {
      if (input != null && !input.isEmpty()) {
         String lower = input.toLowerCase(Locale.ROOT);
         List<String> result = new ArrayList<>(values.size());

         for (String value : values) {
            if (value.startsWith(lower)) {
               result.add(value);
            }
         }

         return result;
      } else {
         return values;
      }
   }
}
