package cs.cloudstudio.command;

import cs.cloudstudio.CloudApi;
import cs.cloudstudio.command.sub.ReloadSubCommand;

public final class AdminCommand extends BaseCommand {
   public AdminCommand(CloudApi plugin) {
      super("cloudapi.admin", plugin.getConfigManager());
      this.registerSubCommand(new ReloadSubCommand(plugin));
   }
}
