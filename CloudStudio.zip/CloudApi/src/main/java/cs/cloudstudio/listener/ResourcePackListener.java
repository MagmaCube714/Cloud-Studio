package cs.cloudstudio.listener;

import cs.cloudstudio.cache.ResourcePackCache;
import java.nio.charset.StandardCharsets;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.messaging.PluginMessageListener;

public final class ResourcePackListener implements Listener, PluginMessageListener {
   private static final String CHANNEL = "forcepack:status";
   private static final String STATUS_LOADED = "SUCCESSFULLY_LOADED";
   private final ResourcePackCache resourcePackCache;

   public ResourcePackListener(ResourcePackCache resourcePackCache) {
      this.resourcePackCache = resourcePackCache;
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onPlayerQuit(PlayerQuitEvent event) {
      this.resourcePackCache.remove(event.getPlayer().getUniqueId());
   }

   public void onPluginMessageReceived(String channel, Player player, byte[] message) {
      if ("forcepack:status".equals(channel) && player != null && message != null && message.length != 0) {
         String data = new String(message, StandardCharsets.UTF_8);
         int firstSeparator = data.indexOf(59);
         if (firstSeparator >= 0 && firstSeparator + 1 < data.length()) {
            int secondSeparator = data.indexOf(59, firstSeparator + 1);
            String status = secondSeparator < 0 ? data.substring(firstSeparator + 1) : data.substring(firstSeparator + 1, secondSeparator);
            boolean loaded = "SUCCESSFULLY_LOADED".equals(status);
            if (loaded && secondSeparator >= 0 && secondSeparator + 1 < data.length()) {
               loaded = Boolean.parseBoolean(data.substring(secondSeparator + 1));
            }

            this.resourcePackCache.setPlayerResourcePackStatus(player.getUniqueId(), loaded);
         }
      }
   }
}
