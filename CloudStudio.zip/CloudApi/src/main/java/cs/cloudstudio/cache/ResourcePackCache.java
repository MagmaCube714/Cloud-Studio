package cs.cloudstudio.cache;

import java.util.Collections;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;

public final class ResourcePackCache {
   private final Set<UUID> loadedPlayers = Collections.newSetFromMap(new ConcurrentHashMap<>(64));

   public boolean hasResourcePack(Player player) {
      return player != null && this.loadedPlayers.contains(player.getUniqueId());
   }

   public void setPlayerResourcePackStatus(UUID uuid, boolean loaded) {
      if (uuid != null) {
         if (loaded) {
            this.loadedPlayers.add(uuid);
         } else {
            this.loadedPlayers.remove(uuid);
         }
      }
   }

   public void remove(UUID uuid) {
      if (uuid != null) {
         this.loadedPlayers.remove(uuid);
      }
   }

   public void clear() {
      this.loadedPlayers.clear();
   }
}
