package cs.cloudstudio.cache;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public final class PrefixCache {
   private final Map<String, String> cache;

   public PrefixCache(final int maximumSize) {
      this.cache = new LinkedHashMap<String, String>(128, 0.75F, true) {
         @Override
         protected boolean removeEldestEntry(Entry<String, String> eldest) {
            return this.size() > maximumSize;
         }
      };
   }

   public synchronized String get(String key) {
      return this.cache.get(key);
   }

   public synchronized void put(String key, String value) {
      this.cache.put(key, value);
   }

   public synchronized void clear() {
      this.cache.clear();
   }
}
