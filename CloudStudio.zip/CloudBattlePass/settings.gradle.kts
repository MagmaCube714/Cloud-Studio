rootProject.name = "CloudBattlePass"
