package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.command.PlayerCommand;
import cs.cloudstudio.config.ConfigCache;
import cs.cloudstudio.database.IPlayerDatabase;
import cs.cloudstudio.database.IQuestDatabase;
import cs.cloudstudio.database.impl.PlayerDatabase;
import cs.cloudstudio.database.impl.quest.QuestDatabase;
import cs.cloudstudio.listener.ActionListener;
import cs.cloudstudio.listener.InventoryClickListener;
import cs.cloudstudio.listener.PlayerJoinListener;
import cs.cloudstudio.manager.InventoryManager;
import cs.cloudstudio.manager.level.LevelConfiguration;
import cs.cloudstudio.manager.placeholder.BattlePassPlaceholder;
import cs.cloudstudio.manager.quest.QuestProgressHandler;
import cs.cloudstudio.manager.quest.enums.QuestTime;
import cs.cloudstudio.manager.quest.enums.QuestType;
import cs.cloudstudio.manager.quest.impl.BlockBreakQuest;
import cs.cloudstudio.manager.quest.impl.BlockPlaceQuest;
import cs.cloudstudio.manager.quest.impl.CraftQuest;
import cs.cloudstudio.manager.quest.impl.EatQuest;
import cs.cloudstudio.manager.quest.impl.ExperienceQuest;
import cs.cloudstudio.manager.quest.impl.KillQuest;
import cs.cloudstudio.manager.service.PlayerInitService;
import cs.cloudstudio.manager.token.TokenHandler;
import cs.cloudstudio.manager.token.impl.TokenManagerHandler;
import cs.cloudstudio.util.RandomizeUtil;
import cs.cloudstudio.util.TimeUtil;
import java.io.File;
import java.util.Collection;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudBattlePass extends JavaPlugin {
   private static volatile CloudBattlePass INSTANCE;
   private IPlayerDatabase playerDataBase;
   private IQuestDatabase questDatabase;
   private InventoryManager inventoryManager;
   private TokenHandler handler;
   private BattlePassPlaceholder placeHolder;
   private volatile boolean initialized;

   public void onEnable() {
      INSTANCE = this;

      try {
         this.saveDefaultConfig();
         this.saveResourceIfMissing("admin.yml");
         this.saveResourceIfMissing("levels.yml");
         if (!this.initTokenHandler()) {
            return;
         }

         this.initDatabases();
         this.loadManagers();
         this.reloadRuntimeConfiguration();
         this.registerCommands();
         this.registerListeners();
         this.registerPlaceholder();
         this.initialized = true;
         this.scheduleAsyncTasks();
         this.log("&fCloudBattlePass &aуспешно загружен!");
      } catch (Exception e) {
         this.getLogger().warning("[CloudBattlePass] Плагин не загружен: " + e.getMessage());
         Bukkit.getPluginManager().disablePlugin(this);
      }
   }

   public void onDisable() {
      this.initialized = false;
      Bukkit.getScheduler().cancelTasks(this);
      if (this.placeHolder != null) {
         try {
            this.placeHolder.unregister();
         } catch (Exception var4) {
         }
      }

      if (this.playerDataBase != null) {
         try {
            this.playerDataBase.disconnect();
         } catch (Exception var3) {
         }
      }

      if (this.questDatabase != null) {
         try {
            this.questDatabase.disconnect();
         } catch (Exception var2) {
         }
      }

      this.log("&fCloudBattlePass &cуспешно выгружен!");
   }

   private boolean initTokenHandler() {
      if (Bukkit.getPluginManager().isPluginEnabled("TokenManager")) {
         this.handler = new TokenManagerHandler();
         return true;
      } else {
         this.log("&fCloudBattlePass &cTokenManager не найден, плагин отключён");
         Bukkit.getPluginManager().disablePlugin(this);
         return false;
      }
   }

   private void initDatabases() {
      this.playerDataBase = new PlayerDatabase();
      this.questDatabase = new QuestDatabase();
      this.playerDataBase.connect();
      this.questDatabase.connect();
   }

   private void loadManagers() {
      this.inventoryManager = new InventoryManager();
      this.inventoryManager.load();
   }

   private void registerCommands() {
      AdminCommand adminCommand = new AdminCommand(this);
      adminCommand.register();
      PlayerCommand playerCommand = new PlayerCommand(this);
      playerCommand.register();
   }

   private void registerListeners() {
      QuestProgressHandler questHandler = new QuestProgressHandler();
      Bukkit.getPluginManager().registerEvents(new InventoryClickListener(), this);
      Bukkit.getPluginManager().registerEvents(new PlayerJoinListener(), this);
      Bukkit.getPluginManager()
         .registerEvents(
            new ActionListener(
               new BlockBreakQuest(), new BlockPlaceQuest(), new CraftQuest(), new KillQuest(), new EatQuest(), new ExperienceQuest(), questHandler
            ),
            this
         );
   }

   private void registerPlaceholder() {
      if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
         this.placeHolder = new BattlePassPlaceholder(this);
         this.placeHolder.register();
      }
   }

   private void scheduleAsyncTasks() {
      this.scheduleDailyQuestClear(TimeUtil.calculateTimeToNextDay() * 20L);
      this.scheduleWeeklyQuestClear(TimeUtil.calculateTimeToMonday() * 20L);
      this.initOnlinePlayers();
   }

   private void scheduleDailyQuestClear(long delay) {
      Bukkit.getScheduler().runTaskLaterAsynchronously(this, () -> {
         if (this.initialized) {
            this.questDatabase.clearSync(QuestTime.DAY);
            Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
               if (this.initialized) {
                  this.questDatabase.clearSync(QuestTime.DAY);
               }
            }, 1728000L, 1728000L);
         }
      }, Math.max(1L, delay));
   }

   private void scheduleWeeklyQuestClear(long delay) {
      Bukkit.getScheduler().runTaskLaterAsynchronously(this, () -> {
         if (this.initialized) {
            this.questDatabase.clearSync(QuestTime.WEEK);
            Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
               if (this.initialized) {
                  this.questDatabase.clearSync(QuestTime.WEEK);
               }
            }, 12096000L, 12096000L);
         }
      }, Math.max(1L, delay));
   }

   private void initOnlinePlayers() {
      Bukkit.getScheduler().runTaskLater(this, () -> {
         if (this.initialized) {
            Collection<? extends Player> onlinePlayers = Bukkit.getOnlinePlayers();
            String[] onlineNames = new String[onlinePlayers.size()];
            int index = 0;

            for (Player player : onlinePlayers) {
               onlineNames[index++] = player.getName();
            }

            Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
               PlayerInitService service = new PlayerInitService();

               for (String onlineName : onlineNames) {
                  service.init(onlineName);
               }
            });
         }
      }, 20L);
   }

   public void reload() {
      this.reloadConfig();
      if (this.inventoryManager != null) {
         this.inventoryManager.reloadConfig();
      }

      this.reloadRuntimeConfiguration();
      if (this.placeHolder != null) {
         this.placeHolder.invalidateTopCache();
      }
   }

   private void reloadRuntimeConfiguration() {
      ConfigCache.load();
      LevelConfiguration.reload();
      QuestType.reloadAll();
      RandomizeUtil.reload();
   }

   private void saveResourceIfMissing(String name) {
      File file = new File(this.getDataFolder(), name);
      if (!file.exists()) {
         this.saveResource(name, false);
      }
   }

   private void log(String message) {
      Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', message));
   }

   public IPlayerDatabase getPlayerDataBase() {
      return this.playerDataBase;
   }

   public IQuestDatabase getQuestDatabase() {
      return this.questDatabase;
   }

   public InventoryManager getInventoryManager() {
      return this.inventoryManager;
   }

   public TokenHandler getHandler() {
      return this.handler;
   }

   public BattlePassPlaceholder getPlaceHolder() {
      return this.placeHolder;
   }

   public static CloudBattlePass getInstance() {
      return INSTANCE;
   }

   public boolean isInitialized() {
      return this.initialized;
   }
}
