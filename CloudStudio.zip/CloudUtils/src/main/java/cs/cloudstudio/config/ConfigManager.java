package cs.cloudstudio.config;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.util.ColorUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public final class ConfigManager {
   private static final char DEFAULT_KEY_SEPARATOR = '\u0000';
   private final CloudUtils plugin;
   private FileConfiguration config;
   private final Map<String, Set<String>> stringSetCache = new HashMap<>();
   private final Map<String, Set<String>> normalizedCommandSetCache = new HashMap<>();
   private final Map<String, Set<String>> normalizedRawCommandSetCache = new HashMap<>();
   private final Map<String, String> coloredStringCache = new HashMap<>();
   private final Map<String, List<String>> coloredStringListCache = new HashMap<>();
   private final Map<String, String> stringCache = new HashMap<>();
   private final Map<String, Integer> intCache = new HashMap<>();
   private final Map<String, Long> longCache = new HashMap<>();
   private final Map<String, Double> doubleCache = new HashMap<>();
   private final Map<String, Boolean> booleanCache = new HashMap<>();
   private final Map<String, List<String>> stringListCache = new HashMap<>();

   public ConfigManager(CloudUtils plugin) {
      this.plugin = plugin;
      plugin.saveDefaultConfig();
      this.config = plugin.getConfig();
   }

   public void reload() {
      this.plugin.reloadConfig();
      this.config = this.plugin.getConfig();
      this.clearCaches();
   }

   public FileConfiguration getConfig() {
      return this.config;
   }

   public ConfigurationSection getSection(String path) {
      return this.config.getConfigurationSection(path);
   }

   public boolean contains(String path) {
      return this.config.contains(path);
   }

   public int getInt(String path) {
      Integer cached = this.intCache.get(path);
      if (cached != null) {
         return cached;
      }

      int value = this.config.getInt(path);
      this.intCache.put(path, value);
      return value;
   }

   public int getInt(String path, int def) {
      String key = defaultKey(path, def);
      Integer cached = this.intCache.get(key);
      if (cached != null) {
         return cached;
      }

      int value = this.config.getInt(path, def);
      this.intCache.put(key, value);
      return value;
   }

   public long getLong(String path) {
      Long cached = this.longCache.get(path);
      if (cached != null) {
         return cached;
      }

      long value = this.config.getLong(path);
      this.longCache.put(path, value);
      return value;
   }

   public long getLong(String path, long def) {
      String key = defaultKey(path, def);
      Long cached = this.longCache.get(key);
      if (cached != null) {
         return cached;
      }

      long value = this.config.getLong(path, def);
      this.longCache.put(key, value);
      return value;
   }

   public double getDouble(String path) {
      Double cached = this.doubleCache.get(path);
      if (cached != null) {
         return cached;
      }

      double value = this.config.getDouble(path);
      this.doubleCache.put(path, value);
      return value;
   }

   public double getDouble(String path, double def) {
      String key = defaultKey(path, def);
      Double cached = this.doubleCache.get(key);
      if (cached != null) {
         return cached;
      }

      double value = this.config.getDouble(path, def);
      this.doubleCache.put(key, value);
      return value;
   }

   public boolean getBoolean(String path) {
      Boolean cached = this.booleanCache.get(path);
      if (cached != null) {
         return cached;
      }

      boolean value = this.config.getBoolean(path);
      this.booleanCache.put(path, value);
      return value;
   }

   public boolean getBoolean(String path, boolean def) {
      String key = defaultKey(path, def);
      Boolean cached = this.booleanCache.get(key);
      if (cached != null) {
         return cached;
      }

      boolean value = this.config.getBoolean(path, def);
      this.booleanCache.put(key, value);
      return value;
   }

   public String getString(String path) {
      String cached = this.stringCache.get(path);
      if (cached != null) {
         return cached;
      }

      String value = this.config.getString(path, "");
      if (value == null) {
         value = "";
      }

      this.stringCache.put(path, value);
      return value;
   }

   public String getString(String path, String def) {
      String key = defaultKey(path, def == null ? "" : def);
      String cached = this.stringCache.get(key);
      if (cached != null) {
         return cached;
      }

      String value = this.config.getString(path, def);
      if (value == null) {
         value = def == null ? "" : def;
      }

      this.stringCache.put(key, value);
      return value;
   }

   public List<String> getStringList(String path) {
      List<String> cached = this.stringListCache.get(path);
      if (cached != null) {
         return cached;
      }

      List<String> built = Collections.unmodifiableList(new ArrayList<>(this.config.getStringList(path)));
      this.stringListCache.put(path, built);
      return built;
   }

   public Set<String> getStringSet(String path) {
      Set<String> cached = this.stringSetCache.get(path);
      if (cached != null) {
         return cached;
      }

      Set<String> built = Collections.unmodifiableSet(new HashSet<>(this.config.getStringList(path)));
      this.stringSetCache.put(path, built);
      return built;
   }

   public Set<String> getNormalizedCommandSet(String path) {
      Set<String> cached = this.normalizedCommandSetCache.get(path);
      if (cached != null) {
         return cached;
      }

      Set<String> commands = new HashSet<>();

      for (String command : this.config.getStringList(path)) {
         String normalized = normalizeCommand(command);
         if (!normalized.isEmpty()) {
            commands.add(normalized);
         }
      }

      Set<String> built = Collections.unmodifiableSet(commands);
      this.normalizedCommandSetCache.put(path, built);
      return built;
   }

   public Set<String> getNormalizedRawCommandSet(String path) {
      Set<String> cached = this.normalizedRawCommandSetCache.get(path);
      if (cached != null) {
         return cached;
      }

      Set<String> commands = new HashSet<>();

      for (String command : this.config.getStringList(path)) {
         String normalized = normalizeRawCommand(command);
         if (!normalized.isEmpty()) {
            commands.add(normalized);
         }
      }

      Set<String> built = Collections.unmodifiableSet(commands);
      this.normalizedRawCommandSetCache.put(path, built);
      return built;
   }

   public String getColoredString(String path) {
      String cached = this.coloredStringCache.get(path);
      if (cached != null) {
         return cached;
      }

      String built = this.color(this.getString(path));
      this.coloredStringCache.put(path, built);
      return built;
   }

   public List<String> getColoredStringList(String path) {
      List<String> cached = this.coloredStringListCache.get(path);
      if (cached != null) {
         return cached;
      }

      List<String> built = this.colorList(this.config.getStringList(path));
      this.coloredStringListCache.put(path, built);
      return built;
   }

   public String color(String text) {
      return ColorUtil.colorize(text);
   }

   public List<String> colorList(List<String> source) {
      if (source != null && !source.isEmpty()) {
         List<String> list = new ArrayList<>(source.size());

         for (String line : source) {
            String colored = this.color(line);
            if (!colored.isEmpty()) {
               list.add(colored);
            } else {
               list.add("");
            }
         }

         return Collections.unmodifiableList(list);
      } else {
         return Collections.emptyList();
      }
   }

   private void clearCaches() {
      this.stringSetCache.clear();
      this.normalizedCommandSetCache.clear();
      this.normalizedRawCommandSetCache.clear();
      this.coloredStringCache.clear();
      this.coloredStringListCache.clear();
      this.stringCache.clear();
      this.intCache.clear();
      this.longCache.clear();
      this.doubleCache.clear();
      this.booleanCache.clear();
      this.stringListCache.clear();
   }

   private static String defaultKey(String path, Object def) {
      return path + "\u0000" + def;
   }

   public static String normalizeCommand(String command) {
      if (command == null) {
         return "";
      }

      int start = 0;
      int end = command.length();

      while (start < end && command.charAt(start) <= ' ') {
         start++;
      }

      while (end > start && command.charAt(end - 1) <= ' ') {
         end--;
      }

      while (start < end && command.charAt(start) == '/') {
         start++;
      }

      int space = start;

      while (space < end && command.charAt(space) > ' ') {
         space++;
      }

      if (space <= start) {
         return "";
      }

      String label = command.substring(start, space);
      int namespace = label.indexOf(58);
      if (namespace >= 0 && namespace + 1 < label.length()) {
         label = label.substring(namespace + 1);
      }

      return label.toLowerCase(Locale.ROOT);
   }

   public static String normalizeRawCommand(String command) {
      if (command == null) {
         return "";
      }

      int start = 0;
      int end = command.length();

      while (start < end && command.charAt(start) <= ' ') {
         start++;
      }

      while (end > start && command.charAt(end - 1) <= ' ') {
         end--;
      }

      int space = start;

      while (space < end && command.charAt(space) > ' ') {
         space++;
      }

      return space <= start ? "" : command.substring(start, space).toLowerCase(Locale.ROOT);
   }
}
