package cs.cloudstudio.manager;

import cs.cloudstudio.CloudUtils;
import de.maxhenkel.voicechat.api.BukkitVoicechatService;
import de.maxhenkel.voicechat.api.ServerPlayer;
import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;
import de.maxhenkel.voicechat.api.events.PlayerConnectedEvent;
import de.maxhenkel.voicechat.api.events.PlayerDisconnectedEvent;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import litebans.api.Database;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.ServerCommandEvent;

public final class VoiceMuteManager implements Listener {
   private static final long COMMAND_RECHECK_DELAY_TICKS = 20L;
   private static final int DEFAULT_VOICE_MAX_PACKETS_PER_SECOND = 90;
   private static final int DEFAULT_VOICE_BURST_PACKETS = 140;
   private static final long DEFAULT_VOICE_BLOCK_MILLIS = 3000L;
   private static final long DEFAULT_VOICE_LOG_COOLDOWN_MILLIS = 10000L;
   private final CloudUtils plugin;
   private final Set<UUID> mutedPlayers = ConcurrentHashMap.newKeySet();
   private final Set<UUID> pendingChecks = ConcurrentHashMap.newKeySet();
   private final Map<UUID, VoicechatConnection> voiceConnections = new ConcurrentHashMap<>();
   private final Map<UUID, VoiceMuteManager.VoicePacketRateState> voicePacketStates = new ConcurrentHashMap<>();
   private volatile Database liteBansDatabase;
   private volatile boolean liteBansAvailable;
   private volatile boolean voiceHookEnabled;
   private volatile boolean voiceExploitProtectionEnabled;
   private volatile int voiceMaxPacketsPerSecond;
   private volatile int voiceBurstPackets;
   private volatile long voiceBlockMillis;
   private volatile boolean voiceExploitLogEnabled;
   private volatile long voiceExploitLogCooldownMillis;

   public VoiceMuteManager(CloudUtils plugin) {
      this.plugin = plugin;
   }

   public void enable() {
      this.reload();
      this.setupLiteBans();
      this.setupVoiceChat();

      for (Player player : Bukkit.getOnlinePlayers()) {
         this.checkPlayerAsync(player.getUniqueId());
      }
   }

   public void reload() {
      this.voiceHookEnabled = this.plugin.getConfigManager().getBoolean("voice.mute-sync.enabled", false);
      this.voiceExploitProtectionEnabled = this.plugin.getConfigManager().getBoolean("voice.exploit-protection.enabled", true);
      this.voiceMaxPacketsPerSecond = clamp(this.plugin.getConfigManager().getInt("voice.exploit-protection.max-packets-per-second", 90), 1, 10000);
      this.voiceBurstPackets = clamp(this.plugin.getConfigManager().getInt("voice.exploit-protection.burst-packets", 140), 1, 50000);
      this.voiceBlockMillis = clamp(this.plugin.getConfigManager().getLong("voice.exploit-protection.block-ms", 3000L), 0L, 60000L);
      this.voiceExploitLogEnabled = this.plugin.getConfigManager().getBoolean("voice.exploit-protection.log", true);
      this.voiceExploitLogCooldownMillis = clamp(this.plugin.getConfigManager().getLong("voice.exploit-protection.log-cooldown-ms", 10000L), 1000L, 300000L);
      this.voicePacketStates.clear();
   }

   public void disable() {
      this.voiceConnections.clear();
      this.voicePacketStates.clear();
      this.mutedPlayers.clear();
      this.pendingChecks.clear();
      this.liteBansDatabase = null;
      this.liteBansAvailable = false;
   }

   private void setupLiteBans() {
      try {
         this.liteBansDatabase = Database.get();
         this.liteBansAvailable = this.liteBansDatabase != null;
      } catch (Throwable ignored) {
         this.liteBansDatabase = null;
         this.liteBansAvailable = false;
      }
   }

   private void setupVoiceChat() {
      try {
         BukkitVoicechatService service = (BukkitVoicechatService)Bukkit.getServicesManager().load(BukkitVoicechatService.class);
         if (service != null) {
            service.registerPlugin(new VoiceMuteManager.VoiceChatHook());
         }
      } catch (Throwable var2) {
      }
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      this.checkPlayerAsync(event.getPlayer().getUniqueId());
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
      this.scheduleMuteCommandRecheck(event.getMessage());
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onServerCommand(ServerCommandEvent event) {
      this.scheduleMuteCommandRecheck(event.getCommand());
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      UUID uuid = event.getPlayer().getUniqueId();
      this.voiceConnections.remove(uuid);
      this.voicePacketStates.remove(uuid);
      this.pendingChecks.remove(uuid);
      this.mutedPlayers.remove(uuid);
   }

   public void checkPlayerAsync(final UUID uuid) {
      if (this.plugin.isEnabled() && this.liteBansAvailable && uuid != null && this.pendingChecks.add(uuid)) {
         Bukkit.getScheduler().runTaskAsynchronously(this.plugin, new Runnable() {
            @Override
            public void run() {
               try {
                  VoiceMuteManager.this.setCachedMuteState(uuid, VoiceMuteManager.this.isPlayerMuted(uuid));
               } finally {
                  VoiceMuteManager.this.pendingChecks.remove(uuid);
               }
            }
         });
      }
   }

   private void setCachedMuteState(UUID uuid, boolean muted) {
      if (uuid != null) {
         if (muted) {
            this.mutedPlayers.add(uuid);
         } else {
            this.mutedPlayers.remove(uuid);
         }
      }
   }

   private void scheduleMuteCommandRecheck(String rawCommand) {
      String targetName = this.getLiteBansMuteCommandTarget(rawCommand);
      if (targetName != null) {
         this.scheduleCommandRecheck(targetName);
      }
   }

   private String getLiteBansMuteCommandTarget(String rawCommand) {
      if (rawCommand == null) {
         return null;
      }

      int length = rawCommand.length();
      int index = 0;

      while (index < length && rawCommand.charAt(index) <= ' ') {
         index++;
      }

      while (index < length && rawCommand.charAt(index) == '/') {
         index++;
      }

      while (index < length && rawCommand.charAt(index) <= ' ') {
         index++;
      }

      if (index >= length) {
         return null;
      }

      int labelStart = index;

      while (index < length && rawCommand.charAt(index) > ' ') {
         index++;
      }

      String label = rawCommand.substring(labelStart, index).toLowerCase(Locale.ROOT);
      int namespace = label.indexOf(58);
      if (namespace >= 0) {
         label = label.substring(namespace + 1);
      }

      if (!this.isLiteBansMuteCommand(label)) {
         return null;
      }

      while (index < length) {
         while (index < length && rawCommand.charAt(index) <= ' ') {
            index++;
         }

         if (index >= length) {
            return null;
         }

         int argStart = index;

         while (index < length && rawCommand.charAt(index) > ' ') {
            index++;
         }

         if (rawCommand.charAt(argStart) != '-') {
            return rawCommand.substring(argStart, index);
         }
      }

      return null;
   }

   private boolean isLiteBansMuteCommand(String label) {
      return "mute".equals(label) || "tempmute".equals(label) || "ipmute".equals(label) || "tempipmute".equals(label) || "unmute".equals(label);
   }

   private void scheduleCommandRecheck(String playerName) {
      UUID uuid = this.resolvePlayerUuid(playerName);
      if (uuid != null) {
         this.scheduleMuteStateRefresh(uuid, 20L);
      }
   }

   private void scheduleMuteStateRefresh(final UUID uuid, long delayTicks) {
      if (uuid != null && this.plugin.isEnabled()) {
         Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
            @Override
            public void run() {
               VoiceMuteManager.this.checkPlayerAsync(uuid);
            }
         }, Math.max(1L, delayTicks));
      }
   }

   private UUID resolvePlayerUuid(String playerName) {
      if (playerName != null && !playerName.trim().isEmpty()) {
         Player online = Bukkit.getPlayerExact(playerName);
         if (online != null) {
            return online.getUniqueId();
         }

         OfflinePlayer offline = Bukkit.getOfflinePlayer(playerName);
         return offline != null && (offline.hasPlayedBefore() || offline.getName() != null) ? offline.getUniqueId() : null;
      } else {
         return null;
      }
   }

   private boolean isPlayerMuted(UUID uuid) {
      Database database = this.liteBansDatabase;
      if (this.liteBansAvailable && database != null) {
         try {
            return database.isPlayerMuted(uuid, null);
         } catch (Throwable ignored) {
            return false;
         }
      } else {
         return false;
      }
   }

   private void onMicrophonePacket(MicrophonePacketEvent event) {
      VoicechatConnection connection = event.getSenderConnection();
      UUID uuid = this.getConnectionUuid(connection);
      if (uuid != null) {
         this.voiceConnections.put(uuid, connection);
         if (this.shouldCancelExcessiveVoicePacket(uuid)) {
            event.cancel();
         } else {
            if (this.mutedPlayers.contains(uuid)) {
               event.cancel();
            }
         }
      }
   }

   private void onPlayerConnected(PlayerConnectedEvent event) {
      VoicechatConnection connection = event.getConnection();
      UUID uuid = this.getConnectionUuid(connection);
      if (uuid != null) {
         this.voiceConnections.put(uuid, connection);
         this.checkPlayerAsync(uuid);
      }
   }

   private void onPlayerDisconnected(PlayerDisconnectedEvent event) {
      UUID uuid = event.getPlayerUuid();
      if (uuid != null) {
         this.voiceConnections.remove(uuid);
         this.voicePacketStates.remove(uuid);
      }
   }

   private UUID getConnectionUuid(VoicechatConnection connection) {
      if (connection == null) {
         return null;
      }

      try {
         ServerPlayer player = connection.getPlayer();
         return player == null ? null : player.getUuid();
      } catch (Throwable ignored) {
         return null;
      }
   }

   public boolean isMuted(OfflinePlayer player) {
      return player != null && this.mutedPlayers.contains(player.getUniqueId());
   }

   private boolean shouldCancelExcessiveVoicePacket(UUID uuid) {
      if (this.voiceExploitProtectionEnabled && uuid != null) {
         long now = System.currentTimeMillis();
         VoiceMuteManager.VoicePacketRateState state = this.voicePacketStates
            .computeIfAbsent(uuid, ignored -> new VoiceMuteManager.VoicePacketRateState(now, this.voiceBurstPackets));
         synchronized (state) {
            this.refillVoiceTokens(state, now);
            if (state.blockedUntil > now) {
               this.logVoiceRateLimit(uuid, state, now);
               return true;
            } else if (state.tokens >= 1.0) {
               state.tokens--;
               return false;
            } else {
               state.blockedUntil = now + this.voiceBlockMillis;
               this.logVoiceRateLimit(uuid, state, now);
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private void refillVoiceTokens(VoiceMuteManager.VoicePacketRateState state, long now) {
      long elapsed = now - state.lastRefillAt;
      if (elapsed > 0L) {
         double refill = (double)elapsed * this.voiceMaxPacketsPerSecond / 1000.0;
         state.tokens = Math.min(this.voiceBurstPackets, state.tokens + refill);
         state.lastRefillAt = now;
      }
   }

   private void logVoiceRateLimit(UUID uuid, VoiceMuteManager.VoicePacketRateState state, long now) {
      if (this.voiceExploitLogEnabled && now - state.lastLogAt >= this.voiceExploitLogCooldownMillis) {
         state.lastLogAt = now;
         Player player = Bukkit.getPlayer(uuid);
         String name = player == null ? uuid.toString() : player.getName();
         this.plugin
            .getLogger()
            .warning("VoiceChat packet flood blocked for " + name + " (limit " + this.voiceMaxPacketsPerSecond + "/s, burst " + this.voiceBurstPackets + ")");
      }
   }

   private static int clamp(int value, int min, int max) {
      return Math.max(min, Math.min(max, value));
   }

   private static long clamp(long value, long min, long max) {
      return Math.max(min, Math.min(max, value));
   }

   private final class VoiceChatHook implements VoicechatPlugin {
      public String getPluginId() {
         return "cloudutils";
      }

      public void initialize(VoicechatApi api) {
      }

      public void registerEvents(EventRegistration registration) {
         registration.registerEvent(MicrophonePacketEvent.class, VoiceMuteManager.this::onMicrophonePacket);
         registration.registerEvent(PlayerConnectedEvent.class, VoiceMuteManager.this::onPlayerConnected);
         registration.registerEvent(PlayerDisconnectedEvent.class, VoiceMuteManager.this::onPlayerDisconnected);
      }
   }

   private static final class VoicePacketRateState {
      private long lastRefillAt;
      private double tokens;
      private long blockedUntil;
      private long lastLogAt;

      private VoicePacketRateState(long now, int burstPackets) {
         this.lastRefillAt = now;
         this.tokens = Math.max(0.0, burstPackets);
      }
   }
}
