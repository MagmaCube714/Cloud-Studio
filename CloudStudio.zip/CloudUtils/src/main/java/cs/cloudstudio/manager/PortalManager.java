package cs.cloudstudio.manager;

import cs.cloudstudio.CloudUtils;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public final class PortalManager {
   private final CloudUtils plugin;
   private final Map<String, PortalManager.PortalData> portals = new HashMap<>();

   public PortalManager(CloudUtils plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.portals.clear();
      ConfigurationSection portalsSection = this.plugin.getConfigManager().getSection("portals");
      if (portalsSection != null) {
         for (String portalId : portalsSection.getKeys(false)) {
            if (!"settings".equalsIgnoreCase(portalId)) {
               ConfigurationSection portalSection = portalsSection.getConfigurationSection(portalId);
               if (portalSection != null) {
                  this.loadPortal(portalSection);
               }
            }
         }
      }
   }

   private void loadPortal(ConfigurationSection portalSection) {
      String region = portalSection.getString("region", "");
      if (!region.isEmpty()) {
         String command = portalSection.getString("command", "").trim();
         if (!command.isEmpty()) {
            this.portals.put(region, new PortalManager.PortalData(command, null, 0.0, 0.0, 0.0, 0.0F, 0.0F));
         } else {
            String worldName = portalSection.getString("world", "").trim();
            if (!worldName.isEmpty()) {
               this.portals
                  .put(
                     region,
                     new PortalManager.PortalData(
                        null,
                        worldName,
                        portalSection.getDouble("x"),
                        portalSection.getDouble("y"),
                        portalSection.getDouble("z"),
                        (float)portalSection.getDouble("yaw"),
                        (float)portalSection.getDouble("pitch")
                     )
                  );
            }
         }
      }
   }

   public void handlePortalEnter(Player player, String regionName) {
      PortalManager.PortalData data = this.portals.get(regionName);
      if (data != null) {
         if (data.command != null) {
            player.performCommand(data.command);
         } else if (data.worldName != null && !data.worldName.isEmpty()) {
            World world = Bukkit.getWorld(data.worldName);
            if (world != null) {
               player.teleport(new Location(world, data.x, data.y, data.z, data.yaw, data.pitch));
            }
         }
      }
   }

   public boolean hasPortal(String regionName) {
      return this.portals.containsKey(regionName);
   }

   public boolean hasAnyPortals() {
      return !this.portals.isEmpty();
   }

   private static final class PortalData {
      private final String command;
      private final String worldName;
      private final double x;
      private final double y;
      private final double z;
      private final float yaw;
      private final float pitch;

      private PortalData(String command, String worldName, double x, double y, double z, float yaw, float pitch) {
         this.command = command;
         this.worldName = worldName;
         this.x = x;
         this.y = y;
         this.z = z;
         this.yaw = yaw;
         this.pitch = pitch;
      }
   }
}
