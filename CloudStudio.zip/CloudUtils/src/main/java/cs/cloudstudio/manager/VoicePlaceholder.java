package cs.cloudstudio.manager;

import cs.cloudstudio.CloudUtils;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

public final class VoicePlaceholder extends PlaceholderExpansion {
   private final CloudUtils plugin;

   public VoicePlaceholder(CloudUtils plugin) {
      this.plugin = plugin;
   }

   public String getIdentifier() {
      return "cloudutils";
   }

   public String getAuthor() {
      return "cloudutils";
   }

   public String getVersion() {
      return "1";
   }

   public boolean persist() {
      return true;
   }

   public String onRequest(OfflinePlayer player, String params) {
      if (player == null || params == null) {
         return "";
      } else if (params.equalsIgnoreCase("voicechat_disabled")) {
         return this.plugin.getVoiceMuteManager().isMuted(player) ? "disabled" : "";
      } else if (params.equalsIgnoreCase("voice_muted")) {
         return this.plugin.getVoiceMuteManager().isMuted(player) ? "true" : "false";
      } else if (params.equalsIgnoreCase("voice_status")) {
         return this.plugin.getVoiceMuteManager().isMuted(player) ? "disabled" : "active";
      } else {
         return "";
      }
   }
}
