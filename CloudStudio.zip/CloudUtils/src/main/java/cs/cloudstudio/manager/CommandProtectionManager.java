package cs.cloudstudio.manager;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.ExploitPayloadUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.event.EventSubscription;
import net.luckperms.api.event.user.UserDataRecalculateEvent;
import net.luckperms.api.model.user.User;
import net.milkbowl.vault.permission.Permission;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class CommandProtectionManager {
   private static final String BYPASS_PERMISSION = "cloudutils.commandwhitelist.bypass";
   private static final String DEFAULT_GROUP_NAME = "default";
   private static final String GROUP_PERMISSION_PREFIX = "cloudutils.commandwhitelist.group.";
   private static final String LUCKPERMS_GROUP_PERMISSION_PREFIX = "group.";
   private static final long CACHE_MILLIS = 300000L;
   private static final long VAULT_LOOKUP_RETRY_MILLIS = 5000L;
   private static final String SPEC_COMMAND_LABEL = "spec";
   private final CloudUtils plugin;
   private final File file;
   private final Map<UUID, CommandProtectionManager.CachedAccess> accessCache = new ConcurrentHashMap<>();
   private static volatile String[] lastNormalized;
   private final Map<String, Boolean> unsafeCompletionCache = new ConcurrentHashMap<>();
   private EventSubscription<UserDataRecalculateEvent> permissionSubscription;
   private FileConfiguration config;
   private boolean enabled;
   private String commandDeniedMessage;
   private String blockedCommandMessage;
   private Set<String> blockedCommands = Collections.emptySet();
   private Map<String, List<String>> blockedCommandsByLabel = Collections.emptyMap();
   private Set<String> configuredCommandLabels = Collections.emptySet();
   private List<String> configuredRootCompletions = Collections.emptyList();
   private List<CommandProtectionManager.Group> groups = Collections.emptyList();
   private volatile CommandProtectionManager.VaultPermissionBridge vaultPermissionBridge;
   private volatile CommandProtectionManager.LuckPermsBridge luckPermsBridge;
   private long lastVaultLookup;
   private long lastLuckPermsLookup;

   public CommandProtectionManager(CloudUtils plugin) {
      this.plugin = plugin;
      this.file = new File(plugin.getDataFolder(), "commands.yml");
      if (!this.file.exists()) {
         plugin.saveResource("commands.yml", false);
      }

      this.reload();
      this.subscribePermissionChanges();
   }

   private void subscribePermissionChanges() {
      if (this.plugin.getServer().getPluginManager().isPluginEnabled("LuckPerms")) {
         try {
            this.permissionSubscription = LuckPermsProvider.get()
               .getEventBus()
               .subscribe(this.plugin, UserDataRecalculateEvent.class, event -> this.accessCache.remove(event.getUser().getUniqueId()));
         } catch (IllegalStateException | NoClassDefFoundError exception) {
            this.plugin.getLogger().warning("LuckPerms недоступен: права на команды обновляются раз в 5 минут");
         }
      }
   }

   public void reload() {
      this.config = YamlConfiguration.loadConfiguration(this.file);
      this.enabled = this.config.getBoolean("enabled", true);
      this.commandDeniedMessage = ColorUtil.colorize(
         this.firstMessage("messages.not-whitelisted", "messages.command-denied", "&6ReallyWorld &7» &fКоманда не найдена")
      );
      this.blockedCommandMessage = ColorUtil.colorize(
         this.firstMessage(
            "messages.blocked-command", "messages.blocked", "&6ReallyWorld &7» &cКоманда запрещена. При повторной попытке вы будете временно заблокированы."
         )
      );
      this.blockedCommands = this.loadCommandLines(readStringList(this.config, "blocked-commands"));
      this.blockedCommandsByLabel = indexCommandLines(this.blockedCommands);
      this.groups = this.loadGroups();
      this.configuredCommandLabels = this.loadConfiguredCommandLabels(this.groups);
      this.configuredRootCompletions = this.configuredCommandLabels.isEmpty()
         ? Collections.emptyList()
         : Collections.unmodifiableList(new ArrayList<>(this.configuredCommandLabels));
      this.vaultPermissionBridge = null;
      this.luckPermsBridge = null;
      this.lastVaultLookup = 0L;
      this.lastLuckPermsLookup = 0L;
      this.accessCache.clear();
      this.unsafeCompletionCache.clear();
   }

   public boolean isUnsafeCompletion(String command) {
      if (command == null) {
         return true;
      }

      Boolean cached = this.unsafeCompletionCache.get(command);
      if (cached != null) {
         return cached;
      }

      boolean unsafe = ExploitPayloadUtil.isNamespacedCommandSuggestion(command)
         || ExploitPayloadUtil.isPluginListCommand(command)
         || this.isBlockedOrNamespacedCommandLine(command);
      if (this.unsafeCompletionCache.size() >= 8192) {
         this.unsafeCompletionCache.clear();
      }

      this.unsafeCompletionCache.put(command, unsafe);
      return unsafe;
   }

   private String firstMessage(String primaryPath, String legacyPath, String fallback) {
      String value = this.config.getString(primaryPath);
      if (value != null) {
         return value;
      }

      value = this.config.getString(legacyPath);
      return value == null ? fallback : value;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public boolean hasBypass(Player player) {
      return player.hasPermission("cloudutils.commandwhitelist.bypass");
   }

   public String getCommandDeniedMessage(String command) {
      return applyPlaceholders(this.commandDeniedMessage, command);
   }

   public String getBlockedCommandMessage(String command) {
      return applyPlaceholders(this.blockedCommandMessage, command);
   }

   public CommandProtectionManager.CommandAccess getAccess(Player player) {
      long now = System.currentTimeMillis();
      CommandProtectionManager.CachedAccess cached = this.accessCache.get(player.getUniqueId());
      if (cached != null && now - cached.createdAt <= CACHE_MILLIS) {
         return cached.access;
      }

      CommandProtectionManager.CommandAccess built = this.buildAccess(player);
      this.accessCache.put(player.getUniqueId(), new CommandProtectionManager.CachedAccess(now, built));
      return built;
   }

   public void clearAccess(UUID uuid) {
      this.accessCache.remove(uuid);
   }

   public void clearPlayer(UUID uuid) {
      this.accessCache.remove(uuid);
   }

   public void clearCache() {
      this.accessCache.clear();
   }

   public void refreshOnlineCommands() {
      try {
         for (Player player : this.plugin.getServer().getOnlinePlayers()) {
            player.updateCommands();
         }
      } catch (NoSuchMethodError var3) {
      }
   }

   public boolean isCommandAllowed(CommandProtectionManager.CommandAccess access, String commandLine) {
      String normalized = normalizeCommandLine(commandLine);
      if (normalized.isEmpty()) {
         return true;
      }

      if (!hasNamespacedLabel(normalized) && !this.isBlockedNormalized(normalized)) {
         if (access.allowAll) {
            return true;
         }

         String label = firstToken(normalized);
         if ("spec".equals(label)) {
            return true;
         }

         if (!this.configuredCommandLabels.contains(label)) {
            return false;
         }

         if (access.commandLabels.contains(label)) {
            return true;
         }

         List<String> prefixes = access.commandPrefixesByLabel.get(label);
         if (prefixes == null) {
            return false;
         }

         for (String prefix : prefixes) {
            if (matchesPrefix(normalized, prefix)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean isBlockedOrNamespacedCommandLine(String commandLine) {
      String normalized = normalizeCommandLine(commandLine);
      return !normalized.isEmpty() && (hasNamespacedLabel(normalized) || this.isBlockedNormalized(normalized));
   }

   public boolean isConfiguredCommandLine(String commandLine) {
      String normalized = normalizeCommandLine(commandLine);
      return !normalized.isEmpty()
         && !hasNamespacedLabel(normalized)
         && !this.isBlockedNormalized(normalized)
         && this.configuredCommandLabels.contains(firstToken(normalized));
   }

   public boolean isBlockedCommandLine(String commandLine) {
      String normalized = normalizeCommandLine(commandLine);
      return this.isBlockedNormalized(normalized);
   }

   private boolean isBlockedNormalized(String normalized) {
      if (!normalized.isEmpty() && !this.blockedCommandsByLabel.isEmpty()) {
         List<String> candidates = this.blockedCommandsByLabel.get(firstToken(normalized));
         if (candidates == null) {
            return false;
         }

         for (String blocked : candidates) {
            if (matchesPrefix(normalized, blocked)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public boolean isRootCompletionAllowed(CommandProtectionManager.CommandAccess access, String completion) {
      String normalized = normalizeCommandLine(completion);
      if (normalized.isEmpty() || hasNamespacedLabel(normalized) || this.isBlockedNormalized(normalized)) {
         return false;
      } else if (access.allowAll) {
         return true;
      } else {
         String label = firstToken(normalized);
         if ("spec".equals(label)) {
            return true;
         } else {
            return !this.configuredCommandLabels.contains(label) ? false : access.rootCompletionLabels.contains(label);
         }
      }
   }

   public boolean isRootCompletionAllowedForBypass(String completion) {
      String normalized = normalizeCommandLine(completion);
      return !normalized.isEmpty()
         && !hasNamespacedLabel(normalized)
         && !this.isBlockedNormalized(normalized)
         && this.configuredCommandLabels.contains(firstToken(normalized));
   }

   public List<String> getRootCompletions(CommandProtectionManager.CommandAccess access, String buffer, boolean bypass) {
      String prefix = firstToken(normalizeCommandLine(buffer));
      List<String> roots = bypass ? this.configuredRootCompletions : access.rootCompletions;
      if (prefix.isEmpty()) {
         return roots;
      }

      List<String> result = new ArrayList<>();

      for (String label : roots) {
         if (label.startsWith(prefix)) {
            result.add(label);
         }
      }

      return result.isEmpty() ? Collections.emptyList() : result;
   }

   public boolean isArgumentCompletionAllowed(CommandProtectionManager.CommandAccess access, String buffer, String completion) {
      String candidate = appendCompletion(buffer, completion);
      return this.isCommandAllowed(access, candidate);
   }

   public String getLabel(String commandLine) {
      return firstToken(normalizeCommandLine(commandLine));
   }

   private CommandProtectionManager.CommandAccess buildAccess(Player player) {
      boolean allowAll = false;
      Set<String> commandLabels = new HashSet<>();
      Set<String> commandPrefixes = new HashSet<>();
      Set<String> commandPrefixLabels = new HashSet<>();
      CommandProtectionManager.PlayerGroupSnapshot groupSnapshot = null;

      for (CommandProtectionManager.Group group : this.groups) {
         if (!this.hasDirectGroupAccess(player, group)) {
            if (groupSnapshot == null) {
               groupSnapshot = this.resolvePlayerGroups(player);
            }

            if (!groupSnapshot.contains(group.name)) {
               continue;
            }
         }

         if (group.allowAll) {
            allowAll = true;
         }

         commandLabels.addAll(group.commandLabels);
         commandPrefixes.addAll(group.commandPrefixes);
         commandPrefixLabels.addAll(group.commandPrefixLabels);
      }

      commandLabels.add("spec");
      commandPrefixLabels.add("spec");
      Set<String> immutableLabels = Collections.unmodifiableSet(commandLabels);
      Set<String> rootCompletionLabels = new HashSet<>(commandLabels);
      rootCompletionLabels.addAll(commandPrefixLabels);
      Set<String> immutableRootLabels = Collections.unmodifiableSet(rootCompletionLabels);
      Map<String, List<String>> prefixesByLabel = indexCommandLines(commandPrefixes);
      List<String> roots;
      if (allowAll) {
         roots = this.configuredRootCompletions;
      } else {
         List<String> allowed = new ArrayList<>(immutableRootLabels.size());

         for (String label : this.configuredRootCompletions) {
            if (immutableLabels.contains(label) || immutableRootLabels.contains(label)) {
               allowed.add(label);
            }
         }

         roots = allowed.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(allowed);
      }

      return new CommandProtectionManager.CommandAccess(allowAll, immutableLabels, prefixesByLabel, immutableRootLabels, roots);
   }

   private List<CommandProtectionManager.Group> loadGroups() {
      ConfigurationSection section = this.config.getConfigurationSection("groups");
      if (section == null) {
         return Collections.emptyList();
      }

      List<CommandProtectionManager.Group> loaded = new ArrayList<>();

      for (String rawName : section.getKeys(false)) {
         String groupName = normalizeGroupName(rawName);
         if (!groupName.isEmpty()) {
            List<String> rawCommands;
            if (section.isList(rawName)) {
               rawCommands = readStringList(section, rawName);
            } else {
               ConfigurationSection groupSection = section.getConfigurationSection(rawName);
               if (groupSection == null) {
                  continue;
               }

               rawCommands = readStringList(groupSection, "commands");
            }

            CommandProtectionManager.LoadedCommands commands = this.parseGroupCommands(rawCommands);
            loaded.add(
               new CommandProtectionManager.Group(
                  groupName,
                  groupName.equals("default"),
                  "cloudutils.commandwhitelist.group." + groupName,
                  commands.allowAll,
                  commands.commandLabels,
                  commands.commandPrefixes,
                  commands.commandPrefixLabels
               )
            );
         }
      }

      return loaded.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(loaded);
   }

   private Set<String> loadConfiguredCommandLabels(List<CommandProtectionManager.Group> loadedGroups) {
      if (loadedGroups.isEmpty()) {
         return Collections.emptySet();
      }

      Set<String> labels = new LinkedHashSet<>();

      for (CommandProtectionManager.Group group : loadedGroups) {
         labels.addAll(group.commandLabels);
         labels.addAll(group.commandPrefixLabels);
      }

      labels.add("spec");
      return labels.isEmpty() ? Collections.emptySet() : Collections.unmodifiableSet(labels);
   }

   private CommandProtectionManager.LoadedCommands parseGroupCommands(List<String> commandList) {
      boolean allowAll = false;
      Set<String> commandLabels = new LinkedHashSet<>();
      Set<String> commandPrefixes = new LinkedHashSet<>();
      Set<String> commandPrefixLabels = new LinkedHashSet<>();

      for (String rawCommand : commandList) {
         String command = normalizeCommandLine(rawCommand);
         if (!command.isEmpty()) {
            if (command.equals("*")) {
               allowAll = true;
            } else if (!hasNamespacedLabel(command) && !ExploitPayloadUtil.isPluginListCommand(command) && !this.isBlockedNormalized(command)) {
               if (hasArguments(command)) {
                  commandPrefixes.add(command);
                  commandPrefixLabels.add(firstToken(command));
               } else {
                  commandLabels.add(command);
               }
            }
         }
      }

      return new CommandProtectionManager.LoadedCommands(
         allowAll, Collections.unmodifiableSet(commandLabels), Collections.unmodifiableSet(commandPrefixes), Collections.unmodifiableSet(commandPrefixLabels)
      );
   }

   private static List<String> readStringList(ConfigurationSection section, String path) {
      if (section != null && path != null) {
         List<?> rawValues = section.getList(path);
         if (rawValues == null) {
            return section.getStringList(path);
         }

         if (rawValues.isEmpty()) {
            return Collections.emptyList();
         }

         List<String> values = new ArrayList<>(rawValues.size());

         for (Object rawValue : rawValues) {
            String value = commandListValueToString(rawValue);
            if (value != null) {
               values.add(value);
            }
         }

         return values.isEmpty() ? Collections.emptyList() : values;
      } else {
         return Collections.emptyList();
      }
   }

   private static String commandListValueToString(Object value) {
      if (value == null) {
         return null;
      }

      if (value instanceof String) {
         return (String)value;
      }

      if (value instanceof Map<?, ?> map) {
         if (map.size() == 1) {
            Entry<?, ?> entry = map.entrySet().iterator().next();
            Object key = entry.getKey();
            Object mapValue = entry.getValue();
            if (key == null && mapValue == null) {
               return "?";
            }

            if (mapValue == null && key instanceof String) {
               return (String)key;
            }

            if (key == null && mapValue instanceof String) {
               return (String)mapValue;
            }
         }

         return null;
      } else {
         return String.valueOf(value);
      }
   }

   private Set<String> loadCommandLines(List<String> rawCommands) {
      if (rawCommands.isEmpty()) {
         return Collections.emptySet();
      }

      Set<String> loaded = new HashSet<>();

      for (String rawCommand : rawCommands) {
         String command = normalizeCommandLine(rawCommand);
         if (!command.isEmpty() && !command.equals("*")) {
            loaded.add(command);
         }
      }

      return loaded.isEmpty() ? Collections.emptySet() : Collections.unmodifiableSet(loaded);
   }

   private static Map<String, List<String>> indexCommandLines(Set<String> commandLines) {
      if (commandLines.isEmpty()) {
         return Collections.emptyMap();
      }

      Map<String, List<String>> indexed = new HashMap<>();

      for (String commandLine : commandLines) {
         indexed.computeIfAbsent(firstToken(commandLine), ignored -> new ArrayList<>()).add(commandLine);
      }

      for (Entry<String, List<String>> entry : indexed.entrySet()) {
         entry.setValue(Collections.unmodifiableList(entry.getValue()));
      }

      return Collections.unmodifiableMap(indexed);
   }

   private boolean hasDirectGroupAccess(Player player, CommandProtectionManager.Group group) {
      if (group.defaultGroup) {
         return true;
      } else {
         return player.hasPermission(group.permission) ? true : player.hasPermission("group." + group.name);
      }
   }

   private CommandProtectionManager.PlayerGroupSnapshot resolvePlayerGroups(Player player) {
      CommandProtectionManager.VaultPermissionBridge bridge = this.getVaultPermissionBridge();
      Set<String> playerGroups = new HashSet<>();
      String world = worldName(player);
      this.addLuckPermsGroups(playerGroups, player);
      if (bridge != null) {
         addGroupName(playerGroups, bridge.getPrimaryGroup(world, player));
         addGroupNames(playerGroups, bridge.getPlayerGroups(world, player));

         for (CommandProtectionManager.Group group : this.groups) {
            if (!playerGroups.contains(group.name) && bridge.playerInGroup(world, player, group.name)) {
               playerGroups.add(group.name);
            }
         }
      }

      return playerGroups.isEmpty() ? CommandProtectionManager.PlayerGroupSnapshot.EMPTY : new CommandProtectionManager.PlayerGroupSnapshot(playerGroups);
   }

   private void addLuckPermsGroups(Set<String> target, Player player) {
      CommandProtectionManager.LuckPermsBridge bridge = this.getLuckPermsBridge();
      if (bridge != null) {
         bridge.addGroups(target, player);
      }
   }

   private CommandProtectionManager.LuckPermsBridge getLuckPermsBridge() {
      CommandProtectionManager.LuckPermsBridge current = this.luckPermsBridge;
      if (current != null) {
         return current;
      }

      long now = System.currentTimeMillis();
      if (this.lastLuckPermsLookup != 0L && now - this.lastLuckPermsLookup < 5000L) {
         return null;
      }

      this.lastLuckPermsLookup = now;
      if (!this.plugin.getServer().getPluginManager().isPluginEnabled("LuckPerms")) {
         return null;
      }

      try {
         CommandProtectionManager.LuckPermsBridge bridge = CommandProtectionManager.LuckPermsBridge.create();
         this.luckPermsBridge = bridge;
         return bridge;
      } catch (LinkageError | RuntimeException ignored) {
         return null;
      }
   }

   private CommandProtectionManager.VaultPermissionBridge getVaultPermissionBridge() {
      CommandProtectionManager.VaultPermissionBridge current = this.vaultPermissionBridge;
      if (current != null) {
         return current;
      }

      long now = System.currentTimeMillis();
      if (this.lastVaultLookup != 0L && now - this.lastVaultLookup < 5000L) {
         return null;
      }

      this.lastVaultLookup = now;
      if (!this.plugin.getServer().getPluginManager().isPluginEnabled("Vault")) {
         return null;
      }

      try {
         RegisteredServiceProvider<Permission> registration = this.plugin.getServer().getServicesManager().getRegistration(Permission.class);
         if (registration == null) {
            return null;
         }

         Permission provider = (Permission)registration.getProvider();
         if (provider == null) {
            return null;
         }

         CommandProtectionManager.VaultPermissionBridge bridge = new CommandProtectionManager.VaultPermissionBridge(provider);
         this.vaultPermissionBridge = bridge;
         return bridge;
      } catch (LinkageError | RuntimeException ignored) {
         return null;
      }
   }

   private static void addGroupNames(Set<String> target, String[] values) {
      if (values != null && values.length != 0) {
         for (String value : values) {
            addGroupName(target, value);
         }
      }
   }

   private static void addGroupName(Set<String> target, String value) {
      String normalized = normalizeGroupName(value);
      if (!normalized.isEmpty()) {
         target.add(normalized);
      }
   }

   private static String worldName(Player player) {
      return player.getWorld() == null ? null : player.getWorld().getName();
   }

   private static String appendCompletion(String buffer, String completion) {
      if (completion == null || completion.isEmpty()) {
         return buffer;
      }

      if (buffer != null && !buffer.isEmpty()) {
         int index = buffer.length();

         while (index > 0 && buffer.charAt(index - 1) > ' ') {
            index--;
         }

         return buffer.substring(0, index) + completion;
      } else {
         return completion;
      }
   }

   private static String applyPlaceholders(String message, String command) {
      if (message != null && !message.isEmpty()) {
         String value = command == null ? "" : command;
         return message.replace("{command}", value).replace("{label}", value);
      } else {
         return "";
      }
   }

   private static boolean matchesPrefix(String commandLine, String prefix) {
      if (commandLine.equals(prefix)) {
         return true;
      }

      int prefixLength = prefix.length();
      return commandLine.length() > prefixLength && commandLine.startsWith(prefix) && commandLine.charAt(prefixLength) <= ' ';
   }

   private static boolean hasArguments(String commandLine) {
      return commandLine.indexOf(32) >= 0;
   }

   private static boolean hasNamespacedLabel(String commandLine) {
      return firstToken(commandLine).indexOf(58) >= 0;
   }

   private static String firstToken(String commandLine) {
      if (commandLine != null && !commandLine.isEmpty()) {
         int end = 0;

         while (end < commandLine.length() && commandLine.charAt(end) > ' ') {
            end++;
         }

         return commandLine.substring(0, end);
      } else {
         return "";
      }
   }

   private static String normalizeCommandLine(String commandLine) {
      if (commandLine == null) {
         return "";
      }

      String[] last = lastNormalized;
      if (last != null && last[0] == commandLine) {
         return last[1];
      }

      String normalized = normalizeUncached(commandLine);
      lastNormalized = new String[]{commandLine, normalized};
      return normalized;
   }

   private static String normalizeUncached(String commandLine) {
      int start = 0;
      int end = commandLine.length();

      while (start < end && commandLine.charAt(start) <= ' ') {
         start++;
      }

      while (end > start && commandLine.charAt(end - 1) <= ' ') {
         end--;
      }

      while (start < end && commandLine.charAt(start) == '/') {
         start++;
      }

      if (end <= start) {
         return "";
      }

      StringBuilder builder = new StringBuilder(end - start);
      boolean previousSpace = false;

      for (int i = start; i < end; i++) {
         char c = commandLine.charAt(i);
         if (c <= ' ') {
            if (!previousSpace) {
               builder.append(' ');
               previousSpace = true;
            }
         } else {
            builder.append(Character.toLowerCase(c));
            previousSpace = false;
         }
      }

      return builder.indexOf(":/") < 0 ? builder.toString() : builder.toString().replace(":/", ":");
   }

   private static String normalizeGroupName(String groupName) {
      return groupName == null ? "" : groupName.trim().toLowerCase(Locale.ROOT);
   }

   private static final class CachedAccess {
      private final long createdAt;
      private final CommandProtectionManager.CommandAccess access;

      private CachedAccess(long createdAt, CommandProtectionManager.CommandAccess access) {
         this.createdAt = createdAt;
         this.access = access;
      }
   }

   public static final class CommandAccess {
      private final boolean allowAll;
      private final Set<String> commandLabels;
      private final Map<String, List<String>> commandPrefixesByLabel;
      private final Set<String> rootCompletionLabels;
      private final List<String> rootCompletions;

      private CommandAccess(
         boolean allowAll,
         Set<String> commandLabels,
         Map<String, List<String>> commandPrefixesByLabel,
         Set<String> rootCompletionLabels,
         List<String> rootCompletions
      ) {
         this.allowAll = allowAll;
         this.commandLabels = commandLabels;
         this.commandPrefixesByLabel = commandPrefixesByLabel;
         this.rootCompletionLabels = rootCompletionLabels;
         this.rootCompletions = rootCompletions;
      }

      public boolean allowsAllCommands() {
         return this.allowAll;
      }
   }

   private static final class Group {
      private final String name;
      private final boolean defaultGroup;
      private final String permission;
      private final boolean allowAll;
      private final Set<String> commandLabels;
      private final Set<String> commandPrefixes;
      private final Set<String> commandPrefixLabels;

      private Group(
         String name,
         boolean defaultGroup,
         String permission,
         boolean allowAll,
         Set<String> commandLabels,
         Set<String> commandPrefixes,
         Set<String> commandPrefixLabels
      ) {
         this.name = name;
         this.defaultGroup = defaultGroup;
         this.permission = permission;
         this.allowAll = allowAll;
         this.commandLabels = commandLabels;
         this.commandPrefixes = commandPrefixes;
         this.commandPrefixLabels = commandPrefixLabels;
      }
   }

   private static final class LoadedCommands {
      private final boolean allowAll;
      private final Set<String> commandLabels;
      private final Set<String> commandPrefixes;
      private final Set<String> commandPrefixLabels;

      private LoadedCommands(boolean allowAll, Set<String> commandLabels, Set<String> commandPrefixes, Set<String> commandPrefixLabels) {
         this.allowAll = allowAll;
         this.commandLabels = commandLabels;
         this.commandPrefixes = commandPrefixes;
         this.commandPrefixLabels = commandPrefixLabels;
      }
   }

   private static final class LuckPermsBridge {
      private final LuckPerms provider;

      private LuckPermsBridge(LuckPerms provider) {
         this.provider = provider;
      }

      private static CommandProtectionManager.LuckPermsBridge create() {
         return new CommandProtectionManager.LuckPermsBridge(LuckPermsProvider.get());
      }

      private void addGroups(Set<String> target, Player player) {
         User user = this.provider.getUserManager().getUser(player.getUniqueId());
         if (user != null) {
            CommandProtectionManager.addGroupName(target, user.getPrimaryGroup());

            for (net.luckperms.api.model.group.Group group : user.getInheritedGroups(user.getQueryOptions())) {
               CommandProtectionManager.addGroupName(target, group.getName());
            }
         }
      }
   }

   private static final class PlayerGroupSnapshot {
      private static final CommandProtectionManager.PlayerGroupSnapshot EMPTY = new CommandProtectionManager.PlayerGroupSnapshot(Collections.emptySet());
      private final Set<String> groups;

      private PlayerGroupSnapshot(Set<String> groups) {
         this.groups = groups;
      }

      private boolean contains(String groupName) {
         return this.groups.contains(groupName);
      }
   }

   private static final class VaultPermissionBridge {
      private final Permission provider;

      private VaultPermissionBridge(Permission provider) {
         this.provider = provider;
      }

      private String getPrimaryGroup(String world, Player player) {
         try {
            return this.provider.getPrimaryGroup(world, player);
         } catch (RuntimeException ignored) {
            return null;
         }
      }

      private boolean playerInGroup(String world, Player player, String group) {
         try {
            return this.provider.playerInGroup(world, player, group);
         } catch (RuntimeException ignored) {
            return false;
         }
      }

      private String[] getPlayerGroups(String world, Player player) {
         try {
            return this.provider.getPlayerGroups(world, player);
         } catch (RuntimeException ignored) {
            return null;
         }
      }
   }
}
