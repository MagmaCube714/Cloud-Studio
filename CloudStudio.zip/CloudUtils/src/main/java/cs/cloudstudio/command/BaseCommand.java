package cs.cloudstudio.command;

import cs.cloudstudio.CloudUtils;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public abstract class BaseCommand implements CommandExecutor {
   protected final CloudUtils plugin;
   protected final String permission;
   protected final Map<String, SubCommand> subCommands = new LinkedHashMap<>();
   protected final List<SubCommand> orderedSubCommands = new ArrayList<>();

   protected BaseCommand(CloudUtils plugin, String permission) {
      this.plugin = plugin;
      this.permission = permission;
   }

   protected void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.getName(), subCommand);
      this.orderedSubCommands.add(subCommand);
   }

   protected boolean hasPermission(CommandSender sender) {
      return sender.hasPermission(this.permission);
   }

   protected void message(CommandSender sender, String path) {
      String message = this.plugin.getConfigManager().getColoredString(path);
      if (!message.isEmpty()) {
         sender.sendMessage(message);
      }
   }
}
