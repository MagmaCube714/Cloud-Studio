package cs.cloudstudio.command.player;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.config.ConfigManager;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class VoiceCommand implements CommandExecutor, TabCompleter {
   private static final String HOVER_TEXT = "&6Кликни";
   private static final String FORGE_TEXT = "&b&nforge 1.16.5";
   private static final String FABRIC_TEXT = "&b&nfabric 1.16.5";
   private static final String OTHERS_TEXT = "&b&nтут";
   private static final String FORGE_LINK = "https://modrinth.com/plugin/simple-voice-chat/versions?l=forge&g=1.16.5";
   private static final String FABRIC_LINK = "https://modrinth.com/plugin/simple-voice-chat/versions?l=fabric&g=1.16.5";
   private static final String OTHERS_LINK = "https://modrinth.com/plugin/simple-voice-chat/versions";
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
      .character(LegacyComponentSerializer.SECTION_CHAR)
      .hexColors()
      .useUnusualXRepeatedCharacterHexFormat()
      .build();
   private final ConfigManager configManager;
   private final Map<String, Component> cache = new ConcurrentHashMap<>();

   public VoiceCommand(CloudUtils plugin) {
      this.configManager = plugin.getConfigManager();
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player player)) {
         return true;
      } else {
         for (String message : this.configManager.getStringList("voice.messages")) {
            if (this.hasButton(message)) {
               this.sendComplex(player, message);
            } else {
               this.send(player, message);
            }
         }

         return true;
      }
   }

   private boolean hasButton(String message) {
      return message != null && (message.contains("{forge}") || message.contains("{fabric}") || message.contains("{others}"));
   }

   private void sendComplex(Player player, String message) {
      Component cached = this.cache.get(message);
      if (cached == null) {
         cached = this.buildComplex(message);
         if (this.cache.size() >= 256) {
            this.cache.clear();
         }

         this.cache.put(message, cached);
      }

      player.sendMessage(cached);
   }

   private Component buildComplex(String message) {
      TextComponent.Builder result = Component.text();
      int last = 0;

      while (last < message.length()) {
         int forgeIndex = message.indexOf("{forge}", last);
         int fabricIndex = message.indexOf("{fabric}", last);
         int othersIndex = message.indexOf("{others}", last);
         int next = this.minPos(forgeIndex, fabricIndex, othersIndex);
         if (next == -1) {
            this.addText(result, this.configManager.color(message.substring(last)));
            break;
         }

         this.addText(result, this.configManager.color(message.substring(last, next)));
         if (next == forgeIndex) {
            this.addLink(result, "forge");
            last = forgeIndex + "{forge}".length();
         } else if (next == fabricIndex) {
            this.addLink(result, "fabric");
            last = fabricIndex + "{fabric}".length();
         } else {
            this.addLink(result, "others");
            last = othersIndex + "{others}".length();
         }
      }

      return result.build();
   }

   private int minPos(int... values) {
      int min = -1;

      for (int value : values) {
         if (value != -1 && (min == -1 || value < min)) {
            min = value;
         }
      }

      return min;
   }

   private void send(Player player, String message) {
      String colored = this.configManager.color(message);
      if (!colored.isEmpty()) {
         player.sendMessage(colored);
      }
   }

   private void addText(TextComponent.Builder parent, String text) {
      parent.append(LEGACY.deserialize(text));
   }
   private void addLink(TextComponent.Builder parent, String id) {
      String text;
      String url;
      if ("forge".equals(id)) {
         text = "&b&nforge 1.16.5";
         url = "https://modrinth.com/plugin/simple-voice-chat/versions?l=forge&g=1.16.5";
      } else if ("fabric".equals(id)) {
         text = "&b&nfabric 1.16.5";
         url = "https://modrinth.com/plugin/simple-voice-chat/versions?l=fabric&g=1.16.5";
      } else {
         text = "&b&nтут";
         url = "https://modrinth.com/plugin/simple-voice-chat/versions";
      }

      String coloredText = this.configManager.color(text);
      String coloredHover = this.configManager.color("&6Кликни");

      parent.append(LEGACY.deserialize(coloredText).clickEvent(ClickEvent.openUrl(url)).hoverEvent(HoverEvent.showText(LEGACY.deserialize(coloredHover))));
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return Collections.emptyList();
   }
}
