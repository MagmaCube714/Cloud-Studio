package cs.cloudstudio.command.player;

import cs.cloudstudio.CloudUtils;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.PriorityQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class Baltop implements CommandExecutor, TabCompleter {
   private static final int BALTOP_SIZE = 10;
   private static final long BALTOP_CACHE_TTL_MS = 60000L;
   private static final double MAX_TRANSFER_AMOUNT = 1.0E12;
   private static final ThreadLocal<DecimalFormat> MONEY_FORMAT = ThreadLocal.withInitial(
      () -> new DecimalFormat("#,##0", DecimalFormatSymbols.getInstance(Locale.US))
   );
   private final CloudUtils plugin;
   private final Object economyLock = new Object();
   private final AtomicReference<Baltop.CachedTop> topCache = new AtomicReference<>();
   private final AtomicBoolean topLoading = new AtomicBoolean();
   private volatile Economy economy;

   public Baltop(CloudUtils plugin) {
      this.plugin = plugin;
   }

   public void reload() {
      this.topCache.set(null);
      this.economy = null;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      String name = command.getName().toLowerCase(Locale.ROOT);
      if (name.equals("pay")) {
         return this.pay(sender, args);
      } else if (name.equals("bal") || name.equals("balance") || name.equals("money")) {
         return this.balance(sender, args);
      } else {
         return !name.equals("baltop") && !name.equals("balancetop") ? true : this.baltop(sender);
      }
   }

   private boolean pay(CommandSender sender, String[] args) {
      if (sender instanceof Player && args.length >= 2) {
         Player player = (Player)sender;
         Player target = this.findOnlinePlayer(args[0]);
         if (target == null) {
            this.send(sender, this.message("player-not-found").replace("%player%", args[0]));
            return true;
         }

         if (target.getUniqueId().equals(player.getUniqueId())) {
            this.send(sender, this.message("self-pay"));
            return true;
         }

         double value = this.parseAmount(args[1]);
         if (value <= 0.0) {
            this.send(sender, this.message("invalid-amount"));
            return true;
         }

         Economy economy = this.economy();
         if (economy == null) {
            return true;
         }

         synchronized (this.economyLock) {
            if (!player.isOnline() || !target.isOnline()) {
               this.send(sender, this.message("player-not-found").replace("%player%", args[0]));
               return true;
            }

            if (!economy.has(player, value)) {
               this.send(sender, this.message("not-enough-money"));
               return true;
            }

            EconomyResponse withdraw = economy.withdrawPlayer(player, value);
            if (withdraw == null || !withdraw.transactionSuccess()) {
               this.send(sender, this.message("not-enough-money"));
               return true;
            }

            EconomyResponse deposit = economy.depositPlayer(target, value);
            if (deposit == null || !deposit.transactionSuccess()) {
               EconomyResponse rollback = economy.depositPlayer(player, value);
               if (rollback == null || !rollback.transactionSuccess()) {
                  this.plugin.getLogger().warning("[CloudUtils] Не удалось вернуть списанные Vault-монеты игроку " + player.getName() + ": " + value);
               }

               this.send(sender, this.message("not-enough-money"));
               return true;
            }
         }

         this.topCache.set(null);
         String formatted = this.format(value);
         this.send(player, this.message("pay-sent").replace("%amount%", formatted).replace("%player%", target.getName()));
         this.send(target, this.message("pay-received").replace("%amount%", formatted).replace("%player%", player.getName()));
         return true;
      } else {
         this.send(sender, this.message("pay-usage"));
         return true;
      }
   }

   private boolean balance(CommandSender sender, String[] args) {
      Economy economy = this.economy();
      if (economy == null) {
         return true;
      }

      if (args.length > 0) {
         OfflinePlayer target = this.findPlayer(args[0]);
         if (target == null) {
            this.send(sender, this.message("player-not-found").replace("%player%", args[0]));
            return true;
         } else {
            this.send(
               sender,
               this.message("balance-other").replace("%player%", this.safeName(target)).replace("%money%", this.format(this.safeBalance(economy, target)))
            );
            return true;
         }
      } else if (!(sender instanceof OfflinePlayer)) {
         this.send(sender, this.message("balance").replace("%money%", this.format(0.0)));
         return true;
      } else {
         this.send(sender, this.message("balance").replace("%money%", this.format(this.safeBalance(economy, (OfflinePlayer)sender))));
         return true;
      }
   }

   private boolean baltop(CommandSender sender) {
      Economy economy = this.economy();
      if (economy == null) {
         return true;
      }

      Baltop.CachedTop cached = this.topCache.get();
      long now = System.currentTimeMillis();
      if (cached != null && now - cached.timestamp < 60000L) {
         this.sendTop(sender, cached.entries);
         return true;
      }

      if (!this.topLoading.compareAndSet(false, true)) {
         if (cached != null) {
            this.sendTop(sender, cached.entries);
         }

         return true;
      } else {
         OfflinePlayer[] players = Bukkit.getOfflinePlayers();
         this.plugin.getServer().getScheduler().runTaskAsynchronously(this.plugin, () -> {
            List<Baltop.TopEntry> entries = Collections.emptyList();

            try {
               entries = this.loadTop(players, economy);
               this.topCache.set(new Baltop.CachedTop(entries, System.currentTimeMillis()));
            } finally {
               this.topLoading.set(false);
            }

            List result = entries;
            if (this.plugin.isEnabled()) {
               this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.sendTop(sender, result));
            }
         });
         return true;
      }
   }

   private List<Baltop.TopEntry> loadTop(OfflinePlayer[] players, Economy economy) {
      PriorityQueue<Baltop.TopEntry> top = new PriorityQueue<>(10, (first, second) -> Double.compare(first.balance, second.balance));

      for (OfflinePlayer player : players) {
         if (player != null) {
            double balance = this.safeBalance(economy, player);
            if (!(balance <= 0.0) && !Double.isNaN(balance) && !Double.isInfinite(balance)) {
               Baltop.TopEntry entry = new Baltop.TopEntry(this.safeName(player), balance);
               if (top.size() < 10) {
                  top.offer(entry);
               } else {
                  Baltop.TopEntry lowest = top.peek();
                  if (lowest != null && balance > lowest.balance) {
                     top.poll();
                     top.offer(entry);
                  }
               }
            }
         }
      }

      List<Baltop.TopEntry> entries = new ArrayList<>(top);
      entries.sort((first, second) -> Double.compare(second.balance, first.balance));
      return Collections.unmodifiableList(entries);
   }

   private void sendTop(CommandSender sender, List<Baltop.TopEntry> entries) {
      List<String> lines = this.plugin.getConfigManager().getColoredStringList("vault.messages.baltop");
      int entryIndex = 0;

      for (String line : lines) {
         if (this.isTopLine(line)) {
            if (entryIndex < 10) {
               Baltop.TopEntry entry = entryIndex < entries.size() ? entries.get(entryIndex) : Baltop.TopEntry.EMPTY;
               this.sendRaw(
                  sender,
                  line.replace("%position%", String.valueOf(entryIndex + 1)).replace("%player%", entry.name).replace("%money%", this.format(entry.balance))
               );
               entryIndex++;
            }
         } else {
            this.sendRaw(sender, line);
         }
      }
   }

   private boolean isTopLine(String line) {
      return line != null && (line.indexOf("%player%") >= 0 || line.indexOf("%money%") >= 0 || line.indexOf("%position%") >= 0);
   }

   private Economy economy() {
      Economy current = this.economy;
      if (current != null && current.isEnabled()) {
         return current;
      }

      synchronized (this.economyLock) {
         current = this.economy;
         if (current != null && current.isEnabled()) {
            return current;
         }

         RegisteredServiceProvider<Economy> registration = Bukkit.getServicesManager().getRegistration(Economy.class);
         this.economy = registration == null ? null : (Economy)registration.getProvider();
         return this.economy;
      }
   }

   private OfflinePlayer findPlayer(String name) {
      if (name != null && !name.trim().isEmpty()) {
         Player online = this.findOnlinePlayer(name);
         if (online != null) {
            return online;
         }

         OfflinePlayer offline = Bukkit.getOfflinePlayer(name);
         return offline != null && (offline.hasPlayedBefore() || offline.isOnline()) ? offline : null;
      } else {
         return null;
      }
   }

   private Player findOnlinePlayer(String name) {
      if (name != null && !name.trim().isEmpty()) {
         Player exact = Bukkit.getPlayerExact(name);
         return exact != null && exact.isOnline() ? exact : null;
      } else {
         return null;
      }
   }

   private double parseAmount(String text) {
      if (text == null) {
         return -1.0;
      }

      String normalized = text.trim().replace(" ", "");
      if (!normalized.isEmpty() && this.isValidAmount(normalized)) {
         try {
            double amount = Double.parseDouble(normalized.indexOf(44) >= 0 ? normalized.replace(",", "") : normalized);
            return amount > 0.0 && amount <= 1.0E12 && !Double.isNaN(amount) && !Double.isInfinite(amount) ? amount : -1.0;
         } catch (NumberFormatException ignored) {
            return -1.0;
         }
      } else {
         return -1.0;
      }
   }

   private boolean isValidAmount(String value) {
      int length = value.length();
      int dot = value.indexOf(46);
      if (dot >= 0) {
         int decimals = length - dot - 1;
         if (decimals < 1 || decimals > 2 || value.indexOf(46, dot + 1) >= 0) {
            return false;
         }

         length = dot;
      }

      if (length <= 0) {
         return false;
      }

      int firstComma = value.indexOf(44);
      if (firstComma < 0 || dot >= 0 && firstComma > dot) {
         for (int i = 0; i < length; i++) {
            char c = value.charAt(i);
            if (c < '0' || c > '9') {
               return false;
            }
         }

         return true;
      } else if (firstComma >= 1 && firstComma <= 3) {
         int groupSize = 0;

         for (int i = 0; i < length; i++) {
            char c = value.charAt(i);
            if (c == ',') {
               if (i == firstComma) {
                  groupSize = 0;
               } else {
                  if (groupSize != 3) {
                     return false;
                  }

                  groupSize = 0;
               }
            } else {
               if (c < '0' || c > '9') {
                  return false;
               }

               groupSize++;
            }
         }

         return groupSize == 3;
      } else {
         return false;
      }
   }

   private String safeName(OfflinePlayer player) {
      String name = player.getName();
      return name != null && !name.trim().isEmpty() ? name : player.getUniqueId().toString();
   }

   private double safeBalance(Economy economy, OfflinePlayer player) {
      try {
         return economy.getBalance(player);
      } catch (RuntimeException ignored) {
         return 0.0;
      }
   }

   private String format(double money) {
      return MONEY_FORMAT.get().format(money);
   }

   private String message(String key) {
      return this.plugin.getConfigManager().getColoredString("vault.messages." + key);
   }

   private void send(CommandSender sender, String message) {
      if (message != null && !message.isEmpty()) {
         this.sendRaw(sender, message);
      }
   }

   private void sendRaw(CommandSender sender, String message) {
      if (!(sender instanceof Player) || ((Player)sender).isOnline()) {
         if (message != null && !message.isEmpty()) {
            sender.sendMessage(message);
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      String name = command.getName().toLowerCase(Locale.ROOT);
      return (name.equals("pay") || name.equals("bal") || name.equals("balance") || name.equals("money")) && args.length == 1
         ? this.onlinePlayerNames(args[0])
         : Collections.emptyList();
   }

   private List<String> onlinePlayerNames(String prefix) {
      String lowerPrefix = prefix == null ? "" : prefix.toLowerCase(Locale.ROOT);
      List<String> names = new ArrayList<>();

      for (Player player : Bukkit.getOnlinePlayers()) {
         String name = player.getName();
         if (name.toLowerCase(Locale.ROOT).startsWith(lowerPrefix)) {
            names.add(name);
         }
      }

      Collections.sort(names);
      return names;
   }

   private static final class CachedTop {
      private final List<Baltop.TopEntry> entries;
      private final long timestamp;

      private CachedTop(List<Baltop.TopEntry> entries, long timestamp) {
         this.entries = entries;
         this.timestamp = timestamp;
      }
   }

   private static final class TopEntry {
      private static final Baltop.TopEntry EMPTY = new Baltop.TopEntry("-", 0.0);
      private final String name;
      private final double balance;

      private TopEntry(String name, double balance) {
         this.name = name;
         this.balance = balance;
      }
   }
}
