package cs.cloudstudio.command;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public final class AdminCommand extends BaseCommand implements TabCompleter {
   public AdminCommand(CloudUtils plugin) {
      super(plugin, "cloudutils.admin");
      this.register(new ReloadSubCommand(plugin));
   }

   public void reload() {
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!this.hasPermission(sender)) {
         this.message(sender, "messages.no-perm");
         return true;
      } else if (args.length == 0) {
         this.message(sender, "messages.admin-usage");
         return true;
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            this.message(sender, "messages.admin-usage");
            return true;
         } else {
            subCommand.execute(sender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (this.hasPermission(sender) && args.length >= 1 && args.length <= 2) {
         if (args.length == 1) {
            String input = args[0].toLowerCase(Locale.ROOT);
            List<String> completions = new ArrayList<>();

            for (SubCommand subCommand : this.orderedSubCommands) {
               if (subCommand.getName().startsWith(input)) {
                  completions.add(subCommand.getName());
               }
            }

            return completions;
         } else {
            SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
            return subCommand == null ? Collections.emptyList() : subCommand.tabComplete(sender, args);
         }
      } else {
         return Collections.emptyList();
      }
   }
}
