package cs.cloudstudio.command.player;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.listener.AntiExploitPacketGuard;
import cs.cloudstudio.util.ColorUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.ClickEvent.Action;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public final class SpecCommand implements CommandExecutor, TabCompleter, Listener {
   private static final String PERMISSION = "cloudutils.spec";
   private static final String STOP_ARGUMENT = "stop";
   private final CloudUtils plugin;
   private final ConfigManager configManager;
   private final Map<UUID, SpecCommand.SpectateState> states = new HashMap<>();
   private String requestMessage;
   private String requestHover;
   private String requestSent;
   private String startMessage;
   private String notifyStartMessage;
   private String stopMessage;
   private String notifyStopMessage;
   private String notSpectating;
   private String playerNotFound;
   private String cannotSelf;
   private String noPermission;

   public SpecCommand(CloudUtils plugin) {
      this.plugin = plugin;
      this.configManager = plugin.getConfigManager();
      this.reload();
   }

   public void reload() {
      this.requestMessage = this.message("request-message", "&6Спек &7» &fИгрок &6{player} &fпросит проследить за ним");
      this.requestHover = this.message("request-hover", "&6Нажмите, чтобы следить");
      this.requestSent = this.message("request-sent", "&6Спек &7» &aЗапрос на слежку отправлен");
      this.startMessage = this.message("start-message", "&6Спек &7» &fВы следите за игроком &6{target}");
      this.notifyStartMessage = this.message("notify-start-message", "&6Спек &7» &fИгрок &6{spectator} &fначал слежку за &6{target}");
      this.stopMessage = this.message("stop-message", "&6Спек &7» &fВы вышли из режима слежки");
      this.notifyStopMessage = this.message("notify-stop-message", "&6Спек &7» &fИгрок &6{spectator} &fзакончил слежку за &6{target}");
      this.notSpectating = this.message("not-spectating", "&6Спек &7» &cВы не следите ни за кем");
      this.playerNotFound = this.message("player-not-found", "&6Спек &7» &cИгрок не найден");
      this.cannotSelf = this.message("cannot-self", "&6Спек &7» &cНельзя следить за собой");
      this.noPermission = this.message("no-permission", "&6Спек &7» &fУ тебя нет прав");
   }

   public void shutdown() {
      for (UUID uuid : new ArrayList<>(this.states.keySet())) {
         Player player = this.plugin.getServer().getPlayer(uuid);
         if (player != null) {
            this.restore(player, false, false);
         }
      }

      this.states.clear();
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player player)) {
         return true;
      } else if (args.length == 0) {
         this.sendRequest(player);
         return true;
      } else if (!player.hasPermission("cloudutils.spec")) {
         this.send(player, this.noPermission);
         return true;
      } else if (args.length == 1 && args[0].equalsIgnoreCase("stop")) {
         this.stopSpectating(player);
         return true;
      } else {
         Player target = this.plugin.getServer().getPlayerExact(args[0]);
         if (target == null) {
            this.send(player, this.playerNotFound);
            return true;
         } else if (target.getUniqueId().equals(player.getUniqueId())) {
            this.send(player, this.cannotSelf);
            return true;
         } else {
            this.startSpectating(player, target);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (sender instanceof Player && sender.hasPermission("cloudutils.spec") && args.length == 1) {
         String input = args[0].toLowerCase(Locale.ROOT);
         List<String> completions = new ArrayList<>();
         if ("stop".startsWith(input)) {
            completions.add("stop");
         }

         Player player = (Player)sender;

         for (Player online : this.plugin.getServer().getOnlinePlayers()) {
            if (online != player) {
               String name = online.getName();
               if (name.toLowerCase(Locale.ROOT).startsWith(input)) {
                  completions.add(name);
               }
            }
         }

         return completions.isEmpty() ? Collections.emptyList() : completions;
      } else {
         return Collections.emptyList();
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      if (this.states.containsKey(player.getUniqueId())) {
         this.restore(player, false, true);
      } else {
         UUID targetUuid = player.getUniqueId();
         List<UUID> affected = new ArrayList<>();

         for (Entry<UUID, SpecCommand.SpectateState> entry : this.states.entrySet()) {
            if (targetUuid.equals(entry.getValue().targetUuid)) {
               affected.add(entry.getKey());
            }
         }

         for (UUID spectatorUuid : affected) {
            Player spectator = this.plugin.getServer().getPlayer(spectatorUuid);
            if (spectator != null) {
               this.restore(spectator, true, false);
               this.send(spectator, this.playerNotFound);
            } else {
               this.states.remove(spectatorUuid);
            }
         }
      }
   }

   private void sendRequest(Player player) {
      String message = this.requestMessage.replace("{player}", player.getName());
      BaseComponent[] hover = TextComponent.fromLegacyText(this.requestHover);
      BaseComponent[] components = TextComponent.fromLegacyText(message);
      ClickEvent click = new ClickEvent(Action.RUN_COMMAND, "/spec " + player.getName());
      HoverEvent hoverEvent = new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, hover);

      for (BaseComponent component : components) {
         component.setClickEvent(click);
         component.setHoverEvent(hoverEvent);
      }

      for (Player online : this.plugin.getServer().getOnlinePlayers()) {
         if (online != player && online.hasPermission("cloudutils.spec")) {
            online.spigot().sendMessage(components);
         }
      }

      this.send(player, this.requestSent);
   }

   private void startSpectating(Player spectator, Player target) {
      UUID spectatorUuid = spectator.getUniqueId();
      SpecCommand.SpectateState state = this.states.get(spectatorUuid);
      if (state == null) {
         state = new SpecCommand.SpectateState(spectator.getLocation().clone(), spectator.getGameMode(), target.getUniqueId(), target.getName());
         this.states.put(spectatorUuid, state);
      } else {
         state.targetUuid = target.getUniqueId();
         state.targetName = target.getName();
      }

      this.setSpecPacketProtection(spectator, true);
      spectator.setGameMode(GameMode.SPECTATOR);
      spectator.teleport(target.getLocation());
      this.setSpecPacketProtection(spectator, true);
      this.send(spectator, this.startMessage.replace("{target}", target.getName()));
      this.notifyStaff(this.notifyStartMessage.replace("{spectator}", spectator.getName()).replace("{target}", target.getName()), spectator);
   }

   private void stopSpectating(Player spectator) {
      if (!this.restore(spectator, true, false)) {
         this.send(spectator, this.notSpectating);
      }
   }

   private boolean restore(Player spectator, boolean notify, boolean quitting) {
      SpecCommand.SpectateState state = this.states.remove(spectator.getUniqueId());
      if (state == null) {
         return false;
      }

      this.grantPacketTeleportGrace(spectator);
      if (state.location != null && state.location.getWorld() != null) {
         spectator.teleport(state.location);
      }

      if (state.gameMode != null) {
         spectator.setGameMode(state.gameMode);
      }

      this.setSpecPacketProtection(spectator, false);
      if (!quitting) {
         this.send(spectator, this.stopMessage);
      }

      if (notify) {
         this.notifyStaff(this.notifyStopMessage.replace("{spectator}", spectator.getName()).replace("{target}", state.targetName), spectator);
      }

      return true;
   }

   private void grantPacketTeleportGrace(Player player) {
      AntiExploitPacketGuard guard = this.plugin.getAntiExploitPacketGuard();
      if (guard != null) {
         guard.grantTeleportGrace(player);
      }
   }

   private void setSpecPacketProtection(Player player, boolean enabled) {
      AntiExploitPacketGuard guard = this.plugin.getAntiExploitPacketGuard();
      if (guard != null) {
         guard.setSpectatorPacketProtection(player, enabled);
      }
   }

   private void notifyStaff(String message, Player excluded) {
      if (message != null && !message.isEmpty()) {
         this.plugin.getServer().getConsoleSender().sendMessage(message);

         for (Player online : this.plugin.getServer().getOnlinePlayers()) {
            if (online != excluded && online.hasPermission("cloudutils.spec")) {
               online.sendMessage(message);
            }
         }
      }
   }

   private void send(Player player, String message) {
      if (message != null && !message.isEmpty()) {
         player.sendMessage(message);
      }
   }

   private String message(String key, String fallback) {
      return ColorUtil.colorize(this.configManager.getString("spec." + key, fallback));
   }

   private static final class SpectateState {
      private final Location location;
      private final GameMode gameMode;
      private UUID targetUuid;
      private String targetName;

      private SpectateState(Location location, GameMode gameMode, UUID targetUuid, String targetName) {
         this.location = location;
         this.gameMode = gameMode;
         this.targetUuid = targetUuid;
         this.targetName = targetName == null ? "" : targetName;
      }
   }
}
