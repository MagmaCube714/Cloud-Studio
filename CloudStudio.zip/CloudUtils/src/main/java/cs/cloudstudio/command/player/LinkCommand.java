package cs.cloudstudio.command.player;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.config.ConfigManager;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class LinkCommand implements CommandExecutor, TabCompleter {
   private static final Pattern URL_PATTERN = Pattern.compile("((?:&[0-9a-fk-orA-FK-OR])+)(https?://[^\\s]+)");
   private static final String HOVER_TEXT = "&6Кликни";
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
      .character(LegacyComponentSerializer.SECTION_CHAR)
      .hexColors()
      .useUnusualXRepeatedCharacterHexFormat()
      .build();
   private final ConfigManager configManager;
   private final Map<String, Component> cache = new ConcurrentHashMap<>();

   public LinkCommand(CloudUtils plugin) {
      this.configManager = plugin.getConfigManager();
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player player)) {
         return true;
      } else {
         for (String message : this.configManager.getStringList("link.messages")) {
            this.sendClickable(player, message);
         }

         return true;
      }
   }

   private void sendClickable(Player player, String message) {
      Component cached = this.cache.get(message);
      if (cached != null) {
         player.sendMessage(cached);
         return;
      }

      Matcher matcher = URL_PATTERN.matcher(message);
      if (!matcher.find()) {
         this.send(player, message);
      } else {
         matcher.reset();
         TextComponent.Builder result = Component.text();
         Component hover = LEGACY.deserialize(this.configManager.color(HOVER_TEXT));

         int lastEnd;
         for (lastEnd = 0; matcher.find(); lastEnd = matcher.end()) {
            String colorCodes = matcher.group(1);
            String url = matcher.group(2);
            if (matcher.start() > lastEnd) {
               result.append(LEGACY.deserialize(this.configManager.color(message.substring(lastEnd, matcher.start()))));
            }

            result.append(
               LEGACY.deserialize(this.configManager.color(colorCodes + url)).clickEvent(ClickEvent.openUrl(url)).hoverEvent(HoverEvent.showText(hover))
            );
         }

         if (lastEnd < message.length()) {
            result.append(LEGACY.deserialize(this.configManager.color(message.substring(lastEnd))));
         }

         Component built = result.build();
         if (this.cache.size() >= 256) {
            this.cache.clear();
         }

         this.cache.put(message, built);
         player.sendMessage(built);
      }
   }

   private void send(Player player, String message) {
      String colored = this.configManager.color(message);
      if (!colored.isEmpty()) {
         player.sendMessage(colored);
      }
   }
   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return Collections.emptyList();
   }
}
