package cs.cloudstudio.command.player;

import com.earth2me.essentials.Essentials;
import com.earth2me.essentials.User;
import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.config.ConfigManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

public final class NearCommand implements CommandExecutor, TabCompleter {
   private static final Comparator<NearCommand.PlayerDistance> DISTANCE_COMPARATOR = new Comparator<NearCommand.PlayerDistance>() {
      public int compare(NearCommand.PlayerDistance first, NearCommand.PlayerDistance second) {
         return Double.compare(first.distanceSquared, second.distanceSquared);
      }
   };
   private final ConfigManager configManager;
   private final CloudUtils plugin;
   private final Essentials essentials;
   private int radius;
   private int maxDisplay;
   private double radiusSquared;
   private String noPermission;
   private String playersNotFound;
   private String tooManyPlayers;
   private String header;
   private String playerFormat;
   private String[] directions;

   public NearCommand(CloudUtils plugin) {
      this.plugin = plugin;
      this.configManager = plugin.getConfigManager();
      this.essentials = (Essentials)plugin.getServer().getPluginManager().getPlugin("Essentials");
      this.reload();
   }

   public void reload() {
      this.radius = Math.max(0, this.configManager.getInt("near.radius"));
      this.maxDisplay = this.configManager.getInt("near.max-display");
      this.radiusSquared = (double)this.radius * this.radius;
      this.noPermission = this.message("no-permission");
      this.playersNotFound = this.message("players-not-found");
      this.tooManyPlayers = this.message("too-many-players");
      this.header = this.message("header");
      this.playerFormat = this.message("player-format");
      this.directions = new String[]{
         this.direction("straight"),
         this.direction("straight-left"),
         this.direction("left"),
         this.direction("back-left"),
         this.direction("back"),
         this.direction("back-right"),
         this.direction("right"),
         this.direction("straight-right")
      };
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player player)) {
         return true;
      } else {
         if (!player.hasPermission("cloudutils.near")) {
            this.send(player, this.noPermission);
            return true;
         }

         World playerWorld = player.getWorld();
         Location playerLocation = player.getLocation();
         boolean canViewHidden = player.hasPermission("cloudutils.near.view.bypass");
         List<NearCommand.PlayerDistance> nearby = new ArrayList<>();
         double playerX = playerLocation.getX();
         double playerY = playerLocation.getY();
         double playerZ = playerLocation.getZ();
         double playerYaw = normalizeYaw(playerLocation.getYaw());

         for (Player other : this.plugin.getServer().getOnlinePlayers()) {
            if (other != player && other.getWorld() == playerWorld && (canViewHidden || !isHidden(player, other, this.essentials))) {
               Location otherLocation = other.getLocation();
               double otherX = otherLocation.getX();
               double otherY = otherLocation.getY();
               double otherZ = otherLocation.getZ();
               double distanceSquared = distanceSquared(playerX, playerY, playerZ, otherX, otherY, otherZ);
               if (!(distanceSquared > this.radiusSquared)) {
                  nearby.add(new NearCommand.PlayerDistance(other.getName(), otherX, otherZ, distanceSquared));
                  if (this.maxDisplay > 0 && nearby.size() > this.maxDisplay) {
                     this.send(player, this.header);
                     this.send(player, this.tooManyPlayers);
                     return true;
                  }
               }
            }
         }

         this.send(player, this.header);
         if (nearby.isEmpty()) {
            this.send(player, this.playersNotFound);
            return true;
         }

         Collections.sort(nearby, DISTANCE_COMPARATOR);

         for (NearCommand.PlayerDistance distance : nearby) {
            this.send(player, this.formatPlayer(distance, playerX, playerZ, playerYaw));
         }

         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return Collections.emptyList();
   }

   private void send(Player player, String message) {
      if (message != null && !message.isEmpty()) {
         player.sendMessage(message);
      }
   }

   private String message(String key) {
      return this.configManager.getColoredString("near.messages." + key);
   }

   private static double distanceSquared(double firstX, double firstY, double firstZ, double secondX, double secondY, double secondZ) {
      double dx = firstX - secondX;
      double dy = firstY - secondY;
      double dz = firstZ - secondZ;
      return dx * dx + dy * dy + dz * dz;
   }

   private static boolean isHidden(Player viewer, Player target, Essentials essentials) {
      return viewer.canSee(target) && target.getGameMode() != GameMode.SPECTATOR && !target.hasPotionEffect(PotionEffectType.INVISIBILITY)
         ? isVanished(target, essentials)
         : true;
   }

   static boolean isVanished(Player target, Essentials essentials) {
      User essentialsUser = essentials == null ? null : essentials.getUser(target);
      return essentialsUser != null && essentialsUser.isVanished();
   }

   private String formatPlayer(NearCommand.PlayerDistance target, double playerX, double playerZ, double playerYaw) {
      int distance = (int)Math.sqrt(target.distanceSquared);
      double dx = target.x - playerX;
      double dz = target.z - playerZ;
      double targetYaw = normalizeYaw(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
      double yawDiff = normalizeYaw(playerYaw - targetYaw);
      int yaw = (int)(yawDiff / 45.0);
      if (yaw < 0 || yaw >= this.directions.length) {
         yaw = 0;
      }

      return this.playerFormat.replace("{player}", target.name).replace("{distance}", String.valueOf(distance)).replace("{direction}", this.directions[yaw]);
   }

   private static double normalizeYaw(double yaw) {
      yaw %= 360.0;
      return yaw < 0.0 ? yaw + 360.0 : yaw;
   }

   private String direction(String key) {
      return this.configManager.getColoredString("near.directions." + key);
   }

   private static final class PlayerDistance {
      private final String name;
      private final double x;
      private final double z;
      private final double distanceSquared;

      private PlayerDistance(String name, double x, double z, double distanceSquared) {
         this.name = name;
         this.x = x;
         this.z = z;
         this.distanceSquared = distanceSquared;
      }
   }
}
