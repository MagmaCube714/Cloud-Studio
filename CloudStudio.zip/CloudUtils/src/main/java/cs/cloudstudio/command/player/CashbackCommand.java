package cs.cloudstudio.command.player;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.config.ConfigManager;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import me.realized.tokenmanager.api.TokenManager;
import org.black_ixx.playerpoints.PlayerPoints;
import org.black_ixx.playerpoints.PlayerPointsAPI;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class CashbackCommand implements CommandExecutor, TabCompleter {
   private static final String PLAYER_POINTS_PLUGIN = "PlayerPoints";
   private static final String TOKEN_MANAGER_PLUGIN = "TokenManager";
   private static final int MAX_PURCHASE_AMOUNT = 1000000;
   private final CloudUtils plugin;
   private final ConfigManager config;
   private volatile CashbackCommand.CashbackProvider playerPointsProvider;
   private volatile boolean playerPointsResolved;
   private volatile CashbackCommand.CashbackProvider tokenManagerProvider;
   private volatile boolean tokenManagerResolved;

   public CashbackCommand(CloudUtils plugin) {
      this.plugin = plugin;
      this.config = plugin.getConfigManager();
   }

   public void reload() {
      this.playerPointsProvider = null;
      this.playerPointsResolved = false;
      this.tokenManagerProvider = null;
      this.tokenManagerResolved = false;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (args.length != 0 && args[0].equalsIgnoreCase("give")) {
         return this.handleGive(sender, args);
      }

      this.send(sender, this.config.getColoredString("cashback.messages.insufficient-args"));
      return true;
   }

   private boolean handleGive(CommandSender sender, String[] args) {
      if (!sender.hasPermission("cloudutils.cashback.give") && !sender.isOp()) {
         this.send(sender, this.config.getColoredString("cashback.messages.no-permission"));
         return true;
      }

      if (args.length < 3) {
         this.send(sender, this.config.getColoredString("cashback.messages.insufficient-args"));
         return true;
      }

      Player target = this.findOnlinePlayer(args[1]);
      if (target == null) {
         this.send(sender, this.config.getColoredString("cashback.messages.player-not-found"));
         return true;
      }

      CashbackCommand.CurrencyType currencyType;
      String purchaseAmountArgument;
      if (args.length >= 4) {
         currencyType = CashbackCommand.CurrencyType.fromName(args[2]);
         if (currencyType == null) {
            this.send(sender, this.config.getColoredString("cashback.messages.invalid-type"));
            return true;
         }

         purchaseAmountArgument = args[3];
      } else {
         currencyType = CashbackCommand.CurrencyType.POINTS;
         purchaseAmountArgument = args[2];
      }

      int purchaseAmount;
      try {
         purchaseAmount = Integer.parseInt(purchaseAmountArgument);
      } catch (NumberFormatException ex) {
         this.send(sender, this.config.getColoredString("cashback.messages.invalid-number"));
         return true;
      }

      if (purchaseAmount > 0 && purchaseAmount <= 1000000) {
         double percent = this.config.getDouble("cashback.percent");
         if (percent <= 0.0 || Double.isNaN(percent) || Double.isInfinite(percent)) {
            percent = 0.1;
         }

         int cashback = (int)(purchaseAmount * percent);
         if (cashback <= 0) {
            this.send(sender, this.config.getColoredString("cashback.messages.invalid-number"));
            return true;
         } else {
            this.applyCashback(sender, target, currencyType, cashback);
            return true;
         }
      } else {
         this.send(sender, this.config.getColoredString("cashback.messages.invalid-number"));
         return true;
      }
   }

   private void applyCashback(CommandSender sender, Player target, CashbackCommand.CurrencyType currencyType, int cashback) {
      if (!target.isOnline()) {
         this.send(sender, this.config.getColoredString("cashback.messages.player-not-found"));
      } else {
         String cashbackStr = String.valueOf(cashback);
         if (!target.hasPermission("cloudutils.cashback")) {
            String deniedPath = currencyType == CashbackCommand.CurrencyType.TOKENS
               ? "cashback.messages.target-no-receive-permission-tokens"
               : "cashback.messages.target-no-receive-permission-points";
            List<String> deniedMessages = this.config.getColoredStringList(deniedPath);
            if (deniedMessages == null || deniedMessages.isEmpty()) {
               deniedMessages = this.config.getColoredStringList("cashback.messages.target-no-receive-permission");
            }

            for (String line : deniedMessages) {
               this.send(target, line.replace("{cashback}", cashbackStr).replace("{currency}", currencyType.getDisplayName()));
            }
         } else {
            boolean given;
            if (currencyType == CashbackCommand.CurrencyType.TOKENS) {
               given = this.giveTokens(target, cashback);
            } else {
               given = this.givePlayerPoints(target, cashback);
            }

            if (!given) {
               String message = this.config
                  .getColoredString("cashback.messages.provider-unavailable")
                  .replace("{type}", currencyType.getCommandName())
                  .replace("{currency}", currencyType.getDisplayName());
               this.send(sender, message);
            } else {
               String successPath = currencyType == CashbackCommand.CurrencyType.TOKENS
                  ? "cashback.messages.success-tokens"
                  : "cashback.messages.success-points";
               String message = this.config.getColoredString(successPath);
               if (message != null && !message.isEmpty()) {
                  this.send(target, message.replace("{cashback}", cashbackStr).replace("{currency}", currencyType.getDisplayName()));
               }
            }
         }
      }
   }

   private boolean givePlayerPoints(Player target, int cashback) {
      CashbackCommand.CashbackProvider provider = this.getPlayerPointsProvider();
      if (provider == null) {
         return false;
      }

      try {
         return provider.give(target, cashback);
      } catch (LinkageError | RuntimeException ex) {
         this.plugin.getLogger().warning("[CloudUtils] Ошибка при выдаче кешбека через PlayerPoints: " + ex.getMessage());
         return false;
      }
   }

   private boolean giveTokens(Player target, int cashback) {
      CashbackCommand.CashbackProvider provider = this.getTokenManagerProvider();
      if (provider == null) {
         return false;
      }

      try {
         return provider.give(target, cashback);
      } catch (LinkageError | RuntimeException ex) {
         this.plugin.getLogger().warning("[CloudUtils] Ошибка при выдаче кешбека через TokenManager: " + ex.getMessage());
         return false;
      }
   }

   private CashbackCommand.CashbackProvider getPlayerPointsProvider() {
      if (this.playerPointsResolved) {
         return this.playerPointsProvider;
      }

      synchronized (this) {
         if (this.playerPointsResolved) {
            return this.playerPointsProvider;
         }

         Plugin pp = Bukkit.getPluginManager().getPlugin("PlayerPoints");
         if (pp != null && pp.isEnabled()) {
            try {
               this.playerPointsProvider = CashbackCommand.PlayerPointsProvider.create(pp);
            } catch (LinkageError | RuntimeException ex) {
               this.plugin.getLogger().warning("[CloudUtils] Не удалось подключиться к PlayerPoints: " + ex.getMessage());
               this.playerPointsProvider = null;
            }
         }

         this.playerPointsResolved = true;
         return this.playerPointsProvider;
      }
   }

   private CashbackCommand.CashbackProvider getTokenManagerProvider() {
      if (this.tokenManagerResolved) {
         return this.tokenManagerProvider;
      }

      synchronized (this) {
         if (this.tokenManagerResolved) {
            return this.tokenManagerProvider;
         }

         Plugin tm = Bukkit.getPluginManager().getPlugin("TokenManager");
         if (tm != null && tm.isEnabled()) {
            try {
               this.tokenManagerProvider = CashbackCommand.TokenManagerProvider.create(tm);
            } catch (LinkageError | RuntimeException ex) {
               this.plugin.getLogger().warning("[CloudUtils] Не удалось подключиться к TokenManager: " + ex.getMessage());
               this.tokenManagerProvider = null;
            }
         }

         this.tokenManagerResolved = true;
         return this.tokenManagerProvider;
      }
   }

   private void send(CommandSender sender, String message) {
      if (message != null && !message.isEmpty()) {
         sender.sendMessage(message);
      }
   }

   private Player findOnlinePlayer(String name) {
      if (name != null && !name.trim().isEmpty()) {
         Player exact = Bukkit.getPlayerExact(name);
         return exact != null && exact.isOnline() ? exact : null;
      } else {
         return null;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (args.length == 1) {
         String prefix = args[0].toLowerCase(Locale.ROOT);
         return "give".startsWith(prefix) ? Collections.singletonList("give") : Collections.emptyList();
      }

      if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
         String prefix = args[1].toLowerCase(Locale.ROOT);
         List<String> out = new ArrayList<>();

         for (Player player : Bukkit.getOnlinePlayers()) {
            String name = player.getName();
            if (name.toLowerCase(Locale.ROOT).startsWith(prefix)) {
               out.add(name);
            }
         }

         return out;
      } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
         String prefix = args[2].toLowerCase(Locale.ROOT);
         List<String> out = new ArrayList<>();

         for (String type : Arrays.asList("points", "tokens")) {
            if (type.startsWith(prefix)) {
               out.add(type);
            }
         }

         return out;
      } else {
         return Collections.emptyList();
      }
   }

   private interface CashbackProvider {
      boolean give(Player var1, int var2);
   }

   private enum CurrencyType {
      POINTS("points", "Рублей"),
      TOKENS("tokens", "Ромашек");

      private final String commandName;
      private final String displayName;

      CurrencyType(String commandName, String displayName) {
         this.commandName = commandName;
         this.displayName = displayName;
      }

      String getCommandName() {
         return this.commandName;
      }

      String getDisplayName() {
         return this.displayName;
      }

      static CashbackCommand.CurrencyType fromName(String name) {
         if (name == null) {
            return null;
         }

         String normalized = name.toLowerCase(Locale.ROOT);

         for (CashbackCommand.CurrencyType type : values()) {
            if (type.commandName.equals(normalized)) {
               return type;
            }
         }

         return null;
      }
   }

   private static final class PlayerPointsProvider implements CashbackCommand.CashbackProvider {
      private final PlayerPointsAPI api;

      private PlayerPointsProvider(PlayerPointsAPI api) {
         this.api = api;
      }

      private static CashbackCommand.CashbackProvider create(Plugin plugin) {
         if (plugin instanceof PlayerPoints playerPoints) {
            return new CashbackCommand.PlayerPointsProvider(playerPoints.getAPI());
         } else {
            throw new IllegalStateException("PlayerPoints API несовместим");
         }
      }

      @Override
      public boolean give(Player player, int amount) {
         return this.api.give(player.getUniqueId(), amount);
      }
   }

   private static final class TokenManagerProvider implements CashbackCommand.CashbackProvider {
      private final TokenManager api;

      private TokenManagerProvider(TokenManager api) {
         this.api = api;
      }

      private static CashbackCommand.CashbackProvider create(Plugin plugin) {
         if (plugin instanceof TokenManager tokenManager) {
            return new CashbackCommand.TokenManagerProvider(tokenManager);
         } else {
            throw new IllegalStateException("TokenManager API несовместим");
         }
      }

      @Override
      public boolean give(Player player, int amount) {
         return this.api.addTokens(player, amount);
      }
   }
}
