package cs.cloudstudio.command.player;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.util.WordUtil;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

public final class RepairExpCommand implements CommandExecutor, TabCompleter {
   private static final int DEFAULT_REPAIR_COST = 5;
   private final ConfigManager configManager;
   private Map<Material, Integer> repairCosts = Collections.emptyMap();

   public RepairExpCommand(CloudUtils plugin) {
      this.configManager = plugin.getConfigManager();
      this.reload();
   }

   public void reload() {
      ConfigurationSection section = this.configManager.getSection("repairexp.costs");
      if (section == null) {
         this.repairCosts = Collections.emptyMap();
      } else {
         EnumMap<Material, Integer> costs = new EnumMap<>(Material.class);

         for (String key : section.getKeys(false)) {
            Material material = Material.matchMaterial(key.toUpperCase(Locale.ROOT));
            if (material != null && material.getMaxDurability() > 0) {
               costs.put(material, Math.max(1, section.getInt(key, 5)));
            }
         }

         this.repairCosts = costs.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(costs);
      }
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player player)) {
         return true;
      } else {
         ItemStack[] contents = player.getInventory().getContents();
         int brokenCount = 0;
         int totalCost = 0;

         for (ItemStack item : contents) {
            if (this.isBrokenRepairable(item)) {
               brokenCount++;
               totalCost += this.getRepairCost(item.getType()) * Math.max(1, item.getAmount());
            }
         }

         if (brokenCount != 0) {
            String repairInfo = this.message("repair-info")
               .replace("{broken_word}", WordUtil.declineBroken(brokenCount))
               .replace("{amount}", String.valueOf(brokenCount))
               .replace("{item_word}", WordUtil.declineItem(brokenCount))
               .replace("{exp}", String.valueOf(totalCost))
               .replace("{level_word}", WordUtil.declineLevel(totalCost));
            int playerLevel = player.getLevel();
            if (playerLevel < totalCost) {
               this.send(player, repairInfo);
               this.send(player, this.message("not-enough-exp"));
               return true;
            }

            player.setLevel(playerLevel - totalCost);

            for (ItemStack item : contents) {
               if (this.isBrokenRepairable(item)) {
                  this.repair(item);
               }
            }

            this.send(player, repairInfo);
            this.send(player, this.message("repair-success"));
            return true;
         } else {
            for (String line : this.configManager.getColoredStringList("repairexp.no-broken-items")) {
               this.send(player, line);
            }

            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return Collections.emptyList();
   }

   private void send(Player player, String message) {
      if (message != null && !message.isEmpty()) {
         player.sendMessage(message);
      }
   }

   private String message(String key) {
      return this.configManager.getColoredString("repairexp." + key);
   }

   private boolean isBrokenRepairable(ItemStack item) {
      if (item == null) {
         return false;
      }

      Material type = item.getType();
      if (type != Material.AIR && type.getMaxDurability() > 0) {
         ItemMeta meta = item.getItemMeta();
         if (meta != null && meta.isUnbreakable()) {
            return false;
         } else {
            return meta instanceof Damageable ? ((Damageable)meta).getDamage() > 0 : item.getDurability() > 0;
         }
      } else {
         return false;
      }
   }

   private void repair(ItemStack item) {
      ItemMeta meta = item.getItemMeta();
      if (meta instanceof Damageable damageable) {
         if (damageable.getDamage() > 0) {
            damageable.setDamage(0);
            item.setItemMeta(meta);
         }
      } else {
         item.setDurability((short)0);
      }
   }

   private int getRepairCost(Material material) {
      Integer cost = this.repairCosts.get(material);
      return cost == null ? 5 : cost;
   }
}
