package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand implements SubCommand {
   private final CloudUtils plugin;

   public ReloadSubCommand(CloudUtils plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "reload";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      this.plugin.reloadPlugin();
      String message = this.plugin.getConfigManager().getColoredString("messages.reloaded");
      if (!message.isEmpty()) {
         sender.sendMessage(message);
      }
   }
}
