package cs.cloudstudio;

import com.earth2me.essentials.Essentials;
import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.command.player.Baltop;
import cs.cloudstudio.command.player.CashbackCommand;
import cs.cloudstudio.command.player.HubCommand;
import cs.cloudstudio.command.player.LinkCommand;
import cs.cloudstudio.command.player.NearCommand;
import cs.cloudstudio.command.player.RepairExpCommand;
import cs.cloudstudio.command.player.SpecCommand;
import cs.cloudstudio.command.player.VoiceCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.listener.AntiExploitListener;
import cs.cloudstudio.listener.AntiExploitPacketGuard;
import cs.cloudstudio.listener.AutoMenuListener;
import cs.cloudstudio.listener.AutoRespawnListener;
import cs.cloudstudio.listener.CommandForkLimitListener;
import cs.cloudstudio.listener.CommandProtectionListener;
import cs.cloudstudio.listener.ElytraFlyListener;
import cs.cloudstudio.listener.EndCrystalDamageListener;
import cs.cloudstudio.listener.ExplosionTerrainListener;
import cs.cloudstudio.listener.FaweDupeFixListener;
import cs.cloudstudio.listener.FishingRodPullListener;
import cs.cloudstudio.listener.GameplayIntegrityListener;
import cs.cloudstudio.listener.HeadPlacementListener;
import cs.cloudstudio.listener.LowTpsCommandListener;
import cs.cloudstudio.listener.PortalListener;
import cs.cloudstudio.listener.RecipeGuiDisabler;
import cs.cloudstudio.listener.ServerMessageSilencer;
import cs.cloudstudio.listener.TridentAntiDupeListener;
import cs.cloudstudio.manager.CommandProtectionManager;
import cs.cloudstudio.manager.PortalManager;
import cs.cloudstudio.manager.VoiceMuteManager;
import cs.cloudstudio.manager.VoicePlaceholder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudUtils extends JavaPlugin {
   private ConfigManager configManager;
   private VoiceMuteManager voiceMuteManager;
   private CommandProtectionManager commandProtectionManager;
   private PortalManager portalManager;
   private PortalListener portalListener;
   private AutoMenuListener autoMenuListener;
   private LowTpsCommandListener lowTpsCommandListener;
   private FaweDupeFixListener faweDupeFixListener;
   private TridentAntiDupeListener tridentAntiDupeListener;
   private AntiExploitPacketGuard antiExploitPacketGuard;
   private RecipeGuiDisabler recipeGuiDisabler;
   private Baltop baltop;
   private CashbackCommand cashbackCommand;
   private NearCommand nearCommand;
   private RepairExpCommand repairExpCommand;
   private AdminCommand adminCommand;
   private SpecCommand specCommand;
   private EndCrystalDamageListener endCrystalDamageListener;
   private ElytraFlyListener elytraFlyListener;
   private AutoRespawnListener autoRespawnListener;

   public void onEnable() {
      this.configManager = new ConfigManager(this);
      this.commandProtectionManager = new CommandProtectionManager(this);
      PluginManager pluginManager = this.getServer().getPluginManager();
      this.elytraFlyListener = new ElytraFlyListener(this, (Essentials)pluginManager.getPlugin("Essentials"));
      pluginManager.registerEvents(this.elytraFlyListener, this);
      this.elytraFlyListener.start();
      this.runSafely("portals", () -> this.setupPortals(pluginManager));
      this.runSafely("recipe gui disabler", () -> {
         this.recipeGuiDisabler = new RecipeGuiDisabler(this);
         pluginManager.registerEvents(this.recipeGuiDisabler, this);
      });
      this.adminCommand = new AdminCommand(this);
      this.registerCommand("cloudutils", this.adminCommand);
      this.registerCommand("hub", new HubCommand());
      this.registerCommand("link", new LinkCommand(this));
      this.registerCommand("voice", new VoiceCommand(this));
      this.nearCommand = new NearCommand(this);
      this.registerCommand("near", this.nearCommand);
      this.repairExpCommand = new RepairExpCommand(this);
      this.registerCommand("repairexp", this.repairExpCommand);
      this.cashbackCommand = new CashbackCommand(this);
      this.registerCommand("cashback", this.cashbackCommand);
      this.specCommand = new SpecCommand(this);
      this.registerCommand("spec", this.specCommand);
      this.runSafely("spec listener", () -> pluginManager.registerEvents(this.specCommand, this));
      this.setupVaultCommands();
      this.runSafely("crystal damage", () -> {
         this.endCrystalDamageListener = new EndCrystalDamageListener(this);
         pluginManager.registerEvents(this.endCrystalDamageListener, this);
      });
      this.runSafely("auto respawn", () -> {
         this.autoRespawnListener = new AutoRespawnListener(this);
         pluginManager.registerEvents(this.autoRespawnListener, this);
         this.autoRespawnListener.reload();
      });
      this.runSafely("gameplay integrity", () -> pluginManager.registerEvents(new GameplayIntegrityListener(), this));
      this.runSafely("command fork limit", () -> {
         CommandForkLimitListener commandForkLimitListener = new CommandForkLimitListener();
         commandForkLimitListener.apply(this.getServer().getWorlds());
         pluginManager.registerEvents(commandForkLimitListener, this);
      });
      this.runSafely("explosion terrain protection", () -> pluginManager.registerEvents(new ExplosionTerrainListener(), this));
      this.runSafely("auto menu", () -> {
         this.autoMenuListener = new AutoMenuListener(this);
         pluginManager.registerEvents(this.autoMenuListener, this);
      });
      this.runSafely("low tps commands", () -> {
         this.lowTpsCommandListener = new LowTpsCommandListener(this);
         pluginManager.registerEvents(this.lowTpsCommandListener, this);
      });
      this.runSafely("head placement", () -> pluginManager.registerEvents(new HeadPlacementListener(), this));
      this.runSafely("fawe dupe fix", () -> {
         this.faweDupeFixListener = new FaweDupeFixListener(this);
         pluginManager.registerEvents(this.faweDupeFixListener, this);
      });
      this.runSafely("fishing rod pull", () -> pluginManager.registerEvents(new FishingRodPullListener(), this));
      this.runSafely("server message silencer", () -> pluginManager.registerEvents(new ServerMessageSilencer(), this));
      this.runSafely("anti exploit listener", () -> pluginManager.registerEvents(new AntiExploitListener(this.commandProtectionManager), this));
      this.runSafely("anti exploit packet guard", () -> {
         this.antiExploitPacketGuard = new AntiExploitPacketGuard(this, this.commandProtectionManager);
         pluginManager.registerEvents(this.antiExploitPacketGuard, this);
         this.antiExploitPacketGuard.injectOnlinePlayers();
      });
      this.runSafely("command protection listener", () -> pluginManager.registerEvents(new CommandProtectionListener(this.commandProtectionManager), this));
      this.runSafely("trident anti dupe", () -> {
         this.tridentAntiDupeListener = new TridentAntiDupeListener();
         pluginManager.registerEvents(this.tridentAntiDupeListener, this);
      });
      this.setupVoiceMuteManager(pluginManager);
      this.runSafely("placeholder api", () -> this.registerPlaceholderApi(pluginManager));
      this.log("&fCloudUtils &aуспешно загружен!");
   }

   public void onDisable() {
      if (this.elytraFlyListener != null) {
         this.elytraFlyListener.close();
      }

      if (this.recipeGuiDisabler != null) {
         this.recipeGuiDisabler.shutdown();
      }

      if (this.autoRespawnListener != null) {
         this.autoRespawnListener.close();
      }

      if (this.voiceMuteManager != null) {
         this.voiceMuteManager.disable();
      }

      if (this.specCommand != null) {
         this.specCommand.shutdown();
      }

      if (this.portalListener != null) {
         this.portalListener.clearCache();
      }

      if (this.autoMenuListener != null) {
         this.autoMenuListener.flushPendingSaves();
      }

      if (this.tridentAntiDupeListener != null) {
         this.tridentAntiDupeListener.clear();
      }

      if (this.antiExploitPacketGuard != null) {
         this.antiExploitPacketGuard.shutdown();
      }

      if (this.commandProtectionManager != null) {
         this.commandProtectionManager.clearCache();
      }

      this.getServer().getScheduler().cancelTasks(this);
      this.log("&fCloudUtils &cуспешно выгружен!");
   }

   public void reloadPlugin() {
      this.configManager.reload();
      this.runSafely("admin reload", () -> {
         if (this.adminCommand != null) {
            this.adminCommand.reload();
         }
      });
      this.runSafely("auto respawn reload", () -> {
         if (this.autoRespawnListener != null) {
            this.autoRespawnListener.reload();
         }
      });
      this.runSafely("portal reload", () -> {
         if (this.portalManager != null) {
            this.portalManager.reload();
         }

         if (this.portalListener != null) {
            this.portalListener.reload();
         }
      });
      this.runSafely("auto menu reload", () -> {
         if (this.autoMenuListener != null) {
            this.autoMenuListener.reload();
         }
      });
      this.runSafely("low tps reload", () -> {
         if (this.lowTpsCommandListener != null) {
            this.lowTpsCommandListener.reload();
         }
      });
      this.runSafely("fawe dupe reload", () -> {
         if (this.faweDupeFixListener != null) {
            this.faweDupeFixListener.reload();
         }
      });
      this.runSafely("voice reload", () -> {
         if (this.voiceMuteManager != null) {
            this.voiceMuteManager.reload();
         }
      });
      this.runSafely("command protection reload", () -> {
         if (this.commandProtectionManager != null) {
            this.commandProtectionManager.reload();
            this.commandProtectionManager.refreshOnlineCommands();
         }

         if (this.antiExploitPacketGuard != null) {
            this.antiExploitPacketGuard.reload();
            this.antiExploitPacketGuard.injectOnlinePlayers();
         }
      });
      this.runSafely("repairexp reload", () -> {
         if (this.repairExpCommand != null) {
            this.repairExpCommand.reload();
         }
      });
      this.runSafely("near reload", () -> {
         if (this.nearCommand != null) {
            this.nearCommand.reload();
         }
      });
      this.runSafely("vault reload", () -> {
         if (this.baltop != null) {
            this.baltop.reload();
         }
      });
      this.runSafely("cashback reload", () -> {
         if (this.cashbackCommand != null) {
            this.cashbackCommand.reload();
         }
      });
      this.runSafely("crystal damage reload", () -> {
         if (this.endCrystalDamageListener != null) {
            this.endCrystalDamageListener.reload();
         }
      });
      this.runSafely("spec reload", () -> {
         if (this.specCommand != null) {
            this.specCommand.reload();
         }
      });
   }

   private void setupVaultCommands() {
      if (!this.getServer().getPluginManager().isPluginEnabled("Vault")) {
         CommandExecutor disabled = new CloudUtils.DisabledFeatureCommand("&6Баланс &7» &cэкономика Vault не подключена, команды баланса отключены");
         this.registerCommand("pay", disabled);
         this.registerCommand("bal", disabled);
         this.registerCommand("balance", disabled);
         this.registerCommand("money", disabled);
         this.registerCommand("baltop", disabled);
         this.registerCommand("balancetop", disabled);
         this.getLogger().warning("Vault API не найден: команды баланса отключены, CloudUtils продолжает работать.");
      } else {
         this.runSafely("vault commands", () -> {
            this.baltop = new Baltop(this);
            this.registerCommand("pay", this.baltop);
            this.registerCommand("bal", this.baltop);
            this.registerCommand("balance", this.baltop);
            this.registerCommand("money", this.baltop);
            this.registerCommand("baltop", this.baltop);
            this.registerCommand("balancetop", this.baltop);
         });
      }
   }

   private void setupVoiceMuteManager(PluginManager pluginManager) {
      if (this.configManager.getBoolean("voice.mute-sync.enabled", false)) {
         if (pluginManager.isPluginEnabled("voicechat") && pluginManager.isPluginEnabled("LiteBans")) {
            this.runSafely("voice mute manager", () -> {
               this.voiceMuteManager = new VoiceMuteManager(this);
               pluginManager.registerEvents(this.voiceMuteManager, this);
               this.voiceMuteManager.enable();
            });
         } else {
            this.getLogger().warning("voicechat/LiteBans API не найден: синхронизация mute голосового чата отключена, CloudUtils продолжает работать.");
         }
      }
   }

   private void setupPortals(PluginManager pluginManager) {
      if (pluginManager.isPluginEnabled("WorldGuard")) {
         this.portalManager = new PortalManager(this);
         this.portalListener = new PortalListener(this, this.portalManager);
         pluginManager.registerEvents(this.portalListener, this);
      }
   }

   private void registerCommand(String name, CommandExecutor executor) {
      PluginCommand command = this.getCommand(name);
      if (command != null) {
         command.setExecutor(executor);
         if (executor instanceof TabCompleter) {
            command.setTabCompleter((TabCompleter)executor);
         }
      }
   }

   private void log(String message) {
      Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', message));
   }

   private void runSafely(String featureName, Runnable action) {
      try {
         action.run();
      } catch (Throwable throwable) {
         this.getLogger()
            .warning("CloudUtils: модуль '" + featureName + "' не загружен: " + throwable.getClass().getSimpleName() + ": " + throwable.getMessage());
      }
   }

   private void registerPlaceholderApi(PluginManager pluginManager) {
      if (this.voiceMuteManager != null && pluginManager.isPluginEnabled("PlaceholderAPI")) {
         new VoicePlaceholder(this).register();
      }
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public VoiceMuteManager getVoiceMuteManager() {
      return this.voiceMuteManager;
   }

   public PortalManager getPortalManager() {
      return this.portalManager;
   }

   public CommandProtectionManager getCommandProtectionManager() {
      return this.commandProtectionManager;
   }

   public AntiExploitPacketGuard getAntiExploitPacketGuard() {
      return this.antiExploitPacketGuard;
   }

   private final class DisabledFeatureCommand implements CommandExecutor {
      private final String message;

      private DisabledFeatureCommand(String message) {
         this.message = ChatColor.translateAlternateColorCodes('&', message);
      }

      public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
         sender.sendMessage(this.message);
         return true;
      }
   }
}
