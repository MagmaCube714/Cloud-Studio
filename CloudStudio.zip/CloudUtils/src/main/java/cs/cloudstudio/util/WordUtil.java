package cs.cloudstudio.util;

public final class WordUtil {
   private WordUtil() {
   }

   public static String declineBroken(int count) {
      int mod10 = count % 10;
      int mod100 = count % 100;
      return mod10 == 1 && mod100 != 11 ? "Поломан" : "Поломано";
   }

   public static String declineItem(int count) {
      int mod10 = count % 10;
      int mod100 = count % 100;
      if (mod10 == 1 && mod100 != 11) {
         return "предмет";
      } else {
         return mod10 < 2 || mod10 > 4 || mod100 >= 10 && mod100 < 20 ? "предметов" : "предмета";
      }
   }

   public static String declineLevel(int count) {
      int mod10 = count % 10;
      int mod100 = count % 100;
      if (mod10 == 1 && mod100 != 11) {
         return "уровень";
      } else {
         return mod10 < 2 || mod10 > 4 || mod100 >= 10 && mod100 < 20 ? "уровней" : "уровня";
      }
   }

   public static String decline(int number, String one, String few, String many) {
      int value = Math.abs(number) % 100;
      int last = value % 10;
      if (value > 10 && value < 20) {
         return many;
      } else if (last == 1) {
         return one;
      } else {
         return last >= 2 && last <= 4 ? few : many;
      }
   }
}
