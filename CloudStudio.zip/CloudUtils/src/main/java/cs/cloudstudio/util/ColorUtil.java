package cs.cloudstudio.util;

public final class ColorUtil {
   private static final char ALT_COLOR_CHAR = '&';
   private static final char COLOR_CHAR = '§';

   private ColorUtil() {
   }

   public static String colorize(String message) {
      if (message != null && !message.isEmpty() && message.indexOf(38) >= 0) {
         char[] chars = message.toCharArray();
         int i = 0;

         for (int max = chars.length - 1; i < max; i++) {
            if (chars[i] == '&' && isValidColorCharacter(chars[i + 1])) {
               chars[i] = 167;
               chars[i + 1] = Character.toLowerCase(chars[i + 1]);
            }
         }

         return new String(chars);
      } else {
         return message == null ? "" : message;
      }
   }

   private static boolean isValidColorCharacter(char c) {
      char lower = Character.toLowerCase(c);
      return lower >= '0' && lower <= '9'
         || lower >= 'a' && lower <= 'f'
         || lower == 'r'
         || lower == 'k'
         || lower == 'l'
         || lower == 'm'
         || lower == 'n'
         || lower == 'o';
   }
}
