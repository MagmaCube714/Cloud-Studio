package cs.cloudstudio.util;

import io.netty.channel.Channel;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;

public final class PlayerChannelResolver {
   private static final Map<UUID, Channel> CHANNELS = new ConcurrentHashMap<>();
   private static final Map<Class<?>, Field[]> FIELD_CACHE = new ConcurrentHashMap<>();
   private static volatile Field[] PATH;

   public static Channel get(Player player) {
      if (player == null) {
         return null;
      }

      UUID uuid = player.getUniqueId();
      Channel cached = CHANNELS.get(uuid);
      if (cached != null) {
         if (cached.isOpen()) {
            return cached;
         }

         CHANNELS.remove(uuid, cached);
      }

      try {
         Object handle = player.getClass().getMethod("getHandle").invoke(player);
         Channel channel = followPath(handle);
         if (channel == null) {
            Set<Object> seen = Collections.newSetFromMap(new IdentityHashMap<>());
            List<Field> path = new ArrayList<>();
            channel = find(handle, 0, seen, path);
            if (channel != null) {
               PATH = path.toArray(new Field[0]);
            }
         }

         if (channel != null) {
            CHANNELS.put(uuid, channel);
         }

         return channel;
      } catch (Throwable ignored) {
         return null;
      }
   }

   /** Канал по пути полей, найденному поиском у прошлого игрока (у всех игроков одни и те же классы). */
   private static Channel followPath(Object handle) {
      Field[] path = PATH;
      if (path == null) {
         return null;
      }

      Object value = handle;
      for (Field field : path) {
         if (value == null || !field.getDeclaringClass().isInstance(value)) {
            return null;
         }

         try {
            value = field.get(value);
         } catch (Throwable ignored) {
            return null;
         }
      }

      return value instanceof Channel channel ? channel : null;
   }

   public static void evict(UUID uuid) {
      if (uuid != null) {
         CHANNELS.remove(uuid);
      }
   }

   public static void clear() {
      CHANNELS.clear();
      FIELD_CACHE.clear();
      PATH = null;
   }

   private static Channel find(Object source, int depth, Set<Object> seen, List<Field> path) {
      if (source != null && depth <= 3 && seen.add(source)) {
         for (Field field : fields(source.getClass())) {
            Object value;
            try {
               value = field.get(source);
            } catch (Throwable ignored) {
               continue;
            }

            if (value instanceof Channel) {
               path.add(field);
               return (Channel)value;
            }

            if (value != null && depth < 3 && isServerInternal(value.getClass())) {
               path.add(field);
               Channel nested = find(value, depth + 1, seen, path);
               if (nested != null) {
                  return nested;
               }
               path.remove(path.size() - 1);
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static Field[] fields(Class<?> type) {
      return FIELD_CACHE.computeIfAbsent(type, key -> {
         List<Field> fields = new ArrayList<>();

         for (Class<?> current = (Class<?>)key; current != null && current != Object.class; current = current.getSuperclass()) {
            for (Field field : current.getDeclaredFields()) {
               if (!Modifier.isStatic(field.getModifiers())) {
                  try {
                     field.setAccessible(true);
                     fields.add(field);
                  } catch (Throwable var8) {
                  }
               }
            }
         }

         return fields.toArray(new Field[0]);
      });
   }

   private static boolean isServerInternal(Class<?> type) {
      String name = type.getName();
      return name.startsWith("net.minecraft.") || name.startsWith("org.bukkit.craftbukkit.");
   }

   private PlayerChannelResolver() {
   }
}
