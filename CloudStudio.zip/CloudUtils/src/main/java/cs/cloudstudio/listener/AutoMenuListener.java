package cs.cloudstudio.listener;

import cs.cloudstudio.CloudUtils;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

public final class AutoMenuListener implements Listener {
   private static final long SAVE_DELAY_TICKS = 100L;
   private final CloudUtils plugin;
   private final File openedPlayersFile;
   private final Set<UUID> openedPlayers = new HashSet<>();
   private final Set<UUID> pendingPlayers = new HashSet<>();
   private final Set<UUID> unsavedPlayers = new LinkedHashSet<>();
   private BukkitTask saveTask;
   private boolean asyncSaveRunning;
   private long delayTicks;
   private String commandTemplate;

   public AutoMenuListener(CloudUtils plugin) {
      this.plugin = plugin;
      this.openedPlayersFile = new File(plugin.getDataFolder(), "auto-menu-opened.txt");
      this.reload();
      this.loadOpenedPlayers();
   }

   public void reload() {
      this.delayTicks = Math.max(0L, this.plugin.getConfigManager().getLong("auto-menu.delay-ticks"));
      this.commandTemplate = this.plugin.getConfigManager().getString("auto-menu.command").trim();
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      UUID uuid = player.getUniqueId();
      if (!this.openedPlayers.contains(uuid) && !this.pendingPlayers.contains(uuid)) {
         String command = this.commandTemplate.replace("{player}", player.getName()).trim();
         if (!command.isEmpty()) {
            this.pendingPlayers.add(uuid);
            this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
               this.pendingPlayers.remove(uuid);
               if (!this.openedPlayers.contains(uuid)) {
                  Player online = Bukkit.getPlayer(uuid);
                  if (online != null && online.isOnline()) {
                     Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
                     this.markOpened(uuid);
                  }
               }
            }, this.delayTicks);
         }
      }
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      this.pendingPlayers.remove(event.getPlayer().getUniqueId());
   }

   public void flushPendingSaves() {
      if (this.saveTask != null) {
         this.saveTask.cancel();
         this.saveTask = null;
      }

      if (!this.unsavedPlayers.isEmpty()) {
         List<UUID> snapshot = new ArrayList<>(this.unsavedPlayers);
         this.unsavedPlayers.clear();
         if (!this.writeSnapshot(snapshot)) {
            this.unsavedPlayers.addAll(snapshot);
         }
      }
   }

   private void markOpened(UUID uuid) {
      if (this.openedPlayers.add(uuid)) {
         this.unsavedPlayers.add(uuid);
         this.scheduleSave();
      }
   }

   private void scheduleSave() {
      if (this.saveTask == null && !this.asyncSaveRunning && !this.unsavedPlayers.isEmpty()) {
         this.saveTask = this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
            this.saveTask = null;
            this.saveAsync();
         }, 100L);
      }
   }

   private void saveAsync() {
      if (!this.unsavedPlayers.isEmpty() && !this.asyncSaveRunning && this.plugin.isEnabled()) {
         List<UUID> snapshot = new ArrayList<>(this.unsavedPlayers);
         this.unsavedPlayers.clear();
         this.asyncSaveRunning = true;
         this.plugin.getServer().getScheduler().runTaskAsynchronously(this.plugin, () -> {
            boolean success = this.writeSnapshot(snapshot);
            if (this.plugin.isEnabled()) {
               this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
                  this.asyncSaveRunning = false;
                  if (!success) {
                     this.unsavedPlayers.addAll(snapshot);
                  }

                  if (!this.unsavedPlayers.isEmpty()) {
                     this.scheduleSave();
                  }
               });
            }
         });
      }
   }

   private boolean writeSnapshot(List<UUID> uuids) {
      if (uuids.isEmpty()) {
         return true;
      }

      Path path = this.openedPlayersFile.toPath();

      try {
         Files.createDirectories(path.getParent());

         try (BufferedWriter writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            for (UUID uuid : uuids) {
               writer.write(uuid.toString());
               writer.newLine();
            }
         }

         return true;
      } catch (IOException exception) {
         this.plugin.getLogger().warning("[CloudUtils] Не удалось сохранить список игроков auto-menu: " + exception.getMessage());
         return false;
      }
   }

   private void loadOpenedPlayers() {
      if (this.openedPlayersFile.isFile()) {
         String line;
         try (BufferedReader reader = Files.newBufferedReader(this.openedPlayersFile.toPath(), StandardCharsets.UTF_8)) {
            while ((line = reader.readLine()) != null) {
               String value = line.trim();
               if (!value.isEmpty() && !value.startsWith("#")) {
                  try {
                     this.openedPlayers.add(UUID.fromString(value));
                  } catch (IllegalArgumentException ignored) {
                     this.plugin.getLogger().warning("[CloudUtils] Некорректный UUID в auto-menu-opened.txt: " + value);
                  }
               }
            }
         } catch (IOException exception) {
            this.plugin.getLogger().warning("[CloudUtils] Не удалось загрузить список игроков auto-menu: " + exception.getMessage());
         }
      }
   }
}
