package cs.cloudstudio.listener;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.config.ConfigManager;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public final class EndCrystalDamageListener implements Listener {
   private final ConfigManager config;
   private boolean enabled;
   private double damage;

   public EndCrystalDamageListener(CloudUtils plugin) {
      this.config = plugin.getConfigManager();
      this.reload();
   }

   public void reload() {
      this.enabled = this.config.getBoolean("crystal_damage.enabled", true);
      double configuredDamage = this.config.getDouble("crystal_damage.damage", 6.0);
      if (Double.isNaN(configuredDamage) || Double.isInfinite(configuredDamage) || configuredDamage < 0.0) {
         configuredDamage = 0.0;
      }

      this.damage = configuredDamage;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onEndCrystalDamage(EntityDamageByEntityEvent event) {
      if (this.enabled) {
         if (event.getDamager() instanceof EnderCrystal) {
            if (this.damage <= 0.0) {
               event.setCancelled(true);
            } else {
               event.setDamage(this.damage);
            }
         }
      }
   }
}
