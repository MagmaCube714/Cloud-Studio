package cs.cloudstudio.listener;

import cs.cloudstudio.util.PlayerChannelResolver;
import io.netty.channel.Channel;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.ChannelPromise;
import io.netty.channel.ChannelHandler.Sharable;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class RecipeGuiDisabler implements Listener {
   private static final String HANDLER_NAME = "cloudutils_recipe_filter";
   private static final String PACKET_HANDLER = "packet_handler";
   private static final RecipeGuiDisabler.RecipePacketFilter RECIPE_FILTER = new RecipeGuiDisabler.RecipePacketFilter();
   private final JavaPlugin plugin;
   private final Map<UUID, Channel> playerChannels = new ConcurrentHashMap<>();

   public RecipeGuiDisabler(JavaPlugin plugin) {
      this.plugin = plugin;

      for (Player player : plugin.getServer().getOnlinePlayers()) {
         this.inject(player);
      }
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      this.inject(event.getPlayer());
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.uninject(event.getPlayer());
   }

   public void shutdown() {
      for (Player player : this.plugin.getServer().getOnlinePlayers()) {
         this.uninject(player);
      }

      this.playerChannels.clear();
   }

   private void inject(Player player) {
      Channel channel = PlayerChannelResolver.get(player);
      if (channel != null && channel.isOpen()) {
         this.playerChannels.put(player.getUniqueId(), channel);
         if (channel.eventLoop().inEventLoop()) {
            this.inject(channel);
         } else {
            channel.eventLoop().execute(() -> this.inject(channel));
         }
      }
   }

   private void inject(Channel channel) {
      if (channel.isOpen()) {
         ChannelPipeline pipeline = channel.pipeline();
         if (pipeline.get("cloudutils_recipe_filter") == null) {
            if (pipeline.get("packet_handler") != null) {
               pipeline.addBefore("packet_handler", "cloudutils_recipe_filter", RECIPE_FILTER);
            } else {
               pipeline.addLast("cloudutils_recipe_filter", RECIPE_FILTER);
            }
         }
      }
   }

   private void uninject(Player player) {
      Channel cached = this.playerChannels.remove(player.getUniqueId());
      Channel channel = cached == null ? PlayerChannelResolver.get(player) : cached;
      PlayerChannelResolver.evict(player.getUniqueId());
      if (channel != null && channel.isOpen()) {
         if (channel.eventLoop().inEventLoop()) {
            this.uninject(channel);
         } else {
            channel.eventLoop().execute(() -> this.uninject(channel));
         }
      }
   }

   private void uninject(Channel channel) {
      if (channel.isOpen()) {
         ChannelPipeline pipeline = channel.pipeline();
         ChannelHandler handler = pipeline.get("cloudutils_recipe_filter");
         if (handler != null) {
            pipeline.remove(handler);
         }
      }
   }

   @Sharable
   private static final class RecipePacketFilter extends ChannelDuplexHandler {
      public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
         if (msg != null && isRecipePacket(msg.getClass().getSimpleName())) {
            promise.trySuccess();
         } else {
            super.write(ctx, msg, promise);
         }
      }

      private static boolean isRecipePacket(String simpleName) {
         return simpleName.equals("PacketPlayOutRecipes")
            || simpleName.equals("PacketPlayOutRecipeUpdate")
            || simpleName.equals("ClientboundUpdateRecipesPacket")
            || simpleName.startsWith("ClientboundRecipeBook");
      }
   }
}
