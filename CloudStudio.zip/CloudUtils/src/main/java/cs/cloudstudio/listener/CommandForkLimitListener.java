package cs.cloudstudio.listener;

import java.util.Collection;
import org.bukkit.GameRule;
import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.WorldLoadEvent;

public final class CommandForkLimitListener implements Listener {
   private static final int MINIMUM_FORK_LIMIT = 65536;

   public void apply(Collection<World> worlds) {
      for (World world : worlds) {
         this.apply(world);
      }
   }

   @EventHandler
   public void onWorldLoad(WorldLoadEvent event) {
      this.apply(event.getWorld());
   }

   private void apply(World world) {
      Integer current = (Integer)world.getGameRuleValue(GameRule.MAX_COMMAND_FORK_COUNT);
      if (current == null || current < 65536) {
         world.setGameRule(GameRule.MAX_COMMAND_FORK_COUNT, 65536);
      }
   }
}
