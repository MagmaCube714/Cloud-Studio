package cs.cloudstudio.listener;

import cs.cloudstudio.manager.CommandProtectionManager;
import cs.cloudstudio.util.ExploitPayloadUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerCommandSendEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.TabCompleteEvent;

public final class CommandProtectionListener implements Listener {
   private final CommandProtectionManager manager;

   public CommandProtectionListener(CommandProtectionManager manager) {
      this.manager = manager;
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
      if (this.manager.isEnabled()) {
         Player player = event.getPlayer();
         String message = event.getMessage();
         String label = this.manager.getLabel(message);
         boolean bypass = this.manager.hasBypass(player);
         if (!bypass) {
            if (!this.manager.isBlockedOrNamespacedCommandLine(message) && !ExploitPayloadUtil.isPluginListCommand(message)) {
               CommandProtectionManager.CommandAccess access = this.manager.getAccess(player);
               if (!this.manager.isCommandAllowed(access, message)) {
                  this.denyCommand(event, player, label);
               }
            } else {
               event.setCancelled(true);
               String denied = this.manager.getBlockedCommandMessage(label);
               if (!denied.isEmpty()) {
                  player.sendMessage(denied);
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onPlayerCommandSend(PlayerCommandSendEvent event) {
      if (this.manager.isEnabled()) {
         Player player = event.getPlayer();
         if (!this.manager.hasBypass(player)) {
            CommandProtectionManager.CommandAccess access = this.manager.getAccess(player);
            Collection<String> commands = event.getCommands();
            if (access.allowsAllCommands()) {
               this.removeUnsafeCompletions(commands);
            } else {
               Iterator<String> iterator = commands.iterator();

               while (iterator.hasNext()) {
                  String command = iterator.next();
                  if (this.isUnsafeCompletion(command) || !this.manager.isRootCompletionAllowed(access, command)) {
                     iterator.remove();
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onTabComplete(TabCompleteEvent event) {
      if (this.manager.isEnabled() && event.getSender() instanceof Player) {
         Player player = (Player)event.getSender();
         boolean bypass = this.manager.hasBypass(player);
         String buffer = event.getBuffer();
         if (buffer == null) {
            clearTab(event);
         } else if (buffer.startsWith("/")) {
            if (!bypass) {
               if (!this.manager.isBlockedOrNamespacedCommandLine(buffer) && !ExploitPayloadUtil.isPluginListCommand(buffer)) {
                  CommandProtectionManager.CommandAccess access = this.manager.getAccess(player);
                  if (!hasArguments(buffer)) {
                     event.setCancelled(false);
                     if (access.allowsAllCommands()) {
                        this.removeUnsafeCompletions(event.getCompletions());
                     } else {
                        event.setCompletions(this.getRootTabCompletions(access, buffer));
                     }
                  } else if (event.isCancelled()) {
                     clearTab(event);
                  } else if (access.allowsAllCommands()) {
                     this.removeUnsafeCompletions(event.getCompletions());
                  } else {
                     boolean rootAllowed = this.manager.isCommandAllowed(access, buffer);
                     if (!rootAllowed) {
                        clearTab(event);
                     } else {
                        List<String> completions = event.getCompletions();
                        if (!completions.isEmpty()) {
                           List<String> filtered = new ArrayList<>(completions.size());

                           for (String completion : completions) {
                              boolean allowed = this.manager.isArgumentCompletionAllowed(access, buffer, completion);
                              if (allowed && !this.isUnsafeCompletion(completion)) {
                                 filtered.add(completion);
                              }
                           }

                           event.setCompletions(filtered.isEmpty() ? Collections.emptyList() : filtered);
                        }
                     }
                  }
               } else {
                  clearTab(event);
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onQuit(PlayerQuitEvent event) {
      this.manager.clearPlayer(event.getPlayer().getUniqueId());
   }

   private void denyCommand(PlayerCommandPreprocessEvent event, Player player, String label) {
      event.setCancelled(true);
      String denied = this.manager.getCommandDeniedMessage(label);
      if (!denied.isEmpty()) {
         player.sendMessage(denied);
      }
   }

   private static void clearTab(TabCompleteEvent event) {
      event.setCancelled(true);
      event.setCompletions(Collections.emptyList());
   }

   private void removeUnsafeCompletions(Collection<String> completions) {
      Iterator<String> iterator = completions.iterator();

      while (iterator.hasNext()) {
         if (this.isUnsafeCompletion(iterator.next())) {
            iterator.remove();
         }
      }
   }

   private List<String> getRootTabCompletions(CommandProtectionManager.CommandAccess access, String buffer) {
      List<String> roots = this.manager.getRootCompletions(access, buffer, false);
      if (roots.isEmpty()) {
         return roots;
      }

      List<String> result = new ArrayList<>(roots.size());

      for (String root : roots) {
         if (root.startsWith("/")) {
            result.add(root);
         } else {
            result.add("/" + root);
         }
      }

      return result;
   }

   private boolean isUnsafeCompletion(String command) {
      return this.manager.isUnsafeCompletion(command);
   }

   private static boolean hasArguments(String buffer) {
      int start = buffer.startsWith("/") ? 1 : 0;

      for (int i = start; i < buffer.length(); i++) {
         if (buffer.charAt(i) <= ' ') {
            return true;
         }
      }

      return false;
   }
}
