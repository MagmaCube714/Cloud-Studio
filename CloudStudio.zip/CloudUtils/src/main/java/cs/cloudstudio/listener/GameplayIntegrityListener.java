package cs.cloudstudio.listener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent.RegainReason;
import org.bukkit.inventory.ItemStack;

public final class GameplayIntegrityListener implements Listener {
   private final Map<UUID, List<ItemStack>> deathInventories = new HashMap<>();

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onRegainHealth(EntityRegainHealthEvent event) {
      if (event.getEntity() instanceof Player && event.getRegainReason() != RegainReason.CUSTOM) {
         event.setCancelled(false);
      }
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void captureDeathInventory(PlayerDeathEvent event) {
      List<ItemStack> items = new ArrayList<>();

      for (ItemStack item : event.getEntity().getInventory().getContents()) {
         if (item != null && item.getType() != Material.AIR && item.getAmount() > 0 && !item.containsEnchantment(Enchantment.VANISHING_CURSE)) {
            items.add(item.clone());
         }
      }

      this.deathInventories.put(event.getEntity().getUniqueId(), items);
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void restoreDeathDrops(PlayerDeathEvent event) {
      List<ItemStack> items = this.deathInventories.remove(event.getEntity().getUniqueId());
      event.setKeepInventory(false);
      if (event.getDrops().isEmpty() && items != null && !items.isEmpty()) {
         event.getDrops().addAll(items);
      }
   }
}
