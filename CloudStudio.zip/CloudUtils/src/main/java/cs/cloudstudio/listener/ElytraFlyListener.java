package cs.cloudstudio.listener;

import com.destroystokyo.paper.event.player.PlayerArmorChangeEvent;
import com.earth2me.essentials.Essentials;
import com.earth2me.essentials.User;
import cs.cloudstudio.CloudUtils;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.ess3.api.events.FlyStatusChangeEvent;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.event.EventSubscription;
import net.luckperms.api.event.user.UserDataRecalculateEvent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public final class ElytraFlyListener implements Listener, AutoCloseable {
   private static final String PERMISSION = "cloudutils.elytrafly";
   private static final String DEFAULT_MESSAGE = "&6Полет &7» &cДля полёта нужно надеть элитры";
   private final CloudUtils plugin;
   private final Essentials essentials;
   private final Set<UUID> pending = ConcurrentHashMap.newKeySet();
   private EventSubscription<UserDataRecalculateEvent> permissionSubscription;

   public ElytraFlyListener(CloudUtils plugin, Essentials essentials) {
      this.plugin = plugin;
      this.essentials = essentials;
   }

   public void start() {
      if (Bukkit.getPluginManager().isPluginEnabled("LuckPerms")) {
         this.permissionSubscription = LuckPermsProvider.get()
            .getEventBus()
            .subscribe(this.plugin, UserDataRecalculateEvent.class, event -> this.scheduleCheck(event.getUser().getUniqueId()));
      }

      for (Player player : Bukkit.getOnlinePlayers()) {
         this.scheduleCheck(player.getUniqueId());
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onEssentialsFly(FlyStatusChangeEvent event) {
      Player player = event.getAffected().getBase();
      if (event.getValue() && this.requiresElytra(player)) {
         event.setCancelled(true);
         this.disableFlight(player);
         this.sendRequiredMessage(player);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onToggleFlight(PlayerToggleFlightEvent event) {
      if (event.isFlying() && this.requiresElytra(event.getPlayer())) {
         event.setCancelled(true);
         this.disableFlight(event.getPlayer());
         this.sendRequiredMessage(event.getPlayer());
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onArmorChange(PlayerArmorChangeEvent event) {
      if (event.getSlot() == EquipmentSlot.CHEST) {
         this.scheduleCheck(event.getPlayer().getUniqueId());
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onJoin(PlayerJoinEvent event) {
      this.scheduleCheck(event.getPlayer().getUniqueId());
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onRespawn(PlayerRespawnEvent event) {
      this.scheduleCheck(event.getPlayer().getUniqueId());
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onWorldChange(PlayerChangedWorldEvent event) {
      this.scheduleCheck(event.getPlayer().getUniqueId());
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onGameModeChange(PlayerGameModeChangeEvent event) {
      this.scheduleCheck(event.getPlayer().getUniqueId());
   }

   private void scheduleCheck(UUID playerId) {
      if (this.plugin.isEnabled() && this.pending.add(playerId)) {
         Bukkit.getScheduler().runTask(this.plugin, () -> {
            this.pending.remove(playerId);
            Player player = Bukkit.getPlayer(playerId);
            if (player != null && player.isOnline() && this.requiresElytra(player)) {
               User user = this.essentials.getUser(player);
               if (player.getAllowFlight() || player.isFlying() || user.isFlyModeEnabled()) {
                  this.disableFlight(player);
                  this.sendRequiredMessage(player);
               }
            }
         });
      }
   }

   private boolean requiresElytra(Player player) {
      if (player != null
         && player.hasPermission("cloudutils.elytrafly")
         && player.getGameMode() != GameMode.CREATIVE
         && player.getGameMode() != GameMode.SPECTATOR) {
         ItemStack chest = player.getInventory().getChestplate();
         return chest == null || chest.getType() != Material.ELYTRA;
      } else {
         return false;
      }
   }

   private void disableFlight(Player player) {
      User user = this.essentials.getUser(player);
      if (user.isFlyModeEnabled()) {
         user.setFlyModeEnabled(false);
      }

      player.setFlying(false);
      player.setAllowFlight(false);
      player.setFallDistance(0.0F);
   }

   private void sendRequiredMessage(Player player) {
      String message = this.plugin.getConfig().getString("messages.elytra-fly-required", "&6Полет &7» &cДля полёта нужно надеть элитры");
      player.sendMessage(ChatColor.translateAlternateColorCodes('&', message));
   }

   @Override
   public void close() {
      if (this.permissionSubscription != null) {
         this.permissionSubscription.close();
      }

      this.pending.clear();
   }
}
