package cs.cloudstudio.listener;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.config.ConfigManager;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public final class LowTpsCommandListener implements Listener {
   private final CloudUtils plugin;
   private long lastTpsCheck;
   private double cachedTps = 20.0;
   private Set<String> blockedCommands = Collections.emptySet();
   private List<String> message = Collections.emptyList();
   private double threshold;

   public LowTpsCommandListener(CloudUtils plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.blockedCommands = this.plugin.getConfigManager().getNormalizedCommandSet("low-tps-commands.commands");
      this.message = this.plugin.getConfigManager().getColoredStringList("low-tps-commands.message");
      this.threshold = this.plugin.getConfigManager().getDouble("low-tps-commands.tps-threshold");
      this.lastTpsCheck = 0L;
      this.cachedTps = 20.0;
   }

   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
   public void onCommand(PlayerCommandPreprocessEvent event) {
      if (!this.blockedCommands.isEmpty() && !(this.threshold <= 0.0)) {
         String command = ConfigManager.normalizeCommand(event.getMessage());
         if (this.blockedCommands.contains(command)) {
            long now = System.currentTimeMillis();
            if (now - this.lastTpsCheck >= 1000L) {
               this.cachedTps = this.getTps();
               this.lastTpsCheck = now;
            }

            if (!(this.cachedTps >= this.threshold)) {
               event.setCancelled(true);
               Player player = event.getPlayer();

               for (String line : this.message) {
                  if (!line.isEmpty()) {
                     player.sendMessage(line);
                  }
               }
            }
         }
      }
   }

   private double getTps() {
      double[] tps = Bukkit.getTPS();
      return tps.length == 0 ? 20.0 : tps[0];
   }
}
