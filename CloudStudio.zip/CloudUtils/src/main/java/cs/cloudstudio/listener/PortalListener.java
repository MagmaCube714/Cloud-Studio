package cs.cloudstudio.listener;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.manager.PortalManager;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PortalListener implements Listener {
   private static final String NO_REGION = "\u0000";
   private static final int DEFAULT_CACHE_SIZE = 4096;
   private final CloudUtils plugin;
   private final PortalManager portalManager;
   private final Map<UUID, String> playerRegions = new HashMap<>();
   private final Map<Long, String> regionCache = new LinkedHashMap<Long, String>(4096, 0.75F, true) {
      @Override
      protected boolean removeEldestEntry(Entry<Long, String> eldest) {
         return PortalListener.this.portalCacheSize > 0 && this.size() > PortalListener.this.portalCacheSize;
      }
   };
   private final RegionQuery regionQuery;
   private String portalWorld;
   private int portalCacheSize;

   public PortalListener(CloudUtils plugin, PortalManager portalManager) {
      this.plugin = plugin;
      this.portalManager = portalManager;
      this.regionQuery = WorldGuard.getInstance().getPlatform().getRegionContainer().createQuery();
      this.reload();
   }

   public void reload() {
      this.portalWorld = this.plugin.getConfigManager().getString("portals.settings.world");
      this.portalCacheSize = 4096;
      this.clearCache();
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onMove(PlayerMoveEvent event) {
      Location to = event.getTo();
      if (to != null) {
         Location from = event.getFrom();
         if (from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY() || from.getBlockZ() != to.getBlockZ() || from.getWorld() != to.getWorld()
            )
          {
            Player player = event.getPlayer();
            UUID uuid = player.getUniqueId();
            if (!this.portalWorld.isEmpty() && this.portalManager.hasAnyPortals() && to.getWorld() != null && this.portalWorld.equals(to.getWorld().getName())) {
               String regionName = this.getPortalRegion(to);
               String previousRegion = this.playerRegions.get(uuid);
               if (regionName == null) {
                  if (previousRegion != null) {
                     this.playerRegions.remove(uuid);
                  }
               } else {
                  if (!regionName.equals(previousRegion)) {
                     this.playerRegions.put(uuid, regionName);
                     this.portalManager.handlePortalEnter(player, regionName);
                  }
               }
            } else {
               this.playerRegions.remove(uuid);
            }
         }
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.playerRegions.remove(event.getPlayer().getUniqueId());
   }

   private String getPortalRegion(Location location) {
      if (this.portalCacheSize <= 0) {
         return this.findPortalRegion(this.regionQuery.getApplicableRegions(BukkitAdapter.adapt(location)));
      }

      long key = this.blockKey(location.getBlockX(), location.getBlockY(), location.getBlockZ());
      String cached = this.regionCache.get(key);
      if (cached != null) {
         return "\u0000".equals(cached) ? null : cached;
      }

      String regionName = this.findPortalRegion(this.regionQuery.getApplicableRegions(BukkitAdapter.adapt(location)));
      this.regionCache.put(key, regionName == null ? "\u0000" : regionName);
      return regionName;
   }

   private long blockKey(int x, int y, int z) {
      return (x & 67108863L) << 38 | (z & 67108863L) << 12 | y & 4095L;
   }

   private String findPortalRegion(ApplicableRegionSet regionSet) {
      for (ProtectedRegion region : regionSet) {
         String regionId = region.getId();
         if (this.portalManager.hasPortal(regionId)) {
            return regionId;
         }
      }

      return null;
   }

   public void clearCache() {
      this.playerRegions.clear();
      this.regionCache.clear();
   }
}
