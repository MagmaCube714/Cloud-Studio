package cs.cloudstudio.listener;

import org.bukkit.entity.FishHook;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerFishEvent.State;

public final class FishingRodPullListener implements Listener {
   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onFish(PlayerFishEvent event) {
      if (event.getState() == State.CAUGHT_ENTITY) {
         event.setCancelled(true);
         FishHook hook = event.getHook();
         if (hook != null && !hook.isDead()) {
            hook.remove();
         }
      }
   }
}
