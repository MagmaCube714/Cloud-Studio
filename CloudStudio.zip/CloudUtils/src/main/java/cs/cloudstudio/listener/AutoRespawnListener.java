package cs.cloudstudio.listener;

import cs.cloudstudio.CloudUtils;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public final class AutoRespawnListener implements Listener, AutoCloseable {
   private static final int MAX_TICKET_RADIUS = 4;
   private final CloudUtils plugin;
   private UUID ticketWorld;

   public AutoRespawnListener(CloudUtils plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onPlayerDeath(PlayerDeathEvent event) {
      UUID uuid = event.getEntity().getUniqueId();
      this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
         Player player = Bukkit.getPlayer(uuid);
         if (player != null && player.isOnline() && player.isDead()) {
            player.spigot().respawn();
         }
      }, 1L);
   }

   public void reload() {
      this.close();
      int radius = this.plugin.getConfigManager().getInt("auto-respawn.keep-spawn-chunks-radius", 1);
      if (radius >= 0) {
         World world = this.resolveSpawnWorld(this.plugin.getConfigManager().getString("auto-respawn.keep-spawn-chunks-world", ""));
         if (world != null) {
            radius = Math.min(radius, MAX_TICKET_RADIUS);
            Location spawn = world.getSpawnLocation();
            int centerX = spawn.getBlockX() >> 4;
            int centerZ = spawn.getBlockZ() >> 4;

            for (int dx = -radius; dx <= radius; dx++) {
               for (int dz = -radius; dz <= radius; dz++) {
                  world.addPluginChunkTicket(centerX + dx, centerZ + dz, this.plugin);
               }
            }

            this.ticketWorld = world.getUID();
         }
      }
   }

   private World resolveSpawnWorld(String worldName) {
      if (worldName != null && !worldName.isBlank()) {
         return Bukkit.getWorld(worldName.trim());
      }

      List<World> worlds = Bukkit.getWorlds();
      return worlds.isEmpty() ? null : worlds.get(0);
   }

   @Override
   public void close() {
      if (this.ticketWorld != null) {
         World world = Bukkit.getWorld(this.ticketWorld);
         if (world != null) {
            world.removePluginChunkTickets(this.plugin);
         }

         this.ticketWorld = null;
      }
   }
}
