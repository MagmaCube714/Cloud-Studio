package cs.cloudstudio.listener;

import cs.cloudstudio.CloudUtils;
import cs.cloudstudio.config.ConfigManager;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public final class FaweDupeFixListener implements Listener {
   private final CloudUtils plugin;
   private Set<String> commands = Collections.emptySet();
   private String message = "";

   public FaweDupeFixListener(CloudUtils plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      Set<String> rawCommands = this.plugin.getConfigManager().getNormalizedRawCommandSet("fawe-dupe-fix.commands");
      if (rawCommands.isEmpty()) {
         this.commands = Collections.emptySet();
      } else {
         HashSet<String> variants = new HashSet<>(rawCommands.size() * 4);

         for (String raw : rawCommands) {
            addVariants(variants, raw);
         }

         this.commands = Collections.unmodifiableSet(variants);
      }

      this.message = this.plugin.getConfigManager().getColoredString("fawe-dupe-fix.message");
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onCommand(PlayerCommandPreprocessEvent event) {
      if (!this.commands.isEmpty()) {
         String command = ConfigManager.normalizeRawCommand(event.getMessage());
         if (this.commands.contains(command) && event.getPlayer().getInventory().firstEmpty() == -1) {
            event.setCancelled(true);
            if (!this.message.isEmpty()) {
               event.getPlayer().sendMessage(this.message);
            }
         }
      }
   }

   private static void addVariants(Set<String> target, String command) {
      if (command != null && !command.isEmpty()) {
         String normalized = command.toLowerCase(Locale.ROOT);
         target.add(normalized);
         String withoutFirstSlash = normalized.startsWith("/") ? normalized.substring(1) : normalized;
         target.add(withoutFirstSlash);
         String withoutAllSlashes = withoutFirstSlash;

         while (withoutAllSlashes.startsWith("/")) {
            withoutAllSlashes = withoutAllSlashes.substring(1);
         }

         target.add(withoutAllSlashes);
         target.add(normalized.replace(":/", ":"));
         target.add(addSlashAfterColon(normalized));
         if (!normalized.startsWith("/")) {
            target.add("/" + normalized);
            target.add("//" + normalized);
         }
      }
   }

   private static String addSlashAfterColon(String command) {
      int colon = command.indexOf(58);
      return colon >= 0 && colon + 1 < command.length() && command.charAt(colon + 1) != '/'
         ? command.substring(0, colon + 1) + "/" + command.substring(colon + 1)
         : command;
   }
}
