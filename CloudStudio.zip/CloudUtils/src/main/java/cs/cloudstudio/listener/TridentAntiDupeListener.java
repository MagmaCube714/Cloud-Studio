package cs.cloudstudio.listener;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;

public final class TridentAntiDupeListener implements Listener {
   private static final long THROW_STATE_TTL_MS = 2000L;
   private final Map<UUID, Long> readyThrow = new HashMap<>();

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onPlayerInteract(PlayerInteractEvent event) {
      Action action = event.getAction();
      if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
         ItemStack item = event.getItem();
         if (item != null && item.getType() == Material.TRIDENT && !item.containsEnchantment(Enchantment.RIPTIDE)) {
            this.readyThrow.put(event.getPlayer().getUniqueId(), System.currentTimeMillis() + 2000L);
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onProjectileLaunch(ProjectileLaunchEvent event) {
      if (event.getEntity() instanceof Trident && event.getEntity().getShooter() instanceof Player) {
         this.readyThrow.remove(((Player)event.getEntity().getShooter()).getUniqueId());
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onPlayerItemHeld(PlayerItemHeldEvent event) {
      Player player = event.getPlayer();
      ItemStack item = player.getInventory().getItem(event.getNewSlot());
      if (item == null || item.getType() != Material.TRIDENT) {
         this.readyThrow.remove(player.getUniqueId());
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onInventoryClick(InventoryClickEvent event) {
      HumanEntity entity = event.getWhoClicked();
      if (this.isThrowPending(entity.getUniqueId())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onInventoryDrag(InventoryDragEvent event) {
      HumanEntity entity = event.getWhoClicked();
      if (this.isThrowPending(entity.getUniqueId())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onDrop(PlayerDropItemEvent event) {
      if (this.isThrowPending(event.getPlayer().getUniqueId())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
   public void onSwapHand(PlayerSwapHandItemsEvent event) {
      if (this.isThrowPending(event.getPlayer().getUniqueId())) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onDeath(PlayerDeathEvent event) {
      this.readyThrow.remove(event.getEntity().getUniqueId());
   }

   @EventHandler
   public void onChangedWorld(PlayerChangedWorldEvent event) {
      this.readyThrow.remove(event.getPlayer().getUniqueId());
   }

   @EventHandler
   public void onKick(PlayerKickEvent event) {
      this.readyThrow.remove(event.getPlayer().getUniqueId());
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      this.readyThrow.remove(event.getPlayer().getUniqueId());
   }

   public void clear() {
      this.readyThrow.clear();
   }

   private boolean isThrowPending(UUID uuid) {
      Long expireAt = this.readyThrow.get(uuid);
      if (expireAt == null) {
         return false;
      } else if (System.currentTimeMillis() > expireAt) {
         this.readyThrow.remove(uuid);
         return false;
      } else {
         return true;
      }
   }
}
