package cs.cloudstudio.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class ServerMessageSilencer implements Listener {
   private static final String EMPTY_MESSAGE = "";

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onJoin(PlayerJoinEvent event) {
      event.setJoinMessage("");
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onQuit(PlayerQuitEvent event) {
      event.setQuitMessage("");
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onKick(PlayerKickEvent event) {
      event.setLeaveMessage("");
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDeath(PlayerDeathEvent event) {
      event.setDeathMessage("");
   }
}
