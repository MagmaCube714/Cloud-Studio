package cs.cloudstudio.listener;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;

public final class HeadPlacementListener implements Listener {
   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onBlockPlace(BlockPlaceEvent event) {
      ItemStack item = event.getItemInHand();
      if (this.isHead(item)) {
         if (this.hasAnyNbt(item)) {
            event.setCancelled(true);
         }
      }
   }

   private boolean isHead(ItemStack item) {
      if (item == null) {
         return false;
      }

      Material type = item.getType();
      if (type == null) {
         return false;
      }

      String name = type.name();
      return name.endsWith("_HEAD") || name.endsWith("_SKULL");
   }

   private boolean hasAnyNbt(ItemStack item) {
      return item.hasItemMeta();
   }
}
