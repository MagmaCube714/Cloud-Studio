package cs.cloudstudio.menu;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.config.ConfigValues;
import cs.cloudstudio.manager.Warp;
import cs.cloudstudio.util.ItemUtil;
import cs.cloudstudio.util.MenuPlaceholderUtil;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class MainMenu implements InventoryHolder {
   public static final int[] WARP_SLOTS = new int[]{
      1, 2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43
   };
   public static final int BACK_SLOT = 49;
   public static final int PREVIOUS_SLOT = 45;
   public static final int NEXT_SLOT = 53;
   private static final Set<Material> MENU_MATERIALS = EnumSet.noneOf(Material.class);
   private final CloudWarps plugin;
   private final int page;
   private final Inventory inventory;
   private final NamespacedKey warpKey;
   private final NamespacedKey menuItemKey;
   private boolean hasNextPage;

   public MainMenu(CloudWarps plugin, Player viewer, int page) {
      this.plugin = plugin;
      this.page = Math.max(0, page);
      this.warpKey = new NamespacedKey(plugin, "warp");
      this.menuItemKey = new NamespacedKey(plugin, "menu_item");
      ConfigValues.Menu menu = plugin.configManager().values().menu();
      List<Warp> warps = plugin.warpManager().menuWarps();
      Map<String, String> placeholders = this.menuPlaceholders(viewer, warps);
      this.inventory = Bukkit.createInventory(this, menu.size(), MenuPlaceholderUtil.render(viewer, menu.title(), placeholders));
      this.fill(viewer, menu, warps, placeholders);
   }

   private void fill(Player viewer, ConfigValues.Menu menu, List<Warp> warps, Map<String, String> placeholders) {
      int start = this.page * WARP_SLOTS.length;
      int end = Math.min(warps.size(), start + WARP_SLOTS.length);

      for (int index = start; index < end; index++) {
         this.inventory.setItem(WARP_SLOTS[index - start], this.warpItem(viewer, warps.get(index), menu, placeholders));
      }

      if (this.page == 0) {
         this.inventory
            .setItem(
               49,
               this.menuItem(
                  ItemUtil.item(
                     menu.backMaterial(),
                     MenuPlaceholderUtil.render(viewer, menu.backName(), placeholders),
                     MenuPlaceholderUtil.renderList(viewer, menu.backLore(), null, placeholders),
                     menu.backModelData()
                  )
               )
            );
      }

      if (this.page > 0) {
         this.inventory
            .setItem(
               45,
               this.menuItem(
                  ItemUtil.item(
                     menu.previousMaterial(),
                     MenuPlaceholderUtil.render(viewer, menu.previousName(), placeholders),
                     MenuPlaceholderUtil.renderList(viewer, menu.previousLore(), null, placeholders),
                     menu.previousModelData()
                  )
               )
            );
      }

      if (end < warps.size()) {
         this.inventory
            .setItem(
               53,
               this.menuItem(
                  ItemUtil.item(
                     menu.nextMaterial(),
                     MenuPlaceholderUtil.render(viewer, menu.nextName(), placeholders),
                     MenuPlaceholderUtil.renderList(viewer, menu.nextLore(), null, placeholders),
                     menu.nextModelData()
                  )
               )
            );
         this.hasNextPage = true;
      }
   }

   private ItemStack warpItem(Player viewer, Warp warp, ConfigValues.Menu menu, Map<String, String> placeholders) {
      ItemStack item = new ItemStack(menu.warpMaterial());
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      meta.setDisplayName(MenuPlaceholderUtil.render(viewer, menu.warpName(), warp, placeholders));
      meta.setLore(MenuPlaceholderUtil.renderList(viewer, menu.warpLore(), warp, placeholders));
      markMenuMaterial(item.getType());
      meta.getPersistentDataContainer().set(this.warpKey, PersistentDataType.STRING, warp.name());
      meta.getPersistentDataContainer().set(this.menuItemKey, PersistentDataType.BYTE, (byte)1);
      item.setItemMeta(meta);
      return item;
   }

   private Map<String, String> menuPlaceholders(Player viewer, List<Warp> warps) {
      Map<String, String> placeholders = new HashMap<>(12);
      int pageNumber = this.page + 1;
      int warpCount = warps.size();
      placeholders.put("page", String.valueOf(pageNumber));
      placeholders.put("page_number", String.valueOf(pageNumber));
      placeholders.put("current_page", String.valueOf(pageNumber));
      placeholders.put("previous_page", String.valueOf(Math.max(1, this.page)));
      placeholders.put("next_page", String.valueOf(this.page + 2));
      placeholders.put("warps", String.valueOf(warpCount));
      placeholders.put("warp_count", String.valueOf(warpCount));
      placeholders.put("warps_count", String.valueOf(warpCount));
      placeholders.put("limit", String.valueOf(this.plugin.configManager().values().limit()));
      if (viewer != null) {
         int playerWarps = this.plugin.warpManager().count(viewer.getUniqueId());
         placeholders.put("player_warps", String.valueOf(playerWarps));
         placeholders.put("player_warps_count", String.valueOf(playerWarps));
      }

      return placeholders;
   }

   private ItemStack menuItem(ItemStack item) {
      if (item == null) {
         return null;
      }

      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      markMenuMaterial(item.getType());
      meta.getPersistentDataContainer().set(this.menuItemKey, PersistentDataType.BYTE, (byte)1);
      item.setItemMeta(meta);
      return item;
   }

   public static void markMenuMaterial(Material material) {
      if (material != null) {
         MENU_MATERIALS.add(material);
      }
   }

   public static boolean menuMaterial(Material material) {
      return MENU_MATERIALS.contains(material);
   }

   public int page() {
      return this.page;
   }

   public boolean hasNextPage() {
      return this.hasNextPage;
   }

   public Inventory getInventory() {
      return this.inventory;
   }

   public void open(Player player) {
      player.openInventory(this.inventory);
   }
}
