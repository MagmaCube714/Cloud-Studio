package cs.cloudstudio.menu;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.config.ConfigValues;
import cs.cloudstudio.manager.Warp;
import cs.cloudstudio.util.ItemUtil;
import cs.cloudstudio.util.MenuPlaceholderUtil;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class ConfirmMenu implements InventoryHolder {
   private static final int CONFIRM_SLOT = 21;
   private static final int CANCEL_SLOT = 23;
   private final String warpName;
   private final Inventory inventory;
   private final NamespacedKey menuItemKey;

   public ConfirmMenu(CloudWarps plugin, Player viewer, String warpName) {
      this.warpName = warpName;
      this.menuItemKey = new NamespacedKey(plugin, "menu_item");
      ConfigValues.Confirm confirm = plugin.configManager().values().confirm();
      Warp warp = plugin.warpManager().warp(warpName).orElse(null);
      this.inventory = Bukkit.createInventory(this, confirm.size(), MenuPlaceholderUtil.render(viewer, confirm.title(), warp));
      this.inventory
         .setItem(
            21,
            this.menuItem(
               ItemUtil.item(
                  confirm.confirmMaterial(),
                  MenuPlaceholderUtil.render(viewer, confirm.confirmName(), warp),
                  MenuPlaceholderUtil.renderList(viewer, confirm.confirmLore(), warp),
                  0
               )
            )
         );
      this.inventory
         .setItem(
            23,
            this.menuItem(
               ItemUtil.item(
                  confirm.cancelMaterial(),
                  MenuPlaceholderUtil.render(viewer, confirm.cancelName(), warp),
                  MenuPlaceholderUtil.renderList(viewer, confirm.cancelLore(), warp),
                  0
               )
            )
         );
   }

   public String warpName() {
      return this.warpName;
   }

   public boolean confirmSlot(int slot) {
      return slot == 21;
   }

   public boolean cancelSlot(int slot) {
      return slot == 23;
   }

   public Inventory getInventory() {
      return this.inventory;
   }

   public void open(Player player) {
      player.openInventory(this.inventory);
   }

   private ItemStack menuItem(ItemStack item) {
      if (item == null) {
         return null;
      }

      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      MainMenu.markMenuMaterial(item.getType());
      meta.getPersistentDataContainer().set(this.menuItemKey, PersistentDataType.BYTE, (byte)1);
      item.setItemMeta(meta);
      return item;
   }
}
