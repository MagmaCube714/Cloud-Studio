package cs.cloudstudio.database.connection;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.database.DatabaseType;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class SQLiteConnectionFactory implements ConnectionFactory {
   private final CloudWarps plugin;

   public SQLiteConnectionFactory(CloudWarps plugin) {
      this.plugin = plugin;
   }

   @Override
   public DatabaseType type() {
      return DatabaseType.SQLITE;
   }

   @Override
   public Connection open() throws SQLException {
      File folder = this.plugin.getDataFolder();
      if (!folder.exists() && !folder.mkdirs()) {
         throw new SQLException("Не удалось создать папку " + folder.getAbsolutePath());
      }

      String name = this.plugin.getConfig().getString("database.playerDatabase", "data");
      if (name == null || name.trim().isEmpty()) {
         name = "data";
      }

      name = name.trim();
      if (!name.toLowerCase().endsWith(".db")) {
         name = name + ".db";
      }

      try {
         Class.forName("org.sqlite.JDBC");
      } catch (ClassNotFoundException var4) {
      }

      return DriverManager.getConnection("jdbc:sqlite:" + new File(folder, name).getAbsolutePath());
   }
}
