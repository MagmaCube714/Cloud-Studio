package cs.cloudstudio.database.connection;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.database.DatabaseType;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class MySQLConnectionFactory implements ConnectionFactory {
   private final CloudWarps plugin;

   public MySQLConnectionFactory(CloudWarps plugin) {
      this.plugin = plugin;
   }

   @Override
   public DatabaseType type() {
      return DatabaseType.MYSQL;
   }

   @Override
   public Connection open() throws SQLException {
      String host = this.plugin.getConfig().getString("database.host", "localhost");
      int port = this.plugin.getConfig().getInt("database.port", 3306);
      String database = this.plugin.getConfig().getString("database.playerDatabase", "data");
      String username = this.plugin.getConfig().getString("database.username", "admin");
      String password = this.plugin.getConfig().getString("database.password", "admin");
      if (host == null || host.trim().isEmpty()) {
         host = "localhost";
      }

      if (database == null || database.trim().isEmpty()) {
         database = "data";
      }

      try {
         Class.forName("com.mysql.cj.jdbc.Driver");
      } catch (ClassNotFoundException var7) {
      }

      String url = "jdbc:mysql://"
         + host.trim()
         + ":"
         + port
         + "/"
         + database.trim()
         + "?useUnicode=true&characterEncoding=utf8&useSSL=false&autoReconnect=true";
      return DriverManager.getConnection(url, username == null ? "" : username, password == null ? "" : password);
   }
}
