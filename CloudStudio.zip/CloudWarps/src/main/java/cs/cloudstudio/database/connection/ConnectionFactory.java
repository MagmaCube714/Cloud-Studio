package cs.cloudstudio.database.connection;

import cs.cloudstudio.database.DatabaseType;
import java.sql.Connection;
import java.sql.SQLException;

public interface ConnectionFactory {
   DatabaseType type();

   Connection open() throws SQLException;
}
