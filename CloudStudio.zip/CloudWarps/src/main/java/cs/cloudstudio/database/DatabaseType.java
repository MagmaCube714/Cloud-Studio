package cs.cloudstudio.database;

import java.util.Locale;

public enum DatabaseType {
   SQLITE,
   MYSQL;

   public static DatabaseType from(String value) {
      if (value == null) {
         return SQLITE;
      } else {
         String normalized = value.trim().toUpperCase(Locale.ROOT);
         if (normalized.equals("MYSQL")) {
            return MYSQL;
         } else {
            return normalized.equals("SQLITE") ? SQLITE : null;
         }
      }
   }
}
