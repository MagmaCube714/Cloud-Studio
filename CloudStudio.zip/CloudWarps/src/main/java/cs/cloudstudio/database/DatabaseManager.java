package cs.cloudstudio.database;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.cache.WarpCache;
import cs.cloudstudio.database.connection.ConnectionFactory;
import cs.cloudstudio.database.connection.MySQLConnectionFactory;
import cs.cloudstudio.database.connection.SQLiteConnectionFactory;
import cs.cloudstudio.manager.Warp;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.locks.ReentrantLock;
import org.bukkit.configuration.file.YamlConfiguration;

public final class DatabaseManager {
   private static final String TABLE = "warps";
   private final CloudWarps plugin;
   private final File legacyFile;
   private final ReentrantLock lock = new ReentrantLock();
   private final WarpCache cache = new WarpCache();
   private volatile Connection connection;
   private volatile boolean connected;
   private volatile long nextExpiresAt;
   private DatabaseType type = DatabaseType.SQLITE;

   public DatabaseManager(CloudWarps plugin) {
      this.plugin = plugin;
      this.legacyFile = new File(plugin.getDataFolder(), "warps.yml");
   }

   public void connect() {
      this.lock.lock();

      try {
         if (!this.connected) {
            ConnectionFactory factory = this.factory();
            this.type = factory.type();
            this.connection = factory.open();
            this.configureConnection();
            this.connection.setAutoCommit(false);
            this.createTable();
            this.migrateLegacyYamlIfNeeded();
            this.load();
            this.removeExpiredWarps(System.currentTimeMillis());
            this.connected = true;
            return;
         }
      } catch (SQLException exception) {
         this.connected = false;
         this.closeConnectionQuietly();
         this.plugin.warning("База данных не подключена: " + exception.getMessage());
         return;
      } finally {
         this.lock.unlock();
      }
   }

   private ConnectionFactory factory() {
      String rawType = this.plugin.getConfig().getString("database.type", "SQLite");
      DatabaseType databaseType = DatabaseType.from(rawType);
      if (databaseType == null) {
         this.plugin.warning("Неверный тип базы данных в database.type: используется SQLite");
         databaseType = DatabaseType.SQLITE;
      }

      return databaseType == DatabaseType.MYSQL ? new MySQLConnectionFactory(this.plugin) : new SQLiteConnectionFactory(this.plugin);
   }

   private void configureConnection() throws SQLException {
      if (this.type == DatabaseType.SQLITE) {
         try (Statement statement = this.connection.createStatement()) {
            statement.execute("PRAGMA busy_timeout=5000");
            statement.execute("PRAGMA journal_mode=WAL");
            statement.execute("PRAGMA synchronous=NORMAL");
            statement.execute("PRAGMA wal_autocheckpoint=1000");
            statement.execute("PRAGMA journal_size_limit=16777216");
            statement.execute("PRAGMA foreign_keys=ON");
         }
      }
   }

   private void createTable() throws SQLException {
      try (Statement statement = this.connection.createStatement()) {
         if (this.type == DatabaseType.MYSQL) {
            statement.executeUpdate(
               "CREATE TABLE IF NOT EXISTS warps(`key` VARCHAR(64) PRIMARY KEY,name VARCHAR(32) NOT NULL,owner VARCHAR(36) NOT NULL,owner_name VARCHAR(64) NOT NULL,world VARCHAR(128) NOT NULL,x DOUBLE NOT NULL,y DOUBLE NOT NULL,z DOUBLE NOT NULL,yaw DOUBLE NOT NULL,pitch DOUBLE NOT NULL,expires_at BIGINT NOT NULL,created_at BIGINT NOT NULL) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            );
         } else {
            statement.executeUpdate(
               "CREATE TABLE IF NOT EXISTS warps(key TEXT PRIMARY KEY,name TEXT NOT NULL,owner TEXT NOT NULL,owner_name TEXT NOT NULL,world TEXT NOT NULL,x REAL NOT NULL,y REAL NOT NULL,z REAL NOT NULL,yaw REAL NOT NULL,pitch REAL NOT NULL,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL)"
            );
         }

         this.createIndex(statement, "warps_owner_index", "owner");
         this.createIndex(statement, "warps_created_at_index", "created_at");
         this.createIndex(statement, "warps_expires_at_index", "expires_at");
         this.connection.commit();
      }
   }

   private void createIndex(Statement statement, String name, String column) {
      try {
         if (this.type == DatabaseType.MYSQL) {
            statement.executeUpdate("CREATE INDEX " + name + " ON warps(" + column + ")");
         } else {
            statement.executeUpdate("CREATE INDEX IF NOT EXISTS " + name + " ON warps(" + column + ")");
         }
      } catch (SQLException var5) {
      }
   }

   private void migrateLegacyYamlIfNeeded() throws SQLException {
      if (this.legacyFile.exists() && this.isTableEmpty()) {
         YamlConfiguration data = YamlConfiguration.loadConfiguration(this.legacyFile);
         if (data.isConfigurationSection("warps")) {
            int migrated = 0;

            try (PreparedStatement statement = this.insertStatement(true)) {
               for (String key : data.getConfigurationSection("warps").getKeys(false)) {
                  String path = "warps." + key + ".";

                  try {
                     String name = data.getString(path + "name", key);
                     UUID owner = UUID.fromString(data.getString(path + "owner"));
                     String ownerName = data.getString(path + "owner-name", "Unknown");
                     String world = data.getString(path + "world", "world");
                     double x = data.getDouble(path + "x");
                     double y = data.getDouble(path + "y");
                     double z = data.getDouble(path + "z");
                     float yaw = (float)data.getDouble(path + "yaw");
                     float pitch = (float)data.getDouble(path + "pitch");
                     long expiresAt = data.getLong(path + "expires-at");
                     long createdAt = data.getLong(path + "created-at");
                     if (expiresAt > 0L && createdAt > 0L) {
                        this.bind(statement, new Warp(name, owner, ownerName, world, x, y, z, yaw, pitch, expiresAt, createdAt));
                        statement.addBatch();
                        migrated++;
                     }
                  } catch (Exception var24) {
                  }
               }

               statement.executeBatch();
               this.connection.commit();
            } catch (SQLException exception) {
               this.rollback();
               throw exception;
            }

            if (migrated > 0) {
               File archive = new File(this.legacyFile.getParentFile(), "warps.yml.migrated");
               if (archive.exists() && !archive.delete()) {
                  this.plugin.warning("Не удалось удалить старый архив warps.yml.migrated");
               }

               if (!this.legacyFile.renameTo(archive)) {
                  this.plugin.warning("Файл warps.yml не перенесён в архив после миграции");
               }
            }
         }
      }
   }

   private boolean isTableEmpty() throws SQLException {
      try (
         Statement statement = this.connection.createStatement();
         ResultSet set = statement.executeQuery("SELECT 1 FROM warps LIMIT 1");
      ) {
         return !set.next();
      }
   }

   private void load() throws SQLException {
      this.cache.clear();

      try (
         Statement statement = this.connection.createStatement();
         ResultSet set = statement.executeQuery("SELECT name, owner, owner_name, world, x, y, z, yaw, pitch, expires_at, created_at FROM warps");
      ) {
         while (set.next()) {
            try {
               Warp warp = new Warp(
                  set.getString("name"),
                  UUID.fromString(set.getString("owner")),
                  set.getString("owner_name"),
                  set.getString("world"),
                  set.getDouble("x"),
                  set.getDouble("y"),
                  set.getDouble("z"),
                  (float)set.getDouble("yaw"),
                  (float)set.getDouble("pitch"),
                  set.getLong("expires_at"),
                  set.getLong("created_at")
               );
               this.cache.put(warp);
            } catch (Exception var7) {
            }
         }
      }

      this.refreshNextExpirationAt();
   }

   public Optional<Warp> warp(String name) {
      return this.cache.warp(name);
   }

   public Collection<Warp> warps() {
      return this.cache.warps();
   }

   public int count(UUID owner) {
      return owner == null ? 0 : this.cache.count(owner);
   }

   public boolean add(Warp warp) {
      if (warp == null) {
         return false;
      }

      this.lock.lock();

      try {
         if (this.connection != null && !this.connection.isClosed() && !this.cache.contains(warp.key())) {
            try (PreparedStatement statement = this.insertStatement(false)) {
               this.bind(statement, warp);
               statement.executeUpdate();
               this.connection.commit();
            }

            this.cache.put(warp);
            this.updateNextExpirationAt(warp.expiresAt());
            return true;
         } else {
            return false;
         }
      } catch (SQLException exception) {
         this.rollback();
         this.plugin.warning("Варп " + warp.name() + " не сохранён: " + exception.getMessage());
         return false;
      } finally {
         this.lock.unlock();
      }
   }

   public boolean remove(String name) {
      String key = Warp.normalize(name);
      this.lock.lock();

      try {
         if (this.connection != null && !this.connection.isClosed()) {
            Warp removed = this.cache.warp(key).orElse(null);
            if (removed == null) {
               return false;
            }

            try (PreparedStatement statement = this.connection.prepareStatement("DELETE FROM warps WHERE " + this.keyColumn() + " = ?")) {
               statement.setString(1, key);
               statement.executeUpdate();
               this.connection.commit();
            }

            this.cache.remove(key);
            if (removed.expiresAt() == this.nextExpiresAt) {
               this.refreshNextExpirationAt();
            }

            return true;
         } else {
            return false;
         }
      } catch (SQLException exception) {
         this.rollback();
         this.plugin.warning("Варп " + name + " не удалён: " + exception.getMessage());
         return false;
      } finally {
         this.lock.unlock();
      }
   }

   public List<Warp> removeExpiredWarps(long now) {
      this.lock.lock();

      try {
         if (this.connection != null && !this.connection.isClosed()) {
            List<Warp> expired = new ArrayList<>();

            for (Warp warp : this.cache.warps()) {
               if (warp.expired(now)) {
                  expired.add(warp);
               }
            }

            if (expired.isEmpty()) {
               this.refreshNextExpirationAt();
               return Collections.emptyList();
            }

            try (PreparedStatement statement = this.connection.prepareStatement("DELETE FROM warps WHERE expires_at <= ?")) {
               statement.setLong(1, now);
               statement.executeUpdate();
               this.connection.commit();
            }

            for (Warp warp : expired) {
               this.cache.remove(warp.key());
            }

            this.refreshNextExpirationAt();
            return expired;
         } else {
            return Collections.emptyList();
         }
      } catch (SQLException exception) {
         this.rollback();
         this.plugin.warning("Истекшие варпы не очищены: " + exception.getMessage());
         return Collections.emptyList();
      } finally {
         this.lock.unlock();
      }
   }

   public long nextExpirationAt() {
      return this.nextExpiresAt;
   }

   private void updateNextExpirationAt(long expiresAt) {
      if (expiresAt > 0L) {
         long current = this.nextExpiresAt;
         if (current <= 0L || expiresAt < current) {
            this.nextExpiresAt = expiresAt;
         }
      }
   }

   private void refreshNextExpirationAt() {
      long next = 0L;

      for (Warp warp : this.cache.warps()) {
         long expiresAt = warp.expiresAt();
         if (expiresAt > 0L && (next == 0L || expiresAt < next)) {
            next = expiresAt;
         }
      }

      this.nextExpiresAt = next;
   }

   private PreparedStatement insertStatement(boolean ignoreExisting) throws SQLException {
      String action;
      if (ignoreExisting) {
         action = this.type == DatabaseType.MYSQL ? "INSERT IGNORE" : "INSERT OR IGNORE";
      } else {
         action = "INSERT";
      }

      return this.connection
         .prepareStatement(
            action
               + " INTO warps("
               + this.keyColumn()
               + ", name, owner, owner_name, world, x, y, z, yaw, pitch, expires_at, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
         );
   }

   private String keyColumn() {
      return this.type == DatabaseType.MYSQL ? "`key`" : "key";
   }

   private void bind(PreparedStatement statement, Warp warp) throws SQLException {
      statement.setString(1, warp.key());
      statement.setString(2, warp.name());
      statement.setString(3, warp.owner().toString());
      statement.setString(4, warp.ownerName());
      statement.setString(5, warp.worldName());
      statement.setDouble(6, warp.x());
      statement.setDouble(7, warp.y());
      statement.setDouble(8, warp.z());
      statement.setDouble(9, warp.yaw());
      statement.setDouble(10, warp.pitch());
      statement.setLong(11, warp.expiresAt());
      statement.setLong(12, warp.createdAt());
   }

   public void disconnect() {
      this.connected = false;
      this.lock.lock();

      try {
         this.closeConnection();
      } catch (SQLException exception) {
         this.plugin.warning("База данных не закрыта: " + exception.getMessage());
      } finally {
         this.cache.clear();
         this.nextExpiresAt = 0L;
         this.connection = null;
         this.lock.unlock();
      }
   }

   private void rollback() {
      try {
         if (this.connection != null && !this.connection.isClosed()) {
            this.connection.rollback();
         }
      } catch (SQLException exception) {
         this.plugin.warning("Откат транзакции не выполнен: " + exception.getMessage());
      }
   }

   private void closeConnection() throws SQLException {
      if (this.connection != null && !this.connection.isClosed()) {
         this.connection.close();
      }
   }

   private void closeConnectionQuietly() {
      try {
         this.closeConnection();
      } catch (SQLException var5) {
      } finally {
         this.connection = null;
         this.nextExpiresAt = 0L;
      }
   }

   public boolean isConnected() {
      try {
         return this.connected && this.connection != null && !this.connection.isClosed();
      } catch (SQLException exception) {
         return false;
      }
   }
}
