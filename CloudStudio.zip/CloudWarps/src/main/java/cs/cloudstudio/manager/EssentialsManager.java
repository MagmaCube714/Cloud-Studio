package cs.cloudstudio.manager;

import com.earth2me.essentials.Essentials;
import com.earth2me.essentials.Warps;
import cs.cloudstudio.CloudWarps;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.Plugin;

public final class EssentialsManager {
   private static final long CACHE_TTL_MILLIS = 30000L;
   private final CloudWarps plugin;
   private Warps warps;
   private List<String> cachedNames = Collections.emptyList();
   private Set<String> cachedKeys = Collections.emptySet();
   private long cacheExpiresAt;

   public EssentialsManager(CloudWarps plugin) {
      this.plugin = plugin;
   }

   public void hook() {
      this.clearCache();
      Plugin essentialsPlugin = Bukkit.getPluginManager().getPlugin("Essentials");
      if (essentialsPlugin != null && essentialsPlugin.isEnabled()) {
         try {
            this.warps = ((Essentials)essentialsPlugin).getWarps();
         } catch (Throwable ignored) {
            this.warps = null;
            this.plugin.warning("Essentials найден, но его API несовместимо: серверные варпы недоступны");
         }
      } else {
         this.warps = null;
         this.plugin.warning("Essentials не найден: серверные варпы недоступны, работают только собственные варпы");
      }
   }

   public boolean enabled() {
      return this.warps != null;
   }

   public Location warp(String name) {
      if (this.warps != null && name != null && !name.isEmpty()) {
         try {
            return this.warps.getWarp(name);
         } catch (Exception ignored) {
            return null;
         }
      } else {
         return null;
      }
   }

   public boolean exists(String name) {
      String key = Warp.normalize(name);
      return !key.isEmpty() && this.keys().contains(key);
   }

   public List<String> names() {
      this.refreshCacheIfNeeded();
      return this.cachedNames;
   }

   public Set<String> keys() {
      this.refreshCacheIfNeeded();
      return this.cachedKeys;
   }

   private void refreshCacheIfNeeded() {
      if (this.warps == null) {
         this.clearCache();
      } else {
         long now = System.currentTimeMillis();
         if (now >= this.cacheExpiresAt) {
            Collection<String> list;
            try {
               list = this.warps.getList();
            } catch (Exception ignored) {
               this.clearCache();
               return;
            }

            if (list != null && !list.isEmpty()) {
               List<String> names = new ArrayList<>(list.size());
               Set<String> keys = new HashSet<>(list.size() * 2);

               for (String name : list) {
                  String key = Warp.normalize(name);
                  if (!key.isEmpty()) {
                     names.add(name);
                     keys.add(key);
                  }
               }

               this.cachedNames = Collections.unmodifiableList(names);
               this.cachedKeys = Collections.unmodifiableSet(keys);
               this.cacheExpiresAt = now + 30000L;
            } else {
               this.cachedNames = Collections.emptyList();
               this.cachedKeys = Collections.emptySet();
               this.cacheExpiresAt = now + 30000L;
            }
         }
      }
   }

   private void clearCache() {
      this.cachedNames = Collections.emptyList();
      this.cachedKeys = Collections.emptySet();
      this.cacheExpiresAt = 0L;
   }
}
