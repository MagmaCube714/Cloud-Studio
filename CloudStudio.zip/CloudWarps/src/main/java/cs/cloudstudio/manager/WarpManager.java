package cs.cloudstudio.manager;

import cs.cloudstudio.CloudWarps;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public final class WarpManager {
   private static final Comparator<Warp> NEWEST_FIRST = new Comparator<Warp>() {
      public int compare(Warp first, Warp second) {
         return Long.compare(second.createdAt(), first.createdAt());
      }
   };
   private final CloudWarps plugin;
   private BukkitTask expirationTask;

   public WarpManager(CloudWarps plugin) {
      this.plugin = plugin;
   }

   public void startExpirationTask() {
      this.scheduleExpirationTask();
   }

   public void stopExpirationTask() {
      if (this.expirationTask != null) {
         this.expirationTask.cancel();
         this.expirationTask = null;
      }
   }

   private void scheduleExpirationTask() {
      this.stopExpirationTask();
      long nextExpirationAt = this.plugin.database().nextExpirationAt();
      if (nextExpirationAt > 0L) {
         long millis = nextExpirationAt - System.currentTimeMillis();
         long delay = millis <= 0L ? 1L : Math.max(1L, (millis + 999L) / 1000L * 20L);
         this.expirationTask = this.plugin.getServer().getScheduler().runTaskLater(this.plugin, new Runnable() {
            @Override
            public void run() {
               WarpManager.this.expireWarps();
            }
         }, delay);
      }
   }

   private void expireWarps() {
      long now = System.currentTimeMillis();
      List<Warp> expired = this.plugin.database().removeExpiredWarps(now);

      for (int i = 0; i < expired.size(); i++) {
         Warp warp = expired.get(i);
         Player owner = this.plugin.getServer().getPlayer(warp.owner());
         if (owner != null) {
            owner.sendMessage(this.plugin.configManager().message(owner, "warp-expired", warp));
         }
      }

      this.scheduleExpirationTask();
   }

   public boolean create(Player owner, String name) {
      if (owner == null || name == null || !this.plugin.configManager().validWarpName(name)) {
         return false;
      }

      if (!this.reservedName(name) && !this.warp(name).isPresent()) {
         Location location = owner.getLocation();
         if (location.getWorld() != null && !this.plugin.configManager().isRestrictedWorld(location.getWorld().getName()) && this.safeLocation(location)) {
            long now = System.currentTimeMillis();
            long expiresAt = now + this.plugin.configManager().warpDurationMillis();
            boolean created = this.plugin.database().add(new Warp(name.trim(), owner.getUniqueId(), owner.getName(), location, expiresAt, now));
            if (created) {
               this.scheduleExpirationTask();
            }

            return created;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean delete(String name) {
      boolean deleted = this.plugin.database().remove(name);
      if (deleted) {
         this.scheduleExpirationTask();
      }

      return deleted;
   }

   public Optional<Warp> warp(String name) {
      return this.plugin.database().warp(name);
   }

   public Collection<Warp> warps() {
      return this.plugin.database().warps();
   }

   public List<Warp> menuWarps() {
      Collection<Warp> all = this.warps();
      if (all.isEmpty()) {
         return Collections.emptyList();
      }

      Set<String> reservedNames = this.reservedNames();
      List<Warp> result = new ArrayList<>(all.size());

      for (Warp warp : all) {
         if (!reservedNames.contains(warp.key())) {
            result.add(warp);
         }
      }

      result.sort(NEWEST_FIRST);
      return result;
   }

   public int count(UUID owner) {
      return this.plugin.database().count(owner);
   }

   public boolean reservedName(String name) {
      return this.plugin.configManager().isServerWarp(name) || this.plugin.essentialsManager().exists(name);
   }

   public int removeReservedWarps() {
      Set<String> reservedNames = this.reservedNames();
      List<Warp> reserved = new ArrayList<>();

      for (Warp warp : this.warps()) {
         if (reservedNames.contains(warp.key())) {
            reserved.add(warp);
         }
      }

      int removed = 0;

      for (int i = 0; i < reserved.size(); i++) {
         if (this.plugin.database().remove(reserved.get(i).name())) {
            removed++;
         }
      }

      if (removed > 0) {
         this.scheduleExpirationTask();
      }

      return removed;
   }

   private Set<String> reservedNames() {
      Set<String> serverWarps = this.plugin.configManager().values().serverWarps();
      Set<String> essentialsWarps = this.plugin.essentialsManager().keys();
      if (serverWarps.isEmpty() && essentialsWarps.isEmpty()) {
         return Collections.emptySet();
      }

      Set<String> names = new HashSet<>(serverWarps.size() + essentialsWarps.size() + 4);
      names.addAll(serverWarps);
      names.addAll(essentialsWarps);
      return names;
   }

   public boolean safeLocation(Location location) {
      if (location != null && location.getWorld() != null) {
         Block feet = location.getBlock();
         Block head = feet.getRelative(0, 1, 0);
         Block below = feet.getRelative(0, -1, 0);
         Material feetType = feet.getType();
         Material headType = head.getType();
         Material belowType = below.getType();
         return !feetType.isSolid()
            && !headType.isSolid()
            && feetType != Material.WATER
            && feetType != Material.LAVA
            && headType != Material.WATER
            && headType != Material.LAVA
            && belowType.isSolid()
            && belowType != Material.AIR
            && belowType != Material.WATER
            && belowType != Material.LAVA;
      } else {
         return false;
      }
   }
}
