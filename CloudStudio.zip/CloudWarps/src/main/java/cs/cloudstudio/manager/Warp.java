package cs.cloudstudio.manager;

import java.util.Locale;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class Warp {
   private final String name;
   private final String key;
   private final UUID owner;
   private final String ownerName;
   private final String worldName;
   private final double x;
   private final double y;
   private final double z;
   private final float yaw;
   private final float pitch;
   private final long expiresAt;
   private final long createdAt;

   public Warp(String name, UUID owner, String ownerName, Location location, long expiresAt, long createdAt) {
      this(
         name,
         owner,
         ownerName,
         location.getWorld().getName(),
         location.getX(),
         location.getY(),
         location.getZ(),
         location.getYaw(),
         location.getPitch(),
         expiresAt,
         createdAt
      );
   }

   public Warp(
      String name, UUID owner, String ownerName, String worldName, double x, double y, double z, float yaw, float pitch, long expiresAt, long createdAt
   ) {
      this.name = name;
      this.key = normalize(name);
      this.owner = owner;
      this.ownerName = ownerName != null && !ownerName.trim().isEmpty() ? ownerName : "Unknown";
      this.worldName = worldName;
      this.x = x;
      this.y = y;
      this.z = z;
      this.yaw = yaw;
      this.pitch = pitch;
      this.expiresAt = expiresAt;
      this.createdAt = createdAt;
   }

   public static String normalize(String value) {
      return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
   }

   public String name() {
      return this.name;
   }

   public String key() {
      return this.key;
   }

   public UUID owner() {
      return this.owner;
   }

   public String ownerName() {
      return this.ownerName;
   }

   public String worldName() {
      return this.worldName;
   }

   public double x() {
      return this.x;
   }

   public double y() {
      return this.y;
   }

   public double z() {
      return this.z;
   }

   public float yaw() {
      return this.yaw;
   }

   public float pitch() {
      return this.pitch;
   }

   public long expiresAt() {
      return this.expiresAt;
   }

   public long createdAt() {
      return this.createdAt;
   }

   public boolean expired(long now) {
      return this.expiresAt <= now;
   }

   public long remainingMillis() {
      return Math.max(0L, this.expiresAt - System.currentTimeMillis());
   }

   public Location location() {
      World world = Bukkit.getWorld(this.worldName);
      return world == null ? null : new Location(world, this.x, this.y, this.z, this.yaw, this.pitch);
   }
}
