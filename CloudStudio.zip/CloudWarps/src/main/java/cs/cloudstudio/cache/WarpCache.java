package cs.cloudstudio.cache;

import cs.cloudstudio.manager.Warp;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class WarpCache {
   private final Map<String, Warp> warps = new ConcurrentHashMap<>();
   private final Map<UUID, Integer> ownerCounts = new ConcurrentHashMap<>();

   public Optional<Warp> warp(String name) {
      return Optional.ofNullable(this.warps.get(Warp.normalize(name)));
   }

   public Collection<Warp> warps() {
      return Collections.unmodifiableCollection(this.warps.values());
   }

   public boolean contains(String name) {
      return this.warps.containsKey(Warp.normalize(name));
   }

   public int count(UUID owner) {
      return owner == null ? 0 : this.ownerCounts.getOrDefault(owner, 0);
   }

   public void put(Warp warp) {
      if (warp != null) {
         this.warps.put(warp.key(), warp);
         this.ownerCounts.merge(warp.owner(), 1, Integer::sum);
      }
   }

   public Warp remove(String name) {
      Warp removed = this.warps.remove(Warp.normalize(name));
      if (removed != null) {
         this.ownerCounts.computeIfPresent(removed.owner(), (uuid, count) -> count > 1 ? count - 1 : null);
      }

      return removed;
   }

   public void clear() {
      this.warps.clear();
      this.ownerCounts.clear();
   }
}
