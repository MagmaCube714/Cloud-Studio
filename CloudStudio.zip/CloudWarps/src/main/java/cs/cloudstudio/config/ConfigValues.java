package cs.cloudstudio.config;

import java.util.List;
import java.util.Set;
import org.bukkit.Material;

public final class ConfigValues {
   private final int limit;
   private final Set<String> serverWarps;
   private final Set<String> restrictedWorlds;
   private final ConfigValues.Menu menu;
   private final ConfigValues.Confirm confirm;

   public ConfigValues(int limit, Set<String> serverWarps, Set<String> restrictedWorlds, ConfigValues.Menu menu, ConfigValues.Confirm confirm) {
      this.limit = limit;
      this.serverWarps = serverWarps;
      this.restrictedWorlds = restrictedWorlds;
      this.menu = menu;
      this.confirm = confirm;
   }

   public int limit() {
      return this.limit;
   }

   public Set<String> serverWarps() {
      return this.serverWarps;
   }

   public Set<String> restrictedWorlds() {
      return this.restrictedWorlds;
   }

   public ConfigValues.Menu menu() {
      return this.menu;
   }

   public ConfigValues.Confirm confirm() {
      return this.confirm;
   }

   public static final class Confirm {
      private final int size;
      private final String title;
      private final String confirmName;
      private final Material confirmMaterial;
      private final List<String> confirmLore;
      private final String cancelName;
      private final Material cancelMaterial;
      private final List<String> cancelLore;

      public Confirm(
         int size,
         String title,
         String confirmName,
         Material confirmMaterial,
         List<String> confirmLore,
         String cancelName,
         Material cancelMaterial,
         List<String> cancelLore
      ) {
         this.size = size;
         this.title = title;
         this.confirmName = confirmName;
         this.confirmMaterial = confirmMaterial;
         this.confirmLore = confirmLore;
         this.cancelName = cancelName;
         this.cancelMaterial = cancelMaterial;
         this.cancelLore = cancelLore;
      }

      public int size() {
         return this.size;
      }

      public String title() {
         return this.title;
      }

      public String confirmName() {
         return this.confirmName;
      }

      public Material confirmMaterial() {
         return this.confirmMaterial;
      }

      public List<String> confirmLore() {
         return this.confirmLore;
      }

      public String cancelName() {
         return this.cancelName;
      }

      public Material cancelMaterial() {
         return this.cancelMaterial;
      }

      public List<String> cancelLore() {
         return this.cancelLore;
      }
   }

   public static final class Menu {
      private final int size;
      private final String title;
      private final String warpName;
      private final Material warpMaterial;
      private final List<String> warpLore;
      private final String backName;
      private final Material backMaterial;
      private final List<String> backLore;
      private final int backModelData;
      private final String backCommand;
      private final String previousName;
      private final Material previousMaterial;
      private final List<String> previousLore;
      private final int previousModelData;
      private final String nextName;
      private final Material nextMaterial;
      private final List<String> nextLore;
      private final int nextModelData;

      public Menu(
         int size,
         String title,
         String warpName,
         Material warpMaterial,
         List<String> warpLore,
         String backName,
         Material backMaterial,
         List<String> backLore,
         int backModelData,
         String backCommand,
         String previousName,
         Material previousMaterial,
         List<String> previousLore,
         int previousModelData,
         String nextName,
         Material nextMaterial,
         List<String> nextLore,
         int nextModelData
      ) {
         this.size = size;
         this.title = title;
         this.warpName = warpName;
         this.warpMaterial = warpMaterial;
         this.warpLore = warpLore;
         this.backName = backName;
         this.backMaterial = backMaterial;
         this.backLore = backLore;
         this.backModelData = backModelData;
         this.backCommand = backCommand;
         this.previousName = previousName;
         this.previousMaterial = previousMaterial;
         this.previousLore = previousLore;
         this.previousModelData = previousModelData;
         this.nextName = nextName;
         this.nextMaterial = nextMaterial;
         this.nextLore = nextLore;
         this.nextModelData = nextModelData;
      }

      public int size() {
         return this.size;
      }

      public String title() {
         return this.title;
      }

      public String warpName() {
         return this.warpName;
      }

      public Material warpMaterial() {
         return this.warpMaterial;
      }

      public List<String> warpLore() {
         return this.warpLore;
      }

      public String backName() {
         return this.backName;
      }

      public Material backMaterial() {
         return this.backMaterial;
      }

      public List<String> backLore() {
         return this.backLore;
      }

      public int backModelData() {
         return this.backModelData;
      }

      public String backCommand() {
         return this.backCommand;
      }

      public String previousName() {
         return this.previousName;
      }

      public Material previousMaterial() {
         return this.previousMaterial;
      }

      public List<String> previousLore() {
         return this.previousLore;
      }

      public int previousModelData() {
         return this.previousModelData;
      }

      public String nextName() {
         return this.nextName;
      }

      public Material nextMaterial() {
         return this.nextMaterial;
      }

      public List<String> nextLore() {
         return this.nextLore;
      }

      public int nextModelData() {
         return this.nextModelData;
      }
   }
}
