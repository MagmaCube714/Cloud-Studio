package cs.cloudstudio.config;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.manager.Warp;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.ItemUtil;
import cs.cloudstudio.util.MenuPlaceholderUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public final class ConfigManager {
   private static final int MIN_NAME_LENGTH = 1;
   private static final int MAX_NAME_LENGTH = 16;
   private static final long WARP_DURATION_MILLIS = 604800000L;
   private static final long EXPIRATION_CHECK_TICKS = 1200L;
   private static final Pattern NAME_PATTERN = Pattern.compile("^[A-Za-z0-9_]+$");
   private final CloudWarps plugin;
   private volatile Map<String, String> messages = Collections.emptyMap();
   private ConfigValues values;

   public ConfigManager(CloudWarps plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.plugin.reloadConfig();
      FileConfiguration config = this.plugin.getConfig();
      Map<String, String> loadedMessages = new HashMap<>();
      ConfigurationSection messagesSection = config.getConfigurationSection("messages");
      if (messagesSection != null) {
         for (String key : messagesSection.getKeys(false)) {
            loadedMessages.put(key.toLowerCase(Locale.ROOT), ColorUtil.color(messagesSection.getString(key, "")));
         }
      }

      Set<String> serverWarps = new HashSet<>();

      for (String warpName : this.stringList(config, "settings.server-warps", "server-warps")) {
         String normalized = Warp.normalize(warpName);
         if (!normalized.isEmpty()) {
            serverWarps.add(normalized);
         }
      }

      Set<String> restrictedWorlds = new HashSet<>();

      for (String worldName : this.stringList(config, "settings.restricted-worlds", "restricted-worlds")) {
         String normalized = this.normalizeWorldName(worldName);
         if (!normalized.isEmpty()) {
            restrictedWorlds.add(normalized);
         }
      }

      int limit = Math.max(0, config.contains("settings.limit") ? config.getInt("settings.limit", 3) : config.getInt("limit", 3));
      ConfigValues.Menu menu = this.loadMainMenu(config.getConfigurationSection("menu.main"));
      ConfigValues.Confirm confirm = this.loadConfirmMenu(config.getConfigurationSection("menu.confirm"));
      this.messages = Collections.unmodifiableMap(loadedMessages);
      this.values = new ConfigValues(limit, Collections.unmodifiableSet(serverWarps), Collections.unmodifiableSet(restrictedWorlds), menu, confirm);
   }

   private List<String> stringList(FileConfiguration config, String path, String legacyPath) {
      return config.contains(path) ? config.getStringList(path) : config.getStringList(legacyPath);
   }

   private ConfigValues.Menu loadMainMenu(ConfigurationSection section) {
      int size = Math.max(54, this.inventorySize(section == null ? 54 : section.getInt("size", 54)));
      String title = ColorUtil.color(section == null ? "Warps" : section.getString("name", "Warps"));
      ConfigurationSection warps = section == null ? null : section.getConfigurationSection("warps");
      String warpName = ColorUtil.color(warps == null ? "&7Варп &8- &6{name}" : warps.getString("name", "&7Варп &8- &6{name}"));
      Material warpMaterial = ItemUtil.material(warps == null ? "CHEST" : warps.getString("material", "CHEST"), Material.CHEST);
      List<String> warpLore = warps == null ? this.defaultWarpLore() : ColorUtil.color(warps.getStringList("description"));
      if (warpLore.isEmpty()) {
         warpLore = this.defaultWarpLore();
      } else if (warps != null) {
         warpLore = Collections.unmodifiableList(warpLore);
      }

      ConfigurationSection back = section == null ? null : section.getConfigurationSection("back");
      ConfigurationSection previous = section == null ? null : section.getConfigurationSection("previous");
      ConfigurationSection next = section == null ? null : section.getConfigurationSection("next");
      return new ConfigValues.Menu(
         size,
         title,
         warpName,
         warpMaterial,
         warpLore,
         ColorUtil.color(back == null ? "&eВ главное меню" : back.getString("name", "&eВ главное меню")),
         ItemUtil.material(back == null ? "OAK_DOOR" : back.getString("material", "OAK_DOOR"), Material.OAK_DOOR),
         this.itemLore(back),
         back == null ? 0 : back.getInt("model_data", 0),
         back == null ? "" : back.getString("command_on_click", ""),
         ColorUtil.color(previous == null ? "&6Предыдущая страница" : previous.getString("name", "&6Предыдущая страница")),
         ItemUtil.material(previous == null ? "ARROW" : previous.getString("material", "ARROW"), Material.ARROW),
         this.itemLore(previous),
         previous == null ? 0 : previous.getInt("model_data", 0),
         ColorUtil.color(next == null ? "&6Следующая страница" : next.getString("name", "&6Следующая страница")),
         ItemUtil.material(next == null ? "ARROW" : next.getString("material", "ARROW"), Material.ARROW),
         this.itemLore(next),
         next == null ? 0 : next.getInt("model_data", 0)
      );
   }

   private List<String> itemLore(ConfigurationSection section) {
      if (section == null) {
         return Collections.emptyList();
      }

      List<String> lore = section.getStringList("description");
      if (lore.isEmpty()) {
         lore = section.getStringList("lore");
      }

      return Collections.unmodifiableList(ColorUtil.color(lore));
   }

   private List<String> defaultWarpLore() {
      List<String> lore = new ArrayList<>();
      lore.add("");
      lore.add(" &7Владелец: &6{owner} ");
      lore.add(" &7Истекает через: &6{time} ");
      lore.add("");
      lore.add(" &7Нажми, чтобы перейти на &6/warp {name} ");
      return Collections.unmodifiableList(ColorUtil.color(lore));
   }

   private ConfigValues.Confirm loadConfirmMenu(ConfigurationSection section) {
      int size = Math.max(27, this.inventorySize(section == null ? 54 : section.getInt("size", 54)));
      String title = ColorUtil.color(section == null ? "Confirm" : section.getString("name", "Confirm"));
      ConfigurationSection items = section == null ? null : section.getConfigurationSection("items");
      ConfigurationSection confirm = items == null ? null : items.getConfigurationSection("confirm");
      ConfigurationSection cancel = items == null ? null : items.getConfigurationSection("cancel");
      return new ConfigValues.Confirm(
         size,
         title,
         ColorUtil.color(confirm == null ? "&aТелепортироваться" : confirm.getString("name", "&aТелепортироваться")),
         ItemUtil.material(confirm == null ? "EMERALD_BLOCK" : confirm.getString("material", "EMERALD_BLOCK"), Material.EMERALD_BLOCK),
         this.itemLore(confirm),
         ColorUtil.color(cancel == null ? "&cНе телепортироваться" : cancel.getString("name", "&cНе телепортироваться")),
         ItemUtil.material(cancel == null ? "REDSTONE_BLOCK" : cancel.getString("material", "REDSTONE_BLOCK"), Material.REDSTONE_BLOCK),
         this.itemLore(cancel)
      );
   }

   private int inventorySize(int size) {
      int fixed = Math.max(9, Math.min(54, size));
      fixed -= fixed % 9;
      return fixed <= 0 ? 54 : fixed;
   }

   public ConfigValues values() {
      return this.values;
   }

   public String message(String key) {
      return key == null ? "" : this.messages.getOrDefault(key.toLowerCase(Locale.ROOT), "");
   }

   public String message(Player player, String key) {
      return MenuPlaceholderUtil.render(player, this.message(key));
   }

   public String message(Player player, String key, Warp warp) {
      return MenuPlaceholderUtil.render(player, this.message(key), warp);
   }

   public String message(Player player, String key, Map<String, String> placeholders) {
      return MenuPlaceholderUtil.render(player, this.message(key), placeholders);
   }

   public String message(Player player, String key, Warp warp, Map<String, String> placeholders) {
      return MenuPlaceholderUtil.render(player, this.message(key), warp, placeholders);
   }

   public boolean isServerWarp(String name) {
      return this.values.serverWarps().contains(Warp.normalize(name));
   }

   public boolean isRestrictedWorld(String worldName) {
      return this.values.restrictedWorlds().contains(this.normalizeWorldName(worldName));
   }

   private String normalizeWorldName(String worldName) {
      return worldName == null ? "" : worldName.trim().toLowerCase(Locale.ROOT);
   }

   public boolean validWarpName(String name) {
      if (name == null) {
         return false;
      }

      String trimmed = name.trim();
      int length = trimmed.length();
      return length >= 1 && length <= 16 && NAME_PATTERN.matcher(trimmed).matches();
   }

   public long warpDurationMillis() {
      return 604800000L;
   }

   public long expirationCheckTicks() {
      return 1200L;
   }

   public long warpDurationDays() {
      return 7L;
   }
}
