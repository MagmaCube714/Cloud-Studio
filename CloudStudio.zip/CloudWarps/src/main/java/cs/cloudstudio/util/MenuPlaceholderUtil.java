package cs.cloudstudio.util;

import cs.cloudstudio.manager.Warp;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

public final class MenuPlaceholderUtil {
   private static volatile boolean placeholderApiChecked;
   private static volatile Method placeholderApiMethod;

   private MenuPlaceholderUtil() {
   }

   public static String render(Player player, String text) {
      return render(player, text, null, Collections.emptyMap());
   }

   public static String render(Player player, String text, Warp warp) {
      return render(player, text, warp, Collections.emptyMap());
   }

   public static String render(Player player, String text, Map<String, String> placeholders) {
      return render(player, text, null, placeholders);
   }

   public static String render(Player player, String text, Warp warp, Map<String, String> placeholders) {
      return ColorUtil.color(renderRaw(player, text, warp, placeholders));
   }

   public static List<String> renderList(Player player, List<String> lines) {
      return renderList(player, lines, null, Collections.emptyMap());
   }

   public static List<String> renderList(Player player, List<String> lines, Warp warp) {
      return renderList(player, lines, warp, Collections.emptyMap());
   }

   public static List<String> renderList(Player player, List<String> lines, Warp warp, Map<String, String> placeholders) {
      if (lines != null && !lines.isEmpty()) {
         List<String> result = new ArrayList<>(lines.size());

         for (String line : lines) {
            result.add(render(player, line, warp, placeholders));
         }

         return result;
      } else {
         return Collections.emptyList();
      }
   }

   public static String renderRaw(Player player, String text) {
      return renderRaw(player, text, null, Collections.emptyMap());
   }

   public static String renderRaw(Player player, String text, Warp warp) {
      return renderRaw(player, text, warp, Collections.emptyMap());
   }

   public static String renderRaw(Player player, String text, Map<String, String> placeholders) {
      return renderRaw(player, text, null, placeholders);
   }

   public static String renderRaw(Player player, String text, Warp warp, Map<String, String> placeholders) {
      if (text != null && !text.isEmpty()) {
         String result = text;
         if (text.indexOf(123) >= 0 || text.indexOf(37) >= 0) {
            result = applyLocalPlaceholders(text, player, warp, placeholders);
         }

         return applyPlaceholderApi(player, result);
      } else {
         return "";
      }
   }

   private static String applyLocalPlaceholders(String text, Player player, Warp warp, Map<String, String> placeholders) {
      Map<String, String> custom = normalizedCustom(placeholders);
      int length = text.length();
      StringBuilder builder = null;
      int copied = 0;
      int index = 0;

      while (index < length) {
         char open = text.charAt(index);
         if (open != '{' && open != '%') {
            index++;
            continue;
         }

         char close = open == '{' ? '}' : '%';
         int end = text.indexOf(close, index + 1);
         if (end < 0) {
            index++;
            continue;
         }

         String value = null;
         if (end > index + 1) {
            String token = text.substring(index + 1, end);
            String lower = token.toLowerCase(Locale.ROOT);
            if (lower.equals(token) || token.toUpperCase(Locale.ROOT).equals(token)) {
               value = resolve(lower, player, warp, custom);
            }
         }

         if (value == null) {
            index++;
            continue;
         }

         if (builder == null) {
            builder = new StringBuilder(length + 32);
         }

         builder.append(text, copied, index).append(value);
         index = end + 1;
         copied = index;
      }

      if (builder == null) {
         return text;
      }

      builder.append(text, copied, length);
      return builder.toString();
   }

   private static Map<String, String> normalizedCustom(Map<String, String> placeholders) {
      if (placeholders == null || placeholders.isEmpty()) {
         return null;
      }

      Map<String, String> normalized = null;

      for (Entry<String, String> entry : placeholders.entrySet()) {
         String key = entry.getKey();
         if (key != null) {
            String normalizedKey = normalizeKey(key);
            if (normalized == null) {
               if (normalizedKey.equals(key) && entry.getValue() != null) {
                  continue;
               }

               normalized = new HashMap<>(placeholders.size() * 2);

               for (Entry<String, String> previous : placeholders.entrySet()) {
                  if (previous == entry) {
                     break;
                  }

                  if (previous.getKey() != null) {
                     normalized.put(normalizeKey(previous.getKey()), previous.getValue() == null ? "" : previous.getValue());
                  }
               }
            }

            normalized.put(normalizedKey, entry.getValue() == null ? "" : entry.getValue());
         }
      }

      return normalized == null ? placeholders : normalized;
   }

   private static String resolve(String key, Player player, Warp warp, Map<String, String> custom) {
      if (custom != null) {
         String value = custom.get(key);
         if (value != null) {
            return value;
         }
      }

      if (warp != null) {
         switch (key) {
            case "name":
            case "warp":
            case "warp_name":
               return warp.name();
            case "key":
            case "warp_key":
               return warp.key();
            case "owner":
            case "owner_name":
               return warp.ownerName();
            case "owner_uuid":
               return warp.owner().toString();
            case "time":
            case "left_time":
            case "remaining":
            case "remaining_time":
               return TimeUtil.format(warp.remainingMillis());
            case "world":
            case "warp_world":
            case "world_name":
               return nullToEmpty(warp.worldName());
            case "warp_x":
               return format(warp.x());
            case "warp_y":
               return format(warp.y());
            case "warp_z":
               return format(warp.z());
            case "yaw":
               return format(warp.yaw());
            case "pitch":
               return format(warp.pitch());
            case "created_at":
               return String.valueOf(warp.createdAt());
            case "expires_at":
               return String.valueOf(warp.expiresAt());
         }
      }

      if (player != null) {
         switch (key) {
            case "name":
            case "player":
            case "player_name":
            case "viewer":
            case "viewer_name":
               return nullToEmpty(player.getName());
            case "display_name":
               return nullToEmpty(player.getDisplayName());
            case "uuid":
               return player.getUniqueId().toString();
            case "world":
            case "player_world":
               return player.getWorld().getName();
            case "x":
            case "player_x":
               return format(player.getLocation().getX());
            case "y":
            case "player_y":
               return format(player.getLocation().getY());
            case "z":
            case "player_z":
               return format(player.getLocation().getZ());
         }
      }

      return null;
   }

   private static String nullToEmpty(String value) {
      return value == null ? "" : value;
   }

   private static String normalizeKey(String key) {
      String normalized = key.trim().toLowerCase(Locale.ROOT);
      if (normalized.length() > 1 && normalized.startsWith("%") && normalized.endsWith("%")) {
         normalized = normalized.substring(1, normalized.length() - 1);
      }

      if (normalized.length() > 1 && normalized.startsWith("{") && normalized.endsWith("}")) {
         normalized = normalized.substring(1, normalized.length() - 1);
      }

      return normalized;
   }

   private static String format(double value) {
      long scaled = Math.round(value * 10.0);
      if (scaled < 0L) {
         long positive = -scaled;
         return "-" + positive / 10L + "." + positive % 10L;
      } else {
         return scaled / 10L + "." + scaled % 10L;
      }
   }

   private static String applyPlaceholderApi(Player player, String text) {
      if (player != null && text != null && !text.isEmpty() && text.indexOf(37) >= 0) {
         try {
            Method method = placeholderApiMethod();
            if (method == null) {
               return text;
            }

            Object replaced = method.invoke(null, player, text);
            return replaced instanceof String ? (String)replaced : text;
         } catch (Throwable ignored) {
            return text;
         }
      } else {
         return text == null ? "" : text;
      }
   }

   private static Method placeholderApiMethod() {
      if (placeholderApiChecked) {
         return placeholderApiMethod;
      }

      placeholderApiChecked = true;

      try {
         if (!Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            return null;
         }

         Class<?> placeholderApi = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
         placeholderApiMethod = placeholderApi.getMethod("setPlaceholders", OfflinePlayer.class, String.class);
      } catch (Throwable ignored) {
         placeholderApiMethod = null;
      }

      return placeholderApiMethod;
   }
}
