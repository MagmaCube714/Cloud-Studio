package cs.cloudstudio.util;

public final class TimeUtil {
   private TimeUtil() {
   }

   public static String format(long millis) {
      if (millis <= 0L) {
         return "истек";
      } else {
         long seconds = millis / 1000L;
         long days = seconds / 86400L;
         seconds %= 86400L;
         long hours = seconds / 3600L;
         seconds %= 3600L;
         long minutes = seconds / 60L;
         seconds %= 60L;
         if (days > 0L) {
            return hours > 0L ? days + "д " + hours + "ч" : days + "д";
         } else if (hours > 0L) {
            return minutes > 0L ? hours + "ч " + minutes + "м" : hours + "ч";
         } else {
            return minutes > 0L ? minutes + "м" : seconds + "с";
         }
      }
   }
}
