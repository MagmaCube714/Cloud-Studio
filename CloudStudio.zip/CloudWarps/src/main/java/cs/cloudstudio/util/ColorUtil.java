package cs.cloudstudio.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.ChatColor;

public final class ColorUtil {
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

   private ColorUtil() {
   }

   public static String color(String text) {
      if (text != null && !text.isEmpty()) {
         String colored = text;
         if (text.indexOf(38) < 0) {
            return colored;
         }

         if (text.indexOf("&#") >= 0) {
            Matcher matcher = HEX_PATTERN.matcher(text);
            StringBuffer buffer = new StringBuffer(text.length() + 32);

            while (matcher.find()) {
               String hex = matcher.group(1);
               StringBuilder replacement = new StringBuilder(14).append('§').append('x');

               for (int i = 0; i < 6; i++) {
                  replacement.append('§').append(hex.charAt(i));
               }

               matcher.appendReplacement(buffer, Matcher.quoteReplacement(replacement.toString()));
            }

            matcher.appendTail(buffer);
            colored = buffer.toString();
         }

         return ChatColor.translateAlternateColorCodes('&', colored);
      } else {
         return "";
      }
   }

   public static List<String> color(List<String> lines) {
      if (lines != null && !lines.isEmpty()) {
         List<String> result = new ArrayList<>(lines.size());

         for (String line : lines) {
            result.add(color(line));
         }

         return result;
      } else {
         return Collections.emptyList();
      }
   }
}
