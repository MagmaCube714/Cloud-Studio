package cs.cloudstudio.util;

import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ItemUtil {
   private ItemUtil() {
   }

   public static Material material(String name, Material fallback) {
      Material material = name == null ? null : Material.matchMaterial(name);
      return material == null ? fallback : material;
   }

   public static ItemStack item(Material material, String name, List<String> lore, int modelData) {
      ItemStack item = new ItemStack(material == null ? Material.STONE : material);
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      if (name != null && !name.isEmpty()) {
         meta.setDisplayName(name);
      }

      if (lore != null) {
         meta.setLore(lore);
      }

      if (modelData > 0) {
         meta.setCustomModelData(modelData);
      }

      item.setItemMeta(meta);
      return item;
   }
}
