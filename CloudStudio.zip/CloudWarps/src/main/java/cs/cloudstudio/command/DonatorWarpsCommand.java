package cs.cloudstudio.command;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.menu.MainMenu;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class DonatorWarpsCommand implements CommandExecutor, TabCompleter {
   private final CloudWarps plugin;

   public DonatorWarpsCommand(CloudWarps plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§cЭта команда доступна только игрокам");
         return true;
      } else {
         new MainMenu(this.plugin, (Player)sender, 0).open((Player)sender);
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return Collections.emptyList();
   }
}
