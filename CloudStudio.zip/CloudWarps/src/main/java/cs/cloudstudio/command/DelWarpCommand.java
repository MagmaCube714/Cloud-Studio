package cs.cloudstudio.command;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.manager.Warp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class DelWarpCommand implements CommandExecutor, TabCompleter {
   private final CloudWarps plugin;

   public DelWarpCommand(CloudWarps plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      Player player = sender instanceof Player ? (Player)sender : null;
      if (args.length < 1) {
         sender.sendMessage(this.plugin.configManager().message(player, "provide-warp-name"));
         return true;
      }

      Warp warp = this.plugin.warpManager().warp(args[0]).orElse(null);
      if (warp == null) {
         sender.sendMessage(this.plugin.configManager().message(player, "warp-does-not-exist"));
         return true;
      }

      boolean admin = sender.hasPermission("cloudwarps.admin");
      if (!(sender instanceof Player)) {
         if (!admin) {
            sender.sendMessage(this.plugin.configManager().message(null, "no-permission-delwarp", warp));
            return true;
         }
      } else {
         if (!admin && !player.hasPermission("cloudwarps.delwarp")) {
            player.sendMessage(this.plugin.configManager().message(player, "no-permission-delwarp", warp));
            return true;
         }

         if (!admin && !warp.owner().equals(player.getUniqueId())) {
            player.sendMessage(this.plugin.configManager().message(player, "warp-not-owner", warp));
            return true;
         }
      }

      if (this.plugin.warpManager().delete(warp.name())) {
         sender.sendMessage(this.plugin.configManager().message(player, "warp-deleted", warp));
      }

      return true;
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (args.length != 1) {
         return Collections.emptyList();
      }

      String prefix = args[0].toLowerCase(Locale.ROOT);
      List<String> result = new ArrayList<>();

      for (Warp warp : this.plugin.warpManager().warps()) {
         if (warp.name().toLowerCase(Locale.ROOT).startsWith(prefix)) {
            result.add(warp.name());
         }
      }

      result.sort(String.CASE_INSENSITIVE_ORDER);
      return result;
   }
}
