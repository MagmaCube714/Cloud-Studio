package cs.cloudstudio.command;

import cs.cloudstudio.CloudWarps;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public abstract class BaseCommand {
   protected final CloudWarps plugin;

   protected BaseCommand(CloudWarps plugin) {
      this.plugin = plugin;
   }

   protected Player player(CommandSender sender) {
      return sender instanceof Player ? (Player)sender : null;
   }

   protected void message(CommandSender sender, String key) {
      sender.sendMessage(this.plugin.configManager().message(this.player(sender), key));
   }
}
