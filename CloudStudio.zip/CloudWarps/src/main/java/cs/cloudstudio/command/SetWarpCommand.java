package cs.cloudstudio.command;

import cs.cloudstudio.CloudWarps;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class SetWarpCommand implements CommandExecutor, TabCompleter {
   private final CloudWarps plugin;

   public SetWarpCommand(CloudWarps plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player player)) {
         sender.sendMessage("§cЭта команда доступна только игрокам");
         return true;
      } else {
         if (!player.hasPermission("cloudwarps.setwarp") && !player.hasPermission("cloudwarps.admin")) {
            player.sendMessage(this.plugin.configManager().message(player, "no-permission-setwarp"));
            return true;
         }

         if (args.length >= 1 && this.plugin.configManager().validWarpName(args[0])) {
            String name = args[0].trim();
            if (this.plugin.warpManager().reservedName(name) || this.plugin.warpManager().warp(name).isPresent()) {
               player.sendMessage(this.plugin.configManager().message(player, "warp-name-exists", this.namePlaceholders(name)));
               return true;
            }

            if (player.getWorld() != null && this.plugin.configManager().isRestrictedWorld(player.getWorld().getName())) {
               player.sendMessage(this.plugin.configManager().message(player, "restricted-world"));
               return true;
            }

            int limit = this.plugin.configManager().values().limit();
            if (!player.hasPermission("cloudwarps.admin") && this.plugin.warpManager().count(player.getUniqueId()) >= limit) {
               Map<String, String> placeholders = this.namePlaceholders(name);
               placeholders.put("limit", String.valueOf(limit));
               player.sendMessage(this.plugin.configManager().message(player, "warp-limit-reached", placeholders));
               return true;
            }

            if (!this.plugin.warpManager().safeLocation(player.getLocation())) {
               player.sendMessage(this.plugin.configManager().message(player, "invalid-location"));
               return true;
            }

            if (this.plugin.warpManager().create(player, name)) {
               Map<String, String> placeholders = this.namePlaceholders(name);
               placeholders.put("days", String.valueOf(this.plugin.configManager().warpDurationDays()));
               player.sendMessage(this.plugin.configManager().message(player, "warp-set", placeholders));
            }

            return true;
         } else {
            player.sendMessage(this.plugin.configManager().message(player, "provide-warp-name"));
            return true;
         }
      }
   }

   private Map<String, String> namePlaceholders(String name) {
      Map<String, String> placeholders = new HashMap<>();
      placeholders.put("name", name);
      placeholders.put("warp", name);
      placeholders.put("warp_name", name);
      return placeholders;
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return Collections.emptyList();
   }
}
