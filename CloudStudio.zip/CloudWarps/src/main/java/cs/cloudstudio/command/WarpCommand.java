package cs.cloudstudio.command;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.manager.Warp;
import cs.cloudstudio.menu.ConfirmMenu;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.TreeSet;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class WarpCommand implements CommandExecutor, TabCompleter {
   private final CloudWarps plugin;

   public WarpCommand(CloudWarps plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player player)) {
         sender.sendMessage("§cЭта команда доступна только игрокам");
         return true;
      } else {
         if (args.length < 1) {
            player.sendMessage(this.plugin.configManager().message(player, "provide-warp-name"));
            return true;
         }

         String name = args[0].trim();
         Location essentialsWarp = this.plugin.essentialsManager().warp(name);
         if (essentialsWarp != null) {
            // чанки варпа догружаются асинхронно, главный поток не ждёт диск
            player.teleportAsync(essentialsWarp).thenAccept(done -> {
               if (Boolean.TRUE.equals(done) && player.isOnline()) {
                  player.sendMessage(this.plugin.configManager().message(player, "warp-teleported", this.namePlaceholders(name)));
               }
            });
            return true;
         }

         if (this.plugin.configManager().isServerWarp(name)) {
            player.sendMessage(this.plugin.configManager().message(player, "warp-does-not-exist"));
            return true;
         }

         Optional<Warp> optionalWarp = this.plugin.warpManager().warp(name);
         if (optionalWarp.isPresent()) {
            Warp warp = optionalWarp.get();
            Location location = warp.location();
            if (location == null) {
               player.sendMessage(this.plugin.configManager().message(player, "warp-does-not-exist", warp));
               return true;
            } else {
               new ConfirmMenu(this.plugin, player, warp.name()).open(player);
               return true;
            }
         } else {
            player.sendMessage(this.plugin.configManager().message(player, "warp-does-not-exist"));
            return true;
         }
      }
   }

   private Map<String, String> namePlaceholders(String name) {
      Map<String, String> placeholders = new HashMap<>();
      placeholders.put("name", name);
      placeholders.put("warp", name);
      placeholders.put("warp_name", name);
      return placeholders;
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (args.length != 1) {
         return Collections.emptyList();
      }

      String prefix = args[0].toLowerCase(Locale.ROOT);
      TreeSet<String> result = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

      for (String warpName : this.plugin.essentialsManager().names()) {
         if (warpName.toLowerCase(Locale.ROOT).startsWith(prefix)) {
            result.add(warpName);
         }
      }

      for (Warp warp : this.plugin.warpManager().warps()) {
         if (!this.plugin.warpManager().reservedName(warp.name()) && warp.name().toLowerCase(Locale.ROOT).startsWith(prefix)) {
            result.add(warp.name());
         }
      }

      return new ArrayList<>(result);
   }
}
