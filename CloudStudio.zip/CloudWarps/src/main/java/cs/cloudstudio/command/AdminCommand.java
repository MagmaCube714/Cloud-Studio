package cs.cloudstudio.command;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class AdminCommand extends BaseCommand implements CommandExecutor, TabCompleter {
   private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();

   public AdminCommand(CloudWarps plugin) {
      super(plugin);
      this.register(new ReloadSubCommand(plugin));
   }

   private void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.name().toLowerCase(Locale.ROOT), subCommand);
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      Player player = this.player(sender);
      if (!sender.hasPermission("cloudwarps.admin")) {
         sender.sendMessage(this.plugin.configManager().message(player, "no-permission"));
         return true;
      }

      if (args.length > 0) {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand != null) {
            return subCommand.execute(sender, Arrays.copyOfRange(args, 1, args.length));
         }
      }

      sender.sendMessage(this.plugin.configManager().message(player, "admin-usage"));
      return true;
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.hasPermission("cloudwarps.admin")) {
         return Collections.emptyList();
      }

      if (args.length == 1) {
         String prefix = args[0].toLowerCase(Locale.ROOT);
         List<String> result = new ArrayList<>();

         for (String name : this.subCommands.keySet()) {
            if (name.startsWith(prefix)) {
               result.add(name);
            }
         }

         return result;
      } else {
         if (args.length > 1) {
            SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
            if (subCommand != null) {
               return subCommand.complete(sender, Arrays.copyOfRange(args, 1, args.length));
            }
         }

         return Collections.emptyList();
      }
   }
}
