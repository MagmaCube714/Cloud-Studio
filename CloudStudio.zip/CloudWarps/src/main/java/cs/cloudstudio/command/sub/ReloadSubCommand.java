package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class ReloadSubCommand implements SubCommand {
   private final CloudWarps plugin;

   public ReloadSubCommand(CloudWarps plugin) {
      this.plugin = plugin;
   }

   @Override
   public String name() {
      return "reload";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      this.plugin.configManager().reload();
      this.plugin.essentialsManager().hook();
      this.plugin.warpManager().removeReservedWarps();
      this.plugin.warpManager().startExpirationTask();
      sender.sendMessage(this.plugin.configManager().message(sender instanceof Player ? (Player)sender : null, "reloaded"));
      return true;
   }
}
