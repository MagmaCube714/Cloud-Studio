package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.command.DelWarpCommand;
import cs.cloudstudio.command.DonatorWarpsCommand;
import cs.cloudstudio.command.SetWarpCommand;
import cs.cloudstudio.command.WarpCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.database.DatabaseManager;
import cs.cloudstudio.listener.MenuListener;
import cs.cloudstudio.manager.EssentialsManager;
import cs.cloudstudio.manager.WarpManager;
import cs.cloudstudio.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudWarps extends JavaPlugin {
   private ConfigManager configManager;
   private DatabaseManager database;
   private EssentialsManager essentialsManager;
   private WarpManager warpManager;

   public void onEnable() {
      this.saveDefaultConfig();
      this.configManager = new ConfigManager(this);
      this.database = new DatabaseManager(this);
      this.database.connect();
      if (!this.database.isConnected()) {
         this.log("&fCloudWarps &cБаза данных не подключена, плагин отключён");
         Bukkit.getPluginManager().disablePlugin(this);
      } else {
         this.essentialsManager = new EssentialsManager(this);
         this.essentialsManager.hook();
         this.warpManager = new WarpManager(this);
         this.warpManager.removeReservedWarps();
         this.registerCommands();
         this.getServer().getPluginManager().registerEvents(new MenuListener(this), this);
         this.warpManager.startExpirationTask();
         this.log("&fCloudWarps &aуспешно загружен!");
      }
   }

   public void onDisable() {
      if (this.warpManager != null) {
         this.warpManager.stopExpirationTask();
      }

      this.getServer().getScheduler().cancelTasks(this);
      HandlerList.unregisterAll(this);
      if (this.database != null) {
         this.database.disconnect();
      }

      this.log("&fCloudWarps &cуспешно выгружен!");
   }

   private void registerCommands() {
      this.register("cloudwarps", new AdminCommand(this));
      this.register("warp", new WarpCommand(this));
      this.register("setwarp", new SetWarpCommand(this));
      this.register("delwarp", new DelWarpCommand(this));
      this.register("donatorwarps", new DonatorWarpsCommand(this));
   }

   private void register(String name, CommandExecutor executor) {
      PluginCommand pluginCommand = this.getCommand(name);
      if (pluginCommand == null) {
         this.warning("Команда " + name + " не зарегистрирована в plugin.yml");
      } else {
         pluginCommand.setExecutor(executor);
         if (executor instanceof TabCompleter) {
            pluginCommand.setTabCompleter((TabCompleter)executor);
         }
      }
   }

   public void log(String message) {
      Bukkit.getConsoleSender().sendMessage(ColorUtil.color(message));
   }

   public void warning(String message) {
      this.getLogger().warning("[CloudWarps] " + message);
   }

   public ConfigManager configManager() {
      return this.configManager;
   }

   public DatabaseManager database() {
      return this.database;
   }

   public EssentialsManager essentialsManager() {
      return this.essentialsManager;
   }

   public WarpManager warpManager() {
      return this.warpManager;
   }
}
