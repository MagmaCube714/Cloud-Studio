package cs.cloudstudio.listener;

import cs.cloudstudio.CloudWarps;
import cs.cloudstudio.config.ConfigValues;
import cs.cloudstudio.manager.Warp;
import cs.cloudstudio.menu.ConfirmMenu;
import cs.cloudstudio.menu.MainMenu;
import cs.cloudstudio.util.MenuPlaceholderUtil;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.Event.Result;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class MenuListener implements Listener {
   private static final long MENU_CLICK_DELAY_MILLIS = 250L;
   private final CloudWarps plugin;
   private final NamespacedKey warpKey;
   private final NamespacedKey menuItemKey;
   private final Set<UUID> processing = new HashSet<>();
   private final Map<UUID, Long> clickCooldownUntil = new HashMap<>();

   public MenuListener(CloudWarps plugin) {
      this.plugin = plugin;
      this.warpKey = new NamespacedKey(plugin, "warp");
      this.menuItemKey = new NamespacedKey(plugin, "menu_item");
      this.markConfiguredMaterials();
   }

   private void markConfiguredMaterials() {
      try {
         ConfigValues values = this.plugin.configManager().values();
         MainMenu.markMenuMaterial(values.menu().warpMaterial());
         MainMenu.markMenuMaterial(values.menu().backMaterial());
         MainMenu.markMenuMaterial(values.menu().previousMaterial());
         MainMenu.markMenuMaterial(values.menu().nextMaterial());
         MainMenu.markMenuMaterial(values.confirm().confirmMaterial());
         MainMenu.markMenuMaterial(values.confirm().cancelMaterial());
      } catch (RuntimeException ignored) {
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDrag(InventoryDragEvent event) {
      InventoryHolder holder = event.getView().getTopInventory().getHolder(false);
      if (this.menuHolder(holder)) {
         event.setCancelled(true);
         event.setResult(Result.DENY);
         HumanEntity clicker = event.getWhoClicked();
         if (clicker instanceof Player) {
            this.removeMenuItems((Player)clicker);
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onInventoryClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player player) {
         Inventory top = event.getView().getTopInventory();
         InventoryHolder holder = top.getHolder(false);
         if (this.menuHolder(holder)) {
            this.deny(event);
            if (this.allowedClick(event)) {
               if (event.getRawSlot() >= 0 && event.getRawSlot() < top.getSize()) {
                  if (event.getClickedInventory() == top) {
                     ItemStack current = event.getCurrentItem();
                     if (current != null && !current.getType().isAir()) {
                        if (this.startMenuClickCooldown(player)) {
                           UUID uuid = player.getUniqueId();
                           if (this.processing.add(uuid)) {
                              try {
                                 if (holder instanceof MainMenu) {
                                    this.handleMainMenu((MainMenu)holder, event, player);
                                 } else {
                                    this.handleConfirmMenu((ConfirmMenu)holder, event, player);
                                 }
                              } finally {
                                 this.processing.remove(uuid);
                              }
                           }
                        }
                     }
                  }
               }
            }
         } else {
            if (this.menuItem(event.getCurrentItem()) || this.menuItem(event.getCursor())) {
               this.deny(event);
               this.removeMenuItems(player);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
   public void onPlayerDrop(PlayerDropItemEvent event) {
      if (this.menuItem(event.getItemDrop().getItemStack())) {
         event.setCancelled(true);
         event.getItemDrop().remove();
         this.removeMenuItems(event.getPlayer());
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onInventoryClose(InventoryCloseEvent event) {
      if (event.getPlayer() instanceof Player) {
         if (this.menuHolder(event.getInventory().getHolder(false))) {
            this.removeMenuItems((Player)event.getPlayer());
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onQuit(PlayerQuitEvent event) {
      this.clearState(event.getPlayer().getUniqueId());
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onKick(PlayerKickEvent event) {
      this.clearState(event.getPlayer().getUniqueId());
   }

   private void handleMainMenu(MainMenu menu, InventoryClickEvent event, Player player) {
      int slot = event.getSlot();
      ItemStack item = event.getCurrentItem();
      if (slot == 49 && menu.page() == 0) {
         if (this.menuItem(item)) {
            String command = this.plugin.configManager().values().menu().backCommand();
            if (command != null && !command.trim().isEmpty()) {
               player.updateInventory();
               Bukkit.dispatchCommand(Bukkit.getConsoleSender(), MenuPlaceholderUtil.renderRaw(player, command));
            }
         }
      } else if (slot == 45 && menu.page() > 0) {
         if (this.menuItem(item)) {
            new MainMenu(this.plugin, player, menu.page() - 1).open(player);
         }
      } else if (slot == 53 && menu.hasNextPage()) {
         if (this.menuItem(item)) {
            new MainMenu(this.plugin, player, menu.page() + 1).open(player);
         }
      } else {
         String warpName = this.readWarpName(item);
         if (warpName != null && this.plugin.warpManager().warp(warpName).isPresent()) {
            if (event.isShiftClick()) {
               this.teleportToWarp(player, warpName);
            } else {
               new ConfirmMenu(this.plugin, player, warpName).open(player);
            }
         }
      }
   }

   private void handleConfirmMenu(ConfirmMenu menu, InventoryClickEvent event, Player player) {
      int slot = event.getSlot();
      ItemStack item = event.getCurrentItem();
      if (this.menuItem(item)) {
         if (menu.cancelSlot(slot)) {
            player.closeInventory();
         } else if (menu.confirmSlot(slot)) {
            this.teleportToWarp(player, menu.warpName());
         }
      }
   }

   private void teleportToWarp(Player player, String warpName) {
      Warp warp = this.plugin.warpManager().warp(warpName).orElse(null);
      if (warp != null && !warp.expired(System.currentTimeMillis())) {
         Location location = warp.location();
         if (location != null && location.getWorld() != null) {
            player.closeInventory();
            player.teleportAsync(location).thenAccept(done -> {
               if (Boolean.TRUE.equals(done) && player.isOnline()) {
                  player.sendMessage(this.plugin.configManager().message(player, "warp-teleported", warp));
               }
            });
         } else {
            player.closeInventory();
            player.sendMessage(this.plugin.configManager().message(player, "warp-does-not-exist"));
         }
      } else {
         player.closeInventory();
         player.sendMessage(this.plugin.configManager().message(player, "warp-does-not-exist"));
      }
   }

   private boolean menuHolder(InventoryHolder holder) {
      return holder instanceof MainMenu || holder instanceof ConfirmMenu;
   }

   private void deny(InventoryClickEvent event) {
      event.setCancelled(true);
      event.setResult(Result.DENY);
   }

   private boolean allowedClick(InventoryClickEvent event) {
      InventoryAction action = event.getAction();
      return action == InventoryAction.PICKUP_ALL
         || action == InventoryAction.PICKUP_HALF
         || action == InventoryAction.PICKUP_ONE
         || action == InventoryAction.PICKUP_SOME
         || action == InventoryAction.MOVE_TO_OTHER_INVENTORY
         || action == InventoryAction.COLLECT_TO_CURSOR
         || action == InventoryAction.HOTBAR_SWAP;
   }

   private boolean startMenuClickCooldown(Player player) {
      UUID uuid = player.getUniqueId();
      long now = System.currentTimeMillis();
      Long until = this.clickCooldownUntil.get(uuid);
      if (until != null && until > now) {
         return false;
      }

      this.clickCooldownUntil.put(uuid, now + 250L);
      return true;
   }

   private String readWarpName(ItemStack item) {
      if (item != null && !item.getType().isAir() && item.hasItemMeta()) {
         ItemMeta meta = item.getItemMeta();
         return meta == null ? null : (String)meta.getPersistentDataContainer().get(this.warpKey, PersistentDataType.STRING);
      } else {
         return null;
      }
   }

   private boolean menuItem(ItemStack item) {
      if (item != null && MainMenu.menuMaterial(item.getType()) && item.hasItemMeta()) {
         return item.getPersistentDataContainer().has(this.menuItemKey, PersistentDataType.BYTE);
      } else {
         return false;
      }
   }

   private void removeMenuItems(Player player) {
      ItemStack cursor = player.getItemOnCursor();
      if (this.menuItem(cursor)) {
         player.setItemOnCursor(new ItemStack(Material.AIR));
      }

      PlayerInventory inventory = player.getInventory();

      for (int slot = 0; slot < inventory.getSize(); slot++) {
         if (this.menuItem(inventory.getItem(slot))) {
            inventory.setItem(slot, null);
         }
      }

      player.updateInventory();
   }

   private void clearState(UUID uuid) {
      this.processing.remove(uuid);
      this.clickCooldownUntil.remove(uuid);
   }
}
