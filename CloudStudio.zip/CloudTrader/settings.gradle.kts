rootProject.name = "CloudTrader"
