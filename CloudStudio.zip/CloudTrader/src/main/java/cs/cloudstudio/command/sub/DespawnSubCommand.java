package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudTrader;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.config.Config;
import org.bukkit.command.CommandSender;

public final class DespawnSubCommand extends BaseCommand {
   public DespawnSubCommand(CloudTrader plugin) {
      super(plugin);
   }

   @Override
   public String getName() {
      return "despawn";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      if (!this.plugin.getTraderManager().hasActiveTrader()) {
         Config.send(sender, "messages.no-trader");
      } else {
         this.plugin.getTraderManager().despawn();
         Config.send(sender, "messages.removed");
      }
   }
}
