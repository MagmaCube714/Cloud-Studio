package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudTrader;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.config.Config;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand extends BaseCommand {
   public ReloadSubCommand(CloudTrader plugin) {
      super(plugin);
   }

   @Override
   public String getName() {
      return "reload";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      this.plugin.reloadAll();
      Config.send(sender, "messages.config-reloaded");
   }
}
