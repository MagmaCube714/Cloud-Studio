package cs.cloudstudio.command;

import cs.cloudstudio.CloudTrader;
import cs.cloudstudio.command.sub.DespawnSubCommand;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import cs.cloudstudio.command.sub.SpawnSubCommand;
import cs.cloudstudio.config.Config;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class AdminCommand implements CommandExecutor, TabCompleter {
   private static final String PERMISSION = "cloudtrader.admin";
   private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();

   public AdminCommand(CloudTrader plugin) {
      this.register(new SpawnSubCommand(plugin));
      this.register(new DespawnSubCommand(plugin));
      this.register(new ReloadSubCommand(plugin));
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!this.hasAdminPermission(sender)) {
         Config.send(sender, "messages.no-permission");
         return true;
      } else if (args.length == 0) {
         this.sendHelp(sender);
         return true;
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            this.sendHelp(sender);
            return true;
         } else {
            subCommand.execute(sender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!this.hasAdminPermission(sender)) {
         return Collections.emptyList();
      }

      if (args.length == 1) {
         String prefix = args[0].toLowerCase(Locale.ROOT);
         List<String> result = new ArrayList<>();

         for (String name : this.subCommands.keySet()) {
            if (name.startsWith(prefix)) {
               result.add(name);
            }
         }

         return result;
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         return subCommand == null ? Collections.emptyList() : subCommand.tab(sender, args);
      }
   }

   private void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.getName(), subCommand);
   }

   private boolean hasAdminPermission(CommandSender sender) {
      return !(sender instanceof Player) || sender.hasPermission("cloudtrader.admin");
   }

   private void sendHelp(CommandSender sender) {
      Config.send(sender, "messages.help");
   }
}
