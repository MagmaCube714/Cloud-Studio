package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudTrader;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.config.Config;
import org.bukkit.command.CommandSender;

public final class SpawnSubCommand extends BaseCommand {
   public SpawnSubCommand(CloudTrader plugin) {
      super(plugin);
   }

   @Override
   public String getName() {
      return "spawn";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      if (this.plugin.getTraderManager().hasActiveTrader()) {
         Config.send(sender, "messages.already-exists");
      } else {
         this.plugin.getTraderManager().spawn(sender);
      }
   }
}
