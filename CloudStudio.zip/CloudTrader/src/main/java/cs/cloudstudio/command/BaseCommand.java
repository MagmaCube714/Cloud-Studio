package cs.cloudstudio.command;

import cs.cloudstudio.CloudTrader;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.CommandSender;

public abstract class BaseCommand implements SubCommand {
   protected final CloudTrader plugin;

   protected BaseCommand(CloudTrader plugin) {
      this.plugin = plugin;
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      return Collections.emptyList();
   }
}
