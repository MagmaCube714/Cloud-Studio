package cs.cloudstudio.manager.npc;

import org.bukkit.Location;

public final class TraderNpc {
   private final String id;
   private final Location location;

   public TraderNpc(String id, Location location) {
      this.id = id;
      this.location = location == null ? null : location.clone();
   }

   public String getId() {
      return this.id;
   }

   public Location getLocation() {
      return this.location == null ? null : this.location.clone();
   }
}
