package cs.cloudstudio.manager;

import java.util.Collections;
import java.util.List;
import org.bukkit.Material;

public final class ItemManager {
   private final String key;
   private final Material material;
   private final String name;
   private final double price;
   private final int maxLimit;
   private final int amount;
   private final int slot;
   private final String command;
   private final List<String> description;
   private final boolean enchant;
   private final int modelData;
   private final String targetMenuKey;

   public ItemManager(
      String key,
      Material material,
      String name,
      int slot,
      double price,
      int maxLimit,
      int amount,
      String command,
      List<String> description,
      boolean enchant,
      int modelData,
      String targetMenuKey
   ) {
      this.key = key;
      this.material = material;
      this.name = name == null ? "" : name;
      this.price = price;
      this.maxLimit = maxLimit;
      this.amount = Math.max(1, amount);
      this.slot = slot;
      this.command = command == null ? "" : command;
      this.description = description == null ? Collections.emptyList() : description;
      this.enchant = enchant;
      this.modelData = modelData;
      this.targetMenuKey = targetMenuKey;
   }

   public String getKey() {
      return this.key;
   }

   public Material getMaterial() {
      return this.material;
   }

   public String getName() {
      return this.name;
   }

   public double getPrice() {
      return this.price;
   }

   public int getMaxLimit() {
      return this.maxLimit;
   }

   public int getAmount() {
      return this.amount;
   }

   public int getSlot() {
      return this.slot;
   }

   public String getCommand() {
      return this.command;
   }

   public List<String> getDescription() {
      return this.description;
   }

   public boolean isEnchant() {
      return this.enchant;
   }

   public int getModelData() {
      return this.modelData;
   }

   public boolean isNavigation() {
      return this.targetMenuKey != null && !this.targetMenuKey.isEmpty();
   }

   public String getTargetMenuKey() {
      return this.targetMenuKey;
   }
}
