package cs.cloudstudio.manager.npc;

import org.bukkit.Location;

public interface TraderNpcService {
   TraderNpc spawn(Location var1, String var2, String var3, boolean var4);

   void despawn(TraderNpc var1);
}
