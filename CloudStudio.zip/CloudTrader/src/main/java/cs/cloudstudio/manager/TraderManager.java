package cs.cloudstudio.manager;

import cs.cloudstudio.CloudTrader;
import cs.cloudstudio.config.Config;
import cs.cloudstudio.manager.npc.TraderNpc;
import cs.cloudstudio.manager.npc.TraderNpcService;
import cs.cloudstudio.manager.npc.ZnpcsPlusTraderNpcService;
import cs.cloudstudio.util.LocationUtil;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public final class TraderManager {
   private static final String TRADER_NAME = "&c&lТАЙНЫЙ ТОРГОВЕЦ";
   private static final String TRADER_SKIN = "GwynRoach";
   private static final boolean USE_SKIN = true;
   private static final int MIN_ONLINE_PLAYERS = 1;
   private static final int SPAWN_MAX_ATTEMPTS = 64;
   private static final long LIVE_TIME_SECONDS = 600L;
   private final CloudTrader plugin;
   private final TraderNpcService traderNpcService;
   private BukkitTask spawnTask;
   private BukkitTask despawnTask;
   private volatile TraderNpc activeTrader;
   private long lastSpawnTimeMillis;
   private long spawnIntervalTicks;
   private boolean searching;

   public TraderManager(CloudTrader plugin) {
      this.plugin = plugin;
      this.traderNpcService = new ZnpcsPlusTraderNpcService(plugin);
   }

   public void start() {
      this.scheduleSpawner();
   }

   public void reload() {
      this.cancelSpawnTask();
      this.despawn();
      this.scheduleSpawner();
   }

   public void shutdown() {
      this.searching = false;
      this.cancelSpawnTask();
      this.cancelDespawnTask();
      this.despawn();
   }

   public boolean hasActiveTrader() {
      return this.activeTrader != null;
   }

   public Location getTraderLocation() {
      return this.activeTrader == null ? null : this.activeTrader.getLocation();
   }

   public boolean isActiveTraderId(String npcId) {
      TraderNpc trader = this.activeTrader;
      return trader != null && npcId != null && npcId.equals(trader.getId());
   }

   public boolean canOpenTrader(Player player) {
      Location traderLocation = this.getTraderLocation();
      return traderLocation != null && traderLocation.getWorld() != null && player.getWorld() == traderLocation.getWorld()
         ? player.getLocation().distanceSquared(traderLocation) <= 64.0
         : false;
   }

   public long getNextSpawnTime() {
      if (this.hasActiveTrader()) {
         return 0L;
      }

      long interval = Math.max(20L, this.spawnIntervalTicks);
      long ticksSinceLastSpawn = (System.currentTimeMillis() - this.lastSpawnTimeMillis) / 50L;
      long remaining = interval - ticksSinceLastSpawn % interval;
      return Math.max(0L, remaining);
   }

   public void spawn(CommandSender sender) {
      if (this.activeTrader == null && this.plugin.isEnabled() && !this.searching) {
         World world = this.spawnWorld();
         if (world == null) {
            this.sendOrLog(sender, "messages.no-safe-location", "no_safe_location_message");
         } else {
            int maxX = Config.getInt("settings.cord-x", 5000, "settings.coord-x", "trader-settings.spawn-radius", "spawn_radius");
            int maxZ = Config.getInt("settings.cord-y", 5000, "settings.coord-y", "trader-settings.spawn-radius", "spawn_radius");
            int attempts = Config.getInt("settings.spawn-attempts", 64, "settings.spawn_attempts", "trader-settings.spawn-attempts");
            this.searching = true;
            this.searchSpawn(sender, world, Math.max(1, Math.abs(maxX)), Math.max(1, Math.abs(maxZ)), Math.max(1, Math.min(256, attempts)));
         }
      }
   }

   private void searchSpawn(CommandSender sender, World world, int maxX, int maxZ, int attemptsLeft) {
      if (!this.plugin.isEnabled() || this.activeTrader != null) {
         this.searching = false;
         return;
      }

      ThreadLocalRandom random = ThreadLocalRandom.current();

      while (attemptsLeft > 0) {
         attemptsLeft--;
         int x = random.nextInt(-maxX, maxX + 1);
         int z = random.nextInt(-maxZ, maxZ + 1);
         int chunkX = x >> 4;
         int chunkZ = z >> 4;
         if (world.isChunkLoaded(chunkX, chunkZ)) {
            Location found = LocationUtil.findSafeInColumn(world, x, z);
            if (found != null) {
               this.searching = false;
               this.spawnAt(sender, found);
               return;
            }
         } else if (LocationUtil.isGenerated(world, chunkX, chunkZ)) {
            int remaining = attemptsLeft;
            world.getChunkAtAsync(chunkX, chunkZ, false).whenComplete((chunk, throwable) -> {
               if (throwable == null && chunk != null && this.plugin.isEnabled() && this.activeTrader == null) {
                  Location found = LocationUtil.findSafeInColumn(world, x, z);
                  if (found != null) {
                     this.searching = false;
                     this.spawnAt(sender, found);
                     return;
                  }
               }

               this.searchSpawn(sender, world, maxX, maxZ, remaining);
            });
            return;
         }
      }

      this.searching = false;
      this.sendOrLog(sender, "messages.no-safe-location", "no_safe_location_message");
   }

   private void spawnAt(CommandSender sender, Location spawnLocation) {
      if (this.activeTrader == null && this.plugin.isEnabled()) {
         TraderNpc spawnedTrader;
         try {
            String traderName = Config.getRawString("settings.name", "&c&lТАЙНЫЙ ТОРГОВЕЦ", "trader-settings.name", "trader_name");
            String traderSkin = Config.getRawString("settings.skin", "GwynRoach", "trader-settings.skin", "trader_skin");
            boolean useSkin = Config.getBoolean("settings.use-skin", true, "settings.use_skin", "trader-settings.use-skin", "use_skin");
            spawnedTrader = this.traderNpcService.spawn(spawnLocation, Config.color(traderName), traderSkin, useSkin);
         } catch (Throwable exception) {
            this.activeTrader = null;
            this.plugin.getLogger().warning("[CloudTrader] Торговец не создан: " + exception.getMessage());
            this.sendOrLog(sender, "messages.cannot-spawn", "cannot_spawn_message");
            return;
         }

         if (spawnedTrader == null) {
            this.sendOrLog(sender, "messages.cannot-spawn", "cannot_spawn_message");
         } else {
            this.activeTrader = spawnedTrader;
            this.plugin.getLimitManager().resetLimits();
            this.lastSpawnTimeMillis = System.currentTimeMillis();
            this.broadcastSpawn(spawnLocation);
            this.scheduleDespawn(spawnedTrader.getId());
         }
      }
   }

   public void despawn() {
      TraderNpc trader = this.activeTrader;
      if (trader != null) {
         this.cancelDespawnTask();
         this.activeTrader = null;

         try {
            this.traderNpcService.despawn(trader);
         } catch (Throwable exception) {
            this.plugin.getLogger().warning("[CloudTrader] Торговец не удалён: " + exception.getMessage());
         }

         this.plugin.getLimitManager().resetLimits();
      }
   }

   private World spawnWorld() {
      String worldName = Config.getRawString("settings.world", "world", "trader-settings.spawn-world", "spawn_world");
      return Bukkit.getWorld(worldName != null && !worldName.trim().isEmpty() ? worldName.trim() : "world");
   }

   private void scheduleSpawner() {
      this.spawnIntervalTicks = this.parseIntervalToTicks(Config.getRawString("settings.interval", "3600", "trader-settings.spawn-interval", "spawn_interval"));
      this.lastSpawnTimeMillis = System.currentTimeMillis();
      this.spawnTask = Bukkit.getScheduler().runTaskTimer(this.plugin, new Runnable() {
         @Override
         public void run() {
            if (TraderManager.this.activeTrader == null && TraderManager.this.plugin.isEnabled()) {
               int minOnline = Config.getInt("settings.min-online", 1, "settings.min_online", "trader-settings.min-online");
               if (Bukkit.getOnlinePlayers().size() >= Math.max(0, minOnline)) {
                  TraderManager.this.spawn(null);
               }
            }
         }
      }, this.spawnIntervalTicks, this.spawnIntervalTicks);
   }

   private void scheduleDespawn(final String spawnedNpcId) {
      this.cancelDespawnTask();
      long liveTimeSeconds = Config.getLong("settings.live-time", 600L, "settings.live_time", "trader-settings.live-time");
      if (liveTimeSeconds > 0L) {
         this.despawnTask = Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
            @Override
            public void run() {
               if (TraderManager.this.activeTrader != null && TraderManager.this.activeTrader.getId().equals(spawnedNpcId)) {
                  TraderManager.this.despawn();
               }
            }
         }, Math.max(20L, liveTimeSeconds * 20L));
      }
   }

   private void broadcastSpawn(Location location) {
      String message = Config.getString("messages.spawned", "trader_spawn_message");
      if (!message.isEmpty()) {
         String x = String.valueOf(location.getBlockX());
         String z = String.valueOf(location.getBlockZ());
         if (message.indexOf(123) != -1) {
            Bukkit.broadcastMessage(message.replace("{x}", x).replace("{z}", z));
         } else {
            try {
               Bukkit.broadcastMessage(String.format(message, x, z));
            } catch (RuntimeException ignored) {
               Bukkit.broadcastMessage(message);
            }
         }
      }
   }

   private void sendOrLog(CommandSender sender, String path, String legacyPath) {
      if (sender != null) {
         String message = Config.getString(path, legacyPath);
         if (!message.isEmpty()) {
            sender.sendMessage(message);
         }
      }
   }

   private void cancelSpawnTask() {
      if (this.spawnTask != null) {
         this.spawnTask.cancel();
         this.spawnTask = null;
      }
   }

   private void cancelDespawnTask() {
      if (this.despawnTask != null) {
         this.despawnTask.cancel();
         this.despawnTask = null;
      }
   }

   private long parseIntervalToTicks(String value) {
      if (value == null) {
         return 72000L;
      }

      String interval = value.trim().toLowerCase();

      try {
         long multiplier = 20L;
         String number = interval;
         if (interval.endsWith("s")) {
            multiplier = 20L;
            number = interval.substring(0, interval.length() - 1);
         } else if (interval.endsWith("m")) {
            multiplier = 1200L;
            number = interval.substring(0, interval.length() - 1);
         } else if (interval.endsWith("h")) {
            multiplier = 72000L;
            number = interval.substring(0, interval.length() - 1);
         }

         long seconds = Long.parseLong(number.trim());
         if (seconds <= 0L) {
            return 72000L;
         } else {
            return seconds > Long.MAX_VALUE / multiplier ? 72000L : Math.max(20L, seconds * multiplier);
         }
      } catch (NumberFormatException exception) {
         return 72000L;
      }
   }
}
