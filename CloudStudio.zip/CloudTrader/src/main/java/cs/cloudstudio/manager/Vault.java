package cs.cloudstudio.manager;

import cs.cloudstudio.CloudTrader;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class Vault {
   private final CloudTrader plugin;
   private Economy economy;

   public Vault(CloudTrader plugin) {
      this.plugin = plugin;
   }

   public boolean setupEconomy() {
      if (this.plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
         return false;
      } else {
         RegisteredServiceProvider<Economy> provider = this.plugin.getServer().getServicesManager().getRegistration(Economy.class);
         if (provider != null && provider.getProvider() != null) {
            this.economy = (Economy)provider.getProvider();
            return true;
         } else {
            this.plugin.getLogger().warning("[CloudTrader] Экономика Vault не подключена: нужен плагин экономики (EssentialsX, CMI)");
            return false;
         }
      }
   }

   public double getBalance(Player player) {
      return this.economy == null ? 0.0 : this.economy.getBalance(player);
   }

   public boolean withdraw(Player player, double amount) {
      if (this.economy != null && !(amount < 0.0)) {
         EconomyResponse response = this.economy.withdrawPlayer(player, amount);
         if (!response.transactionSuccess()) {
            this.plugin.getLogger().warning("[CloudTrader] Деньги не сняты у " + player.getName() + ": " + response.errorMessage);
            return false;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   public boolean deposit(Player player, double amount) {
      if (this.economy != null && !(amount <= 0.0)) {
         EconomyResponse response = this.economy.depositPlayer(player, amount);
         if (!response.transactionSuccess()) {
            this.plugin.getLogger().warning("[CloudTrader] Деньги не возвращены игроку " + player.getName() + ": " + response.errorMessage);
            return false;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }
}
