package cs.cloudstudio.manager;

import cs.cloudstudio.CloudTrader;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitTask;

public final class LimitManager {
   private final CloudTrader plugin;
   private final Map<String, Integer> purchasedByItemKey = new HashMap<>();
   private File limitsFile;
   private FileConfiguration limitsConfig;
   private BukkitTask saveTask;

   public LimitManager(CloudTrader plugin) {
      this.plugin = plugin;
      this.loadLimitsConfig();
   }

   public synchronized void reloadLimits() {
      this.cancelPendingSave();
      this.loadLimitsConfig();
   }

   public synchronized int getPurchased(String itemKey) {
      Integer value = this.purchasedByItemKey.get(normalizeKey(itemKey));
      return value == null ? 0 : Math.max(0, value);
   }

   public synchronized boolean tryConsume(String itemKey, int maxLimit) {
      if (maxLimit <= 0) {
         return true;
      }

      String key = normalizeKey(itemKey);
      int purchased = this.getPurchased(key);
      if (purchased >= maxLimit) {
         return false;
      }

      this.purchasedByItemKey.put(key, purchased + 1);
      this.scheduleSaveLimits();
      return true;
   }

   public synchronized void release(String itemKey) {
      String key = normalizeKey(itemKey);
      int purchased = this.getPurchased(key);
      if (purchased <= 1) {
         this.purchasedByItemKey.remove(key);
      } else {
         this.purchasedByItemKey.put(key, purchased - 1);
      }

      this.scheduleSaveLimits();
   }

   public synchronized void resetLimits() {
      this.purchasedByItemKey.clear();
      this.scheduleSaveLimits();
   }

   public synchronized void saveLimits() {
      this.cancelPendingSave();
      this.writeLimits();
   }

   private synchronized void scheduleSaveLimits() {
      if (this.saveTask == null && this.plugin.isEnabled()) {
         this.saveTask = this.plugin.getServer().getScheduler().runTaskLaterAsynchronously(this.plugin, () -> {
            synchronized (this) {
               this.saveTask = null;
               this.writeLimits();
            }
         }, 20L);
      }
   }

   private void cancelPendingSave() {
      if (this.saveTask != null) {
         this.saveTask.cancel();
         this.saveTask = null;
      }
   }

   private void writeLimits() {
      if (this.limitsConfig != null && this.limitsFile != null) {
         try {
            this.limitsConfig.set("limits", null);
            this.limitsConfig.set("global_limits", null);

            for (Entry<String, Integer> entry : this.purchasedByItemKey.entrySet()) {
               if (entry.getValue() != null && entry.getValue() > 0) {
                  this.limitsConfig.set("global_limits." + normalizeKey(entry.getKey()), entry.getValue());
               }
            }

            java.nio.file.Path target = this.limitsFile.toPath();
            java.nio.file.Path temp = target.resolveSibling(target.getFileName() + ".tmp");
            java.nio.file.Files.writeString(temp, this.limitsConfig.saveToString(), java.nio.charset.StandardCharsets.UTF_8);
            try {
               java.nio.file.Files.move(temp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
               java.nio.file.Files.move(temp, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
         } catch (IOException exception) {
            this.plugin.getLogger().warning("[CloudTrader] limits.yml не сохранён: " + exception.getMessage());
         }
      }
   }

   private synchronized void loadLimitsConfig() {
      this.limitsFile = new File(this.plugin.getDataFolder(), "limits.yml");
      if (!this.limitsFile.exists()) {
         try {
            File parent = this.limitsFile.getParentFile();
            if (parent != null) {
               parent.mkdirs();
            }

            this.limitsFile.createNewFile();
         } catch (IOException exception) {
            this.plugin.getLogger().warning("[CloudTrader] limits.yml не создан: " + exception.getMessage());
         }
      }

      this.limitsConfig = YamlConfiguration.loadConfiguration(this.limitsFile);
      this.loadLimits();
   }

   private void loadLimits() {
      this.purchasedByItemKey.clear();
      ConfigurationSection section = this.limitsConfig.getConfigurationSection("global_limits");
      if (section != null) {
         this.loadSection(section, "");
      } else {
         ConfigurationSection legacy = this.limitsConfig.getConfigurationSection("limits");
         if (legacy != null) {
            this.loadSection(legacy, "");
         }
      }
   }

   private void loadSection(ConfigurationSection section, String prefix) {
      for (String child : section.getKeys(false)) {
         String path = prefix.isEmpty() ? child : prefix + "." + child;
         if (section.isConfigurationSection(child)) {
            this.loadSection(section.getConfigurationSection(child), path);
         } else {
            int value = section.getInt(child, 0);
            if (value > 0) {
               this.purchasedByItemKey.put(normalizeKey(path), value);
            }
         }
      }
   }

   private static String normalizeKey(String itemKey) {
      return itemKey == null ? "" : itemKey.trim().replace(':', '.');
   }
}
