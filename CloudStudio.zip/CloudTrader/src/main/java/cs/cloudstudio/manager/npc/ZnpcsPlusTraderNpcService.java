package cs.cloudstudio.manager.npc;

import cs.cloudstudio.CloudTrader;
import lol.pyr.znpcsplus.api.NpcApi;
import lol.pyr.znpcsplus.api.NpcApiProvider;
import lol.pyr.znpcsplus.api.entity.EntityProperty;
import lol.pyr.znpcsplus.api.hologram.Hologram;
import lol.pyr.znpcsplus.api.npc.Npc;
import lol.pyr.znpcsplus.api.npc.NpcEntry;
import lol.pyr.znpcsplus.api.npc.NpcRegistry;
import lol.pyr.znpcsplus.api.npc.NpcType;
import lol.pyr.znpcsplus.api.skin.SkinDescriptor;
import lol.pyr.znpcsplus.util.NpcLocation;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public final class ZnpcsPlusTraderNpcService implements TraderNpcService {
   private static final String NPC_ID = "cloudtrader";
   private static final String NPC_TYPE = "player";
   private final CloudTrader plugin;

   public ZnpcsPlusTraderNpcService(CloudTrader plugin) {
      this.plugin = plugin;
   }

   @Override
   public TraderNpc spawn(Location location, String displayName, String skinName, boolean useSkin) {
      if (location != null && location.getWorld() != null) {
         NpcApi api = this.getApi();
         NpcRegistry registry = api.getNpcRegistry();
         String npcId = this.getNpcId();

         try {
            this.safeDelete(registry, npcId);
            NpcType npcType = api.getNpcTypeRegistry().getByName(this.getNpcType());
            if (npcType == null) {
               throw new IllegalStateException("ZNPCsPlus NPC type not found: " + this.getNpcType());
            }

            NpcEntry entry = registry.create(npcId, location.getWorld(), npcType, new NpcLocation(location));
            entry.enableEverything();
            entry.setSave(false);
            entry.setAllowCommandModification(false);
            Npc npc = entry.getNpc();
            npc.setWorld(location.getWorld());
            npc.setLocation(new NpcLocation(location));
            npc.clearActions();
            Hologram hologram = npc.getHologram();
            hologram.clearLines();
            hologram.addLine(this.toMiniMessage(displayName));
            npc.setEnabled(true);
            this.showToOnlinePlayers(npc);
            this.applySkin(api, npcId, skinName, useSkin);
            return new TraderNpc(npcId, location);
         } catch (Throwable exception) {
            this.safeDelete(registry, npcId);
            if (exception instanceof RuntimeException) {
               throw (RuntimeException)exception;
            } else {
               throw new IllegalStateException("Failed to spawn ZNPCsPlus trader", exception);
            }
         }
      } else {
         throw new IllegalStateException("Invalid trader location");
      }
   }

   @Override
   public void despawn(TraderNpc traderNpc) {
      if (traderNpc != null) {
         try {
            this.safeDelete(this.getApi().getNpcRegistry(), traderNpc.getId());
         } catch (Throwable exception) {
            this.plugin.getLogger().warning("[CloudTrader] ZNPCsPlus NPC не удалён: " + traderNpc.getId() + ": " + exception.getMessage());
         }
      }
   }

   private void applySkin(final NpcApi api, final String npcId, String skinName, boolean useSkin) {
      if (useSkin && skinName != null && !skinName.trim().isEmpty()) {
         final EntityProperty<SkinDescriptor> skinProperty;
         try {
            skinProperty = api.getPropertyRegistry().getByName("skin", SkinDescriptor.class);
         } catch (Throwable exception) {
            this.plugin.getLogger().warning("[CloudTrader] Skin-property ZNPCsPlus не получен: " + exception.getMessage());
            return;
         }

         if (skinProperty != null) {
            final String skin = skinName.trim();
            Bukkit.getScheduler()
               .runTaskAsynchronously(
                  this.plugin,
                  new Runnable() {
                     @Override
                     public void run() {
                        final SkinDescriptor descriptor;
                        try {
                           descriptor = api.getSkinDescriptorFactory().createStaticDescriptor(skin);
                        } catch (Throwable exception) {
                           ZnpcsPlusTraderNpcService.this.plugin
                              .getLogger()
                              .warning("[CloudTrader] Скин торговца не загружен " + skin + ": " + exception.getMessage());
                           return;
                        }

                        if (descriptor != null && ZnpcsPlusTraderNpcService.this.plugin.isEnabled()) {
                           Bukkit.getScheduler()
                              .runTask(
                                 ZnpcsPlusTraderNpcService.this.plugin,
                                 new Runnable() {
                                    @Override
                                    public void run() {
                                       if (ZnpcsPlusTraderNpcService.this.plugin.isEnabled()) {
                                          try {
                                             NpcEntry entry = ZnpcsPlusTraderNpcService.this.getApi().getNpcRegistry().getById(npcId);
                                             if (entry == null) {
                                                return;
                                             }

                                             Npc npc = entry.getNpc();
                                             npc.setProperty(skinProperty, descriptor);
                                             npc.setEnabled(true);
                                             ZnpcsPlusTraderNpcService.this.showToOnlinePlayers(npc);
                                          } catch (Throwable exception) {
                                             ZnpcsPlusTraderNpcService.this.plugin
                                                .getLogger()
                                                .warning("[CloudTrader] Скин торговца не применён " + skin + ": " + exception.getMessage());
                                          }
                                       }
                                    }
                                 }
                              );
                        }
                     }
                  }
               );
         }
      }
   }

   private void showToOnlinePlayers(Npc npc) {
      if (npc != null) {
         for (Player player : Bukkit.getOnlinePlayers()) {
            try {
               npc.show(player);
            } catch (Throwable var5) {
            }
         }
      }
   }

   private void safeDelete(NpcRegistry registry, String npcId) {
      if (registry != null && npcId != null && !npcId.isEmpty()) {
         try {
            if (registry.getById(npcId) != null) {
               registry.delete(npcId);
            }
         } catch (Throwable var4) {
         }
      }
   }

   private NpcApi getApi() {
      NpcApi api = NpcApiProvider.get();
      if (api == null) {
         throw new IllegalStateException("ZNPCsPlus API is not ready");
      } else {
         return api;
      }
   }

   private String getNpcId() {
      return "cloudtrader";
   }

   private String getNpcType() {
      return "player";
   }

   private String toMiniMessage(String value) {
      if (value != null && !value.isEmpty()) {
         StringBuilder result = new StringBuilder(value.length());

         for (int i = 0; i < value.length(); i++) {
            char current = value.charAt(i);
            if ((current == '&' || current == 167) && i + 1 < value.length()) {
               String tag = this.legacyCodeToMiniMessage(Character.toLowerCase(value.charAt(i + 1)));
               if (tag != null) {
                  result.append(tag);
                  i++;
                  continue;
               }
            }

            if (current == '<') {
               result.append("\\<");
            } else if (current == '\\') {
               result.append("\\\\");
            } else {
               result.append(current);
            }
         }

         return result.toString();
      } else {
         return "";
      }
   }

   private String legacyCodeToMiniMessage(char code) {
      switch (code) {
         case '0':
            return "<black>";
         case '1':
            return "<dark_blue>";
         case '2':
            return "<dark_green>";
         case '3':
            return "<dark_aqua>";
         case '4':
            return "<dark_red>";
         case '5':
            return "<dark_purple>";
         case '6':
            return "<gold>";
         case '7':
            return "<gray>";
         case '8':
            return "<dark_gray>";
         case '9':
            return "<blue>";
         case ':':
         case ';':
         case '<':
         case '=':
         case '>':
         case '?':
         case '@':
         case 'A':
         case 'B':
         case 'C':
         case 'D':
         case 'E':
         case 'F':
         case 'G':
         case 'H':
         case 'I':
         case 'J':
         case 'K':
         case 'L':
         case 'M':
         case 'N':
         case 'O':
         case 'P':
         case 'Q':
         case 'R':
         case 'S':
         case 'T':
         case 'U':
         case 'V':
         case 'W':
         case 'X':
         case 'Y':
         case 'Z':
         case '[':
         case '\\':
         case ']':
         case '^':
         case '_':
         case '`':
         case 'g':
         case 'h':
         case 'i':
         case 'j':
         case 'k':
         case 'p':
         case 'q':
         default:
            return null;
         case 'a':
            return "<green>";
         case 'b':
            return "<aqua>";
         case 'c':
            return "<red>";
         case 'd':
            return "<light_purple>";
         case 'e':
            return "<yellow>";
         case 'f':
            return "<white>";
         case 'l':
            return "<bold>";
         case 'm':
            return "<strikethrough>";
         case 'n':
            return "<underlined>";
         case 'o':
            return "<italic>";
         case 'r':
            return "<reset>";
      }
   }
}
