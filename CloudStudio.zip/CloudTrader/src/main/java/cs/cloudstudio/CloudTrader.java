package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.listener.TraderListener;
import cs.cloudstudio.manager.LimitManager;
import cs.cloudstudio.manager.TraderManager;
import cs.cloudstudio.manager.Vault;
import cs.cloudstudio.menu.TraderMenu;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudTrader extends JavaPlugin {
   private static CloudTrader instance;
   private Vault vault;
   private LimitManager limitManager;
   private TraderMenu traderMenu;
   private TraderManager traderManager;

   public void onEnable() {
      instance = this;
      this.saveDefaultConfig();
      if (!this.checkRequiredDependencies()) {
         Bukkit.getPluginManager().disablePlugin(this);
      } else {
         this.vault = new Vault(this);
         if (!this.vault.setupEconomy()) {
            this.console("&fCloudTrader &cэкономика Vault не подключена (нужен плагин экономики: EssentialsX, CMI), плагин отключён");
            Bukkit.getPluginManager().disablePlugin(this);
         } else {
            this.limitManager = new LimitManager(this);
            this.traderMenu = new TraderMenu(this);
            this.traderManager = new TraderManager(this);
            this.registerCommand();
            Bukkit.getPluginManager().registerEvents(new TraderListener(this), this);
            this.traderManager.start();
            this.console("&fCloudTrader &aуспешно загружен!");
         }
      }
   }

   public void onDisable() {
      if (this.traderManager != null) {
         this.traderManager.shutdown();
      }

      if (this.limitManager != null) {
         this.limitManager.saveLimits();
      }

      this.console("&fCloudTrader &cуспешно выгружен!");
      instance = null;
   }

   private boolean checkRequiredDependencies() {
      if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
         this.console("&fCloudTrader &cэкономика Vault не подключена (нужен плагин экономики: EssentialsX, CMI), плагин отключён");
         return false;
      } else if (Bukkit.getPluginManager().getPlugin("ZNPCsPlus") == null) {
         this.console("&fCloudTrader &cZNPCsPlus не найден, плагин отключён");
         return false;
      } else {
         return true;
      }
   }

   private void registerCommand() {
      PluginCommand command = this.getCommand("cloudtrader");
      if (command == null) {
         this.getLogger().warning("[CloudTrader] Команда cloudtrader не указана в plugin.yml");
         Bukkit.getPluginManager().disablePlugin(this);
      } else {
         AdminCommand adminCommand = new AdminCommand(this);
         command.setExecutor(adminCommand);
         command.setTabCompleter(adminCommand);
      }
   }

   public void reloadAll() {
      this.reloadConfig();
      this.limitManager.reloadLimits();
      this.traderMenu.reload();
      this.traderManager.reload();
   }

   public void console(String message) {
      Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', message));
   }

   public static CloudTrader getInstance() {
      return instance;
   }

   public Vault getVault() {
      return this.vault;
   }

   public LimitManager getLimitManager() {
      return this.limitManager;
   }

   public TraderMenu getTraderMenu() {
      return this.traderMenu;
   }

   public TraderManager getTraderManager() {
      return this.traderManager;
   }
}
