package cs.cloudstudio.menu;

import cs.cloudstudio.CloudTrader;
import cs.cloudstudio.config.Config;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public final class TraderMenu {
   private static final String DEFAULT_MENU_KEY = "menu_1";
   private final CloudTrader plugin;
   private String defaultMenuKey;

   public TraderMenu(CloudTrader plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.defaultMenuKey = Config.getRawString("settings.default-menu", "menu_1");
   }

   public void openDefault(Player player) {
      this.open(player, this.defaultMenuKey);
   }

   public void open(Player player, String menuKey) {
      Holder holder = Holder.create(this.plugin, player, normalizeMenuKey(menuKey));
      if (holder == null) {
         player.sendMessage(Config.getString("messages.menu-not-found", "menu_not_found_message"));
      } else {
         holder.refresh(player);
         player.openInventory(holder.getInventory());
      }
   }

   public void switchMenu(Player player, Holder currentHolder, String menuKey) {
      Holder nextHolder = Holder.create(this.plugin, player, normalizeMenuKey(menuKey));
      if (nextHolder == null) {
         player.sendMessage(Config.getString("messages.menu-not-found", "menu_not_found_message"));
      } else {
         Inventory topInventory = player.getOpenInventory().getTopInventory();
         if (topInventory.getHolder() == currentHolder && currentHolder.copyFrom(nextHolder)) {
            currentHolder.refresh(player);
         } else {
            nextHolder.refresh(player);
            player.openInventory(nextHolder.getInventory());
         }
      }
   }

   public void refreshOpenMenus() {
      for (Player player : Bukkit.getOnlinePlayers()) {
         Inventory topInventory = player.getOpenInventory().getTopInventory();
         if (topInventory.getHolder() instanceof Holder) {
            ((Holder)topInventory.getHolder()).refresh(player);
         }
      }
   }

   private static String normalizeMenuKey(String menuKey) {
      return menuKey != null && !menuKey.trim().isEmpty() ? menuKey.trim() : "menu_1";
   }
}
