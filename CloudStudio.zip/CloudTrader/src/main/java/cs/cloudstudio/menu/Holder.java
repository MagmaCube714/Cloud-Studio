package cs.cloudstudio.menu;

import cs.cloudstudio.CloudTrader;
import cs.cloudstudio.config.Config;
import cs.cloudstudio.manager.ItemManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class Holder implements InventoryHolder {
   private final CloudTrader plugin;
   private final Inventory inventory;
   private final Map<Integer, ItemManager> itemsMap = new HashMap<>();
   private String menuKey;
   private String title;

   private Holder(CloudTrader plugin, Player player, String menuKey, ConfigurationSection section) {
      this.plugin = plugin;
      this.menuKey = menuKey;
      int size = normalizeSize(section.getInt("size", 54));
      this.title = buildTitle(player, menuKey, section.getString("name", "&fМеню"));
      this.inventory = Bukkit.createInventory(this, size, this.title);
      this.load(section);
   }

   public static Holder create(CloudTrader plugin, Player player, String menuKey) {
      ConfigurationSection section = plugin.getConfig().getConfigurationSection("menu." + menuKey);
      return section == null ? null : new Holder(plugin, player, menuKey, section);
   }

   public String getMenuKey() {
      return this.menuKey;
   }

   public ItemManager getItem(int slot) {
      return this.itemsMap.get(slot);
   }

   public boolean copyFrom(Holder other) {
      if (other == null || other.inventory.getSize() != this.inventory.getSize()) {
         return false;
      }

      if (!this.title.equals(other.title)) {
         return false;
      }

      this.menuKey = other.menuKey;
      this.itemsMap.clear();
      this.itemsMap.putAll(other.itemsMap);
      this.inventory.setContents(other.inventory.getContents());
      return true;
   }

   public void refresh(Player player) {
      for (Entry<Integer, ItemManager> entry : this.itemsMap.entrySet()) {
         ItemManager item = entry.getValue();
         if (!item.isNavigation()) {
            this.inventory.setItem(entry.getKey(), this.buildItem(item));
         }
      }

      player.updateInventory();
   }

   public Inventory getInventory() {
      return this.inventory;
   }

   private void load(ConfigurationSection section) {
      this.itemsMap.clear();
      this.inventory.clear();
      this.loadNavigation(section.getConfigurationSection("next"), "next");
      ConfigurationSection backSection = section.getConfigurationSection("back");
      if (backSection == null) {
         backSection = section.getConfigurationSection("previous");
      }

      this.loadNavigation(backSection, "back");
      this.loadItems(section.getConfigurationSection("items"));
   }

   private void loadNavigation(ConfigurationSection section, String key) {
      if (section != null) {
         int slot = section.getInt("slot", -1);
         Material material = Material.matchMaterial(getString(section, "material", null, "ARROW"));
         String targetMenuKey = this.getNavigationTarget(key);
         if (this.isValidSlot(slot) && material != null && !targetMenuKey.isEmpty()) {
            ItemManager item = new ItemManager(
               "navigation." + key,
               material,
               Config.color(getString(section, "name", null, "")),
               slot,
               0.0,
               0,
               1,
               "",
               this.colorList(getStringList(section, "lore", "description")),
               false,
               getInt(section, "model-data", "model_data", 0),
               targetMenuKey
            );
            this.itemsMap.put(slot, item);
            this.inventory.setItem(slot, this.buildItem(item));
         }
      }
   }

   private void loadItems(ConfigurationSection itemsSection) {
      if (itemsSection != null) {
         for (String itemId : itemsSection.getKeys(false)) {
            ConfigurationSection section = itemsSection.getConfigurationSection(itemId);
            if (section != null) {
               int slot = section.getInt("slot", -1);
               Material material = Material.matchMaterial(getString(section, "material", null, "STONE"));
               if (this.isValidSlot(slot) && material != null && material != Material.AIR) {
                  ItemManager item = new ItemManager(
                     this.menuKey + "." + itemId,
                     material,
                     Config.color(getString(section, "name", null, "")),
                     slot,
                     section.getDouble("price", 0.0),
                     getInt(section, "max-limit", "max_limit", 0),
                     section.getInt("amount", 1),
                     section.getString("command", ""),
                     this.colorList(getStringList(section, "lore", "description")),
                     section.getBoolean("enchant", false),
                     getInt(section, "model-data", "model_data", 0),
                     null
                  );
                  this.itemsMap.put(slot, item);
                  this.inventory.setItem(slot, this.buildItem(item));
               }
            }
         }
      }
   }

   private ItemStack buildItem(ItemManager item) {
      ItemStack stack = new ItemStack(item.getMaterial(), item.getAmount());
      ItemMeta meta = stack.getItemMeta();
      if (meta != null) {
         if (!item.getName().isEmpty()) {
            meta.setDisplayName(item.getName());
         }

         meta.setLore(this.buildLore(item));
         if (item.isEnchant()) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
         }

         if (item.getModelData() > 0) {
            meta.setCustomModelData(item.getModelData());
         }

         stack.setItemMeta(meta);
      }

      return stack;
   }

   private List<String> buildLore(ItemManager item) {
      List<String> lore = new ArrayList<>(item.getDescription().size());

      for (String line : item.getDescription()) {
         lore.add(
            line.replace("%price%", formatPrice(item.getPrice()))
               .replace("%item_purchased%", String.valueOf(this.plugin.getLimitManager().getPurchased(item.getKey())))
               .replace("%item-purchased%", String.valueOf(this.plugin.getLimitManager().getPurchased(item.getKey())))
               .replace("%max_limit%", String.valueOf(item.getMaxLimit()))
               .replace("%max-limit%", String.valueOf(item.getMaxLimit()))
         );
      }

      return lore;
   }

   private String getNavigationTarget(String key) {
      int direction;
      if ("next".equalsIgnoreCase(key)) {
         direction = 1;
      } else {
         if (!"back".equalsIgnoreCase(key) && !"previous".equalsIgnoreCase(key)) {
            return "";
         }

         direction = -1;
      }

      String targetMenuKey = shiftMenuPage(this.menuKey, direction);
      return !targetMenuKey.isEmpty() && this.plugin.getConfig().isConfigurationSection("menu." + targetMenuKey) ? targetMenuKey : "";
   }

   private static String shiftMenuPage(String menuKey, int direction) {
      if (menuKey != null && !menuKey.isEmpty()) {
         int underscore = menuKey.lastIndexOf(95);
         if (underscore >= 0 && underscore + 1 < menuKey.length()) {
            try {
               int page = Integer.parseInt(menuKey.substring(underscore + 1));
               int targetPage = page + direction;
               return targetPage < 1 ? "" : menuKey.substring(0, underscore + 1) + targetPage;
            } catch (NumberFormatException ignored) {
               return "";
            }
         } else {
            return "";
         }
      } else {
         return "";
      }
   }

   private List<String> colorList(List<String> source) {
      List<String> result = new ArrayList<>(source.size());

      for (String line : source) {
         result.add(Config.color(line));
      }

      return result;
   }

   private boolean isValidSlot(Integer slot) {
      return slot != null && slot >= 0 && slot < this.inventory.getSize();
   }

   private static String getString(ConfigurationSection section, String key, String legacyKey, String defaultValue) {
      if (section.contains(key)) {
         return section.getString(key, defaultValue);
      } else {
         return legacyKey != null && section.contains(legacyKey) ? section.getString(legacyKey, defaultValue) : defaultValue;
      }
   }

   private static int getInt(ConfigurationSection section, String key, String legacyKey, int defaultValue) {
      if (section.contains(key)) {
         return section.getInt(key, defaultValue);
      } else {
         return legacyKey != null && section.contains(legacyKey) ? section.getInt(legacyKey, defaultValue) : defaultValue;
      }
   }

   private static List<String> getStringList(ConfigurationSection section, String key, String legacyKey) {
      if (section.contains(key)) {
         return section.getStringList(key);
      } else {
         return legacyKey != null && section.contains(legacyKey) ? section.getStringList(legacyKey) : new ArrayList<>(0);
      }
   }

   private static String buildTitle(Player player, String menuKey, String rawTitle) {
      String page = extractPage(menuKey);
      return Config.applyPlaceholders(
         player, rawTitle.replace("%menu%", menuKey).replace("%menu_key%", menuKey).replace("%menu-key%", menuKey).replace("%page%", page)
      );
   }

   private static String extractPage(String menuKey) {
      if (menuKey == null) {
         return "";
      }

      int underscore = menuKey.lastIndexOf(95);
      return underscore != -1 && underscore + 1 < menuKey.length() ? menuKey.substring(underscore + 1) : menuKey;
   }

   private static int normalizeSize(int size) {
      if (size < 9) {
         return 9;
      } else {
         return size > 54 ? 54 : (size + 8) / 9 * 9;
      }
   }

   private static String formatPrice(double price) {
      return price == Math.rint(price) ? String.valueOf((long)price) : String.valueOf(price);
   }
}
