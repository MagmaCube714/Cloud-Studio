package cs.cloudstudio.config;

import cs.cloudstudio.CloudTrader;
import cs.cloudstudio.util.ColorUtil;
import java.lang.reflect.Method;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public final class Config {
   private static Method placeholderApiMethod;
   private static boolean placeholderApiLookupDone;

   private Config() {
   }

   public static String getString(String path) {
      return color(getRawString(path, ""));
   }

   public static String getString(String path, String legacyPath) {
      return color(getRawString(path, "", legacyPath));
   }

   public static String getRawString(String path, String defaultValue, String... legacyPaths) {
      FileConfiguration config = getConfig();
      if (config == null) {
         return defaultValue;
      }

      if (config.contains(path)) {
         Object value = config.get(path);
         return value == null ? defaultValue : String.valueOf(value);
      }

      if (legacyPaths != null) {
         for (String legacyPath : legacyPaths) {
            if (legacyPath != null && !legacyPath.isEmpty() && config.contains(legacyPath)) {
               Object value = config.get(legacyPath);
               return value == null ? defaultValue : String.valueOf(value);
            }
         }
      }

      return defaultValue;
   }

   public static int getInt(String path, int defaultValue, String... legacyPaths) {
      FileConfiguration config = getConfig();
      if (config == null) {
         return defaultValue;
      }

      if (config.contains(path)) {
         return config.getInt(path, defaultValue);
      }

      if (legacyPaths != null) {
         for (String legacyPath : legacyPaths) {
            if (legacyPath != null && !legacyPath.isEmpty() && config.contains(legacyPath)) {
               return config.getInt(legacyPath, defaultValue);
            }
         }
      }

      return defaultValue;
   }

   public static long getLong(String path, long defaultValue, String... legacyPaths) {
      FileConfiguration config = getConfig();
      if (config == null) {
         return defaultValue;
      }

      if (config.contains(path)) {
         return config.getLong(path, defaultValue);
      }

      if (legacyPaths != null) {
         for (String legacyPath : legacyPaths) {
            if (legacyPath != null && !legacyPath.isEmpty() && config.contains(legacyPath)) {
               return config.getLong(legacyPath, defaultValue);
            }
         }
      }

      return defaultValue;
   }

   public static boolean getBoolean(String path, boolean defaultValue, String... legacyPaths) {
      FileConfiguration config = getConfig();
      if (config == null) {
         return defaultValue;
      }

      if (config.contains(path)) {
         return config.getBoolean(path, defaultValue);
      }

      if (legacyPaths != null) {
         for (String legacyPath : legacyPaths) {
            if (legacyPath != null && !legacyPath.isEmpty() && config.contains(legacyPath)) {
               return config.getBoolean(legacyPath, defaultValue);
            }
         }
      }

      return defaultValue;
   }

   public static String color(String text) {
      return ColorUtil.color(text);
   }

   public static String applyPlaceholders(Player player, String text) {
      if (text != null && !text.isEmpty()) {
         String result = text;
         if (player != null) {
            result = result.replace("%player%", safe(player.getName())).replace("%player_name%", safe(player.getName()));
         }

         CloudTrader plugin = CloudTrader.getInstance();
         if (plugin != null) {
            result = result.replace("%online%", String.valueOf(Bukkit.getOnlinePlayers().size()));
            if (plugin.getTraderManager() != null && plugin.getTraderManager().getTraderLocation() != null) {
               Location location = plugin.getTraderManager().getTraderLocation();
               result = result.replace("%trader_x%", String.valueOf(location.getBlockX()))
                  .replace("%trader_y%", String.valueOf(location.getBlockY()))
                  .replace("%trader_z%", String.valueOf(location.getBlockZ()));
            }
         }

         result = applyPlaceholderApi(player, result);
         return color(result);
      } else {
         return "";
      }
   }

   public static void send(CommandSender sender, String path) {
      send(sender, path, null);
   }

   public static void send(CommandSender sender, String path, String legacyPath) {
      String message = getString(path, legacyPath);
      if (!message.isEmpty()) {
         sender.sendMessage(message);
      }
   }

   private static FileConfiguration getConfig() {
      CloudTrader plugin = CloudTrader.getInstance();
      return plugin == null ? null : plugin.getConfig();
   }

   private static String applyPlaceholderApi(Player player, String text) {
      if (player != null && text.indexOf(37) != -1) {
         try {
            Method method = getPlaceholderApiMethod();
            if (method == null) {
               return text;
            }

            Object result = method.invoke(null, player, text);
            return result instanceof String ? (String)result : text;
         } catch (Throwable ignored) {
            return text;
         }
      } else {
         return text;
      }
   }

   private static Method getPlaceholderApiMethod() throws ClassNotFoundException, NoSuchMethodException {
      if (placeholderApiLookupDone) {
         return placeholderApiMethod;
      }

      placeholderApiLookupDone = true;
      Class<?> placeholderApiClass = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
      placeholderApiMethod = placeholderApiClass.getMethod("setPlaceholders", Player.class, String.class);
      return placeholderApiMethod;
   }

   private static String safe(String value) {
      return value == null ? "" : value;
   }
}
