package cs.cloudstudio.listener;

import cs.cloudstudio.CloudTrader;
import cs.cloudstudio.config.Config;
import cs.cloudstudio.manager.ItemManager;
import cs.cloudstudio.menu.Holder;
import cs.cloudstudio.util.ItemNameUtil;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import lol.pyr.znpcsplus.api.event.NpcInteractEvent;
import lol.pyr.znpcsplus.api.interaction.InteractionType;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class TraderListener implements Listener {
   private static final String INVENTORY_FULL_DEFAULT_MESSAGE = "&c&lТАЙНЫЙ ТОРГОВЕЦ &7» &fВаш инвентарь полон";
   private final CloudTrader plugin;
   private final Set<UUID> clickCooldown = new HashSet<>();

   public TraderListener(CloudTrader plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onNpcInteract(NpcInteractEvent event) {
      if (event.getClickType() == InteractionType.RIGHT_CLICK && event.getEntry() != null) {
         if (this.plugin.getTraderManager().isActiveTraderId(event.getEntry().getId())) {
            event.setCancelled(true);
            final Player player = event.getPlayer();
            Bukkit.getScheduler().runTask(this.plugin, new Runnable() {
               @Override
               public void run() {
                  if (player.isOnline() && TraderListener.this.plugin.getTraderManager().canOpenTrader(player)) {
                     TraderListener.this.plugin.getTraderMenu().openDefault(player);
                  }
               }
            });
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onInventoryClick(InventoryClickEvent event) {
      Inventory topInventory = event.getView().getTopInventory();
      if (topInventory.getHolder() instanceof Holder) {
         event.setCancelled(true);
         if (event.getWhoClicked() instanceof Player) {
            if (event.getClickedInventory() != null && event.getClickedInventory() == topInventory) {
               if (event.getRawSlot() >= 0 && event.getRawSlot() < topInventory.getSize()) {
                  ClickType clickType = event.getClick();
                  if (clickType.isLeftClick() || clickType.isRightClick()) {
                     ItemStack clicked = event.getCurrentItem();
                     if (clicked != null && clicked.getType() != Material.AIR) {
                        Holder holder = (Holder)topInventory.getHolder();
                        ItemManager item = holder.getItem(event.getRawSlot());
                        if (item != null) {
                           Player player = (Player)event.getWhoClicked();
                           if (this.tryStartClickCooldown(player)) {
                              if (item.isNavigation()) {
                                 this.plugin.getTraderMenu().switchMenu(player, holder, item.getTargetMenuKey());
                              } else {
                                 this.buyItem(player, holder, item);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onInventoryDrag(InventoryDragEvent event) {
      if (event.getView().getTopInventory().getHolder() instanceof Holder) {
         event.setCancelled(true);
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.clickCooldown.remove(event.getPlayer().getUniqueId());
   }

   private boolean tryStartClickCooldown(Player player) {
      final UUID uuid = player.getUniqueId();
      if (!this.clickCooldown.add(uuid)) {
         return false;
      }

      Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
         @Override
         public void run() {
            TraderListener.this.clickCooldown.remove(uuid);
         }
      }, Math.max(1L, Config.getLong("settings.click-delay-ticks", 5L)));
      return true;
   }

   private void buyItem(Player player, Holder holder, ItemManager item) {
      if (!this.hasInventorySpace(player, item)) {
         this.sendInventoryFullMessage(player);
      } else if (item.getPrice() > 0.0 && this.plugin.getVault().getBalance(player) < item.getPrice()) {
         player.sendMessage(Config.getString("messages.insufficient-funds", "insufficient_funds_message"));
      } else {
         String command = item.getCommand() == null ? "" : item.getCommand().replace("%player%", player.getName());
         command = command.trim();
         if (command.startsWith("/")) {
            command = command.substring(1).trim();
         }

         if (!this.isRegisteredCommand(command)) {
            player.sendMessage(Config.getString("messages.purchase-error", "cannot_spawn_message"));
         } else {
            boolean reservedLimit = item.getMaxLimit() > 0;
            if (!this.plugin.getLimitManager().tryConsume(item.getKey(), item.getMaxLimit())) {
               player.sendMessage(Config.getString("messages.max-limit-reached", "max_limit_reached_message"));
               holder.refresh(player);
            } else if (item.getPrice() > 0.0 && !this.plugin.getVault().withdraw(player, item.getPrice())) {
               if (reservedLimit) {
                  this.plugin.getLimitManager().release(item.getKey());
               }

               player.sendMessage(Config.getString("messages.insufficient-funds", "insufficient_funds_message"));
               holder.refresh(player);
            } else {
               String failure = null;
               try {
                  if (!Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command)) {
                     failure = "команда вернула ошибку";
                  }
               } catch (RuntimeException exception) {
                  failure = exception.toString();
               }

               if (failure != null) {
                  if (item.getPrice() > 0.0 && !this.plugin.getVault().deposit(player, item.getPrice())) {
                     this.plugin.getLogger().severe("[CloudTrader] Не удалось вернуть " + item.getPrice() + " игроку " + player.getName() + " после ошибки покупки: " + command);
                  }
                  if (reservedLimit) {
                     this.plugin.getLimitManager().release(item.getKey());
                  }
                  this.plugin.getLogger().warning("[CloudTrader] Покупка отменена, деньги возвращены (" + failure + "): " + command);
                  player.sendMessage(Config.getString("messages.purchase-error", "cannot_spawn_message"));
                  holder.refresh(player);
                  return;
               }

               player.sendMessage(this.formatPurchaseMessage(item));
               this.plugin.getTraderMenu().refreshOpenMenus();
            }
         }
      }
   }

   private boolean isRegisteredCommand(String command) {
      if (command == null) {
         return false;
      }

      String trimmed = command.trim();
      if (trimmed.startsWith("/")) {
         trimmed = trimmed.substring(1).trim();
      }

      if (trimmed.isEmpty()) {
         return false;
      }

      int separator = trimmed.indexOf(32);
      String root = separator < 0 ? trimmed : trimmed.substring(0, separator);
      return Bukkit.getCommandMap().getCommand(root) != null;
   }

   private void sendInventoryFullMessage(Player player) {
      String message = Config.color(Config.getRawString("messages.inventory-full", "&c&lТАЙНЫЙ ТОРГОВЕЦ &7» &fВаш инвентарь полон", "inventory_full_message"));
      if (!message.isEmpty()) {
         player.sendMessage(message);
      }
   }

   private boolean hasInventorySpace(Player player, ItemManager item) {
      ItemStack stack = this.getExpectedPurchaseStack(item);
      if (stack.getType() != Material.AIR && stack.getAmount() > 0) {
         int remaining = stack.getAmount();
         int maxStackSize = Math.min(stack.getMaxStackSize(), player.getInventory().getMaxStackSize());
         if (maxStackSize <= 0) {
            maxStackSize = 64;
         }

         ItemStack probe = stack.clone();
         probe.setAmount(1);
         ItemStack[] contents = player.getInventory().getStorageContents();

         for (ItemStack content : contents) {
            if (!isEmpty(content) && content.isSimilar(probe)) {
               int free = Math.min(maxStackSize, content.getMaxStackSize()) - content.getAmount();
               if (free > 0) {
                  remaining -= free;
                  if (remaining <= 0) {
                     return true;
                  }
               }
            }
         }

         for (ItemStack content : contents) {
            if (isEmpty(content)) {
               remaining -= maxStackSize;
               if (remaining <= 0) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private ItemStack getExpectedPurchaseStack(ItemManager item) {
      Material material = item.getMaterial();
      int amount = item.getAmount();
      String[] giveArgs = parseGiveCommand(item.getCommand());
      if (giveArgs != null) {
         Material parsedMaterial = parseMaterial(giveArgs[0]);
         if (parsedMaterial != null && parsedMaterial != Material.AIR) {
            material = parsedMaterial;
         }

         amount = parsePositiveInt(giveArgs[1], amount);
      }

      return new ItemStack(material == null ? Material.AIR : material, Math.max(1, amount));
   }

   private static String[] parseGiveCommand(String command) {
      if (command == null) {
         return null;
      }

      String normalized = command.trim();
      if (normalized.isEmpty()) {
         return null;
      }

      if (normalized.charAt(0) == '/') {
         normalized = normalized.substring(1).trim();
      }

      String[] parts = normalized.split("\\s+");
      if (parts.length >= 3 && isGiveCommand(parts[0])) {
         String amount = parts.length >= 4 ? parts[3] : "1";
         return new String[]{parts[2], amount};
      } else {
         return null;
      }
   }

   private static boolean isGiveCommand(String commandName) {
      return "give".equalsIgnoreCase(commandName)
         || "minecraft:give".equalsIgnoreCase(commandName)
         || "bukkit:give".equalsIgnoreCase(commandName)
         || "essentials:give".equalsIgnoreCase(commandName);
   }

   private static Material parseMaterial(String rawMaterial) {
      if (rawMaterial != null && !rawMaterial.isEmpty()) {
         String materialName = rawMaterial;
         int dataStart = firstIndexOfAny(materialName, '[', '{');
         if (dataStart > 0) {
            materialName = materialName.substring(0, dataStart);
         }

         Material material = Material.matchMaterial(materialName);
         if (material != null) {
            return material;
         }

         int namespaceIndex = materialName.indexOf(58);
         return namespaceIndex >= 0 && namespaceIndex + 1 < materialName.length() ? Material.matchMaterial(materialName.substring(namespaceIndex + 1)) : null;
      } else {
         return null;
      }
   }

   private static int firstIndexOfAny(String value, char first, char second) {
      int firstIndex = value.indexOf(first);
      int secondIndex = value.indexOf(second);
      if (firstIndex < 0) {
         return secondIndex;
      } else {
         return secondIndex < 0 ? firstIndex : Math.min(firstIndex, secondIndex);
      }
   }

   private static int parsePositiveInt(String value, int defaultValue) {
      try {
         int parsed = Integer.parseInt(value);
         return parsed > 0 ? parsed : defaultValue;
      } catch (NumberFormatException ignored) {
         return defaultValue;
      }
   }

   private static boolean isEmpty(ItemStack stack) {
      return stack == null || stack.getType() == Material.AIR || stack.getAmount() <= 0;
   }

   private String formatPurchaseMessage(ItemManager item) {
      String itemName = this.resolveItemName(item);
      String price = formatPrice(item.getPrice());
      String message = Config.getString("messages.purchased", "purchase_message");
      if (message.indexOf(123) != -1) {
         return message.replace("{item}", itemName).replace("{price}", price);
      }

      try {
         return String.format(message, itemName, price);
      } catch (RuntimeException ignored) {
         return message;
      }
   }

   private String resolveItemName(ItemManager item) {
      return !item.getName().isEmpty() ? item.getName() : ItemNameUtil.fallback(item.getMaterial());
   }

   private static String formatPrice(double price) {
      return price == Math.rint(price) ? String.valueOf((long)price) : String.valueOf(price);
   }
}
