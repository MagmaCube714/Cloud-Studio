package cs.cloudstudio.util;

import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

public final class LocationUtil {
   private LocationUtil() {
   }

   public static Location findRandomSafeLocation(World world, int radius, int maxAttempts) {
      return findRandomSafeLocation(world, radius, radius, maxAttempts);
   }

   public static Location findRandomSafeLocation(World world, int maxX, int maxZ, int maxAttempts) {
      if (world == null) {
         return null;
      }

      int safeX = Math.max(1, Math.abs(maxX));
      int safeZ = Math.max(1, Math.abs(maxZ));
      int attempts = Math.max(1, Math.min(256, maxAttempts));
      ThreadLocalRandom random = ThreadLocalRandom.current();
      int maxY = Math.max(2, world.getMaxHeight() - 2);

      for (int attempt = 0; attempt < attempts; attempt++) {
         int x = random.nextInt(-safeX, safeX + 1);
         int z = random.nextInt(-safeZ, safeZ + 1);
         if (isChunkGenerated(world, x >> 4, z >> 4)) {
            Location location = findSafeInColumn(world, x, z);
            if (location != null) {
               return location;
            }
         }
      }

      return null;
   }

   public static Location findSafeInColumn(World world, int x, int z) {
      ThreadLocalRandom random = ThreadLocalRandom.current();
      int maxY = Math.max(2, world.getMaxHeight() - 2);
      int highestY;
      try {
         highestY = Math.min(world.getHighestBlockYAt(x, z), maxY);
      } catch (Throwable ignored) {
         return null;
      }

      if (highestY > 1 && !isLiquid(blockTypeAt(world, x, highestY, z))) {
         int minY = Math.max(1, highestY - 24);

         for (int y = highestY; y >= minY; y--) {
            Location location = new Location(world, x + 0.5, y + 1.0, z + 0.5, random.nextFloat() * 360.0F, 0.0F);
            if (isSafeLocation(location)) {
               return location;
            }
         }
      }

      return null;
   }

   public static boolean isGenerated(World world, int chunkX, int chunkZ) {
      return isChunkGenerated(world, chunkX, chunkZ);
   }

   public static boolean isSafeLocation(Location location) {
      if (location != null && location.getWorld() != null) {
         Block body = location.getBlock();
         Block head = location.clone().add(0.0, 1.0, 0.0).getBlock();
         Block ground = location.clone().subtract(0.0, 1.0, 0.0).getBlock();
         Material groundType = ground.getType();
         if (!groundType.isSolid() || isUnsafeGround(groundType)) {
            return false;
         } else {
            return isSafeAir(body.getType()) && isSafeAir(head.getType()) ? !hasLiquidAbove(location) : false;
         }
      } else {
         return false;
      }
   }

   private static boolean hasLiquidAbove(Location location) {
      World world = location.getWorld();
      int x = location.getBlockX();
      int z = location.getBlockZ();
      int fromY = location.getBlockY() + 2;
      int highestY = Math.min(world.getHighestBlockYAt(x, z), world.getMaxHeight() - 1);
      if (fromY > highestY) {
         return false;
      }

      for (int y = fromY; y <= highestY; y++) {
         if (isLiquid(blockTypeAt(world, x, y, z))) {
            return true;
         }
      }

      return false;
   }

   private static Material blockTypeAt(World world, int x, int y, int z) {
      try {
         return world.getBlockAt(x, y, z).getType();
      } catch (Throwable ignored) {
         return Material.AIR;
      }
   }

   private static boolean isChunkGenerated(World world, int chunkX, int chunkZ) {
      try {
         return world.isChunkGenerated(chunkX, chunkZ);
      } catch (Throwable ignored) {
         return true;
      }
   }

   private static boolean isSafeAir(Material material) {
      return material != null && material.isAir();
   }

   private static boolean isLiquid(Material material) {
      return material == Material.WATER || material == Material.LAVA;
   }

   private static boolean isUnsafeGround(Material material) {
      switch (material) {
         case WATER:
         case LAVA:
         case FIRE:
         case SOUL_FIRE:
         case CACTUS:
         case MAGMA_BLOCK:
         case CAMPFIRE:
         case SOUL_CAMPFIRE:
         case SWEET_BERRY_BUSH:
            return true;
         default:
            return false;
      }
   }
}
