package cs.cloudstudio.util;

import org.bukkit.Material;

public final class ItemNameUtil {
   private ItemNameUtil() {
   }

   public static String fallback(Material material) {
      if (material == null) {
         return "Неизвестный предмет";
      }

      String[] parts = material.name().toLowerCase().split("_");
      StringBuilder builder = new StringBuilder();

      for (String part : parts) {
         if (!part.isEmpty()) {
            if (builder.length() > 0) {
               builder.append(' ');
            }

            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
         }
      }

      return builder.length() == 0 ? material.name() : builder.toString();
   }
}
