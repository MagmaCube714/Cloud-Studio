package cs.cloudstudio.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.ChatColor;

public final class ColorUtil {
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

   private ColorUtil() {
   }

   public static String color(String text) {
      if (text == null) {
         return "";
      }

      Matcher matcher = HEX_PATTERN.matcher(text);
      StringBuffer buffer = new StringBuffer();

      while (matcher.find()) {
         String hex = matcher.group(1);
         StringBuilder builder = new StringBuilder("§x");

         for (char symbol : hex.toCharArray()) {
            builder.append('§').append(symbol);
         }

         matcher.appendReplacement(buffer, Matcher.quoteReplacement(builder.toString()));
      }

      matcher.appendTail(buffer);
      return ChatColor.translateAlternateColorCodes('&', buffer.toString());
   }
}
