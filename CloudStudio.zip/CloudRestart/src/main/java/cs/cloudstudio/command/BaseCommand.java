package cs.cloudstudio.command;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public abstract class BaseCommand {
   private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();

   protected void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.name().toLowerCase(Locale.ROOT), subCommand);
   }

   protected SubCommand find(String name) {
      return name == null ? null : this.subCommands.get(name.toLowerCase(Locale.ROOT));
   }

   protected Collection<String> names() {
      return this.subCommands.keySet();
   }
}
