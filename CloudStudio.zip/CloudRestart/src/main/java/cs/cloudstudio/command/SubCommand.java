package cs.cloudstudio.command;

import org.bukkit.command.CommandSender;

public interface SubCommand {
   String name();

   void execute(CommandSender var1, String[] var2);
}
