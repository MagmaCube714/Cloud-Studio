package cs.cloudstudio.command.sub;

import cs.cloudstudio.command.SubCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.manager.RestartManager;
import org.bukkit.command.CommandSender;

public final class StopSubCommand implements SubCommand {
   private final ConfigManager configManager;
   private final RestartManager restartManager;

   public StopSubCommand(ConfigManager configManager, RestartManager restartManager) {
      this.configManager = configManager;
      this.restartManager = restartManager;
   }

   @Override
   public String name() {
      return "stop";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      if (!this.restartManager.stopRestart()) {
         sender.sendMessage(this.configManager.messages().notRunning());
      }
   }
}
