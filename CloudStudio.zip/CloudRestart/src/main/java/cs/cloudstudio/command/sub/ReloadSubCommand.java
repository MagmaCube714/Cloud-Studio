package cs.cloudstudio.command.sub;

import cs.cloudstudio.command.SubCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.manager.ScheduleManager;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand implements SubCommand {
   private final ConfigManager configManager;
   private final ScheduleManager scheduleManager;

   public ReloadSubCommand(ConfigManager configManager, ScheduleManager scheduleManager) {
      this.configManager = configManager;
      this.scheduleManager = scheduleManager;
   }

   @Override
   public String name() {
      return "reload";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      if (!this.configManager.reload()) {
         sender.sendMessage(this.configManager.messages().reloadFailed());
      } else {
         this.scheduleManager.scheduleNext();
         sender.sendMessage(this.configManager.messages().reloaded());
      }
   }
}
