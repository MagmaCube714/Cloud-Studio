package cs.cloudstudio.command;

import cs.cloudstudio.command.sub.ReloadSubCommand;
import cs.cloudstudio.command.sub.StartSubCommand;
import cs.cloudstudio.command.sub.StopSubCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.manager.RestartManager;
import cs.cloudstudio.manager.ScheduleManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public final class AdminCommand extends BaseCommand implements CommandExecutor, TabCompleter {
   private static final String PERMISSION = "cloudrestart.admin";
   private final ConfigManager configManager;

   public AdminCommand(ConfigManager configManager, RestartManager restartManager, ScheduleManager scheduleManager) {
      this.configManager = configManager;
      this.register(new StartSubCommand(configManager, restartManager));
      this.register(new StopSubCommand(configManager, restartManager));
      this.register(new ReloadSubCommand(configManager, scheduleManager));
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("cloudrestart.admin")) {
         sender.sendMessage(this.configManager.messages().noPermission());
         return true;
      } else if (args.length == 0) {
         sender.sendMessage(this.configManager.messages().usage());
         return true;
      } else {
         SubCommand subCommand = this.find(args[0]);
         if (subCommand == null) {
            sender.sendMessage(this.configManager.messages().usage());
            return true;
         } else {
            subCommand.execute(sender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (sender.hasPermission("cloudrestart.admin") && args.length == 1) {
         String input = args[0].toLowerCase(Locale.ROOT);
         List<String> result = new ArrayList<>();

         for (String name : this.names()) {
            if (name.startsWith(input)) {
               result.add(name);
            }
         }

         return result;
      } else {
         return Collections.emptyList();
      }
   }
}
