package cs.cloudstudio.manager;

import java.util.UUID;
import me.neznamy.tab.api.TabAPI;
import me.neznamy.tab.api.TabPlayer;
import me.neznamy.tab.api.bossbar.BarColor;
import me.neznamy.tab.api.bossbar.BarStyle;
import me.neznamy.tab.api.bossbar.BossBar;
import me.neznamy.tab.api.bossbar.BossBarManager;
import me.neznamy.tab.api.event.EventBus;
import me.neznamy.tab.api.event.EventHandler;
import me.neznamy.tab.api.event.player.PlayerLoadEvent;
import me.neznamy.tab.api.event.plugin.TabLoadEvent;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class RestartBossBar {
   private final Plugin plugin;
   private TabAPI tabApi;
   private BossBarManager tabBossBars;
   private EventBus tabEventBus;
   private EventHandler<PlayerLoadEvent> playerLoadHandler;
   private EventHandler<TabLoadEvent> tabLoadHandler;
   private BossBar bar;
   private boolean visible;
   private String currentTitle = "";
   private float currentProgress = -1.0F;

   public RestartBossBar(Plugin plugin) {
      this.plugin = plugin;
   }

   public void show(String title, double progress) {
      this.visible = true;
      this.currentTitle = title == null ? "" : title;
      this.currentProgress = this.toPercent(progress);
      if (this.ensureBar()) {
         for (Player player : Bukkit.getOnlinePlayers()) {
            this.addViewer(player.getUniqueId());
         }
      }
   }

   public void update(String title, double progress) {
      if (this.visible && this.bar != null) {
         String safeTitle = title == null ? "" : title;
         if (!this.currentTitle.equals(safeTitle)) {
            try {
               this.bar.setTitle(safeTitle);
            } catch (RuntimeException exception) {
               this.handleBroken(exception);
               return;
            }

            this.currentTitle = safeTitle;
         }

         float pct = this.toPercent(progress);
         if (Float.compare(this.currentProgress, pct) != 0) {
            try {
               this.bar.setProgress(pct);
            } catch (RuntimeException exception) {
               this.handleBroken(exception);
               return;
            }

            this.currentProgress = pct;
         }
      }
   }

   public void addPlayer(Player player) {
      if (this.visible && this.bar != null && player != null) {
         this.addViewer(player.getUniqueId());
      }
   }

   public void removePlayer(Player player) {
      if (this.bar != null && player != null) {
         TabPlayer tabPlayer = this.getTabPlayer(player.getUniqueId());

         try {
            if (tabPlayer != null && this.bar.containsPlayer(tabPlayer)) {
               this.bar.removePlayer(tabPlayer);
            }
         } catch (RuntimeException var4) {
         }
      }
   }

   public void hide() {
      this.visible = false;
      BossBar current = this.bar;
      this.bar = null;
      this.currentTitle = "";
      this.currentProgress = -1.0F;
      if (current != null && this.tabBossBars != null) {
         try {
            this.tabBossBars.removeBossBar(current);
         } catch (RuntimeException var3) {
         }
      }
   }

   public void shutdown() {
      this.hide();
      this.unregisterTabEvents();
      this.tabApi = null;
      this.tabBossBars = null;
   }

   private boolean ensureBar() {
      if (this.bar != null) {
         return true;
      }

      if (!this.isTabReady() && !this.refreshTabApi()) {
         return false;
      }

      int attempt = 0;

      while (attempt < 2) {
         try {
            this.bar = this.tabBossBars.createBossBar(this.currentTitle, this.currentProgress, BarColor.RED, BarStyle.PROGRESS);
            return true;
         } catch (IllegalStateException exception) {
            this.bar = null;
            if (attempt > 0 || !this.refreshTabApi()) {
               this.plugin.getLogger().warning("TAB не смог создать bossbar: " + exception.getMessage());
               return false;
            }

            attempt++;
         } catch (RuntimeException exception) {
            this.bar = null;
            this.plugin.getLogger().warning("TAB не смог создать bossbar: " + exception.getMessage());
            return false;
         }
      }

      return false;
   }

   private void addViewer(UUID uuid) {
      TabPlayer tabPlayer = this.getTabPlayer(uuid);
      if (tabPlayer != null && tabPlayer.isLoaded()) {
         try {
            if (!this.bar.containsPlayer(tabPlayer)) {
               this.bar.addPlayer(tabPlayer);
            }
         } catch (RuntimeException var4) {
         }
      }
   }

   private void handleBroken(RuntimeException exception) {
      this.bar = null;
      this.currentProgress = -1.0F;
      if (this.refreshTabApi() && this.ensureBar()) {
         for (Player player : Bukkit.getOnlinePlayers()) {
            this.addViewer(player.getUniqueId());
         }
      }
   }

   private TabPlayer getTabPlayer(UUID uuid) {
      return this.tabApi != null && uuid != null ? this.tabApi.getPlayer(uuid) : null;
   }

   private boolean isTabReady() {
      return this.tabApi != null && this.tabBossBars != null;
   }

   private boolean refreshTabApi() {
      if (Bukkit.getPluginManager().getPlugin("TAB") == null) {
         return false;
      }

      try {
         this.tabApi = TabAPI.getInstance();
         this.tabBossBars = this.tabApi.getBossBarManager();
      } catch (IllegalStateException | NoClassDefFoundError error) {
         this.tabApi = null;
         this.tabBossBars = null;
         return false;
      }

      if (this.tabBossBars == null) {
         return false;
      }

      this.registerTabEvents();
      return true;
   }

   private void registerTabEvents() {
      if (this.isTabReady() && this.tabEventBus == null) {
         this.tabEventBus = this.tabApi.getEventBus();
         if (this.tabEventBus != null) {
            this.playerLoadHandler = event -> this.onTabPlayerLoaded(event.getPlayer());
            this.tabLoadHandler = event -> this.onTabReloaded();
            this.tabEventBus.register(PlayerLoadEvent.class, this.playerLoadHandler);
            this.tabEventBus.register(TabLoadEvent.class, this.tabLoadHandler);
         }
      }
   }

   private void unregisterTabEvents() {
      if (this.tabEventBus != null) {
         try {
            if (this.playerLoadHandler != null) {
               this.tabEventBus.unregister(this.playerLoadHandler);
            }

            if (this.tabLoadHandler != null) {
               this.tabEventBus.unregister(this.tabLoadHandler);
            }
         } catch (RuntimeException var2) {
         }
      }

      this.tabEventBus = null;
      this.playerLoadHandler = null;
      this.tabLoadHandler = null;
   }

   private void onTabPlayerLoaded(TabPlayer tabPlayer) {
      if (tabPlayer != null && this.visible) {
         UUID uuid = tabPlayer.getUniqueId();
         Bukkit.getScheduler().runTask(this.plugin, () -> {
            if (this.visible && this.bar != null) {
               this.addViewer(uuid);
            }
         });
      }
   }

   private void onTabReloaded() {
      Bukkit.getScheduler().runTask(this.plugin, () -> {
         this.bar = null;
         this.currentProgress = -1.0F;
         if (this.visible && this.refreshTabApi() && this.ensureBar()) {
            for (Player player : Bukkit.getOnlinePlayers()) {
               this.addViewer(player.getUniqueId());
            }
         }
      });
   }

   private float toPercent(double progress) {
      return !Double.isNaN(progress) && !Double.isInfinite(progress) ? (float)(Math.max(0.0, Math.min(1.0, progress)) * 100.0) : 0.0F;
   }
}
