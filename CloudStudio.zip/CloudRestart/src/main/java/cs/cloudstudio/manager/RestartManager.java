package cs.cloudstudio.manager;

import cs.cloudstudio.CloudRestart;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.util.ColorUtil;
import java.time.Duration;
import java.util.ArrayList;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public final class RestartManager {
   private static final long TICKS_PER_SECOND = 20L;
   private static final long MILLIS_PER_SECOND = 1000L;
   private final CloudRestart plugin;
   private final ConfigManager configManager;
   private BukkitTask countdownTask;
   private BukkitTask shutdownTask;
   private final RestartBossBar bossBar;
   private ConfigManager.Settings activeSettings;
   private long deadlineMillis;
   private int lastDisplayedSecond = Integer.MIN_VALUE;
   private boolean restarting;
   private volatile boolean closing;
   private volatile Component closingMessage = Component.empty();

   public RestartManager(CloudRestart plugin, ConfigManager configManager) {
      this.plugin = plugin;
      this.configManager = configManager;
      this.bossBar = new RestartBossBar(plugin);
   }

   public boolean startRestart() {
      if (this.restarting) {
         return false;
      }

      this.activeSettings = this.configManager.settings();
      this.deadlineMillis = safeDeadline(System.currentTimeMillis(), this.activeSettings.countdownSeconds());
      this.lastDisplayedSecond = Integer.MIN_VALUE;
      this.restarting = true;
      this.createBossBar(this.activeSettings);
      this.startCountdown();
      return true;
   }

   public boolean isClosing() {
      return this.closing;
   }

   public Component closingMessage() {
      return this.closingMessage;
   }

   public boolean stopRestart() {
      if (!this.restarting || this.closing) {
         return false;
      }

      this.restarting = false;
      this.cancelTasks();
      this.broadcast(this.configManager.messages().stopNotify());
      return true;
   }

   public void shutdown() {
      this.restarting = false;
      this.cancelTasks();
      this.bossBar.shutdown();
   }

   public void addPlayer(Player player) {
      if (this.restarting) {
         this.bossBar.addPlayer(player);
      }
   }

   public void removePlayer(Player player) {
      this.bossBar.removePlayer(player);
   }

   private void startCountdown() {
      this.countdownTask = (new BukkitRunnable() {
         public void run() {
            if (RestartManager.this.restarting && RestartManager.this.activeSettings != null) {
               int secondsLeft = RestartManager.secondsUntil(RestartManager.this.deadlineMillis, System.currentTimeMillis());
               if (secondsLeft <= 0) {
                  RestartManager.this.countdownTask = null;
                  RestartManager.this.showFinalMessages(RestartManager.this.activeSettings);
                  RestartManager.this.scheduleShutdown(RestartManager.this.activeSettings);
                  this.cancel();
               } else if (secondsLeft != RestartManager.this.lastDisplayedSecond) {
                  RestartManager.this.lastDisplayedSecond = secondsLeft;
                  RestartManager.this.updateBossBar(RestartManager.this.activeSettings, secondsLeft);
                  if (RestartManager.this.activeSettings.shouldNotify(secondsLeft)) {
                     RestartManager.this.notifyPlayers(RestartManager.this.activeSettings, secondsLeft);
                  }
               }
            } else {
               RestartManager.this.countdownTask = null;
               this.cancel();
            }
         }
      }).runTaskTimer(this.plugin, 0L, 20L);
   }

   private void scheduleShutdown(final ConfigManager.Settings settings) {
      long delay = settings.finalDelaySeconds() * 20L;
      this.shutdownTask = Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
         @Override
         public void run() {
            RestartManager.this.shutdownTask = null;
            RestartManager.this.executeRestart(settings);
         }
      }, delay);
   }

   private void createBossBar(ConfigManager.Settings settings) {
      this.bossBar.show(settings.bossBar(settings.countdownSeconds()), 1.0);
   }

   private void updateBossBar(ConfigManager.Settings settings, int secondsLeft) {
      double progress = (double)secondsLeft / settings.countdownSeconds();
      this.bossBar.update(settings.bossBar(secondsLeft), progress);
   }

   private void notifyPlayers(ConfigManager.Settings settings, int secondsLeft) {
      this.broadcast(this.configManager.messages().startNotify(secondsLeft));
      Title title = Title.title(
         ColorUtil.component(settings.title(secondsLeft)), ColorUtil.component(settings.subtitle(secondsLeft)), times(10, 60, 10)
      );

      for (Player player : Bukkit.getOnlinePlayers()) {
         player.showTitle(title);
         player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
      }
   }

   private void showFinalMessages(ConfigManager.Settings settings) {
      this.broadcast(this.configManager.messages().finalNotify());
      this.removeBossBar();
      Title title = Title.title(ColorUtil.component(settings.finalTitle()), ColorUtil.component(settings.finalSubtitle()), times(10, 40, 10));

      for (Player player : Bukkit.getOnlinePlayers()) {
         player.showTitle(title);
      }
   }

   private static Title.Times times(int fadeInTicks, int stayTicks, int fadeOutTicks) {
      return Title.Times.times(Duration.ofMillis(fadeInTicks * 50L), Duration.ofMillis(stayTicks * 50L), Duration.ofMillis(fadeOutTicks * 50L));
   }

   private void executeRestart(ConfigManager.Settings settings) {
      if (this.restarting && !this.closing) {
         for (String command : settings.preShutdownCommands()) {
            try {
               boolean handled = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
               if (!handled) {
                  this.plugin.getLogger().warning("Команда перед выключением не обработана: " + command);
               }
            } catch (RuntimeException exception) {
               this.plugin.getLogger().log(Level.SEVERE, "Ошибка команды перед выключением '" + command + "'", exception);
            }
         }

         this.closing = true;
         this.closingMessage = ColorUtil.component(settings.kickMessage());
         this.removeBossBar();
         this.disconnectAndSave(this.closingMessage);
         long delay = settings.saveDelaySeconds() * 20L;
         if (delay <= 0L) {
            this.finishShutdown();
         } else {
            this.shutdownTask = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               this.shutdownTask = null;
               this.finishShutdown();
            }, delay);
         }
      }
   }

   private void disconnectAndSave(Component kickMessage) {
      for (Player player : new ArrayList<>(Bukkit.getOnlinePlayers())) {
         try {
            player.closeInventory();
         } catch (RuntimeException exception) {
            this.plugin.getLogger().log(Level.WARNING, "Не удалось закрыть инвентарь " + player.getName() + " перед рестартом", exception);
         }
      }

      try {
         Bukkit.savePlayers();
      } catch (RuntimeException exception) {
         this.plugin.getLogger().log(Level.SEVERE, "Не удалось сохранить игроков перед рестартом", exception);
      }

      for (Player player : new ArrayList<>(Bukkit.getOnlinePlayers())) {
         try {
            player.kick(kickMessage);
         } catch (RuntimeException exception) {
            this.plugin.getLogger().log(Level.WARNING, "Не удалось отключить " + player.getName() + " перед рестартом", exception);
         }
      }
   }

   private void finishShutdown() {
      this.restarting = false;
      this.activeSettings = null;
      Bukkit.shutdown();
   }

   private void cancelTasks() {
      if (this.countdownTask != null) {
         this.countdownTask.cancel();
         this.countdownTask = null;
      }

      if (this.shutdownTask != null) {
         this.shutdownTask.cancel();
         this.shutdownTask = null;
      }

      this.activeSettings = null;
      this.lastDisplayedSecond = Integer.MIN_VALUE;
      this.removeBossBar();
   }

   private void removeBossBar() {
      this.bossBar.hide();
   }

   private void broadcast(String message) {
      if (message != null && !message.isEmpty()) {
         Bukkit.broadcast(ColorUtil.component(message));
      }
   }

   static int secondsUntil(long deadline, long now) {
      long remaining = deadline - now;
      return remaining <= 0L ? 0 : (int)Math.min(2147483647L, (remaining + 1000L - 1L) / 1000L);
   }

   private static long safeDeadline(long now, int seconds) {
      long addition = seconds * 1000L;
      return Long.MAX_VALUE - now < addition ? Long.MAX_VALUE : now + addition;
   }
}
