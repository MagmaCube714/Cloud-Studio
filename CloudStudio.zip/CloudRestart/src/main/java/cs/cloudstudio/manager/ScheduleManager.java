package cs.cloudstudio.manager;

import cs.cloudstudio.CloudRestart;
import cs.cloudstudio.config.ConfigManager;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

public final class ScheduleManager {
   private static final long MILLIS_PER_TICK = 50L;
   private final CloudRestart plugin;
   private final ConfigManager configManager;
   private final RestartManager restartManager;
   private BukkitTask task;

   public ScheduleManager(CloudRestart plugin, ConfigManager configManager, RestartManager restartManager) {
      this.plugin = plugin;
      this.configManager = configManager;
      this.restartManager = restartManager;
   }

   public void scheduleNext() {
      this.cancel();
      ZonedDateTime target = this.findNextTarget();
      if (target != null) {
         this.scheduleTarget(target);
      }
   }

   public void cancel() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }
   }

   private void scheduleTarget(final ZonedDateTime target) {
      ZonedDateTime now = ZonedDateTime.now(target.getZone());
      long delayTicks = toDelayTicks(Duration.between(now, target));
      this.task = Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
         @Override
         public void run() {
            ScheduleManager.this.task = null;
            if (ZonedDateTime.now(target.getZone()).isBefore(target)) {
               ScheduleManager.this.scheduleTarget(target);
            } else {
               ScheduleManager.this.restartManager.startRestart();
               ScheduleManager.this.scheduleNext();
            }
         }
      }, delayTicks);
   }

   private ZonedDateTime findNextTarget() {
      ConfigManager.Schedule schedule = this.configManager.schedule();
      if (schedule.days().isEmpty()) {
         return null;
      }

      ZonedDateTime now = ZonedDateTime.now(schedule.zoneId());
      ZonedDateTime nearest = null;

      for (int offset = 0; offset <= 7; offset++) {
         LocalDate date = now.toLocalDate().plusDays(offset);
         ConfigManager.ScheduleDay day = ConfigManager.ScheduleDay.from(date.getDayOfWeek());

         for (ConfigManager.DaySchedule daySchedule : schedule.days()) {
            if (daySchedule.day() == day) {
               for (LocalTime time : daySchedule.times()) {
                  ZonedDateTime candidate = ZonedDateTime.of(date, time, schedule.zoneId());
                  if (candidate.isAfter(now) && (nearest == null || candidate.isBefore(nearest))) {
                     nearest = candidate;
                  }
               }
            }
         }
      }

      return nearest;
   }

   static long toDelayTicks(Duration duration) {
      if (!duration.isNegative() && !duration.isZero()) {
         long millis;
         try {
            millis = duration.toMillis();
         } catch (ArithmeticException exception) {
            return Long.MAX_VALUE;
         }

         return millis >= 9223372036854775758L ? Long.MAX_VALUE : Math.max(1L, (millis + 50L - 1L) / 50L);
      } else {
         return 1L;
      }
   }
}
