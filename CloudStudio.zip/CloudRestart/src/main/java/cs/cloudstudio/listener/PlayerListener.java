package cs.cloudstudio.listener;

import cs.cloudstudio.manager.RestartManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerListener implements Listener {
   private final RestartManager restartManager;

   public PlayerListener(RestartManager restartManager) {
      this.restartManager = restartManager;
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onPreLogin(AsyncPlayerPreLoginEvent event) {
      if (this.restartManager.isClosing()) {
         event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, this.restartManager.closingMessage());
      }
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      if (this.restartManager.isClosing()) {
         event.getPlayer().kick(this.restartManager.closingMessage());
      } else {
         this.restartManager.addPlayer(event.getPlayer());
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.restartManager.removePlayer(event.getPlayer());
   }
}
