package cs.cloudstudio.util;

import java.time.LocalTime;

public final class TimeUtil {
   private TimeUtil() {
   }

   public static LocalTime parseTime(String value) {
      if (value == null) {
         return null;
      } else {
         String prepared = value.trim();
         int separator = prepared.indexOf(58);
         if (separator > 0 && separator == prepared.lastIndexOf(58) && separator != prepared.length() - 1) {
            int hour = parseNumber(prepared, 0, separator);
            int minute = parseNumber(prepared, separator + 1, prepared.length());
            return hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59 ? LocalTime.of(hour, minute) : null;
         } else {
            return null;
         }
      }
   }

   private static int parseNumber(String value, int start, int end) {
      int length = end - start;
      if (length >= 1 && length <= 2) {
         int result = 0;

         for (int index = start; index < end; index++) {
            char character = value.charAt(index);
            if (character < '0' || character > '9') {
               return -1;
            }

            result = result * 10 + character - 48;
         }

         return result;
      } else {
         return -1;
      }
   }
}
