package cs.cloudstudio.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;

public final class ColorUtil {
   private static final String LEGACY_CODES = "0123456789AaBbCcDdEeFfKkLlMmNnOoRrXx";
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
      .character('§')
      .hexColors()
      .useUnusualXRepeatedCharacterHexFormat()
      .build();

   private ColorUtil() {
   }

   public static String color(String text) {
      if (text != null && !text.isEmpty()) {
         char[] chars = text.toCharArray();

         for (int i = 0; i < chars.length - 1; i++) {
            if (chars[i] == '&' && LEGACY_CODES.indexOf(chars[i + 1]) >= 0) {
               chars[i] = 167;
               chars[i + 1] = Character.toLowerCase(chars[i + 1]);
            }
         }

         return new String(chars);
      } else {
         return "";
      }
   }

   public static Component component(String legacyText) {
      return legacyText != null && !legacyText.isEmpty() ? LEGACY.deserialize(legacyText) : Component.empty();
   }

   public static void console(String text) {
      Bukkit.getConsoleSender().sendMessage(color(text));
   }
}
