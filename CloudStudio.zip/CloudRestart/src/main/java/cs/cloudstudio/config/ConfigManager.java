package cs.cloudstudio.config;

import cs.cloudstudio.CloudRestart;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.TimeUtil;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.logging.Level;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public final class ConfigManager {
   private static final String PREFIX = "[CloudRestart] ";
   private static final int DEFAULT_COUNTDOWN = 300;
   private static final int DEFAULT_FINAL_DELAY = 3;
   private static final int MAX_COUNTDOWN = 86400;
   private static final int MAX_FINAL_DELAY = 3600;
   private static final ZoneId DEFAULT_ZONE = ZoneId.of("Europe/Moscow");
   private final CloudRestart plugin;
   private ConfigManager.Settings settings;
   private ConfigManager.Messages messages;
   private ConfigManager.Schedule schedule;

   public ConfigManager(CloudRestart plugin) {
      this.plugin = plugin;
      plugin.saveDefaultConfig();
      if (!this.reload()) {
         throw new IllegalStateException("Не удалось загрузить config.yml");
      }
   }

   public boolean reload() {
      try {
         this.plugin.reloadConfig();
         FileConfiguration config = this.plugin.getConfig();
         int countdown = this.boundedInt(config.getInt("settings.countdown-seconds", 300), 1, 86400, "settings.countdown-seconds");
         int finalDelay = this.boundedInt(config.getInt("settings.final-delay-seconds", 3), 0, 3600, "settings.final-delay-seconds");
         ConfigManager.Settings loadedSettings = new ConfigManager.Settings(
            countdown,
            finalDelay,
            ConfigManager.NumberTemplate.compile(ColorUtil.color(config.getString("settings.bossbar", ""))),
            ConfigManager.NumberTemplate.compile(ColorUtil.color(config.getString("settings.title", ""))),
            ConfigManager.NumberTemplate.compile(ColorUtil.color(config.getString("settings.subtitle", ""))),
            ColorUtil.color(config.getString("settings.final-title", "")),
            ColorUtil.color(config.getString("settings.final-subtitle", "")),
            immutableCommandList(config.getStringList("settings.pre-shutdown-commands")),
            immutableNotifySeconds(config.getIntegerList("settings.notify-times"), countdown),
            ColorUtil.color(config.getString("settings.kick-message", config.getString("messages.final-notify", "&6Перезагрузка сервера"))),
            this.boundedInt(config.getInt("settings.save-delay-seconds", 3), 0, 60, "settings.save-delay-seconds")
         );
         ConfigManager.Messages loadedMessages = new ConfigManager.Messages(
            ConfigManager.NumberTemplate.compile(ColorUtil.color(config.getString("messages.start-notify", ""))),
            ColorUtil.color(config.getString("messages.stop-notify", "")),
            ColorUtil.color(config.getString("messages.final-notify", "")),
            ColorUtil.color(config.getString("messages.already-running", "")),
            ColorUtil.color(config.getString("messages.not-running", "")),
            ColorUtil.color(config.getString("messages.no-perm", "")),
            ColorUtil.color(config.getString("messages.admin-usage", "")),
            ColorUtil.color(config.getString("messages.reloaded", "")),
            ColorUtil.color(config.getString("messages.reload-failed", "&cНе удалось перезагрузить config.yml. Подробности в консоли."))
         );
         ConfigManager.Schedule loadedSchedule = this.loadSchedule(config);
         this.settings = loadedSettings;
         this.messages = loadedMessages;
         this.schedule = loadedSchedule;
         return true;
      } catch (RuntimeException exception) {
         this.plugin.getLogger().log(Level.SEVERE, "[CloudRestart] Ошибка чтения config.yml", exception);
         return false;
      }
   }

   public ConfigManager.Settings settings() {
      return this.settings;
   }

   public ConfigManager.Messages messages() {
      return this.messages;
   }

   public ConfigManager.Schedule schedule() {
      return this.schedule;
   }

   private int boundedInt(int value, int minimum, int maximum, String path) {
      if (value < minimum) {
         this.plugin.getLogger().warning("[CloudRestart] " + path + " меньше " + minimum + "; используется " + minimum);
         return minimum;
      } else if (value > maximum) {
         this.plugin.getLogger().warning("[CloudRestart] " + path + " больше " + maximum + "; используется " + maximum);
         return maximum;
      } else {
         return value;
      }
   }

   private ConfigManager.Schedule loadSchedule(FileConfiguration config) {
      ConfigurationSection section = config.getConfigurationSection("schedule");
      if (section == null) {
         return new ConfigManager.Schedule(DEFAULT_ZONE, Collections.emptyList());
      }

      String zoneValue = section.getString("timezone", DEFAULT_ZONE.getId());

      ZoneId zoneId;
      try {
         zoneId = ZoneId.of(zoneValue == null ? DEFAULT_ZONE.getId() : zoneValue.trim());
      } catch (RuntimeException exception) {
         this.plugin.getLogger().warning("[CloudRestart] Неверный timezone в schedule; используется " + DEFAULT_ZONE.getId());
         zoneId = DEFAULT_ZONE;
      }

      List<ConfigManager.DaySchedule> days = new ArrayList<>();

      for (ConfigManager.ScheduleDay day : ConfigManager.ScheduleDay.values()) {
         List<String> rawTimes = section.getStringList(day.configKey());
         if (!rawTimes.isEmpty()) {
            TreeSet<LocalTime> validTimes = new TreeSet<>();

            for (String value : rawTimes) {
               LocalTime time = TimeUtil.parseTime(value);
               if (time == null) {
                  this.plugin.getLogger().warning("[CloudRestart] Расписание " + day.configKey() + " содержит неверное время: " + value);
               } else {
                  validTimes.add(time);
               }
            }

            if (!validTimes.isEmpty()) {
               days.add(new ConfigManager.DaySchedule(day, Collections.unmodifiableList(new ArrayList<>(validTimes))));
            }
         }
      }

      return new ConfigManager.Schedule(zoneId, days.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(days));
   }

   private static List<String> immutableCommandList(List<String> source) {
      if (source != null && !source.isEmpty()) {
         List<String> result = new ArrayList<>(source.size());

         for (String value : source) {
            if (value != null) {
               String prepared = value.trim();

               while (!prepared.isEmpty() && prepared.charAt(0) == '/') {
                  prepared = prepared.substring(1).trim();
               }

               if (!prepared.isEmpty()) {
                  result.add(prepared);
               }
            }
         }

         return result.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(result);
      } else {
         return Collections.emptyList();
      }
   }

   private static boolean[] immutableNotifySeconds(List<Integer> source, int countdownSeconds) {
      boolean[] result = new boolean[countdownSeconds + 1];
      boolean hasConfiguredValue = false;
      if (source != null) {
         for (Integer value : source) {
            if (value != null) {
               int second = value;
               if (second > 0 && second <= countdownSeconds) {
                  result[second] = true;
                  hasConfiguredValue = true;
               }
            }
         }
      }

      if (!hasConfiguredValue) {
         enableNotifySecond(result, countdownSeconds);
         enableNotifySecond(result, 60);
         enableNotifySecond(result, 30);
         enableNotifySecond(result, 10);
         enableNotifySecond(result, 5);
         enableNotifySecond(result, 4);
         enableNotifySecond(result, 3);
         enableNotifySecond(result, 2);
         enableNotifySecond(result, 1);
      }

      return result;
   }

   private static void enableNotifySecond(boolean[] values, int second) {
      if (second > 0 && second < values.length) {
         values[second] = true;
      }
   }

   public static final class DaySchedule {
      private final ConfigManager.ScheduleDay day;
      private final List<LocalTime> times;

      private DaySchedule(ConfigManager.ScheduleDay day, List<LocalTime> times) {
         this.day = day;
         this.times = times;
      }

      public ConfigManager.ScheduleDay day() {
         return this.day;
      }

      public List<LocalTime> times() {
         return this.times;
      }
   }

   public static final class Messages {
      private final ConfigManager.NumberTemplate startNotify;
      private final String stopNotify;
      private final String finalNotify;
      private final String alreadyRunning;
      private final String notRunning;
      private final String noPermission;
      private final String usage;
      private final String reloaded;
      private final String reloadFailed;

      private Messages(
         ConfigManager.NumberTemplate startNotify,
         String stopNotify,
         String finalNotify,
         String alreadyRunning,
         String notRunning,
         String noPermission,
         String usage,
         String reloaded,
         String reloadFailed
      ) {
         this.startNotify = startNotify;
         this.stopNotify = stopNotify;
         this.finalNotify = finalNotify;
         this.alreadyRunning = alreadyRunning;
         this.notRunning = notRunning;
         this.noPermission = noPermission;
         this.usage = usage;
         this.reloaded = reloaded;
         this.reloadFailed = reloadFailed;
      }

      public String startNotify(int seconds) {
         return this.startNotify.format(seconds);
      }

      public String stopNotify() {
         return this.stopNotify;
      }

      public String finalNotify() {
         return this.finalNotify;
      }

      public String alreadyRunning() {
         return this.alreadyRunning;
      }

      public String notRunning() {
         return this.notRunning;
      }

      public String noPermission() {
         return this.noPermission;
      }

      public String usage() {
         return this.usage;
      }

      public String reloaded() {
         return this.reloaded;
      }

      public String reloadFailed() {
         return this.reloadFailed;
      }
   }

   private static final class NumberTemplate {
      private static final String PLACEHOLDER = "{time}";
      private final String fixed;
      private final String[] parts;

      private NumberTemplate(String fixed, String[] parts) {
         this.fixed = fixed;
         this.parts = parts;
      }

      static ConfigManager.NumberTemplate compile(String value) {
         if (value == null || value.isEmpty()) {
            return new ConfigManager.NumberTemplate("", null);
         }

         if (value.indexOf("{time}") < 0) {
            return new ConfigManager.NumberTemplate(value, null);
         }

         List<String> result = new ArrayList<>();
         int from = 0;

         int index;
         while ((index = value.indexOf("{time}", from)) >= 0) {
            result.add(value.substring(from, index));
            from = index + "{time}".length();
         }

         result.add(value.substring(from));
         return new ConfigManager.NumberTemplate(null, result.toArray(new String[result.size()]));
      }

      String format(int number) {
         if (this.fixed != null) {
            return this.fixed;
         }

         String numberValue = Integer.toString(number);
         StringBuilder builder = new StringBuilder(this.parts.length * numberValue.length() + 16);

         for (int index = 0; index < this.parts.length; index++) {
            if (index > 0) {
               builder.append(numberValue);
            }

            builder.append(this.parts[index]);
         }

         return builder.toString();
      }
   }

   public static final class Schedule {
      private final ZoneId zoneId;
      private final List<ConfigManager.DaySchedule> days;

      private Schedule(ZoneId zoneId, List<ConfigManager.DaySchedule> days) {
         this.zoneId = zoneId;
         this.days = days;
      }

      public ZoneId zoneId() {
         return this.zoneId;
      }

      public List<ConfigManager.DaySchedule> days() {
         return this.days;
      }
   }

   public enum ScheduleDay {
      MONDAY("monday"),
      TUESDAY("tuesday"),
      WEDNESDAY("wednesday"),
      THURSDAY("thursday"),
      FRIDAY("friday"),
      SATURDAY("saturday"),
      SUNDAY("sunday");

      private static final Map<DayOfWeek, ConfigManager.ScheduleDay> BY_JAVA_DAY = new EnumMap<>(DayOfWeek.class);
      private final String configKey;

      ScheduleDay(String configKey) {
         this.configKey = configKey;
      }

      public String configKey() {
         return this.configKey;
      }

      public static ConfigManager.ScheduleDay from(DayOfWeek day) {
         return BY_JAVA_DAY.get(day);
      }

      static {
         BY_JAVA_DAY.put(DayOfWeek.MONDAY, MONDAY);
         BY_JAVA_DAY.put(DayOfWeek.TUESDAY, TUESDAY);
         BY_JAVA_DAY.put(DayOfWeek.WEDNESDAY, WEDNESDAY);
         BY_JAVA_DAY.put(DayOfWeek.THURSDAY, THURSDAY);
         BY_JAVA_DAY.put(DayOfWeek.FRIDAY, FRIDAY);
         BY_JAVA_DAY.put(DayOfWeek.SATURDAY, SATURDAY);
         BY_JAVA_DAY.put(DayOfWeek.SUNDAY, SUNDAY);
      }
   }

   public static final class Settings {
      private final int countdownSeconds;
      private final int finalDelaySeconds;
      private final ConfigManager.NumberTemplate bossBar;
      private final ConfigManager.NumberTemplate title;
      private final ConfigManager.NumberTemplate subtitle;
      private final String finalTitle;
      private final String finalSubtitle;
      private final List<String> preShutdownCommands;
      private final boolean[] notifySeconds;
      private final String kickMessage;
      private final int saveDelaySeconds;

      private Settings(
         int countdownSeconds,
         int finalDelaySeconds,
         ConfigManager.NumberTemplate bossBar,
         ConfigManager.NumberTemplate title,
         ConfigManager.NumberTemplate subtitle,
         String finalTitle,
         String finalSubtitle,
         List<String> preShutdownCommands,
         boolean[] notifySeconds,
         String kickMessage,
         int saveDelaySeconds
      ) {
         this.countdownSeconds = countdownSeconds;
         this.finalDelaySeconds = finalDelaySeconds;
         this.bossBar = bossBar;
         this.title = title;
         this.subtitle = subtitle;
         this.finalTitle = finalTitle;
         this.finalSubtitle = finalSubtitle;
         this.preShutdownCommands = preShutdownCommands;
         this.notifySeconds = notifySeconds;
         this.kickMessage = kickMessage;
         this.saveDelaySeconds = saveDelaySeconds;
      }

      public String kickMessage() {
         return this.kickMessage;
      }

      public int saveDelaySeconds() {
         return this.saveDelaySeconds;
      }

      public int countdownSeconds() {
         return this.countdownSeconds;
      }

      public int finalDelaySeconds() {
         return this.finalDelaySeconds;
      }

      public String bossBar(int seconds) {
         return this.bossBar.format(seconds);
      }

      public String title(int seconds) {
         return this.title.format(seconds);
      }

      public String subtitle(int seconds) {
         return this.subtitle.format(seconds);
      }

      public String finalTitle() {
         return this.finalTitle;
      }

      public String finalSubtitle() {
         return this.finalSubtitle;
      }

      public List<String> preShutdownCommands() {
         return this.preShutdownCommands;
      }

      public boolean shouldNotify(int seconds) {
         return seconds > 0 && seconds < this.notifySeconds.length && this.notifySeconds[seconds];
      }
   }
}
