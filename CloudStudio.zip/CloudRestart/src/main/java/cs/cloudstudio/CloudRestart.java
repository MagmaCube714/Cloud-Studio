package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.listener.PlayerListener;
import cs.cloudstudio.manager.RestartManager;
import cs.cloudstudio.manager.ScheduleManager;
import cs.cloudstudio.util.ColorUtil;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudRestart extends JavaPlugin {
   private ConfigManager configManager;
   private RestartManager restartManager;
   private ScheduleManager scheduleManager;

   public void onEnable() {
      this.configManager = new ConfigManager(this);
      this.restartManager = new RestartManager(this, this.configManager);
      this.scheduleManager = new ScheduleManager(this, this.configManager, this.restartManager);
      if (this.registerCommand()) {
         this.getServer().getPluginManager().registerEvents(new PlayerListener(this.restartManager), this);
         this.scheduleManager.scheduleNext();
         ColorUtil.console("&fCloudRestart &aуспешно загружен!");
      }
   }

   public void onDisable() {
      if (this.scheduleManager != null) {
         this.scheduleManager.cancel();
      }

      if (this.restartManager != null) {
         this.restartManager.shutdown();
      }

      this.getServer().getScheduler().cancelTasks(this);
      ColorUtil.console("&fCloudRestart &cуспешно выгружен!");
   }

   private boolean registerCommand() {
      PluginCommand command = this.getCommand("cloudrestart");
      if (command == null) {
         this.getLogger().severe("Команда cloudrestart не зарегистрирована в plugin.yml. Плагин отключён.");
         this.getServer().getPluginManager().disablePlugin(this);
         return false;
      } else {
         AdminCommand adminCommand = new AdminCommand(this.configManager, this.restartManager, this.scheduleManager);
         command.setExecutor(adminCommand);
         command.setTabCompleter(adminCommand);
         return true;
      }
   }
}
