package cs.cloudstudio.menu;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.util.ColorUtil;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public final class LootEditMenu implements InventoryHolder {
   private final CloudTower plugin;
   private final String type;
   private final Inventory inventory;

   public LootEditMenu(CloudTower plugin, String type) {
      this.plugin = plugin;
      this.type = type.toLowerCase();
      int size = plugin.getConfig().getInt("menus.loot-editor.size", 54);
      if (size < 9) {
         size = 9;
      }

      if (size > 54) {
         size = 54;
      }

      size = size / 9 * 9;
      String title = ColorUtil.color(plugin.getConfig().getString("menus.loot-editor.title", "Награды кейса: %type%").replace("%type%", this.type));
      this.inventory = Bukkit.createInventory(this, size, title);
      this.loadItems();
   }

   private void loadItems() {
      List<ItemStack> items = this.plugin.getLootManager().getEditorItems(this.type);

      for (int i = 0; i < items.size() && i < this.inventory.getSize(); i++) {
         ItemStack itemStack = items.get(i);
         if (itemStack != null) {
            this.inventory.setItem(i, itemStack);
         }
      }
   }

   public String getType() {
      return this.type;
   }

   public Inventory getInventory() {
      return this.inventory;
   }
}
