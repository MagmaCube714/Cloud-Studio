package cs.cloudstudio.config;

public enum TowerMode {
   LAND;

   public static TowerMode parse(String value) {
      return LAND;
   }
}
