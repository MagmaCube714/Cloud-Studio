package cs.cloudstudio.config;

public final class TowerDefinition {
   private final String key;
   private final boolean enabled;
   private final String schematic;
   private final TowerMode mode;
   private final int limit;
   private final int targetCandidateMultiplier;
   private final int cellSize;
   private final double chance;
   private final boolean pasteAir;
   private final int yOffset;
   private final int minLandY;
   private final int maxLandY;
   private final int supportRadius;
   private final int supportStep;
   private final int minSupportPoints;
   private final int maxHeightDelta;
   private final boolean randomRotation;

   public TowerDefinition(
      String key,
      boolean enabled,
      String schematic,
      TowerMode mode,
      int limit,
      int targetCandidateMultiplier,
      int cellSize,
      double chance,
      boolean pasteAir,
      int yOffset,
      int minLandY,
      int maxLandY,
      int supportRadius,
      int supportStep,
      int minSupportPoints,
      int maxHeightDelta,
      boolean randomRotation
   ) {
      this.key = key;
      this.enabled = enabled;
      this.schematic = schematic;
      this.mode = mode;
      this.limit = limit;
      this.targetCandidateMultiplier = targetCandidateMultiplier;
      this.cellSize = cellSize;
      this.chance = chance;
      this.pasteAir = pasteAir;
      this.yOffset = yOffset;
      this.minLandY = minLandY;
      this.maxLandY = maxLandY;
      this.supportRadius = supportRadius;
      this.supportStep = supportStep;
      this.minSupportPoints = minSupportPoints;
      this.maxHeightDelta = maxHeightDelta;
      this.randomRotation = randomRotation;
   }

   public String getKey() {
      return this.key;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public String getSchematic() {
      return this.schematic;
   }

   public TowerMode getMode() {
      return this.mode;
   }

   public int getLimit() {
      return this.limit;
   }

   public int getTargetCandidateMultiplier() {
      return this.targetCandidateMultiplier;
   }

   public int getCellSize() {
      return this.cellSize;
   }

   public double getChance() {
      return this.chance;
   }

   public boolean isPasteAir() {
      return this.pasteAir;
   }

   public int getYOffset() {
      return this.yOffset;
   }

   public int getMinLandY() {
      return this.minLandY;
   }

   public int getMaxLandY() {
      return this.maxLandY;
   }

   public int getSupportRadius() {
      return this.supportRadius;
   }

   public int getSupportStep() {
      return this.supportStep;
   }

   public int getMinSupportPoints() {
      return this.minSupportPoints;
   }

   public int getMaxHeightDelta() {
      return this.maxHeightDelta;
   }

   public boolean isRandomRotation() {
      return this.randomRotation;
   }
}
