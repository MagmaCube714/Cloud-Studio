package cs.cloudstudio.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class GenerationSettings {
   private final String worldName;
   private final boolean enabled;
   private final int radius;
   private final int spawnExclusionRadius;
   private final boolean autoPlaceOnWorldLoad;
   private final int autoPlaceStartDelayTicks;
   private final int autoPlacementsPerTick;
   private final List<TowerDefinition> towers;

   public GenerationSettings(
      String worldName,
      boolean enabled,
      int radius,
      int spawnExclusionRadius,
      boolean autoPlaceOnWorldLoad,
      int autoPlaceStartDelayTicks,
      int autoPlacementsPerTick,
      List<TowerDefinition> towers
   ) {
      this.worldName = worldName;
      this.enabled = enabled;
      this.radius = Math.max(1, radius);
      this.spawnExclusionRadius = Math.max(0, Math.min(spawnExclusionRadius, this.radius - 1));
      this.autoPlaceOnWorldLoad = autoPlaceOnWorldLoad;
      this.autoPlaceStartDelayTicks = Math.max(1, autoPlaceStartDelayTicks);
      this.autoPlacementsPerTick = Math.max(1, autoPlacementsPerTick);
      this.towers = Collections.unmodifiableList(new ArrayList<>(towers));
   }

   public String getWorldName() {
      return this.worldName;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public int getRadius() {
      return this.radius;
   }

   public int getSpawnExclusionRadius() {
      return this.spawnExclusionRadius;
   }

   public boolean isAutoPlaceOnWorldLoad() {
      return this.autoPlaceOnWorldLoad;
   }

   public int getAutoPlaceStartDelayTicks() {
      return this.autoPlaceStartDelayTicks;
   }

   public int getAutoPlacementsPerTick() {
      return this.autoPlacementsPerTick;
   }

   public List<TowerDefinition> getTowers() {
      return this.towers;
   }
}
