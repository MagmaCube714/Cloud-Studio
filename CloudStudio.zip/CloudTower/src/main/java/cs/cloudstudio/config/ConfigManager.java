package cs.cloudstudio.config;

import cs.cloudstudio.CloudTower;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.configuration.ConfigurationSection;

public final class ConfigManager {
   private final CloudTower plugin;
   private GenerationSettings settings;

   public ConfigManager(CloudTower plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      ConfigurationSection generation = this.plugin.getConfig().getConfigurationSection("generation");
      List<TowerDefinition> definitions = new ArrayList<>();
      if (generation != null) {
         ConfigurationSection towers = generation.getConfigurationSection("towers");
         if (towers != null) {
            for (String key : towers.getKeys(false)) {
               ConfigurationSection section = towers.getConfigurationSection(key);
               if (section != null) {
                  definitions.add(this.readTower(key.toLowerCase(), section));
               }
            }
         }
      }

      this.settings = new GenerationSettings(
         this.plugin.getConfig().getString("world-name", "world"),
         generation != null && generation.getBoolean("enabled", true),
         generation == null ? 5000 : generation.getInt("radius", 5000),
         generation == null ? 500 : generation.getInt("spawn-exclusion-radius", 500),
         generation != null && generation.getBoolean("auto-place-on-world-load", true),
         generation == null ? 80 : generation.getInt("auto-place-start-delay-ticks", 80),
         generation == null ? 1 : generation.getInt("auto-placements-per-tick", 1),
         definitions
      );
   }

   private TowerDefinition readTower(String key, ConfigurationSection section) {
      return new TowerDefinition(
         key,
         section.getBoolean("enabled", true),
         section.getString("schematic", "plugins/CloudTower/Tower.schem"),
         TowerMode.parse(section.getString("mode", "LAND")),
         Math.max(0, section.getInt("limit", 10)),
         Math.max(1, section.getInt("target-candidate-multiplier", 30)),
         Math.max(16, section.getInt("cell-size", 2000)),
         Math.max(0.0, Math.min(1.0, section.getDouble("chance", 0.7))),
         section.getBoolean("paste-air", false),
         section.getInt("y-offset", 0),
         section.getInt("min-land-y", 50),
         section.getInt("max-land-y", 130),
         Math.max(1, section.getInt("support-radius", 18)),
         Math.max(1, section.getInt("support-step", 6)),
         Math.max(1, section.getInt("min-support-points", 18)),
         Math.max(0, section.getInt("max-height-delta", 5)),
         section.getBoolean("random-rotation", true)
      );
   }

   public GenerationSettings getGenerationSettings() {
      return this.settings;
   }
}
