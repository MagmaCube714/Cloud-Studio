package cs.cloudstudio.listener;

import cs.cloudstudio.CloudTower;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class TowerChestListener implements Listener {
   private final CloudTower plugin;

   public TowerChestListener(CloudTower plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onInteract(PlayerInteractEvent event) {
      if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
         Block block = event.getClickedBlock();
         if (block != null && (block.getType() == Material.CHEST || block.getType() == Material.TRAPPED_CHEST)) {
            if (event.getHand() != EquipmentSlot.HAND) {
               if (this.plugin.getTowerManager().findByChest(block.getLocation()) != null) {
                  event.setCancelled(true);
               }
            } else if (this.plugin.getTowerManager().handleChestUse(event.getPlayer(), block.getLocation())) {
               event.setCancelled(true);
            }
         }
      }
   }
}
