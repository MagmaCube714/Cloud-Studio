package cs.cloudstudio.listener;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.menu.LootEditMenu;
import cs.cloudstudio.util.MessageUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;

public final class LootEditMenuListener implements Listener {
   private final CloudTower plugin;

   public LootEditMenuListener(CloudTower plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onClose(InventoryCloseEvent event) {
      if (event.getInventory().getHolder(false) instanceof LootEditMenu menu) {
         this.plugin.getLootManager().saveEditorItems(menu.getType(), event.getInventory().getContents());
         MessageUtil.send(event.getPlayer(), this.plugin, "edit-saved", "%type%", menu.getType());
      }
   }
}
