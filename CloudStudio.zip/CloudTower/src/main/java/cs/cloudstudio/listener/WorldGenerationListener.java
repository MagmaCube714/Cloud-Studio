package cs.cloudstudio.listener;

import cs.cloudstudio.CloudTower;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.WorldLoadEvent;

public final class WorldGenerationListener implements Listener {
   private final CloudTower plugin;

   public WorldGenerationListener(CloudTower plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onWorldLoad(WorldLoadEvent event) {
      this.plugin.getGenerationManager().schedule(event.getWorld());
   }
}
