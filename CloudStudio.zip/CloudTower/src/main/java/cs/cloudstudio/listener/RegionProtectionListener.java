package cs.cloudstudio.listener;

import cs.cloudstudio.CloudTower;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;

public final class RegionProtectionListener implements Listener {
   private final CloudTower plugin;
   private FileConfiguration cachedConfig;
   private boolean disabledCommandsEnabled;
   private String[] disabledCommands = new String[0];

   public RegionProtectionListener(CloudTower plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onCommand(PlayerCommandPreprocessEvent event) {
      this.refreshCommandCache();
      if (this.disabledCommandsEnabled && this.disabledCommands.length != 0) {
         Player player = event.getPlayer();
         if (this.isInside(player.getLocation()) && !player.hasPermission("cloudtower.admin")) {
            String command = event.getMessage().toLowerCase(Locale.ROOT);

            for (String blockedCommand : this.disabledCommands) {
               if (command.startsWith(blockedCommand)
                  && (command.length() == blockedCommand.length() || command.charAt(blockedCommand.length()) == ' ')) {
                  event.setCancelled(true);
                  return;
               }
            }
         }
      }
   }

   private void refreshCommandCache() {
      FileConfiguration config = this.plugin.getConfig();
      if (config != this.cachedConfig) {
         this.disabledCommandsEnabled = config.getBoolean("region-settings.disabled-cmds.enabled", true);
         List<String> values = config.getStringList("region-settings.disabled-cmds.commands");
         List<String> commands = new ArrayList<>(values.size());

         for (String value : values) {
            String blockedCommand = value.toLowerCase(Locale.ROOT).trim();
            if (!blockedCommand.startsWith("/")) {
               blockedCommand = "/" + blockedCommand;
            }

            commands.add(blockedCommand);
         }

         this.disabledCommands = commands.toArray(new String[0]);
         this.cachedConfig = config;
      }
   }

   @EventHandler
   public void onFly(PlayerToggleFlightEvent event) {
      Player player = event.getPlayer();
      if (event.isFlying() && !this.canFly(player) && this.isInside(player.getLocation())) {
         event.setCancelled(true);
         this.disableFlight(player);
      }
   }

   @EventHandler
   public void onMove(PlayerMoveEvent event) {
      Player player = event.getPlayer();
      if (this.movedBlock(event.getFrom(), event.getTo()) && this.isInside(event.getTo()) && !this.canFly(player)) {
         if (player.isFlying() || player.getAllowFlight()) {
            this.disableFlight(player);
         }
      }
   }

   private boolean canFly(Player player) {
      return player.hasPermission("cloudtower.admin") || player.hasPermission("cloudtower.fly");
   }

   private void disableFlight(Player player) {
      player.setFlying(false);
      if (player.getGameMode() != GameMode.CREATIVE && player.getGameMode() != GameMode.SPECTATOR) {
         player.setAllowFlight(false);
      }
   }

   private boolean movedBlock(Location from, Location to) {
      return from != null && to != null && from.getWorld() != null && to.getWorld() != null
         ? from.getWorld() != to.getWorld() || from.getBlockX() != to.getBlockX() || from.getBlockY() != to.getBlockY() || from.getBlockZ() != to.getBlockZ()
         : true;
   }

   private boolean isInside(Location location) {
      return this.plugin.getTowerManager().findByLocation(location) != null;
   }
}
