package cs.cloudstudio.util;

import cs.cloudstudio.CloudTower;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;

public final class MessageUtil {
   private MessageUtil() {
   }

   private static final Map<String, String> CACHE = new ConcurrentHashMap<>();
   private static volatile FileConfiguration cachedConfig;

   public static String get(CloudTower plugin, String path) {
      FileConfiguration config = plugin.getConfig();
      if (config != cachedConfig) {
         CACHE.clear();
         cachedConfig = config;
      }

      String cached = CACHE.get(path);
      if (cached == null) {
         cached = ColorUtil.color(config.getString("messages." + path, ""));
         CACHE.put(path, cached);
      }

      return cached;
   }

   public static void send(CommandSender sender, CloudTower plugin, String path, String... placeholders) {
      String message = get(plugin, path);
      if (!message.isEmpty()) {
         sender.sendMessage(apply(message, placeholders));
      }
   }

   public static void sendList(CommandSender sender, CloudTower plugin, String path, String... placeholders) {
      List<String> list = plugin.getConfig().getStringList("messages." + path);
      if (list.isEmpty()) {
         send(sender, plugin, path, placeholders);
      } else {
         for (String line : list) {
            sender.sendMessage(apply(ColorUtil.color(line), placeholders));
         }
      }
   }

   public static List<String> coloredList(List<String> lines) {
      List<String> result = new ArrayList<>();

      for (String line : lines) {
         result.add(ColorUtil.color(line));
      }

      return result;
   }

   public static String apply(String message, String... placeholders) {
      String result = message;
      if (placeholders == null) {
         return result;
      }

      for (int i = 0; i + 1 < placeholders.length; i += 2) {
         result = result.replace(placeholders[i], placeholders[i + 1]);
      }

      return result;
   }
}
