package cs.cloudstudio.util;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class LocationUtil {
   private LocationUtil() {
   }

   public static String serialize(Location location) {
      return location != null && location.getWorld() != null
         ? location.getWorld().getName() + ";" + location.getX() + ";" + location.getY() + ";" + location.getZ()
         : "";
   }

   public static Location deserialize(String value) {
      if (value != null && !value.isEmpty()) {
         String[] split = value.split(";");
         if (split.length < 4) {
            return null;
         }

         World world = Bukkit.getWorld(split[0]);
         if (world == null) {
            return null;
         }

         try {
            return new Location(world, Double.parseDouble(split[1]), Double.parseDouble(split[2]), Double.parseDouble(split[3]));
         } catch (NumberFormatException exception) {
            return null;
         }
      } else {
         return null;
      }
   }

   public static boolean sameBlock(Location first, Location second) {
      return first != null && second != null && first.getWorld() != null && second.getWorld() != null
         ? first.getWorld().getName().equalsIgnoreCase(second.getWorld().getName())
            && first.getBlockX() == second.getBlockX()
            && first.getBlockY() == second.getBlockY()
            && first.getBlockZ() == second.getBlockZ()
         : false;
   }
}
