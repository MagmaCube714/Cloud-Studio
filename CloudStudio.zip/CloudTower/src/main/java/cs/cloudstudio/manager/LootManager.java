package cs.cloudstudio.manager;

import cs.cloudstudio.CloudTower;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

public final class LootManager {
   private final CloudTower plugin;
   private final Object lock = new Object();
   private final Object fileLock = new Object();
   private final Map<String, List<ItemStack>> items = new LinkedHashMap<>();
   private final Map<String, String> amounts = new LinkedHashMap<>();
   private BukkitTask saveTask;
   private boolean dirty;
   private boolean saving;

   public LootManager(CloudTower plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      synchronized (this.lock) {
         this.items.clear();
         this.amounts.clear();
         ConfigurationSection loot = this.plugin.getRewardsConfig().getConfigurationSection("loot");
         if (loot != null) {
            for (String key : loot.getKeys(false)) {
               ConfigurationSection section = loot.getConfigurationSection(key);
               if (section != null) {
                  String normalized = this.normalize(key);
                  this.amounts.put(normalized, section.getString("amount", this.getDefaultAmount(normalized)));
                  this.items.put(normalized, this.readItems(section.getConfigurationSection("items")));
               }
            }
         }

         this.ensureDefaultType("blue");
         this.ensureDefaultType("green");
         this.ensureDefaultType("red");
      }
   }

   public List<ItemStack> roll(String type) {
      List<ItemStack> available = this.getEditorItems(type);
      if (available.isEmpty()) {
         return new ArrayList<>();
      }

      Collections.shuffle(available);
      int amount = Math.min(this.getDropAmount(type), available.size());
      List<ItemStack> result = new ArrayList<>();

      for (int i = 0; i < amount; i++) {
         ItemStack itemStack = available.get(i);
         if (itemStack != null && itemStack.getType() != Material.AIR) {
            result.add(itemStack.clone());
         }
      }

      return result;
   }

   public List<ItemStack> getEditorItems(String type) {
      synchronized (this.lock) {
         List<ItemStack> stored = this.items.get(this.normalize(type));
         return stored != null && !stored.isEmpty() ? this.cloneList(stored) : new ArrayList<>();
      }
   }

   public void saveEditorItems(String type, ItemStack[] contents) {
      String normalized = this.normalize(type);
      List<ItemStack> saved = new ArrayList<>();
      if (contents != null) {
         for (ItemStack itemStack : contents) {
            if (itemStack != null && itemStack.getType() != Material.AIR) {
               saved.add(itemStack.clone());
            }
         }
      }

      synchronized (this.lock) {
         this.items.put(normalized, saved);
         if (!this.amounts.containsKey(normalized)) {
            this.amounts.put(normalized, this.getDefaultAmount(normalized));
         }

         this.dirty = true;
         this.scheduleSaveLocked();
      }
   }

   public Collection<String> getTypes() {
      synchronized (this.lock) {
         Set<String> types = new LinkedHashSet<>(this.items.keySet());
         types.addAll(this.amounts.keySet());
         if (types.isEmpty()) {
            types.addAll(Arrays.asList("blue", "green", "red"));
         }

         return new ArrayList<>(types);
      }
   }

   public boolean isTypeAvailable(String type) {
      if (type != null && !type.trim().isEmpty()) {
         String normalized = this.normalize(type);

         for (String value : this.getTypes()) {
            if (value.equalsIgnoreCase(normalized)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public void flush() {
      Map<String, List<ItemStack>> itemSnapshot;
      Map<String, String> amountSnapshot;
      synchronized (this.lock) {
         if (this.saveTask != null) {
            this.saveTask.cancel();
            this.saveTask = null;
         }

         if (!this.dirty && !this.saving) {
            return;
         }

         this.dirty = false;
         itemSnapshot = this.snapshotItemsLocked();
         amountSnapshot = new LinkedHashMap<>(this.amounts);
      }

      this.saveSnapshot(itemSnapshot, amountSnapshot);
   }

   private void scheduleSaveLocked() {
      if (this.saveTask == null && !this.saving) {
         this.saveTask = Bukkit.getScheduler().runTaskLaterAsynchronously(this.plugin, this::runQueuedSave, 40L);
      }
   }

   private void runQueuedSave() {
      Map<String, List<ItemStack>> itemSnapshot;
      Map<String, String> amountSnapshot;
      synchronized (this.lock) {
         this.saveTask = null;
         if (!this.dirty) {
            return;
         }

         this.dirty = false;
         this.saving = true;
         itemSnapshot = this.snapshotItemsLocked();
         amountSnapshot = new LinkedHashMap<>(this.amounts);
      }

      try {
         this.saveSnapshot(itemSnapshot, amountSnapshot);
      } finally {
         synchronized (this.lock) {
            this.saving = false;
            if (this.dirty && this.saveTask == null) {
               this.scheduleSaveLocked();
            }
         }
      }
   }

   private void saveSnapshot(Map<String, List<ItemStack>> itemSnapshot, Map<String, String> amountSnapshot) {
      YamlConfiguration configuration = new YamlConfiguration();
      Set<String> types = new LinkedHashSet<>();
      types.addAll(amountSnapshot.keySet());
      types.addAll(itemSnapshot.keySet());
      if (types.isEmpty()) {
         types.addAll(Arrays.asList("blue", "green", "red"));
      }

      for (String type : types) {
         String path = "loot." + type;
         configuration.set(path + ".amount", amountSnapshot.getOrDefault(type, this.getDefaultAmount(type)));
         List<ItemStack> stored = itemSnapshot.get(type);
         if (stored != null && !stored.isEmpty()) {
            for (int i = 0; i < stored.size(); i++) {
               ItemStack itemStack = stored.get(i);
               if (itemStack != null && itemStack.getType() != Material.AIR) {
                  configuration.set(path + ".items.slot_" + i + ".item", itemStack);
               }
            }
         } else {
            configuration.createSection(path + ".items");
         }
      }

      try {
         synchronized (this.fileLock) {
            configuration.save(this.plugin.getRewardsFile());
         }
      } catch (IOException exception) {
         this.plugin.getLogger().warning("[CloudTower] Файл rewards.yml не сохранён");
      }
   }

   private int getDropAmount(String type) {
      String normalized = this.normalize(type);
      String value;
      synchronized (this.lock) {
         value = this.amounts.getOrDefault(normalized, this.getDefaultAmount(normalized));
      }

      String[] split = value.replace(" ", "").split("-");

      int min;
      int max;
      try {
         min = Integer.parseInt(split[0]);
         max = split.length > 1 ? Integer.parseInt(split[1]) : min;
      } catch (NumberFormatException exception) {
         this.plugin.getLogger().warning("[CloudTower] Неверное количество наград loot." + normalized + ".amount: " + value);
         String fallback = this.getDefaultAmount(normalized);
         String[] fallbackSplit = fallback.split("-");
         min = Integer.parseInt(fallbackSplit[0]);
         max = Integer.parseInt(fallbackSplit[1]);
      }

      if (min < 0) {
         min = 0;
      }

      if (max < min) {
         max = min;
      }

      return ThreadLocalRandom.current().nextInt(min, max + 1);
   }

   private List<ItemStack> readItems(ConfigurationSection section) {
      List<ItemStack> result = new ArrayList<>();
      if (section == null) {
         return result;
      }

      for (String key : section.getKeys(false)) {
         ConfigurationSection itemSection = section.getConfigurationSection(key);
         if (itemSection != null) {
            ItemStack itemStack = itemSection.getItemStack("item");
            if (itemStack != null && itemStack.getType() != Material.AIR) {
               result.add(itemStack.clone());
            }
         }
      }

      return result;
   }

   private Map<String, List<ItemStack>> snapshotItemsLocked() {
      Map<String, List<ItemStack>> snapshot = new LinkedHashMap<>();

      for (Entry<String, List<ItemStack>> entry : this.items.entrySet()) {
         snapshot.put(entry.getKey(), this.cloneList(entry.getValue()));
      }

      return snapshot;
   }

   private List<ItemStack> cloneList(List<ItemStack> source) {
      List<ItemStack> result = new ArrayList<>();

      for (ItemStack itemStack : source) {
         if (itemStack != null && itemStack.getType() != Material.AIR) {
            result.add(itemStack.clone());
         }
      }

      return result;
   }

   private void ensureDefaultType(String type) {
      String normalized = this.normalize(type);
      if (!this.items.containsKey(normalized)) {
         this.items.put(normalized, new ArrayList<>());
      }

      if (!this.amounts.containsKey(normalized)) {
         this.amounts.put(normalized, this.getDefaultAmount(normalized));
      }
   }

   private String getDefaultAmount(String type) {
      if ("green".equalsIgnoreCase(type)) {
         return "5-9";
      } else {
         return "red".equalsIgnoreCase(type) ? "10-15" : "3-5";
      }
   }

   private String normalize(String type) {
      return type == null ? "" : type.toLowerCase(Locale.ROOT);
   }
}
