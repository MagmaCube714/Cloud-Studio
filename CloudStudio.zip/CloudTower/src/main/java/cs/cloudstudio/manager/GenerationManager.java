package cs.cloudstudio.manager;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.config.GenerationSettings;
import cs.cloudstudio.config.TowerDefinition;
import cs.cloudstudio.util.ColorUtil;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.scheduler.BukkitTask;

public final class GenerationManager {
   private static final int SAVE_CANDIDATE_INTERVAL = 250;
   private final CloudTower plugin;
   private final ConfigManager configManager;
   private final TowerManager towerManager;
   private final SchematicManager schematicManager;
   private UUID scheduledWorldUid;
   private BukkitTask delayedTask;
   private BukkitTask task;
   private GenerationManager.Session session;
   private boolean nbtWarningShown;

   public GenerationManager(CloudTower plugin, ConfigManager configManager, TowerManager towerManager, SchematicManager schematicManager) {
      this.plugin = plugin;
      this.configManager = configManager;
      this.towerManager = towerManager;
      this.schematicManager = schematicManager;
   }

   public void scheduleLoadedWorld() {
      World world = Bukkit.getWorld(this.configManager.getGenerationSettings().getWorldName());
      if (world != null) {
         this.schedule(world, this.configManager.getGenerationSettings().getAutoPlaceStartDelayTicks());
      }
   }

   public void schedule(World world) {
      this.schedule(world, this.configManager.getGenerationSettings().getAutoPlaceStartDelayTicks());
   }

   public void resynchronizeLoadedWorld() {
      World world = Bukkit.getWorld(this.configManager.getGenerationSettings().getWorldName());
      if (world != null) {
         this.schedule(world, 1L);
      }
   }

   private void schedule(final World world, long delay) {
      GenerationSettings settings = this.configManager.getGenerationSettings();
      if (world != null
         && settings.isEnabled()
         && settings.isAutoPlaceOnWorldLoad()
         && world.getName().equalsIgnoreCase(settings.getWorldName())
         && this.task == null
         && this.session == null
         && !world.getUID().equals(this.scheduledWorldUid)) {
         this.cancelDelayedTask();
         this.scheduledWorldUid = world.getUID();
         this.delayedTask = Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
            @Override
            public void run() {
               GenerationManager.this.delayedTask = null;
               GenerationManager.this.scheduledWorldUid = null;
               GenerationManager.this.start(world);
            }
         }, Math.max(1L, delay));
      }
   }

   private void cancelDelayedTask() {
      if (this.delayedTask != null) {
         this.delayedTask.cancel();
         this.delayedTask = null;
      }

      this.scheduledWorldUid = null;
   }

   public void shutdown() {
      this.cancelDelayedTask();
      this.settlePaste();
      if (this.session != null) {
         this.session.cancelPaste();
         this.session.deletePendingRegion();
         this.session.releaseChunks();
      }

      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }

      this.session = null;
      this.towerManager.save();
   }

   private void settlePaste() {
      if (this.session != null && this.session.pasteJob != null && this.session.pasteJob.await(5L, TimeUnit.SECONDS)) {
         try {
            this.session.pasteResult = this.session.pasteJob.get();
            this.session.pasteJob = null;
            this.completeTower();
         } catch (Throwable throwable) {
            this.handleFailure(throwable);
         }
      }
   }

   private void start(World world) {
      if (this.plugin.isEnabled() && this.task == null && this.session == null) {
         GenerationSettings settings = this.configManager.getGenerationSettings();
         if (settings.isEnabled() && world.getName().equalsIgnoreCase(settings.getWorldName())) {
            this.towerManager.prepareWorld(world);
            List<GenerationManager.Progress> progress = new ArrayList<>();

            for (TowerDefinition definition : settings.getTowers()) {
               if (definition.isEnabled() && definition.getLimit() > 0) {
                  int current = this.towerManager.count(world.getUID().toString(), definition.getKey());
                  int missing = definition.getLimit() - current;
                  if (missing > 0) {
                     try {
                        this.schematicManager.load(definition.getSchematic());
                     } catch (Exception exception) {
                        this.plugin.getLogger().warning("[CloudTower] Схематика " + definition.getSchematic() + " не загружена: " + this.readable(exception));
                        continue;
                     }

                     int nextIndex = this.towerManager.getProgress(world.getUID().toString(), definition.getKey());
                     int maxIndex = this.addSafely(nextIndex, this.candidateBudget(definition, missing));
                     progress.add(new GenerationManager.Progress(definition, nextIndex, maxIndex));
                  }
               }
            }

            if (!progress.isEmpty()) {
               this.session = new GenerationManager.Session(world, progress);
               this.task = Bukkit.getScheduler().runTaskTimer(this.plugin, new Runnable() {
                  @Override
                  public void run() {
                     GenerationManager.this.tick();
                  }
               }, 1L, 1L);
               Bukkit.getConsoleSender().sendMessage(ColorUtil.color("&fCloudTower &aгенерация башен запущена"));
            }
         }
      }
   }

   private void tick() {
      if (this.plugin.isEnabled() && this.session != null) {
         try {
            if (this.session.pasteJob != null) {
               if (!this.session.pasteJob.isDone()) {
                  return;
               }

               this.session.pasteResult = this.session.pasteJob.get();
               this.session.pasteJob = null;
               this.completeTower();
               return;
            }

            if (this.session.pendingLoads > 0) {
               return;
            }

            if (!this.session.chunks.isEmpty()) {
               int budget = this.workBudget();

               for (int index = 0; index < budget && this.session != null && !this.session.chunks.isEmpty(); index++) {
                  this.loadNextChunk();
                  if (this.session == null || this.session.candidate == null) {
                     break;
                  }
               }

               return;
            }

            if (this.session.candidate != null) {
               this.continueCandidate();
               return;
            }

            int budget = this.workBudget();

            for (int index = 0; index < budget && this.session != null && this.session.candidate == null; index++) {
               if (!this.findCandidate()) {
                  return;
               }
            }
         } catch (Throwable throwable) {
            this.handleFailure(throwable);
         }
      } else {
         this.finish();
      }
   }

   private boolean findCandidate() throws Exception {
      GenerationManager.Progress progress = this.session.nextProgress();
      if (progress == null) {
         this.finish();
         return false;
      }

      int index = progress.nextIndex++;
      this.towerManager.setProgress(this.session.worldUid, progress.definition.getKey(), progress.nextIndex);
      this.session.checkedSinceSave++;
      if (this.session.checkedSinceSave >= 250) {
         this.towerManager.saveAsync();
         this.session.checkedSinceSave = 0;
      }

      TowerCandidate candidate = this.locate(this.session.world, progress.definition, index);
      if (candidate == null) {
         return true;
      } else {
         String id = this.createId(this.session.world, candidate);
         if (!this.towerManager.isGenerated(id)
            && this.towerManager.count(this.session.worldUid, progress.definition.getKey()) < progress.definition.getLimit()) {
            this.session.candidate = candidate;
            this.session.stage = GenerationManager.Stage.TERRAIN;
            this.queueChunks(this.terrainBounds(candidate));
            return true;
         } else {
            return true;
         }
      }
   }

   private void continueCandidate() throws Exception {
      if (this.session.stage == GenerationManager.Stage.TERRAIN) {
         Location placement = this.resolvePlacement(this.session.world, this.session.candidate);
         if (placement == null) {
            this.rejectCandidate();
         } else {
            SchematicBounds bounds = this.schematicManager
               .getBounds(
                  this.session.candidate.getDefinition().getSchematic(),
                  placement.getBlockX(),
                  placement.getBlockY(),
                  placement.getBlockZ(),
                  this.session.candidate.getRotation()
               );
            int minimumDistance = Math.max(this.plugin.getRegionManager().getRadius() * 2, this.session.candidate.getDefinition().getCellSize() / 2);
            if (bounds.getMinY() >= 1
               && bounds.getMaxY() < this.session.world.getMaxHeight()
               && this.towerManager.isFree(this.session.worldUid, bounds, placement.getBlockX(), placement.getBlockZ(), minimumDistance)
               && this.plugin.getRegionManager().canCreateRegion(placement)) {
               this.session.placement = placement;
               this.session.bounds = bounds;
               String number = this.towerManager.claimNumber();
               String regionId = this.plugin.getRegionManager().createRegion(number, placement);
               if (regionId == null) {
                  this.rejectCandidate();
               } else {
                  this.session.number = number;
                  this.session.regionId = regionId;
                  this.session.stage = GenerationManager.Stage.PASTE;
                  this.queueChunks(bounds);
               }
            } else {
               this.rejectCandidate();
            }
         }
      } else {
         if (this.session.stage == GenerationManager.Stage.PASTE) {
            this.session.markDirty(this.session.bounds);
            this.session.pasteJob = this.schematicManager
               .pasteAsync(
                  this.session.world,
                  this.session.candidate.getDefinition().getSchematic(),
                  this.session.placement.getBlockX(),
                  this.session.placement.getBlockY(),
                  this.session.placement.getBlockZ(),
                  this.session.candidate.getRotation(),
                  this.session.candidate.getDefinition().isPasteAir()
               );
         }
      }
   }

   private void completeTower() {
      TowerCandidate candidate = this.session.candidate;
      TowerData tower = new TowerData(
         this.createId(this.session.world, candidate),
         this.session.number,
         this.session.regionId,
         this.session.world.getName(),
         this.session.worldUid,
         candidate.getDefinition().getKey(),
         candidate.getDefinition().getSchematic(),
         this.session.placement.getBlockX(),
         this.session.placement.getBlockY(),
         this.session.placement.getBlockZ(),
         candidate.getRotation(),
         this.mapChests(this.session.pasteResult.getChests()),
         this.session.bounds
      );
      this.towerManager.add(tower);
      this.plugin.getHologramManager().create(tower);
      this.session.generated++;
      this.towerManager.saveAsync();
      this.session.commitRegion();
      this.session.releaseChunks();
      this.session.clearCandidate();
      if (this.session.allLimitsReached()) {
         this.finish();
      }
   }

   private Map<String, Location> mapChests(List<Location> source) {
      List<Location> chests = new ArrayList<>(source);
      Collections.sort(chests, new Comparator<Location>() {
         public int compare(Location first, Location second) {
            return Integer.compare(first.getBlockY(), second.getBlockY());
         }
      });
      Map<String, Location> result = new LinkedHashMap<>();
      if (chests.isEmpty()) {
         return result;
      }

      result.put("blue", chests.get(0));
      result.put("green", chests.size() > 1 ? chests.get(1) : chests.get(0));
      result.put("red", chests.size() > 2 ? chests.get(chests.size() - 1) : chests.get(chests.size() - 1));
      return result;
   }

   private void loadNextChunk() {
      GenerationManager.ChunkPosition position = this.session.chunks.pollFirst();
      if (position != null && !this.session.world.isChunkLoaded(position.x, position.z)) {
         final GenerationManager.Session owner = this.session;
         final int epoch = owner.loadEpoch;
         owner.pendingLoads++;
         owner.world.getChunkAtAsync(position.x, position.z, true).whenComplete((chunk, throwable) -> {
            if (this.session != owner || owner.loadEpoch != epoch) {
               return;
            }

            owner.pendingLoads--;
            if (throwable == null && chunk != null) {
               owner.world.addPluginChunkTicket(position.x, position.z, this.plugin);
               owner.loadedByPlugin.add(position.key());
            } else if (throwable != null && this.isEndCityNbtFailure(throwable)) {
               if (!this.nbtWarningShown) {
                  this.nbtWarningShown = true;
                  this.plugin.getLogger().warning("[CloudTower] Генерация остановлена: ядро не может загрузить структуру мира из-за ограничения NBT");
               }

               this.finish();
            } else if (throwable != null) {
               this.handleFailure(throwable);
            } else {
               this.rejectCandidate();
            }
         });
      }
   }

   private void rejectCandidate() {
      this.session.deletePendingRegion();
      this.session.releaseChunks();
      this.session.clearCandidate();
   }

   private void handleFailure(Throwable throwable) {
      String type = this.session != null && this.session.candidate != null ? this.session.candidate.getDefinition().getKey() : "неизвестная";
      this.plugin.getLogger().warning("[CloudTower] Башня " + type + " не создана: " + this.readable(throwable));
      if (this.session != null) {
         this.session.cancelPaste();
         this.session.deletePendingRegion();
         this.session.releaseChunks();
         this.session.clearCandidate();
      }
   }

   private void finish() {
      if (this.session != null) {
         this.session.releaseChunks();
      }

      this.towerManager.saveAsync();
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }

      if (this.session != null) {
         Bukkit.getConsoleSender().sendMessage(ColorUtil.color("&fCloudTower &aгенерация завершена, создано башен: " + this.session.generated));
      }

      this.session = null;
   }

   private TowerCandidate locate(World world, TowerDefinition definition, int index) {
      Location spawn = world.getSpawnLocation();
      int radius = this.configManager.getGenerationSettings().getRadius();
      int cellSize = definition.getCellSize();
      int cellsAcross = Math.max(1, (radius * 2 + cellSize - 1) / cellSize);
      int cellsPerPass = Math.max(1, cellsAcross * cellsAcross);
      int pass = index / cellsPerPass;
      int slot = Math.floorMod(index, cellsPerPass);
      long seed = this.mix(world.getSeed(), definition.getKey().hashCode(), pass, slot);
      Random random = new Random(seed);
      if (random.nextDouble() > definition.getChance()) {
         return null;
      } else {
         int cellX = slot % cellsAcross;
         int cellZ = slot / cellsAcross;
         int offsetX = random.nextInt(cellSize);
         int offsetZ = random.nextInt(cellSize);
         int x = spawn.getBlockX() - radius + cellX * cellSize + offsetX;
         int z = spawn.getBlockZ() - radius + cellZ * cellSize + offsetZ;
         long dx = (long)x - spawn.getBlockX();
         long dz = (long)z - spawn.getBlockZ();
         long distance = dx * dx + dz * dz;
         long maximum = (long)radius * radius;
         long exclusion = this.configManager.getGenerationSettings().getSpawnExclusionRadius();
         if (distance <= maximum && distance >= exclusion * exclusion) {
            Rotation rotation = definition.isRandomRotation() ? Rotation.random(random) : Rotation.NONE;
            return new TowerCandidate(definition, index, x, z, 0, rotation);
         } else {
            return null;
         }
      }
   }

   private Location resolvePlacement(World world, TowerCandidate candidate) throws Exception {
      TowerDefinition definition = candidate.getDefinition();
      int centerY = this.surfaceY(world, candidate.getX(), candidate.getZ());
      if (this.isSafeGround(world, candidate.getX(), centerY, candidate.getZ()) && centerY >= definition.getMinLandY() && centerY <= definition.getMaxLandY()) {
         int support = 0;
         int radius = definition.getSupportRadius();
         int step = definition.getSupportStep();

         for (int x = -radius; x <= radius; x += step) {
            for (int z = -radius; z <= radius; z += step) {
               if (x * x + z * z <= radius * radius) {
                  int y = this.surfaceY(world, candidate.getX() + x, candidate.getZ() + z);
                  if (this.isSafeGround(world, candidate.getX() + x, y, candidate.getZ() + z)
                     && y >= definition.getMinLandY()
                     && y <= definition.getMaxLandY()
                     && Math.abs(centerY - y) <= definition.getMaxHeightDelta()) {
                     support++;
                  }
               }
            }
         }

         if (support < definition.getMinSupportPoints()) {
            return null;
         }

         int lowest = this.schematicManager.getLowestRelativeY(definition.getSchematic());
         return new Location(world, candidate.getX(), centerY + 1 + definition.getYOffset() - lowest, candidate.getZ());
      } else {
         return null;
      }
   }

   private int surfaceY(World world, int x, int z) {
      int y = world.getHighestBlockYAt(x, z);
      if (y > 0 && world.getBlockAt(x, y, z).getType() == Material.AIR) {
         y--;
      }

      return y;
   }

   private boolean isSafeGround(World world, int x, int y, int z) {
      if (y > 0 && y < world.getMaxHeight() - 2) {
         Material material = world.getBlockAt(x, y, z).getType();
         if (!material.isSolid()) {
            return false;
         }

         String name = material.name();
         return !name.contains("LEAVES")
            && !name.contains("LOG")
            && !name.contains("WOOD")
            && !name.contains("WATER")
            && !name.contains("LAVA")
            && !name.contains("ICE")
            && !name.contains("SNOW")
            && !name.contains("CACTUS")
            && !name.contains("MAGMA");
      } else {
         return false;
      }
   }

   private SchematicBounds terrainBounds(TowerCandidate candidate) {
      int radius = candidate.getDefinition().getSupportRadius();
      return new SchematicBounds(candidate.getX() - radius, 0, candidate.getZ() - radius, candidate.getX() + radius, 255, candidate.getZ() + radius);
   }

   private void queueChunks(SchematicBounds bounds) {
      this.session.chunks.clear();
      this.session.queued.clear();

      for (int x = bounds.getMinChunkX(); x <= bounds.getMaxChunkX(); x++) {
         for (int z = bounds.getMinChunkZ(); z <= bounds.getMaxChunkZ(); z++) {
            GenerationManager.ChunkPosition position = new GenerationManager.ChunkPosition(x, z);
            if (this.session.queued.add(position.key())) {
               this.session.chunks.addLast(position);
            }
         }
      }
   }

   private int workBudget() {
      int configured = this.configManager.getGenerationSettings().getAutoPlacementsPerTick();
      return Math.max(2, Math.min(8, configured * 2));
   }

   private int candidateBudget(TowerDefinition definition, int missing) {
      long value = (long)Math.max(1, missing) * definition.getTargetCandidateMultiplier();
      return (int)Math.min(2147483647L, Math.max(missing, value));
   }

   private int addSafely(int first, int second) {
      long value = (long)first + second;
      return value >= 2147483647L ? Integer.MAX_VALUE : (int)value;
   }

   private String createId(World world, TowerCandidate candidate) {
      return world.getUID().toString().replace("-", "") + "_" + candidate.getDefinition().getKey() + "_" + candidate.getIndex();
   }

   private long mix(long first, long second, long third, long fourth) {
      long value = first ^ second * -7046029254386353131L ^ third * -4417276706812531889L ^ fourth;
      value ^= value >>> 30;
      value *= -4658895280553007687L;
      value ^= value >>> 27;
      value *= -7723592293110705685L;
      return value ^ value >>> 31;
   }

   private boolean isEndCityNbtFailure(Throwable throwable) {
      Throwable current = throwable;

      for (int depth = 0; current != null && depth < 12; depth++) {
         String message = current.getMessage();
         if (message != null) {
            String value = message.toLowerCase(Locale.ROOT);
            if (value.contains("end_city/ship") && value.contains("nbt") || value.contains("nbt list length") && value.contains("exceeds")) {
               return true;
            }
         }

         current = current.getCause();
      }

      return false;
   }

   private String readable(Throwable throwable) {
      Throwable current = throwable;

      while (current.getCause() != null && current.getCause() != current) {
         current = current.getCause();
      }

      String message = current.getMessage();
      return message != null && !message.trim().isEmpty() ? message : current.getClass().getSimpleName();
   }

   private static final class ChunkPosition {
      private final int x;
      private final int z;

      private ChunkPosition(int x, int z) {
         this.x = x;
         this.z = z;
      }

      private long key() {
         return (long)this.x << 32 ^ this.z & 4294967295L;
      }
   }

   private static final class Progress {
      private final TowerDefinition definition;
      private final int maxIndex;
      private int nextIndex;

      private Progress(TowerDefinition definition, int nextIndex, int maxIndex) {
         this.definition = definition;
         this.nextIndex = Math.max(0, nextIndex);
         this.maxIndex = Math.max(this.nextIndex, maxIndex);
      }
   }

   private final class Session {
      private final World world;
      private final String worldUid;
      private final List<GenerationManager.Progress> progress;
      private final Deque<GenerationManager.ChunkPosition> chunks = new ArrayDeque<>();
      private final Set<Long> queued = new HashSet<>();
      private final Set<Long> loadedByPlugin = new HashSet<>();
      private int progressIndex;
      private int generated;
      private int checkedSinceSave;
      private int loadEpoch;
      private int pendingLoads;
      private TowerCandidate candidate;
      private Location placement;
      private SchematicBounds bounds;
      private GenerationManager.Stage stage;
      private String number;
      private String regionId;
      private SchematicManager.PasteJob pasteJob;
      private SchematicManager.PasteResult pasteResult;
      private final Set<Long> dirtyChunks = new HashSet<>();

      private Session(World world, List<GenerationManager.Progress> progress) {
         this.world = world;
         this.worldUid = world.getUID().toString();
         this.progress = progress;
      }

      private GenerationManager.Progress nextProgress() {
         for (int checked = 0; checked < this.progress.size(); checked++) {
            if (this.progressIndex >= this.progress.size()) {
               this.progressIndex = 0;
            }

            GenerationManager.Progress value = this.progress.get(this.progressIndex++);
            if (GenerationManager.this.towerManager.count(this.worldUid, value.definition.getKey()) < value.definition.getLimit()
               && value.nextIndex < value.maxIndex) {
               return value;
            }
         }

         return null;
      }

      private void clearCandidate() {
         this.loadEpoch++;
         this.pendingLoads = 0;
         this.candidate = null;
         this.placement = null;
         this.bounds = null;
         this.stage = null;
         this.number = null;
         this.regionId = null;
         this.pasteJob = null;
         this.pasteResult = null;
         this.chunks.clear();
         this.queued.clear();
         this.dirtyChunks.clear();
      }

      private void releaseChunks() {
         this.loadEpoch++;
         this.pendingLoads = 0;
         this.chunks.clear();
         this.queued.clear();

         for (Long value : new ArrayList<>(this.loadedByPlugin)) {
            long key = value;
            int x = (int)(key >> 32);
            int z = (int)key;
            this.world.removePluginChunkTicket(x, z, GenerationManager.this.plugin);
            this.world.unloadChunk(x, z, this.dirtyChunks.contains(value));
         }

         this.loadedByPlugin.clear();
      }

      private void markDirty(SchematicBounds value) {
         if (value != null) {
            for (int chunkX = value.getMinChunkX(); chunkX <= value.getMaxChunkX(); chunkX++) {
               for (int chunkZ = value.getMinChunkZ(); chunkZ <= value.getMaxChunkZ(); chunkZ++) {
                  this.dirtyChunks.add((long)chunkX << 32 ^ chunkZ & 4294967295L);
               }
            }
         }
      }

      private boolean cancelPaste() {
         if (this.pasteJob == null) {
            return true;
         }

         this.pasteJob.cancel();
         boolean completed = this.pasteJob.await(5L, TimeUnit.SECONDS);
         this.pasteJob = null;
         return completed;
      }

      private void deletePendingRegion() {
         if (this.regionId != null) {
            GenerationManager.this.plugin.getRegionManager().deleteRegion(this.world.getName(), this.regionId);
            this.regionId = null;
         }
      }

      private void commitRegion() {
         this.regionId = null;
      }

      private boolean allLimitsReached() {
         for (GenerationManager.Progress value : this.progress) {
            if (GenerationManager.this.towerManager.count(this.worldUid, value.definition.getKey()) < value.definition.getLimit()) {
               return false;
            }
         }

         return true;
      }
   }

   private enum Stage {
      TERRAIN,
      PASTE;
   }
}
