package cs.cloudstudio.manager;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class TowerData {
   private final String id;
   private final String number;
   private final String regionId;
   private final String worldName;
   private final String worldUid;
   private final String type;
   private final String schematic;
   private final int x;
   private final int y;
   private final int z;
   private final Rotation rotation;
   private final Map<String, Location> chests;
   private final SchematicBounds bounds;

   public TowerData(
      String id,
      String number,
      String regionId,
      String worldName,
      String worldUid,
      String type,
      String schematic,
      int x,
      int y,
      int z,
      Rotation rotation,
      Map<String, Location> chests,
      SchematicBounds bounds
   ) {
      this.id = id;
      this.number = number;
      this.regionId = regionId;
      this.worldName = worldName;
      this.worldUid = worldUid;
      this.type = type;
      this.schematic = schematic;
      this.x = x;
      this.y = y;
      this.z = z;
      this.rotation = rotation;
      this.bounds = bounds;
      this.chests = new LinkedHashMap<>();
      if (chests != null) {
         for (Entry<String, Location> entry : chests.entrySet()) {
            if (entry.getKey() != null && entry.getValue() != null) {
               this.chests.put(entry.getKey().toLowerCase(Locale.ROOT), entry.getValue());
            }
         }
      }
   }

   public String getId() {
      return this.id;
   }

   public String getNumber() {
      return this.number;
   }

   public String getRegionId() {
      return this.regionId;
   }

   public String getWorldName() {
      return this.worldName;
   }

   public String getWorldUid() {
      return this.worldUid;
   }

   public String getType() {
      return this.type;
   }

   public String getSchematic() {
      return this.schematic;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getZ() {
      return this.z;
   }

   public Rotation getRotation() {
      return this.rotation;
   }

   public SchematicBounds getBounds() {
      return this.bounds;
   }

   public World getWorld() {
      return Bukkit.getWorld(this.worldName);
   }

   public Location getBaseLocation() {
      World world = this.getWorld();
      return world == null ? null : new Location(world, this.x, this.y, this.z);
   }

   public Map<String, Location> getChests() {
      return Collections.unmodifiableMap(this.chests);
   }

   public Location getChest(String type) {
      return type == null ? null : this.chests.get(type.toLowerCase(Locale.ROOT));
   }
}
