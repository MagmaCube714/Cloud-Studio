package cs.cloudstudio.manager;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.util.MessageUtil;
import eu.decentsoftware.holograms.api.DHAPI;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;

public final class HologramManager {
   private static final double OFFSET_X = 0.5;
   private static final double OFFSET_Y = 1.73;
   private static final double OFFSET_Z = 0.5;
   private final CloudTower plugin;
   private final Set<String> holograms = new HashSet<>();
   private boolean enabled;

   public HologramManager(CloudTower plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.removeAll();
      this.enabled = Bukkit.getPluginManager().isPluginEnabled("DecentHolograms");
      if (!this.enabled) {
         this.plugin.getLogger().warning("[CloudTower] DecentHolograms не найден: голограммы отключены");
      }
   }

   public void create(TowerData tower) {
      if (this.enabled && tower != null) {
         for (String type : tower.getChests().keySet()) {
            Location chest = tower.getChest(type);
            if (chest != null && chest.getWorld() != null) {
               List<String> lines = MessageUtil.coloredList(this.plugin.getConfig().getStringList("holograms." + type.toLowerCase(Locale.ROOT)));
               if (!lines.isEmpty()) {
                  Location location = chest.clone().add(OFFSET_X, OFFSET_Y, OFFSET_Z);
                  String id = this.getId(tower.getNumber(), type);
                  this.remove(id);

                  try {
                     DecentHologramsBridge.create(id, location, lines);
                     this.holograms.add(id);
                  } catch (RuntimeException | LinkageError exception) {
                     this.plugin.getLogger().warning("[CloudTower] Голограмма " + id + " не создана: " + exception);
                  }
               }
            }
         }
      }
   }

   public void remove(TowerData tower) {
      if (tower != null) {
         for (String type : tower.getChests().keySet()) {
            this.remove(this.getId(tower.getNumber(), type));
         }
      }
   }

   public void removeAll() {
      for (String id : new HashSet<>(this.holograms)) {
         this.remove(id);
      }

      this.holograms.clear();
   }

   private void remove(String id) {
      if (id == null) {
         return;
      }

      if (this.enabled) {
         try {
            DecentHologramsBridge.remove(id);
         } catch (RuntimeException | LinkageError exception) {
            this.plugin.getLogger().warning("[CloudTower] Голограмма " + id + " не удалена: " + exception);
         }
      }

      this.holograms.remove(id);
   }

   private String getId(String number, String type) {
      return "cloudtower_" + number.toLowerCase(Locale.ROOT) + "_" + type.toLowerCase(Locale.ROOT);
   }

   private static final class DecentHologramsBridge {
      static void create(String id, Location location, List<String> lines) {
         DHAPI.createHologram(id, location, lines);
      }

      static void remove(String id) {
         if (DHAPI.getHologram(id) != null) {
            DHAPI.removeHologram(id);
         }
      }
   }
}
