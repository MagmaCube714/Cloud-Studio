package cs.cloudstudio.manager;

import java.util.Random;

public enum Rotation {
   NONE(0),
   CLOCKWISE_90(90),
   CLOCKWISE_180(180),
   CLOCKWISE_270(270);

   private final int degrees;

   Rotation(int degrees) {
      this.degrees = degrees;
   }

   public int getDegrees() {
      return this.degrees;
   }

   public static Rotation random(Random random) {
      Rotation[] values = values();
      return values[random.nextInt(values.length)];
   }

   public static Rotation parse(String value) {
      for (Rotation rotation : values()) {
         if (rotation.name().equalsIgnoreCase(value)) {
            return rotation;
         }
      }

      return NONE;
   }
}
