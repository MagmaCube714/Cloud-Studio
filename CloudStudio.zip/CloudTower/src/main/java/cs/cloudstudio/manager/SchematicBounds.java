package cs.cloudstudio.manager;

public final class SchematicBounds {
   private final int minX;
   private final int minY;
   private final int minZ;
   private final int maxX;
   private final int maxY;
   private final int maxZ;

   public SchematicBounds(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
      this.minX = Math.min(minX, maxX);
      this.minY = Math.min(minY, maxY);
      this.minZ = Math.min(minZ, maxZ);
      this.maxX = Math.max(minX, maxX);
      this.maxY = Math.max(minY, maxY);
      this.maxZ = Math.max(minZ, maxZ);
   }

   public int getMinX() {
      return this.minX;
   }

   public int getMinY() {
      return this.minY;
   }

   public int getMinZ() {
      return this.minZ;
   }

   public int getMaxX() {
      return this.maxX;
   }

   public int getMaxY() {
      return this.maxY;
   }

   public int getMaxZ() {
      return this.maxZ;
   }

   public int getMinChunkX() {
      return this.minX >> 4;
   }

   public int getMaxChunkX() {
      return this.maxX >> 4;
   }

   public int getMinChunkZ() {
      return this.minZ >> 4;
   }

   public int getMaxChunkZ() {
      return this.maxZ >> 4;
   }

   public boolean intersects(SchematicBounds other, int margin) {
      if (other == null) {
         return false;
      }

      int safe = Math.max(0, margin);
      return this.maxX + safe >= other.minX
         && this.minX - safe <= other.maxX
         && this.maxY + safe >= other.minY
         && this.minY - safe <= other.maxY
         && this.maxZ + safe >= other.minZ
         && this.minZ - safe <= other.maxZ;
   }
}
