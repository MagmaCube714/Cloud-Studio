package cs.cloudstudio.manager;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.math.Vector3;
import com.sk89q.worldedit.math.transform.AffineTransform;
import com.sk89q.worldedit.session.ClipboardHolder;
import cs.cloudstudio.CloudTower;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import org.bukkit.Location;
import org.bukkit.World;

public final class SchematicManager {
   private final File serverRoot;
   private final Map<String, SchematicManager.CachedClipboard> cache = new HashMap<>();
   private final Map<Clipboard, List<BlockVector3>> chestCache = new IdentityHashMap<>();
   private final ExecutorService executor;

   public SchematicManager(CloudTower plugin) {
      File plugins = plugin.getDataFolder().getParentFile();
      this.serverRoot = plugins != null && plugins.getParentFile() != null ? plugins.getParentFile() : new File(".");
      this.executor = Executors.newSingleThreadExecutor(new ThreadFactory() {
         @Override
         public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, "CloudTower-FAWE");
            thread.setDaemon(true);
            return thread;
         }
      });
   }

   public boolean isAvailable(String path) {
      return this.resolve(path).isFile();
   }

   public File resolve(String path) {
      String value = path == null ? "" : path.trim();
      File file = new File(value);
      return file.isAbsolute() ? file : new File(this.serverRoot, value);
   }

   public Clipboard load(String path) throws Exception {
      File file = this.resolve(path);
      if (!file.isFile()) {
         throw new IllegalStateException("файл не найден: " + file.getAbsolutePath());
      }

      String key = this.canonical(file);
      SchematicManager.CachedClipboard cached = this.cache.get(key);
      if (cached != null && cached.modified == file.lastModified() && cached.length == file.length()) {
         return cached.clipboard;
      }

      ClipboardFormat format = ClipboardFormats.findByFile(file);
      if (format == null) {
         throw new IllegalStateException("формат схематики не поддерживается: " + file.getAbsolutePath());
      }

      ClipboardReader reader = format.getReader(new BufferedInputStream(new FileInputStream(file)));

      Clipboard var8;
      try {
         Clipboard clipboard = reader.read();
         this.cache.put(key, new SchematicManager.CachedClipboard(file.lastModified(), file.length(), clipboard));
         var8 = clipboard;
      } catch (Throwable var10) {
         if (reader != null) {
            try {
               reader.close();
            } catch (Throwable var9) {
               var10.addSuppressed(var9);
            }
         }

         throw var10;
      }

      if (reader != null) {
         reader.close();
      }

      return var8;
   }

   public void clearCache() {
      this.cache.clear();
      this.chestCache.clear();
   }

   public void shutdown() {
      this.executor.shutdownNow();

      try {
         this.executor.awaitTermination(5L, TimeUnit.SECONDS);
      } catch (InterruptedException exception) {
         Thread.currentThread().interrupt();
      }

      this.clearCache();
   }

   public int getLowestRelativeY(String path) throws Exception {
      Clipboard clipboard = this.load(path);
      return clipboard.getRegion().getMinimumPoint().y() - clipboard.getOrigin().y();
   }

   public SchematicBounds getBounds(String path, int x, int y, int z, Rotation rotation) throws Exception {
      Clipboard clipboard = this.load(path);
      BlockVector3 minimum = clipboard.getRegion().getMinimumPoint();
      BlockVector3 maximum = clipboard.getRegion().getMaximumPoint();
      BlockVector3 origin = clipboard.getOrigin();
      int minX = Integer.MAX_VALUE;
      int minY = Integer.MAX_VALUE;
      int minZ = Integer.MAX_VALUE;
      int maxX = Integer.MIN_VALUE;
      int maxY = Integer.MIN_VALUE;
      int maxZ = Integer.MIN_VALUE;
      int[] xs = new int[]{minimum.x(), maximum.x()};
      int[] ys = new int[]{minimum.y(), maximum.y()};
      int[] zs = new int[]{minimum.z(), maximum.z()};

      for (int sourceX : xs) {
         for (int sourceY : ys) {
            for (int sourceZ : zs) {
               BlockVector3 target = this.transformPoint(BlockVector3.at(sourceX, sourceY, sourceZ), origin, x, y, z, rotation);
               minX = Math.min(minX, target.x());
               minY = Math.min(minY, target.y());
               minZ = Math.min(minZ, target.z());
               maxX = Math.max(maxX, target.x());
               maxY = Math.max(maxY, target.y());
               maxZ = Math.max(maxZ, target.z());
            }
         }
      }

      return new SchematicBounds(minX, minY, minZ, maxX, maxY, maxZ);
   }

   public SchematicManager.PasteJob pasteAsync(
      final World world, String path, final int x, final int y, final int z, final Rotation rotation, final boolean pasteAir
   ) throws Exception {
      final Clipboard clipboard = this.load(path);
      Future<SchematicManager.PasteResult> future = this.executor.submit(new Callable<SchematicManager.PasteResult>() {
         public SchematicManager.PasteResult call() throws Exception {
            SchematicManager.this.paste(world, clipboard, x, y, z, rotation, pasteAir);
            return new SchematicManager.PasteResult(SchematicManager.this.getChestLocations(world, clipboard, x, y, z, rotation));
         }
      });
      return new SchematicManager.PasteJob(future);
   }

   private void paste(World world, Clipboard clipboard, int x, int y, int z, Rotation rotation, boolean pasteAir) throws Exception {
      ClipboardHolder holder = new ClipboardHolder(clipboard);
      holder.setTransform(this.transform(rotation));

      try (EditSession editSession = WorldEdit.getInstance().newEditSessionBuilder().world(BukkitAdapter.adapt(world)).maxBlocks(-1).fastMode(true).build()) {
         Operation operation = holder.createPaste(editSession)
            .to(BlockVector3.at(x, y, z))
            .ignoreAirBlocks(false)
            .copyEntities(false)
            .copyBiomes(false)
            .build();
         Operations.complete(operation);
      }
   }
   private List<Location> getChestLocations(World world, Clipboard clipboard, int x, int y, int z, Rotation rotation) {
      List<BlockVector3> source = this.chestCache.get(clipboard);
      if (source == null) {
         source = new ArrayList<>();
         BlockVector3 minimum = clipboard.getRegion().getMinimumPoint();
         BlockVector3 maximum = clipboard.getRegion().getMaximumPoint();

         for (int sourceX = minimum.x(); sourceX <= maximum.x(); sourceX++) {
            for (int sourceY = minimum.y(); sourceY <= maximum.y(); sourceY++) {
               for (int sourceZ = minimum.z(); sourceZ <= maximum.z(); sourceZ++) {
                  BlockVector3 point = BlockVector3.at(sourceX, sourceY, sourceZ);
                  String id = clipboard.getBlock(point).getBlockType().id();
                  if ("minecraft:chest".equals(id) || "minecraft:trapped_chest".equals(id)) {
                     source.add(point);
                  }
               }
            }
         }

         this.chestCache.put(clipboard, source);
      }

      BlockVector3 origin = clipboard.getOrigin();
      List<Location> result = new ArrayList<>(source.size());

      for (BlockVector3 point : source) {
         BlockVector3 target = this.transformPoint(point, origin, x, y, z, rotation);
         result.add(new Location(world, target.x(), target.y(), target.z()));
      }

      return result;
   }

   private AffineTransform transform(Rotation rotation) {
      AffineTransform transform = new AffineTransform();
      return rotation == Rotation.NONE ? transform : transform.rotateY(rotation.getDegrees());
   }

   private BlockVector3 transformPoint(BlockVector3 point, BlockVector3 origin, int x, int y, int z, Rotation rotation) {
      int relativeX = point.x() - origin.x();
      int relativeY = point.y() - origin.y();
      int relativeZ = point.z() - origin.z();
      BlockVector3 transformed = this.transform(rotation).apply(Vector3.at(relativeX, relativeY, relativeZ)).round().toBlockPoint();
      return BlockVector3.at(x + transformed.x(), y + transformed.y(), z + transformed.z());
   }

   private String canonical(File file) {
      try {
         return file.getCanonicalPath();
      } catch (IOException exception) {
         return file.getAbsolutePath();
      }
   }

   private static final class CachedClipboard {
      private final long modified;
      private final long length;
      private final Clipboard clipboard;

      private CachedClipboard(long modified, long length, Clipboard clipboard) {
         this.modified = modified;
         this.length = length;
         this.clipboard = clipboard;
      }
   }

   public static final class PasteJob {
      private final Future<SchematicManager.PasteResult> future;

      private PasteJob(Future<SchematicManager.PasteResult> future) {
         this.future = future;
      }

      public boolean isDone() {
         return this.future.isDone();
      }

      public SchematicManager.PasteResult get() throws Exception {
         try {
            return this.future.get();
         } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw exception;
         } catch (ExecutionException exception) {
            Throwable cause = exception.getCause();
            if (cause instanceof Exception) {
               throw (Exception)cause;
            } else if (cause instanceof Error) {
               throw (Error)cause;
            } else {
               throw new IllegalStateException(cause);
            }
         }
      }

      public void cancel() {
         this.future.cancel(true);
      }

      public boolean await(long timeout, TimeUnit unit) {
         try {
            this.future.get(timeout, unit);
            return true;
         } catch (Exception exception) {
            return this.future.isDone();
         }
      }
   }

   public static final class PasteResult {
      private final List<Location> chests;

      private PasteResult(List<Location> chests) {
         this.chests = new ArrayList<>(chests);
      }

      public List<Location> getChests() {
         return new ArrayList<>(this.chests);
      }
   }
}
