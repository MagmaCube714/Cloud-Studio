package cs.cloudstudio.manager;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.flags.StateFlag.State;
import com.sk89q.worldguard.protection.managers.storage.StorageException;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import cs.cloudstudio.CloudTower;
import java.util.List;
import java.util.Locale;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class RegionManager {
   private final CloudTower plugin;

   public RegionManager(CloudTower plugin) {
      this.plugin = plugin;
   }

   public int getRadius() {
      return Math.max(1, this.plugin.getConfig().getInt("region-settings.radius", 40));
   }

   public String getRegionId(String number) {
      return "cloudtower_" + number.toLowerCase(Locale.ROOT);
   }

   public String createRegion(String number, Location center) {
      if (number != null && !number.isEmpty()) {
         String regionId = this.getRegionId(number);
         return this.createRegion(regionId, center, true) ? regionId : null;
      } else {
         return null;
      }
   }

   public boolean createRegion(String regionId, Location center, boolean checkIntersections) {
      if (regionId != null && !regionId.isEmpty() && center != null && center.getWorld() != null) {
         com.sk89q.worldguard.protection.managers.RegionManager manager = this.getManager(center.getWorld());
         if (manager == null) {
            this.plugin.getLogger().warning("[CloudTower] Регион башни не создан: WorldGuard недоступен для мира " + center.getWorld().getName());
            return false;
         }

         ProtectedCuboidRegion region = this.createCuboid(regionId, center);
         if (checkIntersections && this.intersects(center, regionId)) {
            return false;
         }

         region.setPriority(1);
         this.applyFlags(region, this.plugin.getConfig().getStringList("region-settings.allow-flags"), State.ALLOW);
         this.applyFlags(region, this.plugin.getConfig().getStringList("region-settings.deny-flags"), State.DENY);
         manager.addRegion(region);
         this.save(manager, center.getWorld().getName());
         return true;
      } else {
         return false;
      }
   }

   public void ensureRegion(TowerData tower) {
      if (tower != null) {
         Location location = tower.getBaseLocation();
         if (location != null && location.getWorld() != null) {
            String regionId = tower.getRegionId();
            if (regionId == null || regionId.isEmpty()) {
               regionId = this.getRegionId(tower.getNumber());
            }

            com.sk89q.worldguard.protection.managers.RegionManager manager = this.getManager(location.getWorld());
            if (manager == null) {
               this.plugin
                  .getLogger()
                  .warning("[CloudTower] Регион башни " + tower.getNumber() + " не проверен: WorldGuard недоступен для мира " + location.getWorld().getName());
            } else {
               ProtectedRegion region = manager.getRegion(regionId);
               if (region == null) {
                  if (!this.createRegion(regionId, location, false)) {
                     this.plugin.getLogger().warning("[CloudTower] Регион башни " + tower.getNumber() + " не восстановлен");
                  }
               } else {
                  region.setPriority(1);
                  this.applyFlags(region, this.plugin.getConfig().getStringList("region-settings.allow-flags"), State.ALLOW);
                  this.applyFlags(region, this.plugin.getConfig().getStringList("region-settings.deny-flags"), State.DENY);
                  this.save(manager, location.getWorld().getName());
               }
            }
         } else {
            this.plugin.getLogger().warning("[CloudTower] Регион башни " + tower.getNumber() + " не проверен: мир не найден");
         }
      }
   }

   public void deleteRegion(String worldName, String regionId) {
      if (worldName != null && regionId != null && !regionId.isEmpty()) {
         World world = Bukkit.getWorld(worldName);
         if (world != null) {
            com.sk89q.worldguard.protection.managers.RegionManager manager = this.getManager(world);
            if (manager != null) {
               manager.removeRegion(regionId);
               this.save(manager, worldName);
            }
         }
      }
   }

   public boolean canCreateRegion(Location center) {
      return center != null && center.getWorld() != null && !this.intersects(center, null);
   }

   public boolean isInsideRegion(Location location) {
      return this.plugin.getTowerManager().findByLocation(location) != null;
   }

   private boolean intersects(Location center, String ignoredRegionId) {
      if (center != null && center.getWorld() != null) {
         com.sk89q.worldguard.protection.managers.RegionManager manager = this.getManager(center.getWorld());
         if (manager == null) {
            return true;
         }

         ProtectedCuboidRegion cuboid = this.createCuboid("__cloudtower_check", center);
         ApplicableRegionSet regions = manager.getApplicableRegions(cuboid);
         if (regions == null) {
            return false;
         }

         for (ProtectedRegion region : regions) {
            if (region != null
               && (ignoredRegionId == null || !region.getId().equalsIgnoreCase(ignoredRegionId))
               && !"__global__".equalsIgnoreCase(region.getId())) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private ProtectedCuboidRegion createCuboid(String id, Location center) {
      int radius = this.getRadius();
      World world = center.getWorld();
      int minX = center.getBlockX() - radius;
      int maxX = center.getBlockX() + radius;
      int minY = Math.max(0, center.getBlockY() - 100);
      int maxY = Math.min(world.getMaxHeight() - 1, center.getBlockY() + 255);
      int minZ = center.getBlockZ() - radius;
      int maxZ = center.getBlockZ() + radius;
      return new ProtectedCuboidRegion(id, BlockVector3.at(minX, minY, minZ), BlockVector3.at(maxX, maxY, maxZ));
   }

   private void applyFlags(ProtectedRegion region, List<String> flags, State state) {
      for (String name : flags) {
         if (name != null && !name.trim().isEmpty()) {
            Flag<?> flag = WorldGuard.getInstance().getFlagRegistry().get(name.toLowerCase(Locale.ROOT));
            if (flag instanceof StateFlag stateFlag) {
               region.setFlag(stateFlag, state);
            } else {
               this.plugin.getLogger().warning("[CloudTower] Флаг региона не применен: " + name);
            }
         }
      }
   }

   private com.sk89q.worldguard.protection.managers.RegionManager getManager(World world) {
      return world == null ? null : WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(world));
   }

   private void save(com.sk89q.worldguard.protection.managers.RegionManager manager, String worldName) {
      try {
         manager.save();
      } catch (StorageException exception) {
         this.plugin.getLogger().warning("[CloudTower] Регионы WorldGuard не сохранены для мира " + worldName);
      }
   }
}
