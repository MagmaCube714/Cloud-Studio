package cs.cloudstudio.manager;

import cs.cloudstudio.CloudCards;
import cs.cloudstudio.CloudTower;
import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class CloudCardsHook {
   private final CloudTower plugin;
   private CardManager cardManager;

   public CloudCardsHook(CloudTower plugin) {
      this.plugin = plugin;
   }

   public boolean setup() {
      Plugin found = Bukkit.getPluginManager().getPlugin("CloudCards");
      if (found instanceof CloudCards && found.isEnabled()) {
         this.cardManager = ((CloudCards)found).getCardManager();
         if (this.cardManager == null) {
            this.plugin.getLogger().warning("[CloudTower] CloudCards подключён, но менеджер карт ещё не готов");
            return false;
         } else {
            return true;
         }
      } else {
         this.plugin.getLogger().warning("[CloudTower] CloudCards не подключён: API ключ-карт недоступен");
         this.cardManager = null;
         return false;
      }
   }

   public boolean isCard(ItemStack item, String type) {
      if (item != null && type != null && this.cardManager != null) {
         CardType cardType = CardType.fromString(type);
         if (cardType == null) {
            return false;
         }

         ItemStack expected = this.cardManager.getCard(cardType);
         return expected != null && item.isSimilar(expected);
      } else {
         return false;
      }
   }
}
