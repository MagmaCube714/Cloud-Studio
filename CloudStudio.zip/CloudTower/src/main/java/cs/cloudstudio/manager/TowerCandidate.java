package cs.cloudstudio.manager;

import cs.cloudstudio.config.TowerDefinition;

public final class TowerCandidate {
   private final TowerDefinition definition;
   private final int index;
   private final int x;
   private final int z;
   private final int y;
   private final Rotation rotation;

   public TowerCandidate(TowerDefinition definition, int index, int x, int z, int y, Rotation rotation) {
      this.definition = definition;
      this.index = index;
      this.x = x;
      this.z = z;
      this.y = y;
      this.rotation = rotation;
   }

   public TowerDefinition getDefinition() {
      return this.definition;
   }

   public int getIndex() {
      return this.index;
   }

   public int getX() {
      return this.x;
   }

   public int getZ() {
      return this.z;
   }

   public int getY() {
      return this.y;
   }

   public Rotation getRotation() {
      return this.rotation;
   }
}
