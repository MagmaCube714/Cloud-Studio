package cs.cloudstudio.manager;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.util.LocationUtil;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ExecutionException;
import java.nio.file.StandardCopyOption;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

public final class TowerManager {
   private static final int SEPARATION_MARGIN = 8;
   private final CloudTower plugin;
   private final File file;
   private final Map<String, TowerData> towers = new LinkedHashMap<>();
   private final Map<String, Integer> counts = new HashMap<>();
   private final Map<String, Integer> progress = new HashMap<>();
   private final Set<String> generatedIds = new HashSet<>();
   private final Map<String, Map<Long, Set<String>>> spatialIndex = new HashMap<>();
   private int nextNumber = 1;
   private volatile TowerManager.WorldKey lastWorldKey;
   private volatile boolean dirty;
   private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor(runnable -> {
      Thread thread = new Thread(runnable, "CloudTower-IO");
      thread.setDaemon(true);
      return thread;
   });

   public TowerManager(CloudTower plugin) {
      this.plugin = plugin;
      this.file = new File(plugin.getDataFolder(), "towers.yml");
   }

   public void load() {
      this.towers.clear();
      this.counts.clear();
      this.progress.clear();
      this.generatedIds.clear();
      this.spatialIndex.clear();
      this.nextNumber = 1;
      if (!this.file.isFile()) {
         this.dirty = true;
         this.save();
      } else {
         YamlConfiguration configuration = YamlConfiguration.loadConfiguration(this.file);
         ConfigurationSection towerSection = configuration.getConfigurationSection("towers");
         if (towerSection != null) {
            for (String id : towerSection.getKeys(false)) {
               TowerData tower = this.readTower(id, towerSection.getConfigurationSection(id));
               if (tower != null && !this.towers.containsKey(tower.getNumber().toLowerCase(Locale.ROOT))) {
                  this.addToMemory(tower);
               }
            }
         }

         ConfigurationSection progressSection = configuration.getConfigurationSection("progress");
         if (progressSection != null) {
            for (String worldUid : progressSection.getKeys(false)) {
               ConfigurationSection worldSection = progressSection.getConfigurationSection(worldUid);
               if (worldSection != null) {
                  for (String type : worldSection.getKeys(false)) {
                     this.progress.put(this.progressKey(worldUid, type), Math.max(0, worldSection.getInt(type, 0)));
                  }
               }
            }
         }

         this.dirty = false;
      }
   }

   public void save() {
      String data = this.snapshot();
      if (data != null) {
         try {
            this.ioExecutor.submit(() -> this.write(data)).get();
         } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            this.write(data);
         } catch (ExecutionException | RejectedExecutionException exception) {
            this.write(data);
         }
      }
   }

   public void saveAsync() {
      String data = this.snapshot();
      if (data != null) {
         try {
            this.ioExecutor.execute(() -> this.write(data));
         } catch (RejectedExecutionException exception) {
            this.write(data);
         }
      }
   }

   private String snapshot() {
      if (this.dirty || !this.file.isFile()) {
         if (!this.plugin.getDataFolder().exists() && !this.plugin.getDataFolder().mkdirs()) {
            this.plugin.getLogger().warning("[CloudTower] Папка плагина не создана");
            return null;
         } else {
            YamlConfiguration configuration = new YamlConfiguration();

            for (TowerData tower : this.getTowers()) {
               String path = "towers." + tower.getId();
               configuration.set(path + ".number", tower.getNumber());
               configuration.set(path + ".region-id", tower.getRegionId());
               configuration.set(path + ".world-name", tower.getWorldName());
               configuration.set(path + ".world-uid", tower.getWorldUid());
               configuration.set(path + ".type", tower.getType());
               configuration.set(path + ".schematic", tower.getSchematic());
               configuration.set(path + ".x", tower.getX());
               configuration.set(path + ".y", tower.getY());
               configuration.set(path + ".z", tower.getZ());
               configuration.set(path + ".rotation", tower.getRotation().name());
               SchematicBounds bounds = tower.getBounds();
               configuration.set(path + ".bounds.min-x", bounds.getMinX());
               configuration.set(path + ".bounds.min-y", bounds.getMinY());
               configuration.set(path + ".bounds.min-z", bounds.getMinZ());
               configuration.set(path + ".bounds.max-x", bounds.getMaxX());
               configuration.set(path + ".bounds.max-y", bounds.getMaxY());
               configuration.set(path + ".bounds.max-z", bounds.getMaxZ());

               for (Entry<String, Location> entry : tower.getChests().entrySet()) {
                  configuration.set(path + ".chests." + entry.getKey(), LocationUtil.serialize(entry.getValue()));
               }
            }

            for (Entry<String, Integer> entry : this.progress.entrySet()) {
               int separator = entry.getKey().indexOf(124);
               if (separator > 0) {
                  configuration.set("progress." + entry.getKey().substring(0, separator) + "." + entry.getKey().substring(separator + 1), entry.getValue());
               }
            }

            this.dirty = false;
            return configuration.saveToString();
         }
      } else {
         return null;
      }
   }

   private void write(String data) {
      Path target = this.file.toPath();
      Path temp = target.resolveSibling(this.file.getName() + ".tmp");

      try {
         Files.writeString(temp, data, StandardCharsets.UTF_8);
         try {
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
         } catch (AtomicMoveNotSupportedException exception) {
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
         }
      } catch (IOException exception) {
         this.dirty = true;
         this.plugin.getLogger().log(Level.WARNING, "[CloudTower] Файл towers.yml не сохранён", exception);
      }
   }

   public void add(TowerData tower) {
      if (tower != null && !this.towers.containsKey(tower.getNumber().toLowerCase(Locale.ROOT))) {
         this.addToMemory(tower);
         this.dirty = true;
      }
   }

   public String claimNumber() {
      while (this.towers.containsKey(String.valueOf(this.nextNumber))) {
         this.nextNumber++;
      }

      return String.valueOf(this.nextNumber);
   }

   public TowerData getTower(String number) {
      return number == null ? null : this.towers.get(number.toLowerCase(Locale.ROOT));
   }

   public Collection<String> getNumbers() {
      List<String> result = new ArrayList<>();

      for (TowerData tower : this.getTowers()) {
         result.add(tower.getNumber());
      }

      return result;
   }

   public List<TowerData> getTowers() {
      List<TowerData> result = new ArrayList<>(this.towers.values());
      Collections.sort(result, new Comparator<TowerData>() {
         public int compare(TowerData first, TowerData second) {
            return Integer.compare(TowerManager.this.parseNumber(first.getNumber()), TowerManager.this.parseNumber(second.getNumber()));
         }
      });
      return result;
   }

   public int count(String worldUid, String type) {
      Integer value = this.counts.get(this.countKey(worldUid, type));
      return value == null ? 0 : value;
   }

   public int getProgress(String worldUid, String type) {
      Integer value = this.progress.get(this.progressKey(worldUid, type));
      return value == null ? 0 : value;
   }

   public void setProgress(String worldUid, String type, int value) {
      this.progress.put(this.progressKey(worldUid, type), Math.max(0, value));
      this.dirty = true;
   }

   public boolean isGenerated(String id) {
      return id != null && this.generatedIds.contains(id);
   }

   public boolean isFree(String worldUid, SchematicBounds bounds, int x, int z, int minimumDistance) {
      Map<Long, Set<String>> worldIndex = this.spatialIndex.get(worldUid);
      if (worldIndex != null && bounds != null) {
         int chunkMargin = Math.max(1, minimumDistance + 15 >> 4);
         Set<String> checked = new HashSet<>();

         for (int chunkX = bounds.getMinChunkX() - chunkMargin; chunkX <= bounds.getMaxChunkX() + chunkMargin; chunkX++) {
            for (int chunkZ = bounds.getMinChunkZ() - chunkMargin; chunkZ <= bounds.getMaxChunkZ() + chunkMargin; chunkZ++) {
               Set<String> numbers = worldIndex.get(this.chunkKey(chunkX, chunkZ));
               if (numbers != null) {
                  for (String number : numbers) {
                     if (checked.add(number)) {
                        TowerData tower = this.towers.get(number);
                        if (tower != null) {
                           if (bounds.intersects(tower.getBounds(), 8)) {
                              return false;
                           }

                           long dx = (long)tower.getX() - x;
                           long dz = (long)tower.getZ() - z;
                           if (minimumDistance > 0 && dx * dx + dz * dz < (long)minimumDistance * minimumDistance) {
                              return false;
                           }
                        }
                     }
                  }
               }
            }
         }

         return true;
      } else {
         return true;
      }
   }

   public void prepareWorld(World world) {
      if (world != null) {
         String uid = world.getUID().toString();
         List<String> remove = new ArrayList<>();

         for (TowerData tower : this.towers.values()) {
            if (tower.getWorldName().equalsIgnoreCase(world.getName()) && !tower.getWorldUid().equals(uid)) {
               remove.add(tower.getNumber().toLowerCase(Locale.ROOT));
            }
         }

         for (String number : remove) {
            this.removeFromMemory(number);
         }

         if (!remove.isEmpty()) {
            this.dirty = true;
            this.save();
         }
      }
   }

   public TowerData findByLocation(Location location) {
      if (location != null && location.getWorld() != null) {
         World world = location.getWorld();
         TowerManager.WorldKey worldKey = this.lastWorldKey;
         if (worldKey == null || worldKey.world != world) {
            worldKey = new TowerManager.WorldKey(world, world.getUID().toString());
            this.lastWorldKey = worldKey;
         }

         Map<Long, Set<String>> worldIndex = this.spatialIndex.get(worldKey.uid);
         if (worldIndex == null) {
            return null;
         }

         Set<String> values = worldIndex.get(this.chunkKey(location.getBlockX() >> 4, location.getBlockZ() >> 4));
         if (values == null) {
            return null;
         }

         for (String number : values) {
            TowerData tower = this.towers.get(number);
            SchematicBounds bounds = tower == null ? null : tower.getBounds();
            if (bounds != null
               && location.getBlockX() >= bounds.getMinX()
               && location.getBlockX() <= bounds.getMaxX()
               && location.getBlockY() >= bounds.getMinY()
               && location.getBlockY() <= bounds.getMaxY()
               && location.getBlockZ() >= bounds.getMinZ()
               && location.getBlockZ() <= bounds.getMaxZ()) {
               return tower;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public TowerData findByChest(Location location) {
      if (location == null) {
         return null;
      }

      TowerData nearby = this.findByLocation(location);
      if (nearby != null) {
         for (Location chest : nearby.getChests().values()) {
            if (LocationUtil.sameBlock(chest, location)) {
               return nearby;
            }
         }
      }

      return null;
   }

   public boolean handleChestUse(Player player, Location chestLocation) {
      TowerData tower = this.findByChest(chestLocation);
      if (tower == null) {
         return false;
      }

      String type = null;

      for (Entry<String, Location> entry : tower.getChests().entrySet()) {
         if (LocationUtil.sameBlock(entry.getValue(), chestLocation)) {
            type = entry.getKey();
            break;
         }
      }

      if (type == null) {
         return false;
      }

      ItemStack hand = player.getInventory().getItemInMainHand();
      if (!this.plugin.getCloudCardsHook().isCard(hand, type)) {
         return true;
      }

      List<ItemStack> loot = this.plugin.getLootManager().roll(type);
      if (hand.getAmount() <= 1) {
         player.getInventory().setItemInMainHand(null);
      } else {
         hand.setAmount(hand.getAmount() - 1);
      }

      this.dropLoot(chestLocation, loot);
      return true;
   }

   public Location getTeleportLocation(TowerData tower) {
      if (tower != null && tower.getWorld() != null) {
         World world = tower.getWorld();
         SchematicBounds bounds = tower.getBounds();
         int centerX = bounds.getMinX() + (bounds.getMaxX() - bounds.getMinX()) / 2;
         int centerZ = bounds.getMinZ() + (bounds.getMaxZ() - bounds.getMinZ()) / 2;

         for (int y = Math.max(2, bounds.getMinY()); y <= Math.min(world.getMaxHeight() - 2, bounds.getMaxY() + 2); y++) {
            Block below = world.getBlockAt(centerX, y - 1, centerZ);
            Block feet = world.getBlockAt(centerX, y, centerZ);
            Block head = world.getBlockAt(centerX, y + 1, centerZ);
            if (below.getType().isSolid() && feet.isPassable() && head.isPassable()) {
               return new Location(world, centerX + 0.5, y, centerZ + 0.5);
            }
         }

         return new Location(world, tower.getX() + 0.5, tower.getY() + 1.0, tower.getZ() + 0.5);
      } else {
         return null;
      }
   }

   public void ensureRegions() {
      for (TowerData tower : this.towers.values()) {
         this.plugin.getRegionManager().ensureRegion(tower);
      }
   }

   public void spawnHolograms() {
      this.plugin.getHologramManager().removeAll();

      for (TowerData tower : this.towers.values()) {
         this.plugin.getHologramManager().create(tower);
      }
   }

   public void clear() {
      this.towers.clear();
      this.counts.clear();
      this.progress.clear();
      this.generatedIds.clear();
      this.spatialIndex.clear();
   }

   private TowerData readTower(String id, ConfigurationSection section) {
      if (section == null) {
         return null;
      }

      ConfigurationSection boundsSection = section.getConfigurationSection("bounds");
      if (boundsSection == null) {
         return null;
      }

      String number = section.getString("number", id).trim();
      if (number.isEmpty()) {
         return null;
      }

      String worldName = section.getString("world-name", section.getString("world", ""));
      World loadedWorld = Bukkit.getWorld(worldName);
      String worldUid = section.getString("world-uid", loadedWorld == null ? "" : loadedWorld.getUID().toString());
      String schematic = section.getString("schematic", "");
      if (schematic.isEmpty() && !this.plugin.getConfigManager().getGenerationSettings().getTowers().isEmpty()) {
         schematic = this.plugin.getConfigManager().getGenerationSettings().getTowers().get(0).getSchematic();
      }

      Map<String, Location> chests = new LinkedHashMap<>();
      ConfigurationSection chestSection = section.getConfigurationSection("chests");
      if (chestSection != null) {
         for (String type : chestSection.getKeys(false)) {
            Location location = LocationUtil.deserialize(chestSection.getString(type, ""));
            if (location != null) {
               chests.put(type.toLowerCase(Locale.ROOT), location);
            }
         }
      }

      return new TowerData(
         id,
         number,
         section.getString("region-id", this.plugin.getRegionManager().getRegionId(number)),
         worldName,
         worldUid,
         section.getString("type", "tower").toLowerCase(Locale.ROOT),
         schematic,
         section.getInt("x"),
         section.getInt("y"),
         section.getInt("z"),
         Rotation.parse(section.getString("rotation", "NONE")),
         chests,
         new SchematicBounds(
            boundsSection.getInt("min-x"),
            boundsSection.getInt("min-y"),
            boundsSection.getInt("min-z"),
            boundsSection.getInt("max-x"),
            boundsSection.getInt("max-y"),
            boundsSection.getInt("max-z")
         )
      );
   }

   private void addToMemory(TowerData tower) {
      String number = tower.getNumber().toLowerCase(Locale.ROOT);
      this.towers.put(number, tower);
      this.generatedIds.add(tower.getId());
      this.nextNumber = Math.max(this.nextNumber, this.parseNumber(tower.getNumber()) + 1);
      String countKey = this.countKey(tower.getWorldUid(), tower.getType());
      this.counts.put(countKey, this.count(tower.getWorldUid(), tower.getType()) + 1);
      Map<Long, Set<String>> worldIndex = this.spatialIndex.get(tower.getWorldUid());
      if (worldIndex == null) {
         worldIndex = new HashMap<>();
         this.spatialIndex.put(tower.getWorldUid(), worldIndex);
      }

      for (int chunkX = tower.getBounds().getMinChunkX(); chunkX <= tower.getBounds().getMaxChunkX(); chunkX++) {
         for (int chunkZ = tower.getBounds().getMinChunkZ(); chunkZ <= tower.getBounds().getMaxChunkZ(); chunkZ++) {
            long key = this.chunkKey(chunkX, chunkZ);
            Set<String> values = worldIndex.get(key);
            if (values == null) {
               values = new HashSet<>();
               worldIndex.put(key, values);
            }

            values.add(number);
         }
      }
   }

   private void removeFromMemory(String number) {
      TowerData tower = this.towers.remove(number);
      if (tower != null) {
         this.generatedIds.remove(tower.getId());
         String key = this.countKey(tower.getWorldUid(), tower.getType());
         this.counts.put(key, Math.max(0, this.count(tower.getWorldUid(), tower.getType()) - 1));
         Map<Long, Set<String>> worldIndex = this.spatialIndex.get(tower.getWorldUid());
         if (worldIndex != null) {
            for (Set<String> values : worldIndex.values()) {
               values.remove(number);
            }
         }
      }
   }

   private void dropLoot(Location chestLocation, List<ItemStack> loot) {
      if (chestLocation != null && chestLocation.getWorld() != null) {
         Location drop = chestLocation.clone().add(0.5, 1.0, 0.5);

         for (ItemStack itemStack : loot) {
            if (itemStack != null && itemStack.getType() != Material.AIR) {
               Item item = chestLocation.getWorld().dropItem(drop, itemStack.clone());
               item.setVelocity(new Vector(0.0, 0.25, 0.0));
            }
         }

         chestLocation.getWorld().spawnParticle(Particle.FLAME, drop, 12, 0.35, 0.35, 0.35, 0.02);
         chestLocation.getWorld().playSound(drop, Sound.BLOCK_CHEST_OPEN, 1.0F, 1.0F);
      }
   }

   private int parseNumber(String value) {
      try {
         return Integer.parseInt(value);
      } catch (NumberFormatException exception) {
         return Integer.MAX_VALUE;
      }
   }

   private String countKey(String worldUid, String type) {
      return worldUid + "|" + type.toLowerCase(Locale.ROOT);
   }

   private String progressKey(String worldUid, String type) {
      return worldUid + "|" + type.toLowerCase(Locale.ROOT);
   }

   private long chunkKey(int x, int z) {
      return (long)x << 32 ^ z & 4294967295L;
   }

   private static final class WorldKey {
      private final World world;
      private final String uid;

      private WorldKey(World world, String uid) {
         this.world = world;
         this.uid = uid;
      }
   }
}