package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.manager.TowerData;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class TeleportSubCommand extends BaseCommand {
   public TeleportSubCommand(CloudTower plugin) {
      super(plugin);
   }

   @Override
   public String getName() {
      return "tp";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      if (!(sender instanceof Player)) {
         this.send(sender, "only-player");
         return true;
      } else if (args.length == 0) {
         this.send(sender, "help-tp");
         return true;
      } else {
         TowerData tower = this.plugin.getTowerManager().getTower(args[0]);
         Location location = this.plugin.getTowerManager().getTeleportLocation(tower);
         if (location == null) {
            this.send(sender, "tower-not-found");
            return true;
         } else {
            ((Player)sender).teleport(location);
            this.send(sender, "tower-teleport", "%number%", tower.getNumber());
            return true;
         }
      }
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      return args.length == 1 ? AdminCommand.filter(this.plugin.getTowerManager().getNumbers(), args[0]) : new ArrayList<>();
   }
}
