package cs.cloudstudio.command;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.util.MessageUtil;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.CommandSender;

public abstract class BaseCommand implements SubCommand {
   protected final CloudTower plugin;

   protected BaseCommand(CloudTower plugin) {
      this.plugin = plugin;
   }

   protected void send(CommandSender sender, String path, String... placeholders) {
      MessageUtil.send(sender, this.plugin, path, placeholders);
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      return Collections.emptyList();
   }
}
