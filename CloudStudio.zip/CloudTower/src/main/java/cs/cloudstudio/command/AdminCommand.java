package cs.cloudstudio.command;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.command.sub.EditSubCommand;
import cs.cloudstudio.command.sub.ListSubCommand;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import cs.cloudstudio.command.sub.TeleportSubCommand;
import cs.cloudstudio.util.MessageUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public final class AdminCommand implements CommandExecutor, TabCompleter {
   private final CloudTower plugin;
   private final Map<String, SubCommand> commands = new LinkedHashMap<>();

   public AdminCommand(CloudTower plugin) {
      this.plugin = plugin;
      this.register(new ListSubCommand(plugin));
      this.register(new TeleportSubCommand(plugin));
      this.register(new EditSubCommand(plugin));
      this.register(new ReloadSubCommand(plugin));
   }

   private void register(SubCommand command) {
      this.commands.put(command.getName().toLowerCase(Locale.ROOT), command);
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("cloudtower.admin")) {
         MessageUtil.send(sender, this.plugin, "no-perm");
         return true;
      } else if (args.length == 0) {
         this.sendUsage(sender);
         return true;
      } else {
         SubCommand subCommand = this.commands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            this.sendUsage(sender);
            return true;
         } else {
            return subCommand.execute(sender, Arrays.copyOfRange(args, 1, args.length));
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.hasPermission("cloudtower.admin")) {
         return new ArrayList<>();
      }

      if (args.length == 1) {
         return filter(this.commands.keySet(), args[0]);
      }

      SubCommand subCommand = this.commands.get(args[0].toLowerCase(Locale.ROOT));
      return subCommand == null ? new ArrayList<>() : subCommand.tab(sender, Arrays.copyOfRange(args, 1, args.length));
   }

   private void sendUsage(CommandSender sender) {
      MessageUtil.send(sender, this.plugin, "admin-usage");
      MessageUtil.send(sender, this.plugin, "help-list");
      MessageUtil.send(sender, this.plugin, "help-tp");
      MessageUtil.send(sender, this.plugin, "help-edit");
      MessageUtil.send(sender, this.plugin, "help-reload");
   }

   public static List<String> filter(Collection<String> values, String input) {
      String prefix = input == null ? "" : input.toLowerCase(Locale.ROOT);
      List<String> result = new ArrayList<>();

      for (String value : values) {
         if (value.toLowerCase(Locale.ROOT).startsWith(prefix)) {
            result.add(value);
         }
      }

      return result;
   }
}
