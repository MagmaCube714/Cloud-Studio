package cs.cloudstudio.command;

import java.util.List;
import org.bukkit.command.CommandSender;

public interface SubCommand {
   String getName();

   boolean execute(CommandSender var1, String[] var2);

   List<String> tab(CommandSender var1, String[] var2);
}
