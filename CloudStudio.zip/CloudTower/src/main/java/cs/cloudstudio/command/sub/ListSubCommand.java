package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.manager.TowerData;
import java.util.List;
import org.bukkit.command.CommandSender;

public final class ListSubCommand extends BaseCommand {
   public ListSubCommand(CloudTower plugin) {
      super(plugin);
   }

   @Override
   public String getName() {
      return "list";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      List<TowerData> towers = this.plugin.getTowerManager().getTowers();
      if (towers.isEmpty()) {
         this.send(sender, "tower-list-empty");
         return true;
      }

      this.send(sender, "tower-list-header", "%count%", String.valueOf(towers.size()));

      for (TowerData tower : towers) {
         this.send(
            sender,
            "tower-list-line",
            "%number%",
            tower.getNumber(),
            "%type%",
            tower.getType(),
            "%world%",
            tower.getWorldName(),
            "%x%",
            String.valueOf(tower.getX()),
            "%y%",
            String.valueOf(tower.getY()),
            "%z%",
            String.valueOf(tower.getZ())
         );
      }

      return true;
   }
}
