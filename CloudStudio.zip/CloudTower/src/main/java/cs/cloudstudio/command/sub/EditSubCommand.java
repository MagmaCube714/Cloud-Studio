package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.menu.LootEditMenu;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class EditSubCommand extends BaseCommand {
   public EditSubCommand(CloudTower plugin) {
      super(plugin);
   }

   @Override
   public String getName() {
      return "edit";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      if (!(sender instanceof Player)) {
         this.send(sender, "only-player");
         return true;
      } else if (args.length == 0) {
         this.send(sender, "edit-usage");
         return true;
      } else {
         String type = args[0].toLowerCase(Locale.ROOT);
         if (!this.plugin.getLootManager().isTypeAvailable(type)) {
            this.send(sender, "edit-type-not-found", "%type%", args[0]);
            return true;
         } else {
            ((Player)sender).openInventory(new LootEditMenu(this.plugin, type).getInventory());
            this.send(sender, "edit-opened", "%type%", type);
            return true;
         }
      }
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      return args.length == 1 ? AdminCommand.filter(this.plugin.getLootManager().getTypes(), args[0]) : new ArrayList<>();
   }
}
