package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudTower;
import cs.cloudstudio.command.BaseCommand;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand extends BaseCommand {
   public ReloadSubCommand(CloudTower plugin) {
      super(plugin);
   }

   @Override
   public String getName() {
      return "reload";
   }

   @Override
   public boolean execute(CommandSender sender, String[] args) {
      if (this.plugin.reloadPlugin()) {
         this.send(sender, "config-reloaded");
      } else {
         this.send(sender, "config-reload-failed");
      }

      return true;
   }
}
