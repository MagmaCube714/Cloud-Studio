package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.listener.LootEditMenuListener;
import cs.cloudstudio.listener.RegionProtectionListener;
import cs.cloudstudio.listener.TowerChestListener;
import cs.cloudstudio.listener.WorldGenerationListener;
import cs.cloudstudio.manager.CloudCardsHook;
import cs.cloudstudio.manager.GenerationManager;
import cs.cloudstudio.manager.HologramManager;
import cs.cloudstudio.manager.LootManager;
import cs.cloudstudio.manager.RegionManager;
import cs.cloudstudio.manager.SchematicManager;
import cs.cloudstudio.manager.TowerManager;
import cs.cloudstudio.util.ColorUtil;
import java.io.File;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudTower extends JavaPlugin {
   private ConfigManager configManager;
   private CloudCardsHook cloudCardsHook;
   private RegionManager regionManager;
   private HologramManager hologramManager;
   private LootManager lootManager;
   private SchematicManager schematicManager;
   private TowerManager towerManager;
   private GenerationManager generationManager;
   private File rewardsFile;
   private YamlConfiguration rewardsConfig;

   public void onEnable() {
      this.saveDefaultConfig();
      this.saveDefaultRewards();
      if (this.checkRequiredPlugin("FastAsyncWorldEdit") && this.checkRequiredPlugin("WorldGuard") && this.checkRequiredPlugin("CloudCards")) {
         this.cloudCardsHook = new CloudCardsHook(this);
         if (!this.cloudCardsHook.setup()) {
            Bukkit.getConsoleSender().sendMessage(ColorUtil.color("&fCloudTower &cCloudCards не подключён, плагин отключён"));
            Bukkit.getPluginManager().disablePlugin(this);
         } else {
            this.configManager = new ConfigManager(this);
            this.regionManager = new RegionManager(this);
            this.hologramManager = new HologramManager(this);
            this.lootManager = new LootManager(this);
            this.schematicManager = new SchematicManager(this);
            this.towerManager = new TowerManager(this);
            this.towerManager.load();
            this.towerManager.ensureRegions();
            this.towerManager.spawnHolograms();
            this.generationManager = new GenerationManager(this, this.configManager, this.towerManager, this.schematicManager);
            this.registerCommand();
            Bukkit.getPluginManager().registerEvents(new WorldGenerationListener(this), this);
            Bukkit.getPluginManager().registerEvents(new TowerChestListener(this), this);
            Bukkit.getPluginManager().registerEvents(new RegionProtectionListener(this), this);
            Bukkit.getPluginManager().registerEvents(new LootEditMenuListener(this), this);
            this.generationManager.scheduleLoadedWorld();
            Bukkit.getConsoleSender().sendMessage(ColorUtil.color("&fCloudTower &aуспешно загружен!"));
         }
      } else {
         Bukkit.getPluginManager().disablePlugin(this);
      }
   }

   public void onDisable() {
      if (this.generationManager != null) {
         this.generationManager.shutdown();
      }

      if (this.lootManager != null) {
         this.lootManager.flush();
      }

      if (this.hologramManager != null) {
         this.hologramManager.removeAll();
      }

      if (this.towerManager != null) {
         this.towerManager.save();
         this.towerManager.clear();
      }

      if (this.schematicManager != null) {
         this.schematicManager.shutdown();
      }

      Bukkit.getConsoleSender().sendMessage(ColorUtil.color("&fCloudTower &cуспешно выгружен!"));
   }

   public boolean reloadPlugin() {
      try {
         if (this.generationManager != null) {
            this.generationManager.shutdown();
         }

         if (this.lootManager != null) {
            this.lootManager.flush();
         }

         this.reloadConfig();
         this.reloadRewards();
         this.configManager.reload();
         this.schematicManager.clearCache();
         this.lootManager.reload();
         if (!this.cloudCardsHook.setup()) {
            this.getLogger().warning("[CloudTower] CloudCards не подключён после перезагрузки");
            return false;
         } else {
            this.hologramManager.reload();
            this.towerManager.load();
            this.towerManager.ensureRegions();
            this.towerManager.spawnHolograms();
            this.generationManager.resynchronizeLoadedWorld();
            return true;
         }
      } catch (Exception exception) {
         this.getLogger().warning("[CloudTower] Плагин не перезагружен: " + exception.getMessage());
         return false;
      }
   }

   private void registerCommand() {
      PluginCommand command = this.getCommand("cloudtower");
      if (command == null) {
         this.getLogger().warning("[CloudTower] Команда cloudtower не найдена в plugin.yml");
      } else {
         AdminCommand adminCommand = new AdminCommand(this);
         command.setExecutor(adminCommand);
         command.setTabCompleter(adminCommand);
      }
   }

   private boolean checkRequiredPlugin(String name) {
      Plugin dependency = Bukkit.getPluginManager().getPlugin(name);
      if (dependency != null && dependency.isEnabled()) {
         return true;
      }

      Bukkit.getConsoleSender().sendMessage(ColorUtil.color("&fCloudTower &c" + name + " не найден, плагин отключён"));
      return false;
   }

   private void saveDefaultRewards() {
      if (!this.getDataFolder().exists() && !this.getDataFolder().mkdirs()) {
         this.getLogger().warning("[CloudTower] Папка плагина не создана");
      }

      this.rewardsFile = new File(this.getDataFolder(), "rewards.yml");
      if (!this.rewardsFile.exists()) {
         this.saveResource("rewards.yml", false);
      }

      this.reloadRewards();
   }

   public void reloadRewards() {
      if (this.rewardsFile == null) {
         this.rewardsFile = new File(this.getDataFolder(), "rewards.yml");
      }

      this.rewardsConfig = YamlConfiguration.loadConfiguration(this.rewardsFile);
   }

   public File getRewardsFile() {
      return this.rewardsFile;
   }

   public YamlConfiguration getRewardsConfig() {
      return this.rewardsConfig;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public CloudCardsHook getCloudCardsHook() {
      return this.cloudCardsHook;
   }

   public RegionManager getRegionManager() {
      return this.regionManager;
   }

   public HologramManager getHologramManager() {
      return this.hologramManager;
   }

   public LootManager getLootManager() {
      return this.lootManager;
   }

   public SchematicManager getSchematicManager() {
      return this.schematicManager;
   }

   public TowerManager getTowerManager() {
      return this.towerManager;
   }

   public GenerationManager getGenerationManager() {
      return this.generationManager;
   }
}
