package cs.cloudstudio.listener;

import cs.cloudstudio.manager.TopManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerStatListener implements Listener {
   private final TopManager topManager;

   public PlayerStatListener(TopManager topManager) {
      this.topManager = topManager;
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      this.topManager.handlePlayerJoin(event.getPlayer());
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.topManager.handlePlayerQuit(event.getPlayer());
   }
}
