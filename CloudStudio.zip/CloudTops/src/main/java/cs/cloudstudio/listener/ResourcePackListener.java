package cs.cloudstudio.listener;

import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.messaging.PluginMessageListener;

public final class ResourcePackListener implements Listener, PluginMessageListener {
   private final Set<UUID> loadedPlayers = ConcurrentHashMap.newKeySet();

   @EventHandler(priority = EventPriority.MONITOR)
   public void onQuit(PlayerQuitEvent event) {
      this.removePlayer(event.getPlayer().getUniqueId());
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onKick(PlayerKickEvent event) {
      this.removePlayer(event.getPlayer().getUniqueId());
   }

   public void onPluginMessageReceived(String channel, Player player, byte[] message) {
      if ("forcepack:status".equals(channel)) {
         try {
            String data = new String(message, StandardCharsets.UTF_8);
            int first = data.indexOf(59);
            if (first < 0 || first + 1 >= data.length()) {
               return;
            }

            int second = data.indexOf(59, first + 1);
            String status = second < 0 ? data.substring(first + 1) : data.substring(first + 1, second);
            boolean loaded = status.equals("SUCCESSFULLY_LOADED");
            if (second >= 0 && second + 1 < data.length()) {
               loaded = loaded && Boolean.parseBoolean(data.substring(second + 1));
            }

            this.setPlayerResourcePackStatus(player.getUniqueId(), loaded);
         } catch (Exception var9) {
         }
      }
   }

   public boolean hasResourcePack(Player player) {
      return player != null && this.loadedPlayers.contains(player.getUniqueId());
   }

   public void setPlayerResourcePackStatus(UUID uuid, boolean loaded) {
      if (uuid != null) {
         if (loaded) {
            this.loadedPlayers.add(uuid);
         } else {
            this.loadedPlayers.remove(uuid);
         }
      }
   }

   public void removePlayer(UUID uuid) {
      if (uuid != null) {
         this.loadedPlayers.remove(uuid);
      }
   }

   public void clear() {
      this.loadedPlayers.clear();
   }
}
