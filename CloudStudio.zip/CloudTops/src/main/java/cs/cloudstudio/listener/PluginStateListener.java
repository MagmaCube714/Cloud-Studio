package cs.cloudstudio.listener;

import cs.cloudstudio.manager.TopManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.event.server.PluginEnableEvent;

public final class PluginStateListener implements Listener {
   private final TopManager topManager;

   public PluginStateListener(TopManager topManager) {
      this.topManager = topManager;
   }

   @EventHandler
   public void onPluginEnable(PluginEnableEvent event) {
      this.topManager.handlePluginStateChange(event.getPlugin().getName(), true);
   }

   @EventHandler
   public void onPluginDisable(PluginDisableEvent event) {
      this.topManager.handlePluginStateChange(event.getPlugin().getName(), false);
   }
}
