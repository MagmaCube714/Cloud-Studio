package cs.cloudstudio.manager;

import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.database.impl.TopsDatabase;
import cs.cloudstudio.manager.impl.BattlePassTop;
import cs.cloudstudio.manager.impl.ClanTop;
import cs.cloudstudio.manager.impl.EcoTop;
import cs.cloudstudio.manager.impl.EloTop;
import cs.cloudstudio.manager.impl.KillTop;
import cs.cloudstudio.manager.impl.OnlineTop;
import cs.cloudstudio.util.FormatUtil;
import cs.cloudstudio.util.StatUtil;
import java.io.File;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class TopManager {
   private static final int LIMIT = 10;
   private static final int NAME_CACHE_LIMIT = 100000;
   private static final int STATS_CACHE_LIMIT = 75000;
   private static final int STATS_FILE_CACHE_LIMIT = 100000;
   private static final int PLAYER_INDEX_LIMIT = 100000;
   private static final int BALANCE_CACHE_LIMIT = 100000;
   private static final Pattern PLAYER_KILLS_PATTERN = Pattern.compile("\"minecraft:player_kills\"\\s*:\\s*(\\d+)");
   private static final Pattern PLAY_ONE_MINUTE_PATTERN = Pattern.compile("\"minecraft:play_one_minute\"\\s*:\\s*(\\d+)");
   private static final Pattern PLAY_TIME_PATTERN = Pattern.compile("\"minecraft:play_time\"\\s*:\\s*(\\d+)");
   private static final long STATS_DIR_CACHE_MILLIS = 300000L;
   private static final long ONLINE_STATS_CACHE_MILLIS = 30000L;
   private static final long OFFLINE_BALANCE_CACHE_MILLIS = 300000L;
   private static final long ESSENTIALS_USERDATA_LIST_CACHE_MILLIS = 600000L;
   private static final int ESSENTIALS_ECO_BATCH_SIZE = 700;
   private static final int ESSENTIALS_ECO_WARMUP_BATCH_SIZE = 3500;
   private static final int ESSENTIALS_API_TOP_LIMIT = 50;
   private static final int PLACEHOLDER_VAULT_BATCH_SIZE = 100;
   private static final int PLACEHOLDER_VAULT_FORCED_BATCH_SIZE = 150;
   private static final int PLACEHOLDER_VAULT_SYNC_BUDGET = 25;
   private static final long OFFLINE_PLACEHOLDER_STATS_CACHE_MILLIS = 43200000L;
   private static final long API_WARMUP_PERIOD_TICKS = 20L;
   private static final int API_WARMUP_ATTEMPTS = 120;
   private final JavaPlugin plugin;
   private final TopsDatabase database;
   private final ConfigManager config;
   private final AtomicBoolean updating = new AtomicBoolean(false);
   private final AtomicBoolean pendingUpdate = new AtomicBoolean(false);
   private final AtomicBoolean apiUpdating = new AtomicBoolean(false);
   private final List<ITopsManager> dbTops = new ArrayList<>();
   private final List<ITopsManager> apiTops = new CopyOnWriteArrayList<>();
   private final FormatUtil formatUtil = new FormatUtil();
   private final Map<String, Map<Integer, String>> cachedTops = new ConcurrentHashMap<>();
   private final Map<String, Map<Integer, String>> cachedPlainTops = new ConcurrentHashMap<>();
   private final Map<String, String> nameCache = new ConcurrentHashMap<>();
   private final Map<UUID, TopManager.CachedStats> statsCache = new ConcurrentHashMap<>();
   private final Map<UUID, File> statsFileCache = new ConcurrentHashMap<>();
   private final Map<UUID, TopManager.CachedOnlineStats> onlineStatsCache = new ConcurrentHashMap<>();
   private final Map<UUID, TopManager.CachedOnlineStats> offlinePlaceholderStatsCache = new ConcurrentHashMap<>();
   private final Map<UUID, TopManager.CachedBalance> offlineBalanceCache = new ConcurrentHashMap<>();
   private final Map<UUID, TopManager.CachedEssentialsBalance> essentialsBalanceFileCache = new ConcurrentHashMap<>();
   private final ExecutorService worker = Executors.newSingleThreadExecutor(runnable -> {
      Thread thread = new Thread(runnable, "CloudTops-Worker");
      thread.setDaemon(true);
      return thread;
   });
   private volatile Economy economy;
   private volatile File worldContainer;
   private volatile List<File> statsDirectories = Collections.emptyList();
   private volatile long statsDirectoriesAt;
   private volatile Map<UUID, File> cachedStatsFiles = Collections.emptyMap();
   private volatile List<UUID> cachedStatsUuidIndex = Collections.emptyList();
   private volatile long cachedStatsFilesAt;
   private volatile List<UUID> cachedPlayerIndex = Collections.emptyList();
   private volatile long cachedPlayerIndexAt;
   private volatile File essentialsUserdataDirectory;
   private volatile List<File> cachedEssentialsUserdataFiles = Collections.emptyList();
   private volatile long cachedEssentialsUserdataFilesAt;
   private volatile long lastApiUpdateAt;
   private volatile boolean closed;
   private BukkitTask updateTask;
   private BukkitTask apiWarmupTask;
   private int apiWarmupAttempt;
   private int statsScanCursor;
   private int ecoScanCursor;
   private int essentialsEcoScanCursor;

   public TopManager(JavaPlugin plugin, TopsDatabase database, ConfigManager config) {
      this.plugin = plugin;
      this.database = database;
      this.config = config;
      this.economy = this.setupEconomy();
   }

   public void initialize() {
      this.closed = false;
      this.loadKnownNames();
      this.initTopsList();
      this.refreshEloTopWarmup();
      this.startTasks();
      Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
         this.updateApiTops(true);
         this.startApiWarmup();
         this.startUpdate(false);
      }, 1L);
   }

   public void reload() {
      this.cancelTasks();
      this.updating.set(false);
      this.pendingUpdate.set(false);
      this.apiUpdating.set(false);
      this.lastApiUpdateAt = 0L;
      this.cachedTops.clear();
      this.cachedPlainTops.clear();
      this.nameCache.clear();
      this.statsCache.clear();
      this.statsFileCache.clear();
      this.onlineStatsCache.clear();
      this.offlinePlaceholderStatsCache.clear();
      this.offlineBalanceCache.clear();
      this.essentialsBalanceFileCache.clear();
      this.statsDirectories = Collections.emptyList();
      this.statsDirectoriesAt = 0L;
      this.cachedStatsFiles = Collections.emptyMap();
      this.cachedStatsUuidIndex = Collections.emptyList();
      this.cachedStatsFilesAt = 0L;
      this.cachedPlayerIndex = Collections.emptyList();
      this.cachedEssentialsUserdataFiles = Collections.emptyList();
      this.essentialsUserdataDirectory = null;
      this.cachedPlayerIndexAt = 0L;
      this.essentialsUserdataDirectory = null;
      this.cachedEssentialsUserdataFiles = Collections.emptyList();
      this.cachedEssentialsUserdataFilesAt = 0L;
      this.statsScanCursor = 0;
      this.ecoScanCursor = 0;
      this.essentialsEcoScanCursor = 0;
      this.config.reloadConfig();
      this.economy = this.setupEconomy();
      this.closed = false;
      this.loadKnownNames();
      this.initTopsList();
      this.startTasks();
      this.forceUpdateNow();
      this.startApiWarmup();
   }

   public void shutdown() {
      this.closed = true;
      this.cancelTasks();
      this.updating.set(false);
      this.pendingUpdate.set(false);
      this.apiUpdating.set(false);
      this.cachedTops.clear();
      this.cachedPlainTops.clear();
      this.nameCache.clear();
      this.statsCache.clear();
      this.statsFileCache.clear();
      this.onlineStatsCache.clear();
      this.offlinePlaceholderStatsCache.clear();
      this.offlineBalanceCache.clear();
      this.essentialsBalanceFileCache.clear();
      this.cachedStatsFiles = Collections.emptyMap();
      this.cachedStatsUuidIndex = Collections.emptyList();
      this.cachedPlayerIndex = Collections.emptyList();
      this.cachedEssentialsUserdataFiles = Collections.emptyList();
      this.essentialsUserdataDirectory = null;
      this.worker.shutdownNow();
   }

   public void performFullScan() {
      this.forceUpdateNow();
   }

   public void forceUpdateNow() {
      this.cachedPlayerIndexAt = 0L;
      this.cachedStatsFilesAt = 0L;
      this.updateApiTops(true);
      this.startUpdate(true);
   }

   public void updateAll() {
      this.startUpdate(false);
   }

   public void handlePlayerJoin(Player player) {
      if (player != null) {
         UUID uuid = this.safeUuid(player);
         if (uuid != null) {
            this.cacheName(uuid, this.safeLiveName(player, uuid));
            this.rememberPlayerInIndex(uuid);
         }

         UUID delayedUuid = uuid;
         Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            Player delayedPlayer = delayedUuid == null ? null : Bukkit.getPlayer(delayedUuid);
            if (delayedPlayer != null && delayedPlayer.isOnline()) {
               this.queueOnlinePlayer(delayedPlayer);
            }

            this.requestEloSourceRefresh();
            this.refreshEloTopWarmup();
            if (!this.hasEloTopData()) {
               this.startApiWarmup();
            }
         }, 40L);
      }
   }

   public void handlePlayerQuit(Player player) {
      if (player != null) {
         this.queueOnlinePlayer(player);
      }
   }

   private void startTasks() {
      long intervalTicks = Math.max(200L, this.config.getUpdateInterval() * 20L);
      this.updateTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::updateAll, intervalTicks, intervalTicks);
   }

   private void cancelTasks() {
      if (this.updateTask != null) {
         this.updateTask.cancel();
         this.updateTask = null;
      }

      this.cancelApiWarmup();
   }

   private void startApiWarmup() {
      this.cancelApiWarmup();
      if (this.hasPlugin("CloudElo")) {
         this.apiWarmupAttempt = 0;
         this.apiWarmupTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            if (!this.closed && this.plugin.isEnabled() && this.hasPlugin("CloudElo")) {
               this.refreshApiIntegrations();
               if (this.apiWarmupAttempt == 0 || this.apiWarmupAttempt % 5 == 0) {
                  this.requestEloSourceRefresh();
               }

               this.refreshEloTopWarmup();
               if (this.hasEloTopData()) {
                  this.cancelApiWarmup();
               } else {
                  this.apiWarmupAttempt++;
                  if (this.apiWarmupAttempt >= 120) {
                     String error = this.eloTopLastError();
                     if (error != null && !error.isEmpty()) {
                        this.plugin.getLogger().warning("[CloudTops] Elo-топ остался пустым после стартового прогрева: " + error);
                     }

                     this.cancelApiWarmup();
                  }
               }
            } else {
               this.cancelApiWarmup();
            }
         }, 1L, 20L);
      }
   }

   private void cancelApiWarmup() {
      if (this.apiWarmupTask != null) {
         this.apiWarmupTask.cancel();
         this.apiWarmupTask = null;
      }
   }

   private void loadKnownNames() {
      if (this.database.isConnected()) {
         CompletableFuture.runAsync(() -> {
            try {
               Map<String, String> names = this.database.getKnownNames(100000);
               if (!names.isEmpty() && !this.closed) {
                  this.nameCache.putAll(names);
                  this.trimCache(this.nameCache, 100000);
               }
            } catch (Throwable var2) {
            }
         }, this.worker);
      }
   }

   private void initTopsList() {
      this.dbTops.clear();
      this.apiTops.clear();
      FormatUtil formatUtil = new FormatUtil();
      if (this.economy != null) {
         this.dbTops.add(new EcoTop(formatUtil));
      }

      this.dbTops.add(new OnlineTop(formatUtil));
      this.dbTops.add(new KillTop(formatUtil));
      this.refreshApiIntegrations();
   }

   public void handlePluginStateChange(String pluginName, boolean enabled) {
      if (!this.closed && this.isApiIntegrationPlugin(pluginName)) {
         this.lastApiUpdateAt = 0L;
         if (!enabled) {
            this.removeApiTop(this.integrationType(pluginName));
            if ("CloudElo".equalsIgnoreCase(pluginName)) {
               this.cancelApiWarmup();
            }
         } else {
            this.refreshApiIntegrations();
            this.updateApiTops(true);
            if ("CloudElo".equalsIgnoreCase(pluginName)) {
               this.startApiWarmup();
            }
         }
      }
   }

   private boolean refreshApiIntegrations() {
      boolean changed = false;
      changed |= this.syncApiTop("battlepass", this.hasPlugin("CloudBattlePass"), () -> new BattlePassTop(this.formatUtil));
      changed |= this.syncApiTop("clan", this.hasPlugin("CloudClans"), () -> new ClanTop(this.formatUtil));
      return changed | this.syncApiTop("elo", this.hasPlugin("CloudElo"), () -> new EloTop(this.formatUtil, this.getEnabledPlugin("CloudElo")));
   }

   private boolean syncApiTop(String type, boolean available, Supplier<ITopsManager> factory) {
      ITopsManager existing = null;

      for (ITopsManager top : this.apiTops) {
         if (top != null && type.equalsIgnoreCase(top.getType())) {
            existing = top;
            break;
         }
      }

      if (available) {
         if (existing == null && factory != null) {
            this.apiTops.add(factory.get());
            return true;
         } else {
            return false;
         }
      } else if (existing != null) {
         this.apiTops.remove(existing);
         this.cachedTops.remove(type);
         this.cachedPlainTops.remove(type);
         return true;
      } else {
         return false;
      }
   }

   private void removeApiTop(String type) {
      if (type != null && !type.isEmpty()) {
         this.syncApiTop(type, false, null);
      }
   }

   private String integrationType(String pluginName) {
      if ("CloudBattlePass".equalsIgnoreCase(pluginName)) {
         return "battlepass";
      } else if ("CloudClans".equalsIgnoreCase(pluginName)) {
         return "clan";
      } else {
         return "CloudElo".equalsIgnoreCase(pluginName) ? "elo" : "";
      }
   }

   private boolean isApiIntegrationPlugin(String pluginName) {
      return !this.integrationType(pluginName).isEmpty();
   }

   private void refreshEloTopWarmup() {
      for (ITopsManager top : this.apiTops) {
         if (top instanceof EloTop) {
            try {
               top.updateFormatted();
               if (this.apiTops.contains(top)) {
                  this.cacheFormattedTop(top);
               }
            } catch (Throwable throwable) {
               this.plugin.getLogger().warning("[CloudTops] Elo-топ не обновлён: " + rootMessage(throwable));
            }

            return;
         }
      }
   }

   private void requestEloSourceRefresh() {
      for (ITopsManager top : this.apiTops) {
         if (top instanceof EloTop) {
            ((EloTop)top).requestSourceRefresh();
            return;
         }
      }
   }

   private boolean hasEloTopData() {
      for (ITopsManager top : this.apiTops) {
         if (top instanceof EloTop && ((EloTop)top).hasData()) {
            return true;
         }
      }

      return false;
   }

   private String eloTopLastError() {
      for (ITopsManager top : this.apiTops) {
         if (top instanceof EloTop) {
            return ((EloTop)top).getLastError();
         }
      }

      return "CloudElo integration not registered";
   }

   private static String rootMessage(Throwable throwable) {
      Throwable current = throwable;

      while (current.getCause() != null && current.getCause() != current) {
         current = current.getCause();
      }

      String message = current.getMessage();
      return current.getClass().getSimpleName() + (message != null && !message.isEmpty() ? ": " + message : "");
   }

   private Plugin getEnabledPlugin(String name) {
      if (name != null && !name.isEmpty()) {
         Plugin plugin = Bukkit.getPluginManager().getPlugin(name);
         return plugin != null && plugin.isEnabled() ? plugin : null;
      } else {
         return null;
      }
   }

   private boolean hasPlugin(String... names) {
      for (String name : names) {
         if (this.getEnabledPlugin(name) != null) {
            return true;
         }
      }

      return false;
   }

   private Economy setupEconomy() {
      if (this.plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
         return null;
      }

      RegisteredServiceProvider<Economy> provider = this.plugin.getServer().getServicesManager().getRegistration(Economy.class);
      return provider != null ? (Economy)provider.getProvider() : null;
   }

   private void startUpdate(boolean forced) {
      if (!this.closed) {
         if (!this.updating.compareAndSet(false, true)) {
            if (forced) {
               this.pendingUpdate.set(true);
            }
         } else {
            Bukkit.getScheduler()
               .runTask(
                  this.plugin,
                  () -> {
                     try {
                        Economy currentEconomy = this.refreshEconomy();
                        long now = System.currentTimeMillis();
                        List<TopManager.OnlineSnapshot> online = this.collectOnlineSnapshots(currentEconomy, now, forced);
                        CompletableFuture.runAsync(() -> this.collectPersistAndFormat(online, currentEconomy, now, forced), this.worker)
                           .whenComplete((ignored, throwablex) -> {
                              if (throwablex != null) {
                                 this.plugin.getLogger().warning("[CloudTops] Обновление топов не выполнено: " + throwablex.getMessage());
                              }

                              this.updateApiTops(false).whenComplete((apiIgnored, apiThrowable) -> {
                                 if (apiThrowable != null) {
                                    this.plugin.getLogger().warning("[CloudTops] Обновление API-топов не выполнено: " + apiThrowable.getMessage());
                                 }

                                 this.finishUpdate();
                              });
                           });
                     } catch (Throwable throwable) {
                        this.plugin.getLogger().warning("[CloudTops] Сбор онлайн-статистики не выполнен: " + throwable.getMessage());
                        this.finishUpdate();
                     }
                  }
               );
         }
      }
   }

   private List<TopManager.OnlineSnapshot> collectOnlineSnapshots(Economy currentEconomy, long now, boolean forced) {
      List<TopManager.OnlineSnapshot> snapshots = new ArrayList<>(Math.max(1, Bukkit.getOnlinePlayers().size()));
      Set<UUID> onlineUuids = new HashSet<>();

      for (Player player : Bukkit.getOnlinePlayers()) {
         TopManager.OnlineSnapshot snapshot = this.readOnlineSnapshot(player, currentEconomy, now, forced);
         if (snapshot != null) {
            onlineUuids.add(snapshot.uuid);
            snapshots.add(snapshot);
         }
      }

      this.onlineStatsCache.keySet().retainAll(onlineUuids);
      return snapshots;
   }

   private TopManager.OnlineSnapshot readOnlineSnapshot(Player player, Economy currentEconomy, long now, boolean forced) {
      UUID uuid = this.safeUuid(player);
      if (uuid == null) {
         return null;
      }

      String name = this.safeLiveName(player, uuid);
      if (name.isEmpty()) {
         return null;
      }

      double balance = this.readBalance(player, currentEconomy);
      this.offlineBalanceCache.put(uuid, new TopManager.CachedBalance(balance, now));
      StatUtil.GameStats stats = this.readOnlineStats(uuid, player, now, forced);
      int kills = stats.playerKills >= 0L ? (int)Math.min(2147483647L, stats.playerKills) : 0;
      long playtime = stats.playtimeTicks >= 0L ? stats.playtimeTicks : 0L;
      this.cacheName(uuid, name);
      return new TopManager.OnlineSnapshot(uuid, name, balance, kills, playtime, now);
   }

   private void queueOnlinePlayer(Player player) {
      if (!this.closed && player != null) {
         long now = System.currentTimeMillis();
         TopManager.OnlineSnapshot snapshot = this.readOnlineSnapshot(player, this.refreshEconomy(), now, true);
         if (snapshot != null) {
            Map<String, TopsDatabase.PlayerData> data = new LinkedHashMap<>();
            data.put(snapshot.uuid.toString(), snapshot.toPlayerData());
            this.database.queue(data);
         }
      }
   }

   private void collectPersistAndFormat(List<TopManager.OnlineSnapshot> online, Economy currentEconomy, long now, boolean forced) {
      if (!this.closed) {
         Map<String, TopsDatabase.PlayerData> changed = new LinkedHashMap<>();
         Set<UUID> onlineUuids = new HashSet<>();
         if (online != null) {
            for (TopManager.OnlineSnapshot snapshot : online) {
               if (snapshot != null && snapshot.uuid != null) {
                  onlineUuids.add(snapshot.uuid);
                  this.mergePlayerData(changed, snapshot.uuid.toString(), snapshot.toPlayerData());
               }
            }
         }

         Map<UUID, File> statsFiles = this.collectStatsFiles(forced);

         for (TopManager.OnlineSnapshot snapshot : this.collectOfflinePlaceholderVaultSnapshots(onlineUuids, currentEconomy, now, forced, statsFiles)) {
            if (snapshot != null && snapshot.uuid != null) {
               this.mergePlayerData(changed, snapshot.uuid.toString(), snapshot.toPlayerData());
            }
         }

         this.collectOfflineEcoSnapshots(changed, onlineUuids, now, forced);
         this.trimCache(this.nameCache, 100000);
         this.trimCache(this.statsCache, 75000);
         this.trimCache(this.statsFileCache, 100000);
         this.trimCache(this.onlineStatsCache, 75000);
         this.trimCache(this.offlinePlaceholderStatsCache, 75000);
         this.trimCache(this.offlineBalanceCache, 100000);
         this.trimCache(this.essentialsBalanceFileCache, 100000);
         if (!changed.isEmpty()) {
            this.database.queue(changed);
            if (forced) {
               this.database.flush();
            }
         }

         TopManager.TopDataSnapshot tops = this.buildTopDataSnapshot(changed);
         this.formatDatabaseTops(tops);
      }
   }

   private List<TopManager.OnlineSnapshot> collectOfflinePlaceholderVaultSnapshots(
      Set<UUID> onlineUuids, final Economy currentEconomy, final long now, final boolean forced, Map<UUID, File> statsFiles
   ) {
      List<UUID> index = this.getPlayerIndex(statsFiles == null ? Collections.emptyMap() : statsFiles, forced, now);
      if (index.isEmpty()) {
         return Collections.emptyList();
      }

      int limit = forced ? 150 : 100;
      final List<UUID> batch = this.selectEcoBatch(index, onlineUuids, limit);
      if (batch.isEmpty()) {
         return Collections.emptyList();
      }

      try {
         final Map<UUID, File> effectiveStatsFiles = statsFiles == null ? Collections.emptyMap() : statsFiles;
         final Map<UUID, StatUtil.GameStats> fileStats = this.prefetchOfflineFiles(batch, effectiveStatsFiles, now, forced);
         final CompletableFuture<List<TopManager.OnlineSnapshot>> future = new CompletableFuture<>();
         (new BukkitRunnable() {
               private final List<TopManager.OnlineSnapshot> result = new ArrayList<>(batch.size());
               private int cursor;

               public void run() {
                  if (!TopManager.this.closed && TopManager.this.plugin.isEnabled()) {
                     try {
                        int end = Math.min(batch.size(), this.cursor + 25);
                        this.result
                           .addAll(
                              TopManager.this.readOfflinePlaceholderVaultSnapshots(
                                 batch.subList(this.cursor, end), currentEconomy, now, forced, effectiveStatsFiles, fileStats
                              )
                           );
                        this.cursor = end;
                        if (this.cursor >= batch.size()) {
                           this.cancel();
                           future.complete(this.result);
                        }
                     } catch (Throwable throwable) {
                        this.cancel();
                        future.completeExceptionally(throwable);
                     }
                  } else {
                     this.cancel();
                     future.complete(this.result);
                  }
               }
            })
            .runTaskTimer(this.plugin, 0L, 1L);
         List<TopManager.OnlineSnapshot> snapshots = future.get(20L, TimeUnit.SECONDS);
         return snapshots == null ? Collections.emptyList() : snapshots;
      } catch (Throwable throwable) {
         this.plugin.getLogger().warning("[CloudTops] Сбор оффлайн-статистики не выполнен: " + throwable.getMessage());
         return Collections.emptyList();
      }
   }

   private Map<UUID, StatUtil.GameStats> prefetchOfflineFiles(List<UUID> batch, Map<UUID, File> statsFiles, long now, boolean forced) {
      Map<UUID, StatUtil.GameStats> result = new HashMap<>(batch.size() * 2);

      for (UUID uuid : batch) {
         if (uuid != null) {
            if (this.cachedName(uuid).isEmpty()) {
               this.readEssentialsUserdataName(uuid);
            }

            TopManager.CachedOnlineStats cached = this.offlinePlaceholderStatsCache.get(uuid);
            if (forced || cached == null || now - cached.readAt >= 43200000L) {
               StatUtil.GameStats stats = this.readStatsFile(uuid, statsFiles.get(uuid));
               if (stats.playerKills >= 0L && stats.playtimeTicks >= 0L) {
                  result.put(uuid, stats);
               }
            }
         }
      }

      return result;
   }

   private List<TopManager.OnlineSnapshot> readOfflinePlaceholderVaultSnapshots(
      List<UUID> batch, Economy currentEconomy, long now, boolean forced, Map<UUID, File> statsFiles, Map<UUID, StatUtil.GameStats> fileStats
   ) {
      if (batch != null && !batch.isEmpty()) {
         List<TopManager.OnlineSnapshot> snapshots = new ArrayList<>(batch.size());

         for (UUID uuid : batch) {
            if (uuid != null) {
               OfflinePlayer player = this.safeOfflinePlayer(uuid);
               String name = this.cachedName(uuid);
               if (name.isEmpty()) {
                  name = this.safeName(player, uuid);
               }

               if (name.isEmpty()) {
                  name = this.readEssentialsUserdataName(uuid);
               }

               if (!name.isEmpty()) {
                  double balance = this.readKnownOfflineBalance(uuid, currentEconomy == null || this.isEssentialsUserdataAvailable());
                  if (balance < 0.0 && currentEconomy != null && !this.isEssentialsUserdataAvailable()) {
                     balance = this.readCachedOfflineBalance(uuid, player, currentEconomy, now);
                  }

                  StatUtil.GameStats stats = fileStats == null ? null : fileStats.get(uuid);
                  if (stats != null) {
                     this.offlinePlaceholderStatsCache.put(uuid, new TopManager.CachedOnlineStats(stats, now));
                  } else {
                     File statsFile = statsFiles == null ? null : statsFiles.get(uuid);
                     stats = this.readOfflinePlaceholderStats(uuid, player, statsFile, now, forced);
                  }
                  int kills = stats.playerKills >= 0L ? (int)Math.min(2147483647L, stats.playerKills) : 0;
                  long playtime = stats.playtimeTicks >= 0L ? stats.playtimeTicks : 0L;
                  this.cacheName(uuid, name);
                  snapshots.add(new TopManager.OnlineSnapshot(uuid, name, balance, kills, playtime, now));
               }
            }
         }

         return snapshots;
      } else {
         return Collections.emptyList();
      }
   }

   private StatUtil.GameStats readOfflinePlaceholderStats(UUID uuid, OfflinePlayer player, File statsFile, long now, boolean forced) {
      if (uuid == null) {
         return new StatUtil.GameStats(-1L, -1L);
      }

      TopManager.CachedOnlineStats cached = this.offlinePlaceholderStatsCache.get(uuid);
      if (!forced && cached != null && now - cached.readAt < 43200000L) {
         return cached.stats;
      }

      StatUtil.GameStats placeholderStats = player == null ? new StatUtil.GameStats(-1L, -1L) : StatUtil.read(player);
      if (placeholderStats == null) {
         placeholderStats = new StatUtil.GameStats(-1L, -1L);
      }

      StatUtil.GameStats fileStats = null;
      if (placeholderStats.playerKills < 0L || placeholderStats.playtimeTicks < 0L) {
         fileStats = this.readStatsFile(uuid, statsFile);
      }

      long kills = placeholderStats.playerKills >= 0L ? placeholderStats.playerKills : (fileStats == null ? -1L : fileStats.playerKills);
      long playtime = placeholderStats.playtimeTicks >= 0L ? placeholderStats.playtimeTicks : (fileStats == null ? -1L : fileStats.playtimeTicks);
      StatUtil.GameStats stats = new StatUtil.GameStats(kills, playtime);
      if (stats.playerKills >= 0L || stats.playtimeTicks >= 0L) {
         this.offlinePlaceholderStatsCache.put(uuid, new TopManager.CachedOnlineStats(stats, now));
      }

      return stats;
   }

   private void collectOfflineEcoSnapshots(Map<String, TopsDatabase.PlayerData> changed, Set<UUID> onlineUuids, long now, boolean forced) {
      if (changed != null) {
         if (this.collectEssentialsApiEcoTop(changed, now) <= 0) {
            this.collectEssentialsUserdataEcoBatch(changed, onlineUuids, now, forced);
         }
      }
   }

   private double readKnownOfflineBalance(UUID uuid, boolean skipStaleCache) {
      if (uuid == null) {
         return -1.0;
      }

      TopManager.CachedEssentialsBalance essentials = this.essentialsBalanceFileCache.get(uuid);
      if (essentials != null) {
         return essentials.balance;
      }

      if (skipStaleCache) {
         return -1.0;
      }

      TopManager.CachedBalance cached = this.offlineBalanceCache.get(uuid);
      return cached == null ? -1.0 : cached.balance;
   }

   private void collectStatsBatch(Map<String, TopsDatabase.PlayerData> changed, Map<UUID, File> statsFiles, Set<UUID> onlineUuids, long now) {
      int limit = this.config.getStatsScanBatchSize();
      if (limit > 0 && statsFiles != null && !statsFiles.isEmpty()) {
         for (UUID uuid : this.selectStatsBatch(statsFiles, onlineUuids, limit)) {
            File statsFile = statsFiles.get(uuid);
            TopsDatabase.PlayerData data = this.readOfflinePlayer(uuid, this.cachedName(uuid), statsFile, null, now, true, false);
            if (data != null) {
               this.mergePlayerData(changed, uuid.toString(), data);
            }
         }
      }
   }

   private void collectEcoBatch(
      Map<String, TopsDatabase.PlayerData> changed, Map<UUID, File> statsFiles, Set<UUID> onlineUuids, Economy currentEconomy, long now, boolean forced
   ) {
      if (currentEconomy != null) {
         int apiMerged = this.collectEssentialsApiEcoTop(changed, now);
         if (apiMerged <= 0) {
            int fileMerged = this.collectEssentialsUserdataEcoBatch(changed, onlineUuids, now, forced);
            if (fileMerged <= 0 && !this.isEssentialsUserdataAvailable()) {
               int limit = this.config.getEcoScanBatchSize();
               if (limit > 0) {
                  List<UUID> index = this.getPlayerIndex(statsFiles, forced, now);
                  if (!index.isEmpty()) {
                     for (UUID uuid : this.selectEcoBatch(index, onlineUuids, limit)) {
                        TopsDatabase.PlayerData data = this.readOfflinePlayer(
                           uuid, this.cachedName(uuid), statsFiles == null ? null : statsFiles.get(uuid), currentEconomy, now, false, true
                        );
                        if (data != null && data.balance >= 0.0) {
                           this.mergePlayerData(changed, uuid.toString(), data);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private int collectEssentialsApiEcoTop(Map<String, TopsDatabase.PlayerData> changed, long now) {
      Map<Object, Object> balances = this.readEssentialsBalanceMap();
      if (balances != null && !balances.isEmpty()) {
         List<TopManager.BalanceCandidate> candidates = new ArrayList<>(Math.min(balances.size(), 100000));

         for (Entry<Object, Object> entry : balances.entrySet()) {
            double balance = this.parseBalanceValue(entry.getValue());
            if (!(balance < 0.0)) {
               TopManager.BalanceIdentity identity = this.parseBalanceIdentity(entry.getKey());
               if (identity != null && (identity.uuid != null || identity.name != null && !identity.name.isEmpty())) {
                  candidates.add(new TopManager.BalanceCandidate(identity.uuid, identity.name, balance));
               }
            }
         }

         if (candidates.isEmpty()) {
            return 0;
         }

         candidates.sort((first, second) -> {
            int valueCompare = Double.compare(second.balance, first.balance);
            return valueCompare != 0 ? valueCompare : first.sortName().compareToIgnoreCase(second.sortName());
         });
         int merged = 0;

         for (TopManager.BalanceCandidate candidate : candidates) {
            if (merged >= 50) {
               break;
            }

            String name = this.resolveBalanceName(candidate.uuid, candidate.name);
            if (!name.isEmpty()) {
               String key = candidate.uuid != null ? candidate.uuid.toString() : "name:" + name.toLowerCase(Locale.ROOT);
               UUID uuid = candidate.uuid;
               if (uuid != null) {
                  this.cacheName(uuid, name);
                  this.offlineBalanceCache.put(uuid, new TopManager.CachedBalance(candidate.balance, now));
               }

               this.mergePlayerData(changed, key, new TopsDatabase.PlayerData(name, candidate.balance, -1, -1L, now));
               merged++;
            }
         }

         return merged;
      } else {
         return 0;
      }
   }

   private Map<Object, Object> readEssentialsBalanceMap() {
      try {
         Class<?> economyClass = Class.forName("com.earth2me.essentials.api.Economy");

         for (Method method : economyClass.getMethods()) {
            if (Modifier.isStatic(method.getModifiers()) && method.getParameterTypes().length == 0 && Map.class.isAssignableFrom(method.getReturnType())) {
               String name = method.getName().toLowerCase(Locale.ROOT);
               if (name.contains("balance") || name.contains("money") || name.contains("account")) {
                  Object raw = method.invoke(null);
                  if (raw instanceof Map && !((Map)raw).isEmpty()) {
                     return (Map<Object, Object>)raw;
                  }
               }
            }
         }
      } catch (Throwable var8) {
      }

      return Collections.emptyMap();
   }

   private int collectEssentialsUserdataEcoBatch(Map<String, TopsDatabase.PlayerData> changed, Set<UUID> onlineUuids, long now, boolean forced) {
      List<File> files = this.collectEssentialsUserdataFiles(forced);
      if (files.isEmpty()) {
         return 0;
      }

      int limit = !forced && this.hasEnoughCachedEcoCandidates() ? 700 : 3500;
      if (limit <= 0) {
         return 0;
      }

      List<File> changedFiles = new ArrayList<>();

      for (File file : files) {
         if (file != null && file.isFile()) {
            UUID uuid = this.parseStatsUuid(file.getName());
            if (uuid != null && (onlineUuids == null || !onlineUuids.contains(uuid))) {
               long modified = file.lastModified();
               long length = file.length();
               TopManager.CachedEssentialsBalance cached = this.essentialsBalanceFileCache.get(uuid);
               if (forced || cached == null || !cached.same(file, modified, length)) {
                  changedFiles.add(file);
                  if (changedFiles.size() >= limit) {
                     break;
                  }
               }
            }
         }
      }

      if (changedFiles.isEmpty()) {
         changedFiles = this.selectEssentialsUserdataBatch(files, onlineUuids, Math.min(limit, 700));
      }

      int merged = 0;

      for (File file : changedFiles) {
         UUID uuid = this.parseStatsUuid(file.getName());
         if (uuid != null) {
            TopsDatabase.PlayerData data = this.readEssentialsUserdataBalance(uuid, file, now);
            if (data != null && data.balance >= 0.0) {
               this.mergePlayerData(changed, uuid.toString(), data);
               merged++;
            }
         }
      }

      return merged;
   }

   private boolean hasEnoughCachedEcoCandidates() {
      int candidates = 0;

      for (TopManager.CachedEssentialsBalance cached : this.essentialsBalanceFileCache.values()) {
         if (cached != null && !cached.name.isEmpty() && cached.balance >= 0.0) {
            if (++candidates >= 10) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean isEssentialsUserdataAvailable() {
      File directory = this.getEssentialsUserdataDirectory();
      return directory != null && directory.isDirectory();
   }

   private List<File> selectEssentialsUserdataBatch(List<File> files, Set<UUID> onlineUuids, int limit) {
      if (files != null && !files.isEmpty() && limit > 0) {
         List<File> result = new ArrayList<>(Math.min(limit, files.size()));
         int scanned = 0;
         int cursor = Math.floorMod(this.essentialsEcoScanCursor, files.size());

         while (result.size() < limit && scanned < files.size()) {
            File file = files.get(cursor);
            cursor = (cursor + 1) % files.size();
            scanned++;
            UUID uuid = file == null ? null : this.parseStatsUuid(file.getName());
            if (uuid != null && (onlineUuids == null || !onlineUuids.contains(uuid))) {
               result.add(file);
            }
         }

         this.essentialsEcoScanCursor = cursor;
         return result;
      } else {
         return Collections.emptyList();
      }
   }

   private List<File> collectEssentialsUserdataFiles(boolean forced) {
      long now = System.currentTimeMillis();
      List<File> cached = this.cachedEssentialsUserdataFiles;
      if (!forced && cached != null && !cached.isEmpty() && now - this.cachedEssentialsUserdataFilesAt < 600000L) {
         return cached;
      }

      File directory = this.getEssentialsUserdataDirectory();
      if (directory != null && directory.isDirectory()) {
         File[] rawFiles = directory.listFiles((dir, name) -> name != null && name.length() == 40 && name.endsWith(".yml"));
         if (rawFiles != null && rawFiles.length != 0) {
            Arrays.sort(rawFiles, (first, second) -> {
               int modifiedCompare = Long.compare(second.lastModified(), first.lastModified());
               return modifiedCompare != 0 ? modifiedCompare : first.getName().compareToIgnoreCase(second.getName());
            });
            List<File> immutable = Collections.unmodifiableList(new ArrayList<>(Arrays.asList(rawFiles)));
            this.cachedEssentialsUserdataFiles = immutable;
            this.cachedEssentialsUserdataFilesAt = now;
            if (!immutable.isEmpty()) {
               this.essentialsEcoScanCursor = Math.floorMod(this.essentialsEcoScanCursor, immutable.size());
            }

            return immutable;
         } else {
            this.cachedEssentialsUserdataFiles = Collections.emptyList();
            this.cachedEssentialsUserdataFilesAt = now;
            return Collections.emptyList();
         }
      } else {
         this.cachedEssentialsUserdataFiles = Collections.emptyList();
         this.cachedEssentialsUserdataFilesAt = now;
         return Collections.emptyList();
      }
   }

   private File getEssentialsUserdataDirectory() {
      File cached = this.essentialsUserdataDirectory;
      if (cached != null) {
         return cached;
      }

      try {
         Plugin essentials = Bukkit.getPluginManager().getPlugin("Essentials");
         if (essentials != null) {
            Object folderObject = essentials.getClass().getMethod("getDataFolder").invoke(essentials);
            if (folderObject instanceof File) {
               File userdata = new File((File)folderObject, "userdata");
               if (userdata.isDirectory()) {
                  this.essentialsUserdataDirectory = userdata;
                  return userdata;
               }
            }
         }
      } catch (Throwable var6) {
      }

      try {
         File folder = new File(this.plugin.getDataFolder().getParentFile(), "Essentials");
         File userdata = new File(folder, "userdata");
         if (userdata.isDirectory()) {
            this.essentialsUserdataDirectory = userdata;
            return userdata;
         }
      } catch (Throwable var5) {
      }

      return null;
   }

   private String readEssentialsUserdataName(UUID uuid) {
      if (uuid == null) {
         return "";
      }

      File directory = this.getEssentialsUserdataDirectory();
      if (directory != null && directory.isDirectory()) {
         File file = new File(directory, uuid.toString() + ".yml");
         if (!file.isFile()) {
            return "";
         }

         try {
            List<String> lines = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
            String fallback = "";

            for (String rawLine : lines) {
               if (rawLine != null) {
                  String line = rawLine.trim();
                  if (line.startsWith("lastAccountName:")) {
                     String parsed = this.unquoteYamlValue(line.substring("lastAccountName:".length()).trim());
                     if (!parsed.isEmpty()) {
                        this.cacheName(uuid, parsed);
                        return parsed;
                     }
                  } else if (line.startsWith("name:")) {
                     String parsed = this.unquoteYamlValue(line.substring("name:".length()).trim());
                     if (!parsed.isEmpty()) {
                        fallback = parsed;
                     }
                  }
               }
            }

            if (!fallback.isEmpty()) {
               this.cacheName(uuid, fallback);
            }

            return fallback;
         } catch (Throwable ignored) {
            return "";
         }
      } else {
         return "";
      }
   }

   private TopsDatabase.PlayerData readEssentialsUserdataBalance(UUID uuid, File file, long now) {
      if (uuid != null && file != null && file.isFile()) {
         try {
            long modified = file.lastModified();
            long length = file.length();
            TopManager.CachedEssentialsBalance cached = this.essentialsBalanceFileCache.get(uuid);
            if (cached != null && cached.same(file, modified, length)) {
               return new TopsDatabase.PlayerData(cached.name, cached.balance, -1, -1L, now);
            }

            List<String> lines = Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
            String name = "";
            double money = -1.0;

            for (String rawLine : lines) {
               if (rawLine != null) {
                  String line = rawLine.trim();
                  if (line.startsWith("lastAccountName:")) {
                     name = this.unquoteYamlValue(line.substring("lastAccountName:".length()).trim());
                  } else if (line.startsWith("name:")) {
                     String parsed = this.unquoteYamlValue(line.substring("name:".length()).trim());
                     if (!parsed.isEmpty()) {
                        name = parsed;
                     }
                  } else if (line.startsWith("money:")) {
                     money = this.parseBalanceText(this.unquoteYamlValue(line.substring("money:".length()).trim()));
                  }
               }
            }

            if (name.isEmpty()) {
               name = this.cachedName(uuid);
            }

            if (name.isEmpty()) {
               TopManager.CachedBalance balanceCache = this.offlineBalanceCache.get(uuid);
               name = balanceCache == null ? "" : this.cachedName(uuid);
            }

            if (name.isEmpty() && money > 0.0) {
               OfflinePlayer offlinePlayer = this.safeOfflinePlayer(uuid);
               name = this.safeName(offlinePlayer, uuid);
            }

            if (name.isEmpty()) {
               return null;
            }

            double balance = Math.max(0.0, money < 0.0 ? 0.0 : money);
            this.cacheName(uuid, name);
            this.offlineBalanceCache.put(uuid, new TopManager.CachedBalance(balance, now));
            this.essentialsBalanceFileCache.put(uuid, new TopManager.CachedEssentialsBalance(file, modified, length, balance, name));
            return new TopsDatabase.PlayerData(name, balance, -1, -1L, now);
         } catch (Throwable ignored) {
            return null;
         }
      } else {
         return null;
      }
   }

   private String unquoteYamlValue(String value) {
      if (value == null) {
         return "";
      }

      String result = value.trim();
      if (result.startsWith("'") && result.endsWith("'") || result.startsWith("\"") && result.endsWith("\"")) {
         result = result.substring(1, result.length() - 1);
      }

      return result.trim();
   }

   private double parseBalanceText(String text) {
      if (text != null && !text.isEmpty()) {
         try {
            return Math.max(0.0, new BigDecimal(text.replace(",", "")).doubleValue());
         } catch (Throwable ignored) {
            return -1.0;
         }
      } else {
         return -1.0;
      }
   }

   private double parseBalanceValue(Object value) {
      if (value == null) {
         return -1.0;
      } else if (value instanceof Number) {
         return Math.max(0.0, ((Number)value).doubleValue());
      } else {
         return value instanceof BigDecimal ? Math.max(0.0, ((BigDecimal)value).doubleValue()) : this.parseBalanceText(String.valueOf(value));
      }
   }

   private TopManager.BalanceIdentity parseBalanceIdentity(Object key) {
      if (key == null) {
         return null;
      } else if (key instanceof UUID) {
         return new TopManager.BalanceIdentity((UUID)key, "");
      } else if (key instanceof OfflinePlayer player) {
         UUID uuid = this.safeUuid(player);
         String name = this.safeName(player, uuid);
         return new TopManager.BalanceIdentity(uuid, name);
      } else {
         String text = String.valueOf(key).trim();
         if (text.isEmpty()) {
            return null;
         }

         UUID uuid = this.parseUuid(text);
         return uuid != null ? new TopManager.BalanceIdentity(uuid, "") : new TopManager.BalanceIdentity(null, text);
      }
   }

   private String resolveBalanceName(UUID uuid, String nameHint) {
      String name = this.normalizeName(nameHint);
      if (!name.isEmpty()) {
         return name;
      } else if (uuid == null) {
         return "";
      } else {
         name = this.cachedName(uuid);
         if (!name.isEmpty()) {
            return name;
         } else {
            name = this.readEssentialsUserName(uuid);
            if (!name.isEmpty()) {
               this.cacheName(uuid, name);
               return name;
            } else {
               OfflinePlayer player = this.safeOfflinePlayer(uuid);
               return this.safeName(player, uuid);
            }
         }
      }
   }

   private String readEssentialsUserName(UUID uuid) {
      if (uuid == null) {
         return "";
      }

      try {
         Plugin essentials = Bukkit.getPluginManager().getPlugin("Essentials");
         if (essentials == null) {
            return "";
         }

         Method getUserMap = essentials.getClass().getMethod("getUserMap");
         Object userMap = getUserMap.invoke(essentials);
         if (userMap == null) {
            return "";
         }

         Method getUser = null;

         for (Method method : userMap.getClass().getMethods()) {
            if ("getUser".equals(method.getName()) && method.getParameterTypes().length == 1) {
               Class<?> parameter = method.getParameterTypes()[0];
               if (UUID.class.isAssignableFrom(parameter)) {
                  getUser = method;
                  break;
               }
            }
         }

         if (getUser == null) {
            return "";
         }

         Object user = getUser.invoke(userMap, uuid);
         if (user == null) {
            return "";
         }

         for (String methodName : new String[]{"getName", "getLastAccountName"}) {
            try {
               Method method = user.getClass().getMethod(methodName);
               Object raw = method.invoke(user);
               if (raw instanceof String) {
                  String name = this.normalizeName((String)raw);
                  if (!name.isEmpty()) {
                     return name;
                  }
               }
            } catch (Throwable var14) {
            }
         }
      } catch (Throwable var15) {
      }

      return "";
   }

   private List<UUID> selectStatsBatch(Map<UUID, File> statsFiles, Set<UUID> onlineUuids, int limit) {
      List<UUID> index = this.cachedStatsUuidIndex;
      if (index == null || index.isEmpty()) {
         index = new ArrayList<>(statsFiles.keySet());
         this.cachedStatsUuidIndex = Collections.unmodifiableList(index);
      }

      if (index.isEmpty()) {
         return Collections.emptyList();
      }

      List<UUID> result = new ArrayList<>(Math.min(limit, index.size()));
      int scanned = 0;
      int cursor = Math.floorMod(this.statsScanCursor, index.size());

      while (result.size() < limit && scanned < index.size()) {
         UUID uuid = index.get(cursor);
         cursor = (cursor + 1) % index.size();
         scanned++;
         if (uuid != null && statsFiles.containsKey(uuid) && (onlineUuids == null || !onlineUuids.contains(uuid))) {
            result.add(uuid);
         }
      }

      this.statsScanCursor = cursor;
      return result;
   }

   private List<UUID> selectEcoBatch(List<UUID> index, Set<UUID> onlineUuids, int limit) {
      if (index != null && !index.isEmpty()) {
         List<UUID> result = new ArrayList<>(Math.min(limit, index.size()));
         int scanned = 0;
         int cursor = Math.floorMod(this.ecoScanCursor, index.size());

         while (result.size() < limit && scanned < index.size()) {
            UUID uuid = index.get(cursor);
            cursor = (cursor + 1) % index.size();
            scanned++;
            if (uuid != null && (onlineUuids == null || !onlineUuids.contains(uuid))) {
               result.add(uuid);
            }
         }

         this.ecoScanCursor = cursor;
         return result;
      } else {
         return Collections.emptyList();
      }
   }

   private List<UUID> getPlayerIndex(Map<UUID, File> statsFiles, boolean forced, long now) {
      List<UUID> cached = this.cachedPlayerIndex;
      if (!forced && cached != null && !cached.isEmpty() && now - this.cachedPlayerIndexAt < this.config.getPlayerIndexCacheMillis()) {
         return cached;
      }

      LinkedHashSet<UUID> uuids = new LinkedHashSet<>();

      try {
         Map<String, String> known = this.database.getKnownPlayersForScan(100000);

         for (Entry<String, String> entry : known.entrySet()) {
            UUID uuid = this.parseUuid(entry.getKey());
            if (uuid != null) {
               String name = this.normalizeName(entry.getValue());
               if (!name.isEmpty()) {
                  this.cacheName(uuid, name);
               }

               uuids.add(uuid);
            }
         }
      } catch (Throwable var12) {
      }

      if (statsFiles != null && !statsFiles.isEmpty()) {
         uuids.addAll(statsFiles.keySet());
      }

      for (File file : this.collectEssentialsUserdataFiles(false)) {
         UUID uuid = file == null ? null : this.parseStatsUuid(file.getName());
         if (uuid != null) {
            uuids.add(uuid);
         }
      }

      List<UUID> immutable = uuids.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(new ArrayList<>(uuids));
      this.cachedPlayerIndex = immutable;
      this.cachedPlayerIndexAt = now;
      if (!immutable.isEmpty()) {
         this.ecoScanCursor = Math.floorMod(this.ecoScanCursor, immutable.size());
      }

      return immutable;
   }

   private UUID parseUuid(String text) {
      if (text != null && !text.isEmpty()) {
         try {
            return UUID.fromString(text);
         } catch (IllegalArgumentException ignored) {
            return null;
         }
      } else {
         return null;
      }
   }

   private void rememberPlayerInIndex(UUID uuid) {
      if (uuid != null) {
         List<UUID> current = this.cachedPlayerIndex;
         if (current != null && !current.isEmpty() && !current.contains(uuid)) {
            ArrayList<UUID> updated = new ArrayList<>(current.size() + 1);
            updated.addAll(current);
            updated.add(uuid);
            this.cachedPlayerIndex = Collections.unmodifiableList(updated);
            this.ecoScanCursor = Math.floorMod(this.ecoScanCursor, updated.size());
         }
      }
   }

   private void mergePlayerData(Map<String, TopsDatabase.PlayerData> target, String uuid, TopsDatabase.PlayerData data) {
      if (target != null && uuid != null && !uuid.isEmpty() && data != null) {
         TopsDatabase.PlayerData old = target.get(uuid);
         if (old == null) {
            target.put(uuid, data);
         } else {
            String name = data.name != null && !data.name.isEmpty() ? data.name : old.name;
            double balance = data.balance >= 0.0 ? data.balance : old.balance;
            int kills = data.kills >= 0 ? data.kills : old.kills;
            long playtime = data.playtime >= 0L ? data.playtime : old.playtime;
            long updatedAt = Math.max(old.updatedAt, data.updatedAt);
            target.put(uuid, new TopsDatabase.PlayerData(name, balance, kills, playtime, updatedAt));
         }
      }
   }

   private StatUtil.GameStats readOnlineStats(UUID uuid, Player player, long now, boolean forced) {
      if (uuid != null && player != null) {
         TopManager.CachedOnlineStats cached = this.onlineStatsCache.get(uuid);
         if (!forced && cached != null && now - cached.readAt < 30000L) {
            long playtime = cached.stats.playtimeTicks;
            if (playtime >= 0L && now > cached.readAt) {
               playtime += Math.max(0L, (now - cached.readAt) / 50L);
            }

            return new StatUtil.GameStats(cached.stats.playerKills, playtime);
         } else {
            StatUtil.GameStats stats = StatUtil.read(player);
            this.onlineStatsCache.put(uuid, new TopManager.CachedOnlineStats(stats, now));
            return stats;
         }
      } else {
         return new StatUtil.GameStats(-1L, -1L);
      }
   }

   private TopsDatabase.PlayerData readOfflinePlayer(
      UUID uuid, String nameHint, File statsFile, Economy currentEconomy, long now, boolean readStats, boolean readBalance
   ) {
      if (uuid == null) {
         return null;
      }

      String name = this.normalizeName(nameHint);
      if (name.isEmpty()) {
         name = this.cachedName(uuid);
      }

      OfflinePlayer player = null;
      if (name.isEmpty() || readBalance) {
         player = this.safeOfflinePlayer(uuid);
      }

      if (name.isEmpty() && player != null) {
         name = this.safeName(player, uuid);
      }

      if (name.isEmpty()) {
         name = this.readEssentialsUserdataName(uuid);
      }

      if (name.isEmpty()) {
         return null;
      }

      double balance = -1.0;
      if (readBalance && currentEconomy != null) {
         balance = this.readCachedOfflineBalance(uuid, player, currentEconomy, now);
      }

      int kills = -1;
      long playtime = -1L;
      if (readStats) {
         StatUtil.GameStats stats = this.readStatsFile(uuid, statsFile);
         kills = stats.playerKills >= 0L ? (int)Math.min(2147483647L, stats.playerKills) : -1;
         playtime = stats.playtimeTicks >= 0L ? stats.playtimeTicks : -1L;
      }

      this.cacheName(uuid, name);
      return new TopsDatabase.PlayerData(name, balance, kills, playtime, now);
   }

   private OfflinePlayer safeOfflinePlayer(UUID uuid) {
      try {
         return Bukkit.getOfflinePlayer(uuid);
      } catch (Throwable ignored) {
         return null;
      }
   }

   private StatUtil.GameStats readStatsFile(UUID uuid, File statsFile) {
      if (uuid != null && statsFile != null && statsFile.isFile()) {
         try {
            long modified = statsFile.lastModified();
            long length = statsFile.length();
            TopManager.CachedStats cached = this.statsCache.get(uuid);
            if (cached != null && cached.same(statsFile, modified, length)) {
               return cached.stats;
            }

            String json = new String(Files.readAllBytes(statsFile.toPath()), StandardCharsets.UTF_8);
            long kills = this.matchLong(json, PLAYER_KILLS_PATTERN);
            if (kills < 0L) {
               kills = 0L;
            }

            long playtime = this.matchLong(json, PLAY_ONE_MINUTE_PATTERN);
            if (playtime < 0L) {
               playtime = this.matchLong(json, PLAY_TIME_PATTERN);
            }

            if (playtime < 0L) {
               playtime = 0L;
            }

            StatUtil.GameStats stats = new StatUtil.GameStats(kills, playtime);
            this.statsCache.put(uuid, new TopManager.CachedStats(statsFile, modified, length, stats));
            return stats;
         } catch (Throwable ignored) {
            return new StatUtil.GameStats(-1L, -1L);
         }
      } else {
         return new StatUtil.GameStats(-1L, -1L);
      }
   }

   private long matchLong(String text, Pattern pattern) {
      Matcher matcher = pattern.matcher(text);
      if (!matcher.find()) {
         return -1L;
      }

      try {
         return Math.max(0L, Long.parseLong(matcher.group(1)));
      } catch (NumberFormatException ignored) {
         return -1L;
      }
   }

   private Map<UUID, File> collectStatsFiles(boolean forced) {
      long now = System.currentTimeMillis();
      Map<UUID, File> cached = this.cachedStatsFiles;
      if (!forced && cached != null && now - this.cachedStatsFilesAt < this.config.getStatsFileListCacheMillis()) {
         return cached;
      }

      Map<UUID, File> result = new LinkedHashMap<>();

      for (File directory : this.getStatsDirectories()) {
         File[] files = directory.listFiles((dir, name) -> name != null && name.length() == 41 && name.endsWith(".json"));
         if (files != null && files.length != 0) {
            Arrays.sort(files, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));

            for (File file : files) {
               UUID uuid = this.parseStatsUuid(file.getName());
               if (uuid != null) {
                  result.putIfAbsent(uuid, file);
                  if (this.statsFileCache.size() < 100000) {
                     this.statsFileCache.putIfAbsent(uuid, file);
                  }
               }
            }
         }
      }

      Map<UUID, File> immutable = result.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(new LinkedHashMap<>(result));
      this.cachedStatsFiles = immutable;
      this.cachedStatsUuidIndex = immutable.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(new ArrayList<>(immutable.keySet()));
      this.cachedStatsFilesAt = now;
      if (!this.cachedStatsUuidIndex.isEmpty()) {
         this.statsScanCursor = Math.floorMod(this.statsScanCursor, this.cachedStatsUuidIndex.size());
      }

      return immutable;
   }

   private UUID parseStatsUuid(String name) {
      if (name == null) {
         return null;
      }

      int extensionLength;
      if (name.endsWith(".json")) {
         extensionLength = 5;
      } else {
         if (!name.endsWith(".yml")) {
            return null;
         }

         extensionLength = 4;
      }

      try {
         return UUID.fromString(name.substring(0, name.length() - extensionLength));
      } catch (IllegalArgumentException ignored) {
         return null;
      }
   }

   private List<File> getStatsDirectories() {
      long now = System.currentTimeMillis();
      List<File> cached = this.statsDirectories;
      if (!cached.isEmpty() && now - this.statsDirectoriesAt < 300000L) {
         return cached;
      }

      File container = this.getWorldContainer();
      if (container == null) {
         return Collections.emptyList();
      }

      Map<String, File> directories = new LinkedHashMap<>();
      File[] worlds = container.listFiles(File::isDirectory);
      if (worlds != null) {
         Arrays.sort(worlds, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));

         for (File world : worlds) {
            File directory = new File(world, "stats");
            if (directory.isDirectory()) {
               directories.putIfAbsent(directory.getAbsolutePath(), directory);
            }
         }
      }

      List<File> immutable = directories.isEmpty() ? Collections.emptyList() : Collections.unmodifiableList(new ArrayList<>(directories.values()));
      this.statsDirectories = immutable;
      this.statsDirectoriesAt = now;
      return immutable;
   }

   private File getWorldContainer() {
      File cached = this.worldContainer;
      if (cached != null) {
         return cached;
      }

      try {
         Object value = this.plugin.getServer().getClass().getMethod("getWorldContainer").invoke(this.plugin.getServer());
         if (value instanceof File) {
            this.worldContainer = (File)value;
            return (File)value;
         }
      } catch (Throwable var3) {
      }

      return null;
   }

   private TopManager.TopDataSnapshot buildTopDataSnapshot(Map<String, TopsDatabase.PlayerData> changed) {
      Map<String, Map<String, TopsDatabase.TopEntry>> databaseTops = this.database.getTops(10);
      Map<String, TopsDatabase.TopEntry> balance = this.mergeDatabaseTop(databaseTops.get("balance"), changed, TopManager.Metric.BALANCE);
      Map<String, TopsDatabase.TopEntry> kills = this.mergeDatabaseTop(databaseTops.get("kills"), changed, TopManager.Metric.KILLS);
      Map<String, TopsDatabase.TopEntry> playtime = this.mergeDatabaseTop(databaseTops.get("playtime"), changed, TopManager.Metric.PLAYTIME);
      return new TopManager.TopDataSnapshot(balance, kills, playtime, changed == null ? Collections.emptyMap() : changed);
   }

   private Map<String, TopsDatabase.TopEntry> mergeDatabaseTop(
      Map<String, TopsDatabase.TopEntry> databaseTop, Map<String, TopsDatabase.PlayerData> changed, TopManager.Metric metric
   ) {
      Map<String, TopsDatabase.TopEntry> entries = new LinkedHashMap<>();
      if (databaseTop != null) {
         entries.putAll(databaseTop);
      }

      if (changed != null) {
         for (Entry<String, TopsDatabase.PlayerData> entry : changed.entrySet()) {
            String uuid = entry.getKey();
            TopsDatabase.PlayerData data = entry.getValue();
            if (uuid != null && !uuid.isEmpty() && data != null && data.name != null && !data.name.isEmpty()) {
               double raw = this.metricRawValue(data, metric);
               if (!(raw < 0.0)) {
                  entries.put(uuid, new TopsDatabase.TopEntry(uuid, data.name, raw));
               }
            }
         }
      }

      return this.selectTopEntries(entries);
   }

   private Map<String, TopsDatabase.TopEntry> selectTopEntries(Map<String, TopsDatabase.TopEntry> entries) {
      if (entries != null && !entries.isEmpty()) {
         List<TopsDatabase.TopEntry> list = new ArrayList<>(entries.values());
         list.removeIf(entryx -> entryx == null || entryx.uuid == null || entryx.uuid.isEmpty() || entryx.name == null || entryx.name.isEmpty());
         list.sort((first, second) -> {
            int valueCompare = Double.compare(second.value, first.value);
            return valueCompare != 0 ? valueCompare : first.name.compareToIgnoreCase(second.name);
         });
         Map<String, TopsDatabase.TopEntry> result = new LinkedHashMap<>();

         for (TopsDatabase.TopEntry entry : list) {
            if (result.size() >= 10) {
               break;
            }

            result.put(entry.uuid, entry);
         }

         return Collections.unmodifiableMap(result);
      } else {
         return Collections.emptyMap();
      }
   }

   private double metricRawValue(TopsDatabase.PlayerData data, TopManager.Metric metric) {
      if (data == null) {
         return -1.0;
      } else if (metric == TopManager.Metric.BALANCE) {
         return data.balance;
      } else {
         return metric == TopManager.Metric.KILLS ? data.kills : data.playtime;
      }
   }

   private void formatDatabaseTops(TopManager.TopDataSnapshot tops) {
      for (ITopsManager top : this.dbTops) {
         try {
            if (top instanceof EcoTop) {
               ((EcoTop)top).updateFromDatabase(tops.balance);
            } else if (top instanceof KillTop) {
               ((KillTop)top).updateFromDatabase(tops.kills);
            } else if (top instanceof OnlineTop) {
               ((OnlineTop)top).updateFromDatabase(tops.playtime);
            }

            this.cacheFormattedTop(top);
         } catch (Throwable var5) {
         }
      }
   }

   private CompletableFuture<Void> updateApiTops(boolean force) {
      return this.updateApiTops(force, null);
   }

   private CompletableFuture<Void> updateApiTop(String type, boolean force) {
      return type != null && !type.isEmpty() ? this.updateApiTops(force, type) : CompletableFuture.completedFuture(null);
   }

   private CompletableFuture<Void> updateApiTops(boolean force, String onlyType) {
      long now = System.currentTimeMillis();
      long intervalMillis = Math.max(10L, this.config.getUpdateInterval()) * 1000L;
      if (!this.closed && (onlyType != null || force || now - this.lastApiUpdateAt >= intervalMillis)) {
         return !this.apiUpdating.compareAndSet(false, true) ? CompletableFuture.completedFuture(null) : CompletableFuture.runAsync(() -> {
            for (ITopsManager top : this.apiTops) {
               if (top != null && (onlyType == null || onlyType.equalsIgnoreCase(top.getType()))) {
                  try {
                     top.updateFormatted();
                     if (this.apiTops.contains(top)) {
                        this.cacheFormattedTop(top);
                     }
                  } catch (Throwable var5x) {
                  }
               }
            }

            if (onlyType == null) {
               this.lastApiUpdateAt = System.currentTimeMillis();
            }
         }, this.worker).whenComplete((ignored, throwable) -> this.apiUpdating.set(false));
      } else {
         return CompletableFuture.completedFuture(null);
      }
   }

   private void finishUpdate() {
      this.updating.set(false);
      if (!this.closed && this.pendingUpdate.getAndSet(false)) {
         this.startUpdate(false);
      }
   }

   private void cacheFormattedTop(ITopsManager top) {
      if (top != null) {
         Map<Integer, String> formatted = top.getFormattedTop();
         if (formatted == null) {
            formatted = Collections.emptyMap();
         }

         this.cachedTops.put(top.getType(), formatted);
         if (top instanceof OnlineTop) {
            this.cachedPlainTops.put(top.getType(), ((OnlineTop)top).getPlainFormattedTop());
         } else {
            this.cachedPlainTops.put(top.getType(), this.formatUtil.toPlainTop(formatted));
         }
      }
   }

   public Map<Integer, String> getFormattedTop(String type) {
      return this.getFormattedTop(type, true);
   }

   public Map<Integer, String> getFormattedTop(String type, boolean resourcePack) {
      if (type != null && !type.isEmpty()) {
         Map<String, Map<Integer, String>> source = resourcePack ? this.cachedTops : this.cachedPlainTops;
         return source.getOrDefault(type, Collections.emptyMap());
      } else {
         return Collections.emptyMap();
      }
   }

   private Economy refreshEconomy() {
      Economy current = this.economy;
      if (current == null) {
         current = this.setupEconomy();
         this.economy = current;
      }

      return current;
   }

   private double readBalance(OfflinePlayer player, Economy currentEconomy) {
      double balance = this.readBalanceOrUnknown(player, currentEconomy);
      return balance >= 0.0 ? balance : 0.0;
   }

   private double readBalanceOrUnknown(OfflinePlayer player, Economy currentEconomy) {
      if (player != null && currentEconomy != null) {
         try {
            return Math.max(0.0, currentEconomy.getBalance(player));
         } catch (Throwable ignored) {
            return -1.0;
         }
      } else {
         return -1.0;
      }
   }

   private double readCachedOfflineBalance(UUID uuid, OfflinePlayer player, Economy currentEconomy, long now) {
      if (uuid != null && currentEconomy != null) {
         TopManager.CachedBalance cached = this.offlineBalanceCache.get(uuid);
         if (cached != null && now - cached.readAt < 300000L) {
            return cached.balance;
         } else if (player == null) {
            return cached == null ? -1.0 : cached.balance;
         } else {
            double balance = this.readBalanceOrUnknown(player, currentEconomy);
            if (balance >= 0.0) {
               this.offlineBalanceCache.put(uuid, new TopManager.CachedBalance(balance, now));
               return balance;
            } else {
               return cached == null ? -1.0 : cached.balance;
            }
         }
      } else {
         return -1.0;
      }
   }

   private UUID safeUuid(OfflinePlayer player) {
      try {
         return player.getUniqueId();
      } catch (Throwable ignored) {
         return null;
      }
   }

   private String safeLiveName(Player player, UUID uuid) {
      if (player != null) {
         try {
            String name = this.normalizeName(player.getName());
            if (!name.isEmpty()) {
               this.cacheName(uuid, name);
               return name;
            }
         } catch (Throwable var4) {
         }
      }

      return this.safeName(player, uuid);
   }

   private String safeName(OfflinePlayer player, UUID uuid) {
      try {
         if (player != null) {
            String name = this.normalizeName(player.getName());
            if (!name.isEmpty()) {
               this.cacheName(uuid, name);
               return name;
            }
         }
      } catch (Throwable var4) {
      }

      return this.cachedName(uuid);
   }

   private String normalizeName(String name) {
      return name == null ? "" : name.trim();
   }

   private String cachedName(UUID uuid) {
      if (uuid == null) {
         return "";
      }

      String name = this.nameCache.get(uuid.toString());
      return name == null ? "" : name;
   }

   private void cacheName(UUID uuid, String name) {
      if (uuid != null && name != null && !name.isEmpty()) {
         this.nameCache.put(uuid.toString(), name);
         if (this.nameCache.size() > 100256) {
            this.trimCache(this.nameCache, 100000);
         }
      }
   }

   private <K, V> void trimCache(Map<K, V> map, int maxSize) {
      if (map != null && maxSize > 0 && map.size() > maxSize) {
         int toRemove = map.size() - maxSize;

         for (Iterator<K> iterator = map.keySet().iterator(); toRemove > 0 && iterator.hasNext(); toRemove--) {
            K key = iterator.next();
            map.remove(key);
         }
      }
   }

   private static final class BalanceCandidate {
      private final UUID uuid;
      private final String name;
      private final double balance;

      private BalanceCandidate(UUID uuid, String name, double balance) {
         this.uuid = uuid;
         this.name = name == null ? "" : name;
         this.balance = Math.max(0.0, balance);
      }

      private String sortName() {
         return this.name.isEmpty() ? (this.uuid == null ? "" : this.uuid.toString()) : this.name;
      }
   }

   private static final class BalanceIdentity {
      private final UUID uuid;
      private final String name;

      private BalanceIdentity(UUID uuid, String name) {
         this.uuid = uuid;
         this.name = name == null ? "" : name;
      }
   }

   private static final class CachedBalance {
      private final double balance;
      private final long readAt;

      private CachedBalance(double balance, long readAt) {
         this.balance = Math.max(0.0, balance);
         this.readAt = readAt;
      }
   }

   private static final class CachedEssentialsBalance {
      private final String path;
      private final long modified;
      private final long length;
      private final double balance;
      private final String name;

      private CachedEssentialsBalance(File file, long modified, long length, double balance, String name) {
         this.path = file.getAbsolutePath();
         this.modified = modified;
         this.length = length;
         this.balance = Math.max(0.0, balance);
         this.name = name == null ? "" : name;
      }

      private boolean same(File file, long modified, long length) {
         return this.modified == modified && this.length == length && this.path.equals(file.getAbsolutePath());
      }
   }

   private static final class CachedOnlineStats {
      private final StatUtil.GameStats stats;
      private final long readAt;

      private CachedOnlineStats(StatUtil.GameStats stats, long readAt) {
         this.stats = stats == null ? new StatUtil.GameStats(-1L, -1L) : stats;
         this.readAt = readAt;
      }
   }

   private static final class CachedStats {
      private final String path;
      private final long modified;
      private final long length;
      private final StatUtil.GameStats stats;

      private CachedStats(File file, long modified, long length, StatUtil.GameStats stats) {
         this.path = file.getAbsolutePath();
         this.modified = modified;
         this.length = length;
         this.stats = stats;
      }

      private boolean same(File file, long modified, long length) {
         return this.modified == modified && this.length == length && this.path.equals(file.getAbsolutePath());
      }
   }

   private enum Metric {
      BALANCE,
      KILLS,
      PLAYTIME;
   }

   private static final class OnlineSnapshot {
      private final UUID uuid;
      private final String name;
      private final double balance;
      private final int kills;
      private final long playtime;
      private final long updatedAt;

      private OnlineSnapshot(UUID uuid, String name, double balance, int kills, long playtime, long updatedAt) {
         this.uuid = uuid;
         this.name = name;
         this.balance = balance;
         this.kills = kills;
         this.playtime = playtime;
         this.updatedAt = updatedAt;
      }

      private TopsDatabase.PlayerData toPlayerData() {
         return new TopsDatabase.PlayerData(this.name, this.balance, this.kills, this.playtime, this.updatedAt);
      }
   }

   private static final class TopDataSnapshot {
      private final Map<String, TopsDatabase.TopEntry> balance;
      private final Map<String, TopsDatabase.TopEntry> kills;
      private final Map<String, TopsDatabase.TopEntry> playtime;
      private final Map<String, TopsDatabase.PlayerData> persistData;

      private TopDataSnapshot(
         Map<String, TopsDatabase.TopEntry> balance,
         Map<String, TopsDatabase.TopEntry> kills,
         Map<String, TopsDatabase.TopEntry> playtime,
         Map<String, TopsDatabase.PlayerData> persistData
      ) {
         this.balance = balance;
         this.kills = kills;
         this.playtime = playtime;
         this.persistData = persistData;
      }
   }
}
