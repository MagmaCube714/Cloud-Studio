package cs.cloudstudio.manager.impl;

import cs.cloudstudio.database.impl.TopsDatabase;
import cs.cloudstudio.manager.ITopsManager;
import cs.cloudstudio.util.FormatUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class OnlineTop implements ITopsManager {
   private final FormatUtil formatUtil;
   private final Map<String, Long> topData = new LinkedHashMap<>();
   private volatile Map<Integer, String> lastFormattedData = Collections.emptyMap();
   private volatile Map<Integer, String> lastPlainFormattedData = Collections.emptyMap();
   private volatile String lastSignature = "";

   public OnlineTop(FormatUtil formatUtil) {
      this.formatUtil = formatUtil;
   }

   public void updateFromDatabase(Map<String, TopsDatabase.TopEntry> dbData) {
      String signature = this.signature(dbData);
      if (!signature.equals(this.lastSignature) || this.lastFormattedData.isEmpty()) {
         this.topData.clear();
         if (dbData != null) {
            int copied = 0;

            for (TopsDatabase.TopEntry entry : dbData.values()) {
               if (entry != null && entry.name != null && !entry.name.isEmpty()) {
                  this.topData.put(entry.name, Math.max(0L, Math.round(entry.value)));
                  if (++copied >= 10) {
                     break;
                  }
               }
            }
         }

         this.updateFormatted();
         this.lastSignature = signature;
      }
   }

   @Override
   public void updateFormatted() {
      List<Entry<String, Long>> sorted = new ArrayList<>(this.topData.entrySet());
      sorted.sort((first, second) -> Long.compare(second.getValue(), first.getValue()));

      while (sorted.size() > 10) {
         sorted.remove(sorted.size() - 1);
      }

      int maxLeftWidth = 0;
      int maxValueWidth = 0;
      int plainMaxLeftWidth = 0;
      int plainMaxValueWidth = 0;
      List<String> valueParts = new ArrayList<>(sorted.size());
      List<String> plainValueParts = new ArrayList<>(sorted.size());

      for (int rank = 1; rank <= sorted.size(); rank++) {
         Entry<String, Long> entry = sorted.get(rank - 1);
         long ticks = Math.max(0L, entry.getValue());
         String time = this.formatUtil.formatTime(ticks);
         String plainTime = this.formatUtil.formatTime(ticks, false);
         String value = this.formatUtil.applyGradient(time, FormatUtil.GRADIENT_START, FormatUtil.GRADIENT_END);
         String plainValue = this.formatUtil.applyGradient(plainTime, FormatUtil.GRADIENT_START, FormatUtil.GRADIENT_END);
         String valuePart = value;
         String plainValuePart = plainValue;
         valueParts.add(valuePart);
         plainValueParts.add(plainValuePart);
         int leftWidth = this.formatUtil.getStringWidth(this.formatUtil.rank(rank) + " §f" + entry.getKey());
         if (leftWidth > maxLeftWidth) {
            maxLeftWidth = leftWidth;
         }

         int valueWidth = this.formatUtil.getStringWidth(valuePart);
         if (valueWidth > maxValueWidth) {
            maxValueWidth = valueWidth;
         }

         int plainLeftWidth = this.formatUtil.getStringWidth(this.formatUtil.plainRank(rank) + " §f" + entry.getKey());
         if (plainLeftWidth > plainMaxLeftWidth) {
            plainMaxLeftWidth = plainLeftWidth;
         }

         int plainValueWidth = this.formatUtil.getStringWidth(plainValuePart);
         if (plainValueWidth > plainMaxValueWidth) {
            plainMaxValueWidth = plainValueWidth;
         }
      }

      int totalWidth = maxLeftWidth + this.formatUtil.getTopColumnGapWidth() + maxValueWidth;
      int plainTotalWidth = plainMaxLeftWidth + this.formatUtil.getTopColumnGapWidth() + plainMaxValueWidth;
      Map<Integer, String> formatted = new LinkedHashMap<>();
      Map<Integer, String> plainFormatted = new LinkedHashMap<>();

      for (int rank = 1; rank <= 10; rank++) {
         String rankString = this.formatUtil.rank(rank);
         String plainRankString = this.formatUtil.plainRank(rank);
         if (rank - 1 < sorted.size()) {
            Entry<String, Long> entry = sorted.get(rank - 1);
            formatted.put(rank, this.formatUtil.buildAlignedLine(rankString, "§f" + entry.getKey(), valueParts.get(rank - 1), totalWidth));
            plainFormatted.put(
               rank,
               this.formatUtil
                  .toPlainLine(this.formatUtil.buildAlignedLine(plainRankString, "§f" + entry.getKey(), plainValueParts.get(rank - 1), plainTotalWidth))
            );
         } else {
            formatted.put(rank, rankString + "  ");
            plainFormatted.put(rank, plainRankString + "  ");
         }
      }

      this.lastFormattedData = Collections.unmodifiableMap(formatted);
      this.lastPlainFormattedData = Collections.unmodifiableMap(plainFormatted);
   }

   private String signature(Map<String, TopsDatabase.TopEntry> dbData) {
      if (dbData != null && !dbData.isEmpty()) {
         StringBuilder builder = new StringBuilder(dbData.size() * 32);
         int copied = 0;

         for (Entry<String, TopsDatabase.TopEntry> entry : dbData.entrySet()) {
            TopsDatabase.TopEntry value = entry.getValue();
            if (value != null) {
               builder.append(entry.getKey()).append(':').append(value.name).append('=').append(Math.max(0L, Math.round(value.value))).append(';');
               if (++copied >= 10) {
                  break;
               }
            }
         }

         return builder.length() == 0 ? "empty" : builder.toString();
      } else {
         return "empty";
      }
   }

   @Override
   public Map<Integer, String> getFormattedTop() {
      return this.lastFormattedData;
   }

   public Map<Integer, String> getPlainFormattedTop() {
      return this.lastPlainFormattedData;
   }

   @Override
   public String getType() {
      return "online";
   }
}
