package cs.cloudstudio.manager.impl;

import cs.cloudstudio.manager.ITopsManager;
import cs.cloudstudio.util.FormatUtil;
import java.awt.Color;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public class BattlePassTop implements ITopsManager {
   private static final int GRADIENT_CACHE_LIMIT = 512;
   private static final Color[] VALUE_COLORS = new Color[]{
      new Color(250, 188, 0), new Color(250, 164, 10), new Color(250, 140, 20), new Color(250, 117, 30), new Color(250, 93, 39)
   };
   private final FormatUtil formatUtil;
   private final Map<String, String> gradientCache = new ConcurrentHashMap<>();
   private volatile Map<Integer, String> lastFormattedData = Collections.emptyMap();
   private volatile String lastSignature = "";
   private Method isInitialized;
   private Method getPlayerDataBase;
   private Method getTopPlayersByExp;

   public BattlePassTop(FormatUtil formatUtil) {
      this.formatUtil = formatUtil;
   }

   @Override
   public void updateFormatted() {
      Map<Integer, BattlePassTop.TopEntry> data = this.readFromBattlePass();
      String signature = this.signature(data);
      if (!signature.equals(this.lastSignature) || this.lastFormattedData.isEmpty()) {
         if (data.isEmpty()) {
            this.lastFormattedData = this.buildEmptyLines();
            this.lastSignature = signature;
         } else {
            int maxLeftWidth = 0;
            int maxValueWidth = 0;
            Map<Integer, String> valueParts = new HashMap<>();

            for (Entry<Integer, BattlePassTop.TopEntry> dataEntry : data.entrySet()) {
               int rank = dataEntry.getKey();
               BattlePassTop.TopEntry entry = dataEntry.getValue();
               String value = this.formatNumber(entry.value);
               String valuePart = this.applyDynamicGradient(value) + " §rꐇ";
               valueParts.put(rank, valuePart);
               int leftWidth = this.formatUtil.getStringWidth(this.formatUtil.rank(rank) + " §f" + entry.name + "§r");
               if (leftWidth > maxLeftWidth) {
                  maxLeftWidth = leftWidth;
               }

               int valueWidth = this.formatUtil.getStringWidth(valuePart);
               if (valueWidth > maxValueWidth) {
                  maxValueWidth = valueWidth;
               }
            }

            int totalWidth = maxLeftWidth + this.formatUtil.getTopColumnGapWidth() + maxValueWidth;
            Map<Integer, String> formatted = new LinkedHashMap<>();

            for (int rank = 1; rank <= 10; rank++) {
               String rankString = this.formatUtil.rank(rank);
               BattlePassTop.TopEntry entry = data.get(rank);
               if (entry != null) {
                  formatted.put(rank, this.formatUtil.buildAlignedLine(rankString, "§f" + entry.name + "§r", valueParts.get(rank), totalWidth));
               } else {
                  formatted.put(rank, rankString + "  ");
               }
            }

            this.lastFormattedData = Collections.unmodifiableMap(formatted);
            this.lastSignature = signature;
         }
      }
   }

   private Map<Integer, BattlePassTop.TopEntry> readFromBattlePass() {
      Plugin plugin = this.findPlugin("CloudBattlePass");
      if (plugin != null && plugin.isEnabled()) {
         try {
            if (this.isInitialized == null) {
               this.isInitialized = plugin.getClass().getMethod("isInitialized");
            }

            Object initialized = this.isInitialized.invoke(plugin);
            if (initialized instanceof Boolean && !(Boolean)initialized) {
               return Collections.emptyMap();
            }

            if (this.getPlayerDataBase == null) {
               this.getPlayerDataBase = plugin.getClass().getMethod("getPlayerDataBase");
            }

            Object database = this.getPlayerDataBase.invoke(plugin);
            if (database == null) {
               return Collections.emptyMap();
            }

            if (this.getTopPlayersByExp == null) {
               this.getTopPlayersByExp = database.getClass().getMethod("getTopPlayersByExp", int.class);
            }

            Object raw = this.getTopPlayersByExp.invoke(database, 10);
            if (!(raw instanceof List)) {
               return Collections.emptyMap();
            }

            Map<Integer, BattlePassTop.TopEntry> result = new LinkedHashMap<>();
            List<?> list = (List<?>)raw;

            for (int index = 0; index < list.size() && result.size() < 10; index++) {
               if (list.get(index) instanceof Entry<?, ?> entry) {
                  Object key = entry.getKey();
                  Object value = entry.getValue();
                  if (key != null && value instanceof Number) {
                     String name = String.valueOf(key).trim();
                     if (!name.isEmpty()) {
                        long exp = Math.max(0L, ((Number)value).longValue());
                        result.put(result.size() + 1, new BattlePassTop.TopEntry(name, exp));
                     }
                  }
               }
            }

            return result;
         } catch (Throwable ignored) {
            return Collections.emptyMap();
         }
      } else {
         return Collections.emptyMap();
      }
   }

   private Plugin findPlugin(String... names) {
      for (String name : names) {
         Plugin plugin = Bukkit.getPluginManager().getPlugin(name);
         if (plugin != null && plugin.isEnabled()) {
            return plugin;
         }
      }

      return null;
   }

   private Map<Integer, String> buildEmptyLines() {
      Map<Integer, String> fallback = new LinkedHashMap<>();

      for (int rank = 1; rank <= 10; rank++) {
         fallback.put(rank, this.formatUtil.rank(rank) + "  ");
      }

      return Collections.unmodifiableMap(fallback);
   }

   private String signature(Map<Integer, BattlePassTop.TopEntry> data) {
      StringBuilder builder = new StringBuilder(data.size() * 20);

      for (Entry<Integer, BattlePassTop.TopEntry> entry : data.entrySet()) {
         BattlePassTop.TopEntry value = entry.getValue();
         builder.append(entry.getKey()).append(':').append(value.name).append('=').append(value.value).append(';');
      }

      return builder.toString();
   }

   private String formatNumber(long value) {
      if (value < 1000L) {
         return Long.toString(value);
      }

      String digits = Long.toString(value);
      StringBuilder builder = new StringBuilder(digits.length() + digits.length() / 3);
      int first = digits.length() % 3;
      if (first == 0) {
         first = 3;
      }

      builder.append(digits, 0, first);

      for (int index = first; index < digits.length(); index += 3) {
         builder.append(',').append(digits, index, index + 3);
      }

      return builder.toString();
   }

   private String applyDynamicGradient(String value) {
      if (value.length() <= 1) {
         return "§f" + value;
      }

      if (this.gradientCache.size() > 512) {
         this.gradientCache.clear();
      }

      return this.gradientCache.computeIfAbsent(value, key -> this.applyMultiColorGradient(key, VALUE_COLORS));
   }

   private String applyMultiColorGradient(String text, Color... colors) {
      StringBuilder builder = new StringBuilder();
      int length = text.length();
      if (length == 1) {
         return ChatColor.of(colors[0]) + text;
      }

      for (int index = 0; index < length; index++) {
         float relative = (float)index / (length - 1);
         float colorIndex = relative * (colors.length - 1);
         int first = (int)colorIndex;
         int second = Math.min(first + 1, colors.length - 1);
         float ratio = colorIndex - first;
         Color color = this.interpolateColor(colors[first], colors[second], ratio);
         builder.append(ChatColor.of(color)).append(text.charAt(index));
      }

      return builder.toString();
   }

   private Color interpolateColor(Color first, Color second, float ratio) {
      int red = (int)(first.getRed() + ratio * (second.getRed() - first.getRed()));
      int green = (int)(first.getGreen() + ratio * (second.getGreen() - first.getGreen()));
      int blue = (int)(first.getBlue() + ratio * (second.getBlue() - first.getBlue()));
      return new Color(Math.max(0, Math.min(255, red)), Math.max(0, Math.min(255, green)), Math.max(0, Math.min(255, blue)));
   }

   @Override
   public Map<Integer, String> getFormattedTop() {
      return this.lastFormattedData;
   }

   @Override
   public String getType() {
      return "battlepass";
   }

   private static final class TopEntry {
      private final String name;
      private final long value;

      private TopEntry(String name, long value) {
         this.name = name;
         this.value = value;
      }
   }
}
