package cs.cloudstudio.manager.impl;

import cs.cloudstudio.database.impl.TopsDatabase;
import cs.cloudstudio.manager.ITopsManager;
import cs.cloudstudio.util.FormatUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class EcoTop implements ITopsManager {
   private final FormatUtil formatUtil;
   private final Map<String, Double> topData = new LinkedHashMap<>();
   private volatile Map<Integer, String> lastFormattedData = Collections.emptyMap();
   private volatile String lastSignature = "";

   public EcoTop(FormatUtil formatUtil) {
      this.formatUtil = formatUtil;
   }

   public void updateFromDatabase(Map<String, TopsDatabase.TopEntry> dbData) {
      String signature = this.signature(dbData);
      if (!signature.equals(this.lastSignature) || this.lastFormattedData.isEmpty()) {
         this.topData.clear();
         if (dbData != null) {
            int copied = 0;

            for (TopsDatabase.TopEntry entry : dbData.values()) {
               if (entry != null && entry.name != null && !entry.name.isEmpty()) {
                  this.topData.put(entry.name, Math.max(0.0, entry.value));
                  if (++copied >= 10) {
                     break;
                  }
               }
            }
         }

         this.updateFormatted();
         this.lastSignature = signature;
      }
   }

   @Override
   public void updateFormatted() {
      List<Entry<String, Double>> sorted = new ArrayList<>(this.topData.entrySet());
      sorted.sort((first, second) -> Double.compare(second.getValue(), first.getValue()));

      while (sorted.size() > 10) {
         sorted.remove(sorted.size() - 1);
      }

      int maxLeftWidth = 0;
      int maxValueWidth = 0;
      List<String> valueParts = new ArrayList<>(sorted.size());

      for (int rank = 1; rank <= sorted.size(); rank++) {
         Entry<String, Double> entry = sorted.get(rank - 1);
         String raw = this.formatUtil.formatEco(Long.toString(Math.round(Math.max(0.0, entry.getValue()))));
         String value = raw.length() >= 2 ? this.formatUtil.applyGradient(raw, FormatUtil.GRADIENT_START, FormatUtil.GRADIENT_END) : "§f" + raw;
         String valuePart = value + "§f ꐂ";
         valueParts.add(valuePart);
         int leftWidth = this.formatUtil.getStringWidth(this.formatUtil.rank(rank) + " §f" + entry.getKey());
         if (leftWidth > maxLeftWidth) {
            maxLeftWidth = leftWidth;
         }

         int valueWidth = this.formatUtil.getStringWidth(valuePart);
         if (valueWidth > maxValueWidth) {
            maxValueWidth = valueWidth;
         }
      }

      int totalWidth = maxLeftWidth + this.formatUtil.getTopColumnGapWidth() + maxValueWidth;
      Map<Integer, String> formatted = new LinkedHashMap<>();

      for (int rank = 1; rank <= 10; rank++) {
         String rankString = this.formatUtil.rank(rank);
         if (rank - 1 < sorted.size()) {
            Entry<String, Double> entry = sorted.get(rank - 1);
            formatted.put(rank, this.formatUtil.buildAlignedLine(rankString, "§f" + entry.getKey(), valueParts.get(rank - 1), totalWidth));
         } else {
            formatted.put(rank, rankString + "  ");
         }
      }

      this.lastFormattedData = Collections.unmodifiableMap(formatted);
   }

   private String signature(Map<String, TopsDatabase.TopEntry> dbData) {
      if (dbData != null && !dbData.isEmpty()) {
         StringBuilder builder = new StringBuilder(dbData.size() * 32);
         int copied = 0;

         for (Entry<String, TopsDatabase.TopEntry> entry : dbData.entrySet()) {
            TopsDatabase.TopEntry value = entry.getValue();
            if (value != null) {
               builder.append(entry.getKey()).append(':').append(value.name).append('=').append(Math.max(0.0, value.value)).append(';');
               if (++copied >= 10) {
                  break;
               }
            }
         }

         return builder.length() == 0 ? "empty" : builder.toString();
      } else {
         return "empty";
      }
   }

   @Override
   public Map<Integer, String> getFormattedTop() {
      return this.lastFormattedData;
   }

   @Override
   public String getType() {
      return "eco";
   }
}
