package cs.cloudstudio.manager.impl;

import cs.cloudstudio.manager.ITopsManager;
import cs.cloudstudio.util.FormatUtil;
import java.awt.Color;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.plugin.Plugin;

public final class EloTop implements ITopsManager {
   private static final int GRADIENT_CACHE_LIMIT = 512;
   private static final Color[] TWO_DIGIT_COLORS = new Color[]{new Color(250, 123, 26), new Color(250, 90, 39)};
   private static final Color[] THREE_DIGIT_COLORS = new Color[]{new Color(253, 157, 13), new Color(250, 123, 26), new Color(250, 90, 39)};
   private static final Color[] LONG_COLORS = new Color[]{new Color(239, 162, 8), new Color(239, 125, 23), new Color(239, 108, 31), new Color(239, 90, 38)};
   private final FormatUtil formatUtil;
   private final Plugin sourcePlugin;
   private final Map<String, String> gradientCache = new ConcurrentHashMap<>();
   private volatile Map<Integer, String> lastFormattedData = Collections.emptyMap();
   private volatile String lastSignature = "";
   private volatile boolean dataAvailable;
   private volatile String lastError = "";

   public EloTop(FormatUtil formatUtil, Plugin sourcePlugin) {
      this.formatUtil = formatUtil;
      this.sourcePlugin = sourcePlugin;
   }

   @Override
   public void updateFormatted() {
      List<EloTop.Entry> entries = this.readTop();
      this.dataAvailable = !entries.isEmpty();
      String signature = this.signature(entries);
      if (!signature.equals(this.lastSignature) || this.lastFormattedData.isEmpty()) {
         int maxLeftWidth = 0;
         int maxValueWidth = 0;
         List<String> valueParts = new ArrayList<>(entries.size());

         for (int rank = 1; rank <= entries.size(); rank++) {
            EloTop.Entry entry = entries.get(rank - 1);
            String valuePart = this.applyDynamicGradient(this.formatNumber(entry.elo));
            valueParts.add(valuePart);
            int leftWidth = this.formatUtil.getStringWidth(this.formatUtil.rank(rank) + " §f" + entry.name);
            if (leftWidth > maxLeftWidth) {
               maxLeftWidth = leftWidth;
            }

            int valueWidth = this.formatUtil.getStringWidth(valuePart);
            if (valueWidth > maxValueWidth) {
               maxValueWidth = valueWidth;
            }
         }

         int totalWidth = maxLeftWidth + this.formatUtil.getTopColumnGapWidth() + maxValueWidth;
         Map<Integer, String> formatted = new LinkedHashMap<>();

         for (int rank = 1; rank <= 10; rank++) {
            String rankString = this.formatUtil.rank(rank);
            if (rank - 1 < entries.size()) {
               EloTop.Entry entry = entries.get(rank - 1);
               formatted.put(rank, this.formatUtil.buildAlignedLine(rankString, "§f" + entry.name, valueParts.get(rank - 1), totalWidth));
            } else {
               formatted.put(rank, rankString + "  ");
            }
         }

         this.lastFormattedData = Collections.unmodifiableMap(formatted);
         this.lastSignature = signature;
      }
   }

   private List<EloTop.Entry> readTop() {
      Plugin plugin = this.sourcePlugin;
      if (plugin != null && plugin.isEnabled()) {
         try {
            Method getApi = plugin.getClass().getMethod("getApi");
            Object api = getApi.invoke(plugin);
            if (api == null) {
               this.lastError = "CloudElo API ещё не опубликован";
               return Collections.emptyList();
            }

            try {
               Method isTopReady = api.getClass().getMethod("isTopReady");
               Object ready = isTopReady.invoke(api);
               if (ready instanceof Boolean && !(Boolean)ready) {
                  this.lastError = "CloudElo top cache ещё не готов";
                  return Collections.emptyList();
               }
            } catch (NoSuchMethodException var15) {
            }

            Method getTop = api.getClass().getMethod("getTop", int.class);
            if (!(getTop.invoke(api, 10) instanceof List<?> source)) {
               this.lastError = "CloudElo API вернул некорректный тип топа";
               return Collections.emptyList();
            } else {
               if (source.isEmpty()) {
                  this.lastError = "CloudElo top cache готов, но содержит 0 записей";
                  return Collections.emptyList();
               }

               this.lastError = "";
               List<EloTop.Entry> result = new ArrayList<>(Math.min(10, source.size()));

               for (Object rawEntry : source) {
                  if (rawEntry != null && result.size() < 10) {
                     Method getName = rawEntry.getClass().getMethod("getName");
                     Method getElo = rawEntry.getClass().getMethod("getElo");
                     Object rawName = getName.invoke(rawEntry);
                     Object rawElo = getElo.invoke(rawEntry);
                     if (rawName instanceof String && rawElo instanceof Number) {
                        String name = ((String)rawName).trim();
                        if (!name.isEmpty()) {
                           result.add(new EloTop.Entry(name, Math.max(0, ((Number)rawElo).intValue())));
                        }
                     }
                  }
               }

               return result;
            }
         } catch (Throwable throwable) {
            this.lastError = rootMessage(throwable);
            return Collections.emptyList();
         }
      } else {
         return Collections.emptyList();
      }
   }

   public void requestSourceRefresh() {
      Plugin plugin = this.sourcePlugin;
      if (plugin != null && plugin.isEnabled()) {
         try {
            Method getApi = plugin.getClass().getMethod("getApi");
            Object api = getApi.invoke(plugin);
            if (api == null) {
               return;
            }

            try {
               Method request = api.getClass().getMethod("requestTopRefresh");
               request.invoke(api);
            } catch (NoSuchMethodException ignored) {
               Method refresh = api.getClass().getMethod("getTop", int.class);
               refresh.invoke(api, 10);
            }
         } catch (Throwable throwable) {
            this.lastError = rootMessage(throwable);
         }
      }
   }

   private static String rootMessage(Throwable throwable) {
      Throwable current = throwable;

      while (current.getCause() != null && current.getCause() != current) {
         current = current.getCause();
      }

      String message = current.getMessage();
      return current.getClass().getSimpleName() + (message != null && !message.isEmpty() ? ": " + message : "");
   }

   private String signature(List<EloTop.Entry> entries) {
      StringBuilder builder = new StringBuilder(entries.size() * 24);

      for (EloTop.Entry entry : entries) {
         builder.append(entry.name).append('=').append(entry.elo).append(';');
      }

      return builder.toString();
   }

   private String formatNumber(long value) {
      if (value < 1000L) {
         return Long.toString(value);
      }

      String digits = Long.toString(value);
      StringBuilder builder = new StringBuilder(digits.length() + digits.length() / 3);
      int first = digits.length() % 3;
      if (first == 0) {
         first = 3;
      }

      builder.append(digits, 0, first);

      for (int index = first; index < digits.length(); index += 3) {
         builder.append(',').append(digits, index, index + 3);
      }

      return builder.toString();
   }

   private String applyDynamicGradient(String value) {
      int length = value.length();
      if (length <= 1) {
         return "§f" + value;
      }

      if (this.gradientCache.size() > 512) {
         this.gradientCache.clear();
      }

      return this.gradientCache.computeIfAbsent(value, key -> {
         if (length == 2) {
            return this.applyMultiColorGradient(key, TWO_DIGIT_COLORS);
         } else {
            return length == 3 ? this.applyMultiColorGradient(key, THREE_DIGIT_COLORS) : this.applyMultiColorGradient(key, LONG_COLORS);
         }
      });
   }

   private String applyMultiColorGradient(String text, Color... colors) {
      StringBuilder builder = new StringBuilder();
      int length = text.length();
      if (length == 1) {
         return ChatColor.of(colors[0]) + text;
      }

      float step = (float)(colors.length - 1) / (length - 1);

      for (int index = 0; index < length; index++) {
         float colorIndex = index * step;
         int first = (int)colorIndex;
         int second = Math.min(colors.length - 1, first + 1);
         float ratio = colorIndex - first;
         Color color = this.interpolateColor(colors[first], colors[second], ratio);
         builder.append(ChatColor.of(color)).append(text.charAt(index));
      }

      return builder.toString();
   }

   private Color interpolateColor(Color first, Color second, float ratio) {
      int red = (int)(first.getRed() + ratio * (second.getRed() - first.getRed()));
      int green = (int)(first.getGreen() + ratio * (second.getGreen() - first.getGreen()));
      int blue = (int)(first.getBlue() + ratio * (second.getBlue() - first.getBlue()));
      return new Color(red, green, blue);
   }

   public boolean hasData() {
      return this.dataAvailable;
   }

   public String getLastError() {
      return this.lastError;
   }

   @Override
   public Map<Integer, String> getFormattedTop() {
      return this.lastFormattedData;
   }

   @Override
   public String getType() {
      return "elo";
   }

   private static final class Entry {
      private final String name;
      private final int elo;

      private Entry(String name, int elo) {
         this.name = name;
         this.elo = elo;
      }
   }
}
