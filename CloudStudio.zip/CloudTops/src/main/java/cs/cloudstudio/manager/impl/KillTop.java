package cs.cloudstudio.manager.impl;

import cs.cloudstudio.database.impl.TopsDatabase;
import cs.cloudstudio.manager.ITopsManager;
import cs.cloudstudio.util.FormatUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.md_5.bungee.api.ChatColor;

public class KillTop implements ITopsManager {
   private static final int GRADIENT_CACHE_LIMIT = 512;
   private static final Color[] TWO_DIGIT_COLORS = new Color[]{new Color(250, 123, 26), new Color(250, 90, 39)};
   private static final Color[] THREE_DIGIT_COLORS = new Color[]{new Color(253, 157, 13), new Color(250, 123, 26), new Color(250, 90, 39)};
   private static final Color[] LONG_COLORS = new Color[]{new Color(239, 162, 8), new Color(239, 125, 23), new Color(239, 108, 31), new Color(239, 90, 38)};
   private final FormatUtil formatUtil;
   private final Map<String, String> gradientCache = new ConcurrentHashMap<>();
   private final Map<String, Integer> topData = new LinkedHashMap<>();
   private volatile Map<Integer, String> lastFormattedData = Collections.emptyMap();
   private volatile String lastSignature = "";

   public KillTop(FormatUtil formatUtil) {
      this.formatUtil = formatUtil;
   }

   public void updateFromDatabase(Map<String, TopsDatabase.TopEntry> dbData) {
      String signature = this.signature(dbData);
      if (!signature.equals(this.lastSignature) || this.lastFormattedData.isEmpty()) {
         this.topData.clear();
         if (dbData != null) {
            int copied = 0;

            for (TopsDatabase.TopEntry entry : dbData.values()) {
               if (entry != null && entry.name != null && !entry.name.isEmpty()) {
                  this.topData.put(entry.name, Math.max(0, (int)Math.round(entry.value)));
                  if (++copied >= 10) {
                     break;
                  }
               }
            }
         }

         this.updateFormatted();
         this.lastSignature = signature;
      }
   }

   @Override
   public void updateFormatted() {
      List<Entry<String, Integer>> sorted = new ArrayList<>(this.topData.entrySet());
      sorted.sort((first, second) -> Integer.compare(second.getValue(), first.getValue()));

      while (sorted.size() > 10) {
         sorted.remove(sorted.size() - 1);
      }

      int maxLeftWidth = 0;
      int maxValueWidth = 0;
      List<String> valueParts = new ArrayList<>(sorted.size());

      for (int rank = 1; rank <= sorted.size(); rank++) {
         Entry<String, Integer> entry = sorted.get(rank - 1);
         String value = this.formatNumber(Math.max(0, entry.getValue()));
         String valuePart = this.applyDynamicGradient(value);
         valueParts.add(valuePart);
         int leftWidth = this.formatUtil.getStringWidth(this.formatUtil.rank(rank) + " §f" + entry.getKey());
         if (leftWidth > maxLeftWidth) {
            maxLeftWidth = leftWidth;
         }

         int valueWidth = this.formatUtil.getStringWidth(valuePart);
         if (valueWidth > maxValueWidth) {
            maxValueWidth = valueWidth;
         }
      }

      int totalWidth = maxLeftWidth + this.formatUtil.getTopColumnGapWidth() + maxValueWidth;
      Map<Integer, String> formatted = new LinkedHashMap<>();

      for (int rank = 1; rank <= 10; rank++) {
         String rankString = this.formatUtil.rank(rank);
         if (rank - 1 < sorted.size()) {
            Entry<String, Integer> entry = sorted.get(rank - 1);
            formatted.put(rank, this.formatUtil.buildAlignedLine(rankString, "§f" + entry.getKey(), valueParts.get(rank - 1), totalWidth));
         } else {
            formatted.put(rank, rankString + "  ");
         }
      }

      this.lastFormattedData = Collections.unmodifiableMap(formatted);
   }

   private String applyDynamicGradient(String value) {
      int length = value.length();
      if (length <= 1) {
         return "§f" + value;
      }

      if (this.gradientCache.size() > 512) {
         this.gradientCache.clear();
      }

      return this.gradientCache.computeIfAbsent(value, key -> {
         if (length == 2) {
            return this.applyMultiColorGradient(key, TWO_DIGIT_COLORS);
         } else {
            return length == 3 ? this.applyMultiColorGradient(key, THREE_DIGIT_COLORS) : this.applyMultiColorGradient(key, LONG_COLORS);
         }
      });
   }

   private String signature(Map<String, TopsDatabase.TopEntry> dbData) {
      if (dbData != null && !dbData.isEmpty()) {
         StringBuilder builder = new StringBuilder(dbData.size() * 32);
         int copied = 0;

         for (Entry<String, TopsDatabase.TopEntry> entry : dbData.entrySet()) {
            TopsDatabase.TopEntry value = entry.getValue();
            if (value != null) {
               builder.append(entry.getKey()).append(':').append(value.name).append('=').append(Math.max(0, (int)Math.round(value.value))).append(';');
               if (++copied >= 10) {
                  break;
               }
            }
         }

         return builder.length() == 0 ? "empty" : builder.toString();
      } else {
         return "empty";
      }
   }

   private String formatNumber(long value) {
      if (value < 1000L) {
         return Long.toString(value);
      }

      String digits = Long.toString(value);
      StringBuilder builder = new StringBuilder(digits.length() + digits.length() / 3);
      int first = digits.length() % 3;
      if (first == 0) {
         first = 3;
      }

      builder.append(digits, 0, first);

      for (int index = first; index < digits.length(); index += 3) {
         builder.append(',').append(digits, index, index + 3);
      }

      return builder.toString();
   }

   private String applyMultiColorGradient(String text, Color... colors) {
      StringBuilder builder = new StringBuilder();
      int length = text.length();
      if (length == 1) {
         return ChatColor.of(colors[0]) + text;
      }

      float step = (float)(colors.length - 1) / (length - 1);

      for (int index = 0; index < length; index++) {
         float colorIndex = index * step;
         int first = (int)colorIndex;
         int second = Math.min(colors.length - 1, first + 1);
         float ratio = colorIndex - first;
         Color color = this.interpolateColor(colors[first], colors[second], ratio);
         builder.append(ChatColor.of(color)).append(text.charAt(index));
      }

      return builder.toString();
   }

   private Color interpolateColor(Color first, Color second, float ratio) {
      int red = (int)(first.getRed() + ratio * (second.getRed() - first.getRed()));
      int green = (int)(first.getGreen() + ratio * (second.getGreen() - first.getGreen()));
      int blue = (int)(first.getBlue() + ratio * (second.getBlue() - first.getBlue()));
      return new Color(red, green, blue);
   }

   @Override
   public Map<Integer, String> getFormattedTop() {
      return this.lastFormattedData;
   }

   @Override
   public String getType() {
      return "kills";
   }
}
