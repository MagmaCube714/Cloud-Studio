package cs.cloudstudio.manager.placeholder;

import cs.cloudstudio.listener.ResourcePackListener;
import cs.cloudstudio.manager.TopManager;
import java.util.Locale;
import java.util.Map;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.clip.placeholderapi.expansion.Relational;
import org.bukkit.entity.Player;

public class TopPlaceholder extends PlaceholderExpansion implements Relational {
   private final TopManager topManager;
   private final ResourcePackListener resourcePackListener;

   public TopPlaceholder(TopManager topManager, ResourcePackListener resourcePackListener) {
      this.topManager = topManager;
      this.resourcePackListener = resourcePackListener;
   }

   public String getIdentifier() {
      return "cloudtops";
   }

   public String getAuthor() {
      return "cloudtops";
   }

   public String getVersion() {
      return "1";
   }

   public boolean persist() {
      return true;
   }

   public String onPlaceholderRequest(Player player, String params) {
      return this.resolvePlaceholder(player, params);
   }

   public String onPlaceholderRequest(Player one, Player two, String params) {
      Player viewer = one != null ? one : two;
      return this.resolvePlaceholder(viewer, params);
   }

   private String resolvePlaceholder(Player viewer, String params) {
      if (params != null && !params.isEmpty()) {
         String lower = params.toLowerCase(Locale.ROOT);
         int underscore = lower.lastIndexOf(95);
         if (underscore > 0 && underscore + 1 < lower.length()) {
            String type = lower.substring(0, underscore);

            int rank;
            try {
               rank = Integer.parseInt(lower.substring(underscore + 1));
            } catch (NumberFormatException ignored) {
               return null;
            }

            if (rank >= 1 && rank <= 10) {
               boolean resourcePack = this.resourcePackListener != null && this.resourcePackListener.hasResourcePack(viewer);
               Map<Integer, String> top = this.topManager.getFormattedTop(type, resourcePack);
               String result = top.get(rank);
               if (result != null) {
                  return result;
               } else {
                  return resourcePack ? (rank == 10 ? "§c#10  " : "§cꅅ#" + rank + "  ") : "§c#" + rank + "  ";
               }
            } else {
               return null;
            }
         } else {
            return null;
         }
      } else {
         return null;
      }
   }
}
