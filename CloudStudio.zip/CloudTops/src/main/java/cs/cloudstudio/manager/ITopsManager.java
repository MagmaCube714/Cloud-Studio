package cs.cloudstudio.manager;

import java.util.Map;

public interface ITopsManager {
   void updateFormatted();

   Map<Integer, String> getFormattedTop();

   String getType();

   default int getCustomUpdateInterval() {
      return -1;
   }
}
