package cs.cloudstudio.manager.impl;

import cs.cloudstudio.clans.api.ClansAPI;
import cs.cloudstudio.clans.api.ClansAPI.ClanInfo;
import cs.cloudstudio.manager.ITopsManager;
import cs.cloudstudio.util.FormatUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class ClanTop implements ITopsManager {
   private final FormatUtil formatUtil;
   private volatile Map<Integer, String> lastFormattedData = Collections.emptyMap();
   private volatile String lastSignature = "";

   public ClanTop(FormatUtil formatUtil) {
      this.formatUtil = formatUtil;
   }

   @Override
   public void updateFormatted() {
      List<ClanTop.TopEntry> entries = this.readFromClans();
      if (entries.isEmpty()) {
         entries = this.readFromPlaceholders();
      }

      entries = this.fillMissingEntries(entries);
      String signature = this.signature(entries);
      if (!signature.equals(this.lastSignature) || this.lastFormattedData.isEmpty()) {
         int maxLeftWidth = 0;
         int maxValueWidth = 0;

         for (int index = 0; index < entries.size(); index++) {
            int rank = index + 1;
            ClanTop.TopEntry entry = entries.get(index);
            String valuePart = "§7" + entry.value + "§r ꐆ";
            int leftWidth = this.formatUtil.getStringWidth(this.formatUtil.rank(rank) + " §r" + entry.name + "§r");
            if (leftWidth > maxLeftWidth) {
               maxLeftWidth = leftWidth;
            }

            int valueWidth = this.formatUtil.getStringWidth(valuePart);
            if (valueWidth > maxValueWidth) {
               maxValueWidth = valueWidth;
            }
         }

         int totalWidth = maxLeftWidth + this.formatUtil.getTopColumnGapWidth() + maxValueWidth;
         Map<Integer, String> formatted = new LinkedHashMap<>();

         for (int rank = 1; rank <= 10; rank++) {
            String rankString = this.formatUtil.rank(rank);
            ClanTop.TopEntry entry = entries.get(rank - 1);
            formatted.put(rank, this.formatUtil.buildAlignedLine(rankString, "§r" + entry.name + "§r", "§7" + entry.value + "§r ꐆ", totalWidth));
         }

         this.lastFormattedData = Collections.unmodifiableMap(formatted);
         this.lastSignature = signature;
      }
   }

   private List<ClanTop.TopEntry> readFromPlaceholders() {
      if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") == null) {
         return Collections.emptyList();
      }

      List<ClanTop.TopEntry> result = new ArrayList<>(10);

      for (int rank = 1; rank <= 10; rank++) {
         String name = this.requestPlaceholder("%cloudclans_clan_top_name_" + rank + "%§r");
         String level = this.requestPlaceholder("%cloudclans_clan_top_level_" + rank + "%§r");
         if (!this.isInvalidPlaceholder(name, "%cloudclans_clan_top_name_" + rank + "%§r")
            && !this.isInvalidPlaceholder(level, "%cloudclans_clan_top_level_" + rank + "%§r")) {
            result.add(new ClanTop.TopEntry(name, level));
         }
      }

      return result;
   }

   private Plugin findPlugin(String... names) {
      for (String name : names) {
         Plugin plugin = Bukkit.getPluginManager().getPlugin(name);
         if (plugin != null && plugin.isEnabled()) {
            return plugin;
         }
      }

      return null;
   }

   private String requestPlaceholder(String placeholder) {
      try {
         String value = PlaceholderAPI.setPlaceholders((Player)null, placeholder);
         return value == null ? "" : value.trim();
      } catch (Throwable ignored) {
         return "";
      }
   }

   private boolean isInvalidPlaceholder(String value, String placeholder) {
      if (value == null) {
         return true;
      }

      String clean = value.replace("§r", "").trim();
      String cleanPlaceholder = placeholder.replace("§r", "").trim();
      return clean.isEmpty() || clean.contains("%") || clean.equalsIgnoreCase(cleanPlaceholder);
   }

   private List<ClanTop.TopEntry> readFromClans() {
      if (!ClansAPI.isAvailable()) {
         return Collections.emptyList();
      }

      List<ClanInfo> clans = ClansAPI.topClans(10);
      List<ClanTop.TopEntry> result = new ArrayList<>(clans.size());

      for (ClanInfo clan : clans) {
         String color = clan.getColor();
         result.add(new ClanTop.TopEntry(ClansAPI.colorize(color + clan.getName()), ClansAPI.colorize(color + clan.getLevel())));
      }

      return result;
   }

   private List<ClanTop.TopEntry> fillMissingEntries(List<ClanTop.TopEntry> source) {
      List<ClanTop.TopEntry> result = new ArrayList<>(10);
      if (source != null) {
         for (ClanTop.TopEntry entry : source) {
            if (entry != null && result.size() < 10) {
               result.add(entry);
            }
         }
      }

      while (result.size() < 10) {
         result.add(new ClanTop.TopEntry("§7Loading..", "0"));
      }

      return result;
   }

   private String signature(List<ClanTop.TopEntry> entries) {
      StringBuilder builder = new StringBuilder(entries.size() * 20);

      for (ClanTop.TopEntry entry : entries) {
         builder.append(entry.name).append('=').append(entry.value).append(';');
      }

      return builder.toString();
   }

   @Override
   public Map<Integer, String> getFormattedTop() {
      return this.lastFormattedData;
   }

   @Override
   public String getType() {
      return "clan";
   }

   private static final class TopEntry {
      private final String name;
      private final String value;

      private TopEntry(String name, String value) {
         this.name = name;
         this.value = value;
      }
   }
}
