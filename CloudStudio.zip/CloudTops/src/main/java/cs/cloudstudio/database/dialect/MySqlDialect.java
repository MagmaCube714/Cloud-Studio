package cs.cloudstudio.database.dialect;

public final class MySqlDialect implements SqlDialect {
   @Override
   public String createTable(String table) {
      return "CREATE TABLE IF NOT EXISTS "
         + table
         + "(uuid VARCHAR(40) NOT NULL PRIMARY KEY,name VARCHAR(32) NOT NULL DEFAULT '',balance DOUBLE NOT NULL DEFAULT 0,kills INT NOT NULL DEFAULT 0,playtime BIGINT NOT NULL DEFAULT 0,updated_at BIGINT NOT NULL DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
   }

   @Override
   public String createBalanceIndex(String table) {
      return "CREATE INDEX player_tops_balance_index ON " + table + "(balance DESC, updated_at DESC)";
   }

   @Override
   public String createKillsIndex(String table) {
      return "CREATE INDEX player_tops_kills_index ON " + table + "(kills DESC, updated_at DESC)";
   }

   @Override
   public String createPlaytimeIndex(String table) {
      return "CREATE INDEX player_tops_playtime_index ON " + table + "(playtime DESC, updated_at DESC)";
   }

   @Override
   public String upsert(String table) {
      return "INSERT INTO "
         + table
         + "(uuid, name, balance, kills, playtime, updated_at) VALUES(?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = CASE WHEN VALUES(updated_at) >= updated_at THEN VALUES(name) ELSE name END, balance = CASE WHEN VALUES(updated_at) >= updated_at AND VALUES(balance) >= 0 THEN VALUES(balance) ELSE balance END, kills = CASE WHEN VALUES(updated_at) >= updated_at AND VALUES(kills) >= 0 THEN VALUES(kills) ELSE kills END, playtime = CASE WHEN VALUES(updated_at) >= updated_at AND VALUES(playtime) >= 0 THEN VALUES(playtime) ELSE playtime END, updated_at = GREATEST(updated_at, VALUES(updated_at))";
   }

   @Override
   public String topComparator(boolean includeZero) {
      return includeZero ? " >= 0" : " > 0";
   }

   @Override
   public String orderByName() {
      return " ASC";
   }

   @Override
   public boolean supportsPragma() {
      return false;
   }
}
