package cs.cloudstudio.database.dialect;

public final class SqliteDialect implements SqlDialect {
   @Override
   public String createTable(String table) {
      return "CREATE TABLE IF NOT EXISTS "
         + table
         + "(uuid TEXT PRIMARY KEY,name TEXT NOT NULL DEFAULT '',balance REAL NOT NULL DEFAULT 0,kills INTEGER NOT NULL DEFAULT 0,playtime INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL DEFAULT 0)";
   }

   @Override
   public String createBalanceIndex(String table) {
      return "CREATE INDEX IF NOT EXISTS player_tops_balance_index ON " + table + "(balance DESC, updated_at DESC)";
   }

   @Override
   public String createKillsIndex(String table) {
      return "CREATE INDEX IF NOT EXISTS player_tops_kills_index ON " + table + "(kills DESC, updated_at DESC)";
   }

   @Override
   public String createPlaytimeIndex(String table) {
      return "CREATE INDEX IF NOT EXISTS player_tops_playtime_index ON " + table + "(playtime DESC, updated_at DESC)";
   }

   @Override
   public String upsert(String table) {
      return "INSERT INTO "
         + table
         + "(uuid, name, balance, kills, playtime, updated_at) VALUES(?, ?, ?, ?, ?, ?) ON CONFLICT(uuid) DO UPDATE SET name = CASE WHEN excluded.updated_at >= "
         + table
         + ".updated_at THEN excluded.name ELSE "
         + table
         + ".name END, balance = CASE WHEN excluded.updated_at >= "
         + table
         + ".updated_at AND excluded.balance >= 0 THEN excluded.balance ELSE "
         + table
         + ".balance END, kills = CASE WHEN excluded.updated_at >= "
         + table
         + ".updated_at AND excluded.kills >= 0 THEN excluded.kills ELSE "
         + table
         + ".kills END, playtime = CASE WHEN excluded.updated_at >= "
         + table
         + ".updated_at AND excluded.playtime >= 0 THEN excluded.playtime ELSE "
         + table
         + ".playtime END, updated_at = MAX("
         + table
         + ".updated_at, excluded.updated_at)";
   }

   @Override
   public String topComparator(boolean includeZero) {
      return includeZero ? " >= 0" : " > 0";
   }

   @Override
   public String orderByName() {
      return " COLLATE NOCASE ASC";
   }

   @Override
   public boolean supportsPragma() {
      return true;
   }
}
