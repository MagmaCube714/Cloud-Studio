package cs.cloudstudio.database.config;

import java.util.Locale;

public enum DatabaseType {
   SQLITE,
   MYSQL;

   public static DatabaseType from(String value) {
      if (value == null) {
         return SQLITE;
      }

      String normalized = value.trim().toLowerCase(Locale.ROOT);
      return !"mysql".equals(normalized) && !"mariadb".equals(normalized) ? SQLITE : MYSQL;
   }
}
