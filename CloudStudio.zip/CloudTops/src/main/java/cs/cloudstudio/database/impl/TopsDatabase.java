package cs.cloudstudio.database.impl;

import com.zaxxer.hikari.HikariDataSource;
import cs.cloudstudio.database.Database;
import cs.cloudstudio.database.config.DataSourceFactory;
import cs.cloudstudio.database.config.DatabaseSettings;
import cs.cloudstudio.database.config.DatabaseType;
import cs.cloudstudio.database.dialect.MySqlDialect;
import cs.cloudstudio.database.dialect.SqlDialect;
import cs.cloudstudio.database.dialect.SqliteDialect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import org.bukkit.plugin.java.JavaPlugin;

public final class TopsDatabase extends Database {
   private static final int MAX_QUERY_LIMIT = 100000;
   private static final int MAX_FLUSH_BATCH_SIZE = 256;
   private static final int QUERY_TIMEOUT_SECONDS = 5;
   private static final String TABLE = "player_tops";
   private static final long FLUSH_INTERVAL_SECONDS = 5L;
   private final JavaPlugin plugin;
   private final ReentrantLock flushLock = new ReentrantLock();
   private final Map<String, TopsDatabase.PlayerData> pendingData = new ConcurrentHashMap<>();
   private final AtomicBoolean closing = new AtomicBoolean();
   private volatile DatabaseSettings settings;
   private volatile SqlDialect dialect;
   private volatile HikariDataSource dataSource;
   private volatile ScheduledExecutorService scheduler;
   private volatile ScheduledFuture<?> flushTask;
   private volatile boolean connected;

   public TopsDatabase(JavaPlugin plugin) {
      this.plugin = plugin;
   }

   @Override
   protected void connectImpl() {
      if (!this.connected) {
         try {
            this.settings = DatabaseSettings.load(this.plugin);
            this.dialect = this.settings.getType() == DatabaseType.MYSQL ? new MySqlDialect() : new SqliteDialect();
            this.loadDriver(this.settings.getType());
            this.dataSource = DataSourceFactory.create(this.plugin, this.settings);
            this.createOrMigrateTable();
            this.closing.set(false);
            this.connected = true;
            this.startFlushScheduler();
         } catch (Throwable exception) {
            this.connected = false;
            this.closeDataSource();
            this.plugin.getLogger().warning("[CloudTops] База данных не подключена: " + exception.getMessage());
         }
      }
   }

   @Override
   protected void disconnectImpl() {
      this.disconnectAsync(null);
   }

   public void disconnectAsync(Runnable completion) {
      if (this.closing.compareAndSet(false, true)) {
         this.stopFlushScheduler();
         Thread thread = new Thread(() -> {
            try {
               this.flush();
            } finally {
               this.connected = false;
               this.closeDataSource();
               this.pendingData.clear();
               if (completion != null && this.plugin.isEnabled()) {
                  try {
                     this.plugin.getServer().getScheduler().runTask(this.plugin, completion);
                  } catch (RuntimeException var8) {
                  }
               }
            }
         }, "CloudTops-Database-Close");
         thread.setDaemon(true);
         thread.start();
      }
   }

   @Override
   public boolean isConnected() {
      HikariDataSource source = this.dataSource;
      return this.connected && source != null && !source.isClosed();
   }

   public void queue(Map<String, TopsDatabase.PlayerData> data) {
      if (data != null && !data.isEmpty() && this.isConnected()) {
         for (Entry<String, TopsDatabase.PlayerData> entry : data.entrySet()) {
            if (entry.getKey() != null && !entry.getKey().isEmpty() && entry.getValue() != null && entry.getValue().isValid()) {
               this.pendingData.merge(entry.getKey(), entry.getValue(), TopsDatabase::mergePlayerData);
            }
         }

         this.scheduleFlush();
      }
   }

   private static TopsDatabase.PlayerData mergePlayerData(TopsDatabase.PlayerData oldData, TopsDatabase.PlayerData newData) {
      if (oldData == null) {
         return newData;
      }

      if (newData == null) {
         return oldData;
      }

      String name = newData.name != null && !newData.name.isEmpty() ? newData.name : oldData.name;
      double balance = newData.balance >= 0.0 ? newData.balance : oldData.balance;
      int kills = newData.kills >= 0 ? newData.kills : oldData.kills;
      long playtime = newData.playtime >= 0L ? newData.playtime : oldData.playtime;
      long updatedAt = Math.max(oldData.updatedAt, newData.updatedAt);
      return new TopsDatabase.PlayerData(name, balance, kills, playtime, updatedAt);
   }

   public void flush() {
      if (!this.pendingData.isEmpty() && this.isConnected()) {
         this.flushLock.lock();

         try {
            List<Entry<String, TopsDatabase.PlayerData>> snapshot = new ArrayList<>(Math.min(this.pendingData.size(), 256));

            for (Entry<String, TopsDatabase.PlayerData> entry : this.pendingData.entrySet()) {
               snapshot.add(entry);
               if (snapshot.size() >= 256) {
                  break;
               }
            }

            if (snapshot.isEmpty()) {
               return;
            }

            try (Connection connection = this.dataSource.getConnection()) {
               connection.setAutoCommit(false);

               try (PreparedStatement statement = connection.prepareStatement(this.dialect.upsert("player_tops"))) {
                  statement.setQueryTimeout(5);

                  for (Entry<String, TopsDatabase.PlayerData> entry : snapshot) {
                     String uuid = entry.getKey();
                     TopsDatabase.PlayerData playerData = entry.getValue();
                     if (uuid != null && !uuid.isEmpty() && playerData != null && playerData.isValid()) {
                        statement.setString(1, uuid);
                        statement.setString(2, playerData.name);
                        statement.setDouble(3, playerData.balance);
                        statement.setInt(4, playerData.kills);
                        statement.setLong(5, playerData.playtime);
                        statement.setLong(6, playerData.updatedAt);
                        statement.addBatch();
                     }
                  }

                  statement.executeBatch();
                  connection.commit();

                  for (Entry<String, TopsDatabase.PlayerData> entry : snapshot) {
                     this.pendingData.remove(entry.getKey(), entry.getValue());
                  }
               } catch (SQLException exception) {
                  this.rollback(connection);
                  this.plugin.getLogger().warning("[CloudTops] Сохранение данных топов не выполнено: " + exception.getMessage());
               }
            } catch (SQLException exception) {
               this.plugin.getLogger().warning("[CloudTops] Соединение базы данных недоступно при сохранении топов: " + exception.getMessage());
            }
         } finally {
            this.flushLock.unlock();
         }
      }
   }

   public Map<String, String> getKnownNames() {
      return this.getKnownNames(100000);
   }

   public Map<String, String> getKnownNames(int limit) {
      if (!this.isConnected()) {
         return Collections.emptyMap();
      }

      int queryLimit = Math.min(Math.max(1, limit), 100000);

      try (
         Connection connection = this.dataSource.getConnection();
         PreparedStatement statement = connection.prepareStatement("SELECT uuid, name FROM player_tops WHERE name <> '' ORDER BY updated_at DESC LIMIT ?");
      ) {
         statement.setQueryTimeout(5);
         statement.setInt(1, queryLimit);

         try (ResultSet set = statement.executeQuery()) {
            Map<String, String> result = new HashMap<>(Math.min(queryLimit, 4096));

            while (set.next()) {
               String uuid = set.getString("uuid");
               String name = set.getString("name");
               if (uuid != null && !uuid.isEmpty() && name != null && !name.isEmpty()) {
                  result.put(uuid, name);
               }
            }

            return result;
         }
      } catch (SQLException exception) {
         this.plugin.getLogger().warning("[CloudTops] Имена игроков не загружены из базы данных: " + exception.getMessage());
         return Collections.emptyMap();
      }
   }

   public Map<String, String> getKnownPlayersForScan(int limit) {
      if (this.isConnected() && limit > 0) {
         int queryLimit = Math.min(limit, 100000);

         try (
            Connection connection = this.dataSource.getConnection();
            PreparedStatement statement = connection.prepareStatement("SELECT uuid, name FROM player_tops WHERE name <> '' ORDER BY updated_at DESC LIMIT ?");
         ) {
            statement.setQueryTimeout(5);
            statement.setInt(1, queryLimit);

            try (ResultSet set = statement.executeQuery()) {
               Map<String, String> result = new LinkedHashMap<>(Math.min(queryLimit, 4096));

               while (set.next()) {
                  String uuid = set.getString("uuid");
                  String name = set.getString("name");
                  if (uuid != null && !uuid.isEmpty() && name != null && !name.isEmpty()) {
                     result.put(uuid, name);
                  }
               }

               return result;
            }
         } catch (SQLException exception) {
            this.plugin.getLogger().warning("[CloudTops] Список игроков для сканирования не загружен: " + exception.getMessage());
            return Collections.emptyMap();
         }
      } else {
         return Collections.emptyMap();
      }
   }

   public Map<String, TopsDatabase.TopEntry> getTopBalance(int limit) {
      return this.selectTop("balance", limit, true);
   }

   public Map<String, TopsDatabase.TopEntry> getTopKills(int limit) {
      return this.selectTop("kills", limit, true);
   }

   public Map<String, TopsDatabase.TopEntry> getTopPlaytime(int limit) {
      return this.selectTop("playtime", limit, true);
   }

   public Map<String, Map<String, TopsDatabase.TopEntry>> getTops(int limit) {
      if (limit > 0 && this.isConnected()) {
         Map<String, Map<String, TopsDatabase.TopEntry>> result = new LinkedHashMap<>();
         result.put("balance", this.getTopBalance(limit));
         result.put("kills", this.getTopKills(limit));
         result.put("playtime", this.getTopPlaytime(limit));
         return result;
      } else {
         return Collections.emptyMap();
      }
   }

   private Map<String, TopsDatabase.TopEntry> selectTop(String column, int requestedLimit, boolean includeZero) {
      if (this.isAllowedColumn(column) && requestedLimit > 0 && this.isConnected()) {
         int limit = Math.min(requestedLimit, 100000);
         String sql = "SELECT uuid, name, "
            + column
            + " AS value FROM player_tops WHERE name <> '' AND "
            + column
            + this.dialect.topComparator(includeZero)
            + " ORDER BY "
            + column
            + " DESC, updated_at DESC, name"
            + this.dialect.orderByName()
            + " LIMIT ?";

         try (
            Connection connection = this.dataSource.getConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
         ) {
            statement.setQueryTimeout(5);
            statement.setInt(1, limit);

            try (ResultSet set = statement.executeQuery()) {
               Map<String, TopsDatabase.TopEntry> result = new LinkedHashMap<>(Math.min(limit, 16));

               while (set.next()) {
                  String uuid = set.getString("uuid");
                  String name = set.getString("name");
                  if (uuid != null && !uuid.isEmpty() && name != null && !name.isEmpty()) {
                     result.put(uuid, new TopsDatabase.TopEntry(uuid, name, set.getDouble("value")));
                  }
               }

               return result;
            }
         } catch (SQLException exception) {
            this.plugin.getLogger().warning("[CloudTops] Топ не загружен из базы данных: " + exception.getMessage());
            return Collections.emptyMap();
         }
      } else {
         return Collections.emptyMap();
      }
   }

   private boolean isAllowedColumn(String column) {
      return "balance".equals(column) || "kills".equals(column) || "playtime".equals(column);
   }

   private void startFlushScheduler() {
      ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor(runnable -> {
         Thread thread = new Thread(runnable, "CloudTops-Flush");
         thread.setDaemon(true);
         return thread;
      });
      this.scheduler = executor;
   }

   private synchronized void scheduleFlush() {
      ScheduledExecutorService executor = this.scheduler;
      if (this.connected && !this.pendingData.isEmpty() && executor != null && !executor.isShutdown()) {
         ScheduledFuture<?> task = this.flushTask;
         if (task == null || task.isDone()) {
            this.flushTask = executor.schedule(() -> {
               synchronized (this) {
                  this.flushTask = null;
               }

               this.flush();
               if (!this.pendingData.isEmpty()) {
                  this.scheduleFlush();
               }
            }, 5L, TimeUnit.SECONDS);
         }
      }
   }

   private void stopFlushScheduler() {
      ScheduledFuture<?> task = this.flushTask;
      if (task != null) {
         task.cancel(false);
         this.flushTask = null;
      }

      ScheduledExecutorService executor = this.scheduler;
      if (executor != null) {
         executor.shutdownNow();
         this.scheduler = null;
      }
   }

   private void createOrMigrateTable() throws SQLException {
      try (
         Connection connection = this.dataSource.getConnection();
         Statement statement = connection.createStatement();
      ) {
         statement.setQueryTimeout(5);
         if (this.dialect.supportsPragma()) {
            statement.execute("PRAGMA foreign_keys=ON");
            statement.execute("PRAGMA journal_mode=WAL");
            statement.execute("PRAGMA synchronous=NORMAL");
            statement.execute("PRAGMA busy_timeout=5000");
         }

         statement.executeUpdate(this.dialect.createTable("player_tops"));
         this.createIndexQuietly(statement, this.dialect.createBalanceIndex("player_tops"));
         this.createIndexQuietly(statement, this.dialect.createKillsIndex("player_tops"));
         this.createIndexQuietly(statement, this.dialect.createPlaytimeIndex("player_tops"));
      }
   }

   private void createIndexQuietly(Statement statement, String sql) throws SQLException {
      try {
         statement.executeUpdate(sql);
      } catch (SQLException exception) {
         String state = exception.getSQLState();
         String message = exception.getMessage() == null ? "" : exception.getMessage().toLowerCase(Locale.ROOT);
         if (!"42S11".equals(state) && !message.contains("duplicate") && !message.contains("already exists")) {
            throw exception;
         }
      }
   }

   private void loadDriver(DatabaseType type) {
      try {
         Class.forName(type == DatabaseType.MYSQL ? "com.mysql.cj.jdbc.Driver" : "org.sqlite.JDBC");
      } catch (ClassNotFoundException var3) {
      }
   }

   private void rollback(Connection connection) {
      try {
         connection.rollback();
      } catch (SQLException exception) {
         this.plugin.getLogger().warning("[CloudTops] Откат транзакции базы данных не выполнен: " + exception.getMessage());
      }
   }

   private void closeDataSource() {
      HikariDataSource source = this.dataSource;
      this.dataSource = null;
      if (source != null) {
         source.close();
      }
   }

   public static final class PlayerData {
      public final String name;
      public final double balance;
      public final int kills;
      public final long playtime;
      public final long updatedAt;

      public PlayerData(String name, double balance, int kills, long playtime, long updatedAt) {
         this.name = name;
         this.balance = balance;
         this.kills = kills;
         this.playtime = playtime;
         this.updatedAt = updatedAt;
      }

      private boolean isValid() {
         return this.name != null && !this.name.isEmpty();
      }
   }

   public static final class TopEntry {
      public final String uuid;
      public final String name;
      public final double value;

      public TopEntry(String uuid, String name, double value) {
         this.uuid = uuid;
         this.name = name;
         this.value = value;
      }
   }
}
