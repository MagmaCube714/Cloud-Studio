package cs.cloudstudio.database.dialect;

public interface SqlDialect {
   String createTable(String var1);

   String createBalanceIndex(String var1);

   String createKillsIndex(String var1);

   String createPlaytimeIndex(String var1);

   String upsert(String var1);

   String topComparator(boolean var1);

   String orderByName();

   boolean supportsPragma();
}
