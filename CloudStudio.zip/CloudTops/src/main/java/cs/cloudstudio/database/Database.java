package cs.cloudstudio.database;

public abstract class Database {
   public final void connect() {
      this.connectImpl();
   }

   public final void disconnect() {
      this.disconnectImpl();
   }

   public abstract boolean isConnected();

   protected abstract void connectImpl();

   protected abstract void disconnectImpl();
}
