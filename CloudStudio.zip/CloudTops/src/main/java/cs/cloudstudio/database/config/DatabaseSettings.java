package cs.cloudstudio.database.config;

import java.io.File;
import java.util.Locale;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

public final class DatabaseSettings {
   private final DatabaseType type;
   private final String host;
   private final int port;
   private final String username;
   private final String password;
   private final String playerDatabase;
   private final File sqliteFile;

   private DatabaseSettings(DatabaseType type, String host, int port, String username, String password, String playerDatabase, File sqliteFile) {
      this.type = type;
      this.host = host;
      this.port = port;
      this.username = username;
      this.password = password;
      this.playerDatabase = playerDatabase;
      this.sqliteFile = sqliteFile;
   }

   public static DatabaseSettings load(JavaPlugin plugin) {
      ConfigurationSection section = plugin.getConfig().getConfigurationSection("database");
      DatabaseType type = DatabaseType.from(section == null ? null : section.getString("type", "SQLite"));
      String host = section == null ? "localhost" : section.getString("host", "localhost");
      int port = section == null ? 3306 : section.getInt("port", 3306);
      String username = section == null ? "admin" : section.getString("username", "admin");
      String password = section == null ? "admin" : section.getString("password", "admin");
      String database = section == null ? "data" : section.getString("playerDatabase", "data");
      String normalizedDatabase = normalizeDatabaseName(database, "data");
      File sqliteFile = new File(plugin.getDataFolder(), normalizedDatabase + ".db");
      return new DatabaseSettings(
         type,
         nullToDefault(host, "localhost"),
         Math.max(1, port),
         nullToDefault(username, "admin"),
         nullToDefault(password, "admin"),
         normalizedDatabase,
         sqliteFile
      );
   }

   private static String nullToDefault(String value, String fallback) {
      if (value == null) {
         return fallback;
      }

      String trimmed = value.trim();
      return trimmed.isEmpty() ? fallback : trimmed;
   }

   private static String normalizeDatabaseName(String value, String fallback) {
      String source = value == null ? fallback : value.trim();
      if (source.isEmpty()) {
         source = fallback;
      }

      String lower = source.toLowerCase(Locale.ROOT);
      if (lower.endsWith(".db")) {
         source = source.substring(0, source.length() - 3);
      }

      StringBuilder builder = new StringBuilder(source.length());

      for (int index = 0; index < source.length(); index++) {
         char character = source.charAt(index);
         if (character >= 'a' && character <= 'z'
            || character >= 'A' && character <= 'Z'
            || character >= '0' && character <= '9'
            || character == '_'
            || character == '-') {
            builder.append(character);
         }
      }

      return builder.length() == 0 ? fallback : builder.toString();
   }

   public DatabaseType getType() {
      return this.type;
   }

   public String getHost() {
      return this.host;
   }

   public int getPort() {
      return this.port;
   }

   public String getUsername() {
      return this.username;
   }

   public String getPassword() {
      return this.password;
   }

   public String getPlayerDatabase() {
      return this.playerDatabase;
   }

   public File getSqliteFile() {
      return this.sqliteFile;
   }
}
