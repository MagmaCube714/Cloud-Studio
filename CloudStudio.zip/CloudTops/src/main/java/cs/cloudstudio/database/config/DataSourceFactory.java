package cs.cloudstudio.database.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.io.File;
import org.bukkit.plugin.java.JavaPlugin;

public final class DataSourceFactory {
   private DataSourceFactory() {
   }

   public static HikariDataSource create(JavaPlugin plugin, DatabaseSettings settings) {
      return settings.getType() == DatabaseType.MYSQL ? createMySql(settings) : createSqlite(plugin, settings);
   }

   private static HikariDataSource createSqlite(JavaPlugin plugin, DatabaseSettings settings) {
      File folder = plugin.getDataFolder();
      if (!folder.exists() && !folder.mkdirs()) {
         throw new IllegalStateException("Cannot create plugin data folder");
      }

      HikariConfig config = new HikariConfig();
      config.setPoolName("CloudTops-SQLite");
      config.setJdbcUrl("jdbc:sqlite:" + settings.getSqliteFile().getAbsolutePath());
      config.setMaximumPoolSize(1);
      config.setMinimumIdle(1);
      config.setConnectionTimeout(3000L);
      config.setMaxLifetime(0L);
      config.setConnectionTestQuery("SELECT 1");
      return new HikariDataSource(config);
   }

   private static HikariDataSource createMySql(DatabaseSettings settings) {
      HikariConfig config = new HikariConfig();
      config.setPoolName("CloudTops-MySQL");
      config.setJdbcUrl(
         "jdbc:mysql://"
            + settings.getHost()
            + ":"
            + settings.getPort()
            + "/"
            + settings.getPlayerDatabase()
            + "?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=UTC"
      );
      config.setUsername(settings.getUsername());
      config.setPassword(settings.getPassword());
      config.setMaximumPoolSize(4);
      config.setMinimumIdle(1);
      config.setConnectionTimeout(5000L);
      config.setIdleTimeout(120000L);
      config.setMaxLifetime(1800000L);
      config.addDataSourceProperty("cachePrepStmts", "true");
      config.addDataSourceProperty("prepStmtCacheSize", "250");
      config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
      config.addDataSourceProperty("useServerPrepStmts", "true");
      config.addDataSourceProperty("rewriteBatchedStatements", "true");
      return new HikariDataSource(config);
   }
}
