package cs.cloudstudio.command;

import cs.cloudstudio.CloudTops;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import cs.cloudstudio.command.sub.UpdateSubCommand;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public final class AdminCommand implements CommandExecutor, TabCompleter {
   private static final String PERMISSION = "cloudtops.admin";
   private final CloudTops plugin;
   private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();

   public AdminCommand(CloudTops plugin) {
      this.plugin = plugin;
      this.register(new ReloadSubCommand(plugin));
      this.register(new UpdateSubCommand(plugin));
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("cloudtops.admin")) {
         sender.sendMessage(this.plugin.getConfigManager().message("no-perm"));
         return true;
      } else if (args.length == 0) {
         sender.sendMessage(this.plugin.getConfigManager().message("admin-usage"));
         return true;
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            sender.sendMessage(this.plugin.getConfigManager().message("admin-usage"));
            return true;
         } else {
            subCommand.execute(sender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.hasPermission("cloudtops.admin")) {
         return Collections.emptyList();
      }

      if (args.length == 1) {
         return this.filter(new ArrayList<>(this.subCommands.keySet()), args[0]);
      }

      SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
      return subCommand == null ? Collections.emptyList() : subCommand.tab(sender, args);
   }

   private void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.getName(), subCommand);
   }

   private List<String> filter(List<String> source, String input) {
      String lower = input.toLowerCase(Locale.ROOT);
      List<String> result = new ArrayList<>();

      for (String value : source) {
         if (value.startsWith(lower)) {
            result.add(value);
         }
      }

      return result;
   }
}
