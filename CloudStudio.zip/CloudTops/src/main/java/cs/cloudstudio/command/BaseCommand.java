package cs.cloudstudio.command;

import cs.cloudstudio.CloudTops;
import org.bukkit.command.CommandSender;

public abstract class BaseCommand implements SubCommand {
   protected final CloudTops plugin;

   protected BaseCommand(CloudTops plugin) {
      this.plugin = plugin;
   }

   protected void message(CommandSender sender, String path) {
      sender.sendMessage(this.plugin.getConfigManager().message(path));
   }
}
