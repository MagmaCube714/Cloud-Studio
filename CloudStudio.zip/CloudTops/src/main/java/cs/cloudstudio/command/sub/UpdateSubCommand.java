package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudTops;
import cs.cloudstudio.command.BaseCommand;
import org.bukkit.command.CommandSender;

public final class UpdateSubCommand extends BaseCommand {
   public UpdateSubCommand(CloudTops plugin) {
      super(plugin);
   }

   @Override
   public String getName() {
      return "update";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      this.plugin.getTopManager().performFullScan();
      this.message(sender, "updated");
   }
}
