package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.database.impl.TopsDatabase;
import cs.cloudstudio.listener.PlayerStatListener;
import cs.cloudstudio.listener.PluginStateListener;
import cs.cloudstudio.listener.ResourcePackListener;
import cs.cloudstudio.manager.TopManager;
import cs.cloudstudio.manager.placeholder.TopPlaceholder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudTops extends JavaPlugin {
   private ConfigManager configManager;
   private TopsDatabase database;
   private TopManager topManager;
   private TopPlaceholder placeholder;
   private ResourcePackListener resourcePackListener;
   private PlayerStatListener playerStatListener;
   private PluginStateListener pluginStateListener;

   public void onEnable() {
      if (this.startPlugin()) {
         this.registerCommand();
         this.log("&fCloudTops &aуспешно загружен!");
      }
   }

   public void onDisable() {
      this.stopPlugin(null);
      this.log("&fCloudTops &cуспешно выгружен!");
   }

   public void reloadPlugin() {
      this.stopPlugin(() -> {
         this.reloadConfig();
         this.startPlugin();
      });
   }

   private boolean startPlugin() {
      if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") == null) {
         this.log("&fCloudTops &cPlaceholderAPI не найден, плагин отключён");
         Bukkit.getPluginManager().disablePlugin(this);
         return false;
      }

      this.saveDefaultConfig();
      this.configManager = new ConfigManager(this);
      this.configManager.loadConfig();
      this.database = new TopsDatabase(this);
      this.database.connect();
      if (!this.database.isConnected()) {
         this.getLogger().warning("[CloudTops] База данных не подключена: проверьте настройки database");
         Bukkit.getPluginManager().disablePlugin(this);
         return false;
      }

      this.resourcePackListener = new ResourcePackListener();
      Bukkit.getPluginManager().registerEvents(this.resourcePackListener, this);
      this.getServer().getMessenger().registerIncomingPluginChannel(this, "forcepack:status", this.resourcePackListener);

      for (Player player : this.getServer().getOnlinePlayers()) {
         this.resourcePackListener.setPlayerResourcePackStatus(player.getUniqueId(), false);
      }

      this.topManager = new TopManager(this, this.database, this.configManager);
      this.topManager.initialize();
      this.pluginStateListener = new PluginStateListener(this.topManager);
      Bukkit.getPluginManager().registerEvents(this.pluginStateListener, this);
      this.playerStatListener = new PlayerStatListener(this.topManager);
      Bukkit.getPluginManager().registerEvents(this.playerStatListener, this);
      this.registerPlaceholders();
      return true;
   }

   private void stopPlugin(Runnable afterClose) {
      if (this.placeholder != null) {
         this.placeholder.unregister();
         this.placeholder = null;
      }

      if (this.playerStatListener != null) {
         HandlerList.unregisterAll(this.playerStatListener);
         this.playerStatListener = null;
      }

      if (this.pluginStateListener != null) {
         HandlerList.unregisterAll(this.pluginStateListener);
         this.pluginStateListener = null;
      }

      if (this.topManager != null) {
         this.topManager.shutdown();
         this.topManager = null;
      }

      if (this.resourcePackListener != null) {
         this.getServer().getMessenger().unregisterIncomingPluginChannel(this, "forcepack:status", this.resourcePackListener);
         HandlerList.unregisterAll(this.resourcePackListener);
         this.resourcePackListener.clear();
         this.resourcePackListener = null;
      } else {
         this.getServer().getMessenger().unregisterIncomingPluginChannel(this, "forcepack:status");
      }

      if (this.database != null) {
         TopsDatabase closingDatabase = this.database;
         this.database = null;
         closingDatabase.disconnectAsync(afterClose);
      } else if (afterClose != null && this.isEnabled()) {
         afterClose.run();
      }
   }

   private void registerCommand() {
      PluginCommand command = this.getCommand("cloudtops");
      if (command != null) {
         AdminCommand executor = new AdminCommand(this);
         command.setExecutor(executor);
         command.setTabCompleter(executor);
      }
   }

   private void registerPlaceholders() {
      this.placeholder = new TopPlaceholder(this.topManager, this.resourcePackListener);
      this.placeholder.register();
   }

   private void log(String message) {
      Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', message));
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public TopsDatabase getDatabase() {
      return this.database;
   }

   public TopManager getTopManager() {
      return this.topManager;
   }
}
