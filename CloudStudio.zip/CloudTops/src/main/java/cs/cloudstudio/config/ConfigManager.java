package cs.cloudstudio.config;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class ConfigManager {
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
   private static final String LEGACY_CODES = "0123456789abcdefklmnorx";
   private static final char COLOR = '§';
   private static final int COLLECTION_BATCH_SIZE = 8;
   private static final boolean ECO_OFFLINE_SCAN_ENABLED = true;
   private static final int ECO_SCAN_BATCH_SIZE = 200;
   private static final int STATS_SCAN_BATCH_SIZE = 350;
   private static final long PLAYER_INDEX_CACHE_MILLIS = 7200000L;
   private static final long STATS_FILE_LIST_CACHE_MILLIS = 3600000L;
   private final JavaPlugin plugin;
   private final Map<String, String> cache = new ConcurrentHashMap<>(128);
   private long updateInterval;

   public ConfigManager(JavaPlugin plugin) {
      this.plugin = plugin;
   }

   public void loadConfig() {
      this.plugin.saveDefaultConfig();
      this.parseConfig(this.plugin.getConfig());
   }

   public void reloadConfig() {
      this.plugin.reloadConfig();
      this.cache.clear();
      this.parseConfig(this.plugin.getConfig());
   }

   private void parseConfig(FileConfiguration config) {
      this.updateInterval = Math.max(10L, config.getLong("settings.update-interval", config.getLong("update-interval", 180L)));
   }

   public String message(String path) {
      return this.color(this.plugin.getConfig().getString("messages." + path, "&cСообщение не найдено: " + path));
   }

   public long getUpdateInterval() {
      return this.updateInterval;
   }

   public int getCollectionBatchSize() {
      return 8;
   }

   public boolean isEcoOfflineScanEnabled() {
      return true;
   }

   public int getEcoScanBatchSize() {
      return 200;
   }

   public int getStatsScanBatchSize() {
      return 350;
   }

   public long getPlayerIndexCacheMillis() {
      return 7200000L;
   }

   public long getStatsFileListCacheMillis() {
      return 3600000L;
   }

   public String color(String text) {
      if (text != null && !text.isEmpty()) {
         String cached = this.cache.get(text);
         if (cached != null) {
            return cached;
         }

         String result = this.translateLegacy(this.translateHex(text));
         if (this.cache.size() < 256) {
            this.cache.put(text, result);
         }

         return result;
      } else {
         return "";
      }
   }

   private String translateHex(String text) {
      Matcher matcher = HEX_PATTERN.matcher(text);
      StringBuffer buffer = new StringBuffer();

      while (matcher.find()) {
         String hex = matcher.group(1);
         matcher.appendReplacement(
            buffer, "§x§" + hex.charAt(0) + "§" + hex.charAt(1) + "§" + hex.charAt(2) + "§" + hex.charAt(3) + "§" + hex.charAt(4) + "§" + hex.charAt(5)
         );
      }

      matcher.appendTail(buffer);
      return buffer.toString();
   }

   private String translateLegacy(String text) {
      char[] chars = text.toCharArray();

      for (int index = 0; index < chars.length - 1; index++) {
         if (chars[index] == '&' && this.isColor(chars[index + 1])) {
            chars[index] = 167;
            chars[index + 1] = Character.toLowerCase(chars[index + 1]);
         }
      }

      return new String(chars);
   }

   private boolean isColor(char value) {
      return "0123456789abcdefklmnorx".indexOf(Character.toLowerCase(value)) >= 0;
   }
}
