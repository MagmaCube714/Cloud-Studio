package cs.cloudstudio.util;

import java.awt.Color;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.md_5.bungee.api.ChatColor;

public class FormatUtil {
   public static final Color GRADIENT_START = new Color(243, 183, 0);
   public static final Color GRADIENT_END = new Color(243, 87, 35);
   private static final int TOP_COLUMN_GAP_WIDTH = 4;
   private static final char[] PADDING_CHARS = new char[]{'ꅈ', 'ꅇ', 'ꅆ', 'ꅅ', 'ꅄ', 'ꅃ', 'ꅂ', 'ꅁ'};
   private static final int[] PADDING_ADVANCE = new int[]{9, 8, 7, 6, 5, 4, 3, 2};
   private static final Map<Character, Integer> CHAR_ADVANCE = new HashMap<>();

   public String applyGradient(String text, Color start, Color end) {
      if (text != null && !text.isEmpty()) {
         StringBuilder sb = new StringBuilder();
         String clean = ChatColor.stripColor(text);
         int len = clean.length();
         if (len == 0) {
            return "";
         }

         if (len == 1) {
            sb.append(ChatColor.of(end)).append(clean);
            return sb.toString();
         }

         for (int i = 0; i < len; i++) {
            float ratio = (float)i / (len - 1);
            int red = (int)(end.getRed() * ratio + start.getRed() * (1.0F - ratio));
            int green = (int)(end.getGreen() * ratio + start.getGreen() * (1.0F - ratio));
            int blue = (int)(end.getBlue() * ratio + start.getBlue() * (1.0F - ratio));
            sb.append(ChatColor.of(new Color(red, green, blue))).append(clean.charAt(i));
         }

         return sb.toString();
      } else {
         return "";
      }
   }

   public int getStringWidth(String text) {
      if (text != null && !text.isEmpty()) {
         int total = 0;
         boolean isBold = false;
         int length = text.length();
         char[] chars = text.toCharArray();

         for (int i = 0; i < length; i++) {
            char c = chars[i];
            if ((c == 167 || c == '&') && i + 1 < length) {
               char nextCode = Character.toLowerCase(chars[i + 1]);
               if (nextCode == 'x' && i + 13 < length) {
                  isBold = false;
                  i += 13;
                  continue;
               }

               if (nextCode == '#' && i + 7 < length) {
                  isBold = false;
                  i += 7;
                  continue;
               }

               if ("0123456789abcdef".indexOf(nextCode) != -1 || nextCode == 'r') {
                  isBold = false;
                  i++;
                  continue;
               }

               if (nextCode == 'l') {
                  isBold = true;
                  i++;
                  continue;
               }

               if ("kmno".indexOf(nextCode) != -1) {
                  i++;
                  continue;
               }
            }

            Integer advance = CHAR_ADVANCE.get(c);
            total += (advance != null ? advance : 6) + (isBold ? 1 : 0);
         }

         return total;
      } else {
         return 0;
      }
   }

   public int getTopColumnGapWidth() {
      return 4;
   }

   public String buildAlignedLine(String rank, String nickname, String value, int totalWidth) {
      String left = rank + " " + nickname;
      int leftW = this.getStringWidth(left);
      int valueW = this.getStringWidth(value);
      int lineWidth = Math.max(totalWidth, leftW + valueW + 4);
      int gap = Math.max(4, lineWidth - leftW - valueW);
      return left + "§r" + this.buildPadding(gap) + value;
   }

   public Map<Integer, String> toPlainTop(Map<Integer, String> formattedTop) {
      if (formattedTop != null && !formattedTop.isEmpty()) {
         Map<Integer, String> plain = new LinkedHashMap<>();

         for (Entry<Integer, String> entry : formattedTop.entrySet()) {
            plain.put(entry.getKey(), this.toPlainLine(entry.getValue()));
         }

         return Collections.unmodifiableMap(plain);
      } else {
         return Collections.emptyMap();
      }
   }

   public String toPlainLine(String line) {
      if (line != null && !line.isEmpty()) {
         String text = line.replace("§cꅅ#", "§c#");
         text = text.replace("§f ꐂ", "§f ");
         text = text.replace("§fꐂ", "§f ");
         text = text.replace("§f ꐆ", "§f ");
         text = text.replace("§fꐆ", "§f ");
         text = text.replace("§r ꐆ", "§f ");
         text = text.replace("§rꐆ", "§f ");
         text = text.replace(" §r ꐇ", " §bОпыта");
         text = text.replace(" §rꐇ", " §bОпыта");
         text = text.replace("§r ꐇ", "§b Опыта");
         text = text.replace("§rꐇ", "§b Опыта");
         return this.replacePaddingWithSingleSpace(text);
      } else {
         return "";
      }
   }

   public String plainRank(int rank) {
      return "§c#" + rank;
   }

   private String replacePaddingWithSingleSpace(String text) {
      StringBuilder builder = new StringBuilder(text.length());
      boolean padding = false;

      for (int index = 0; index < text.length(); index++) {
         char character = text.charAt(index);
         if (this.isPaddingCharacter(character)) {
            if (!padding && builder.length() > 0 && builder.charAt(builder.length() - 1) != ' ') {
               builder.append(' ');
            }

            padding = true;
         } else {
            padding = false;
            builder.append(character);
         }
      }

      return builder.toString();
   }

   private boolean isPaddingCharacter(char character) {
      if (character >= '\uf821' && character <= '\uf82f') {
         return true;
      }

      for (char padding : PADDING_CHARS) {
         if (padding == character) {
            return true;
         }
      }

      return false;
   }

   private String buildPadding(int width) {
      if (width <= 0) {
         return "";
      }

      StringBuilder padding = new StringBuilder();
      int remaining = width;

      while (remaining > 0) {
         int index = this.findPaddingIndex(remaining);
         if (index < 0) {
            break;
         }

         padding.append(PADDING_CHARS[index]);
         remaining -= PADDING_ADVANCE[index];
      }

      return padding.toString();
   }

   private int findPaddingIndex(int remaining) {
      if (remaining == 1) {
         return -1;
      }

      for (int i = 0; i < PADDING_ADVANCE.length; i++) {
         int advance = PADDING_ADVANCE[i];
         if (remaining >= advance && remaining - advance != 1) {
            return i;
         }
      }

      return -1;
   }

   public String rank(int rank) {
      return rank == 10 ? "§c#" + rank : "§cꅅ#" + rank;
   }

   public String formatTime(long ticks) {
      return this.formatTime(ticks, true);
   }

   public String formatTime(long ticks, boolean padded) {
      long seconds = ticks / 20L;
      long days = seconds / 86400L;
      long hours = seconds % 86400L / 3600L;
      long minutes = seconds % 3600L / 60L;
      if (padded) {
         StringBuilder builder = new StringBuilder(14);
         appendTwoDigits(builder, days).append('д').append(", ");
         appendTwoDigits(builder, hours).append('ч').append(", ");
         appendTwoDigits(builder, minutes).append('м');
         return builder.toString();
      } else {
         return days + "д, " + hours + "ч, " + minutes + "м";
      }
   }

   private static StringBuilder appendTwoDigits(StringBuilder builder, long value) {
      if (value >= 0L && value < 10L) {
         builder.append('0');
      }

      return builder.append(value);
   }

   public String formatEco(String value) {
      try {
         long amount = Math.round(Double.parseDouble(value));
         return formatGrouped(amount);
      } catch (NumberFormatException ignored) {
         return value;
      }
   }

   private static String formatGrouped(long value) {
      boolean negative = value < 0L;
      long absolute = negative ? -value : value;
      String digits = Long.toString(absolute);
      StringBuilder builder = new StringBuilder(digits.length() + digits.length() / 3 + (negative ? 1 : 0));
      if (negative) {
         builder.append('-');
      }

      int first = digits.length() % 3;
      if (first == 0) {
         first = 3;
      }

      builder.append(digits, 0, first);

      for (int index = first; index < digits.length(); index += 3) {
         builder.append(',').append(digits, index, index + 3);
      }

      return builder.toString();
   }

   static {
      CHAR_ADVANCE.put('i', 2);
      CHAR_ADVANCE.put('!', 2);
      CHAR_ADVANCE.put('.', 2);
      CHAR_ADVANCE.put(',', 2);
      CHAR_ADVANCE.put(':', 2);
      CHAR_ADVANCE.put(';', 2);
      CHAR_ADVANCE.put('|', 2);
      CHAR_ADVANCE.put('\'', 2);
      CHAR_ADVANCE.put('l', 3);
      CHAR_ADVANCE.put('`', 3);
      CHAR_ADVANCE.put(' ', 4);
      CHAR_ADVANCE.put('I', 4);
      CHAR_ADVANCE.put('t', 4);
      CHAR_ADVANCE.put('[', 4);
      CHAR_ADVANCE.put(']', 4);
      CHAR_ADVANCE.put('f', 5);
      CHAR_ADVANCE.put('k', 5);
      CHAR_ADVANCE.put('"', 5);
      CHAR_ADVANCE.put('*', 5);
      CHAR_ADVANCE.put('<', 5);
      CHAR_ADVANCE.put('>', 5);
      CHAR_ADVANCE.put('{', 5);
      CHAR_ADVANCE.put('}', 5);
      CHAR_ADVANCE.put('(', 5);
      CHAR_ADVANCE.put(')', 5);
      CHAR_ADVANCE.put('@', 7);
      CHAR_ADVANCE.put('~', 7);
      CHAR_ADVANCE.put('Ж', 7);
      CHAR_ADVANCE.put('ж', 7);
      CHAR_ADVANCE.put('М', 7);
      CHAR_ADVANCE.put('м', 7);
      CHAR_ADVANCE.put('Ф', 7);
      CHAR_ADVANCE.put('ф', 7);
      CHAR_ADVANCE.put('Ы', 7);
      CHAR_ADVANCE.put('ы', 7);
      CHAR_ADVANCE.put('Д', 7);
      CHAR_ADVANCE.put('д', 7);
      CHAR_ADVANCE.put('Ш', 8);
      CHAR_ADVANCE.put('ш', 8);
      CHAR_ADVANCE.put('Щ', 8);
      CHAR_ADVANCE.put('щ', 8);
      CHAR_ADVANCE.put('Ю', 8);
      CHAR_ADVANCE.put('ю', 8);
      CHAR_ADVANCE.put('ꐇ', 8);
      CHAR_ADVANCE.put('ꐆ', 8);
      CHAR_ADVANCE.put('ꐂ', 8);
      CHAR_ADVANCE.put('ꅈ', 9);
      CHAR_ADVANCE.put('ꅇ', 8);
      CHAR_ADVANCE.put('ꅆ', 7);
      CHAR_ADVANCE.put('ꅅ', 6);
      CHAR_ADVANCE.put('ꅄ', 5);
      CHAR_ADVANCE.put('ꅃ', 4);
      CHAR_ADVANCE.put('ꅂ', 3);
      CHAR_ADVANCE.put('ꅁ', 2);
      CHAR_ADVANCE.put('\uf821', 1);
      CHAR_ADVANCE.put('\uf822', 2);
      CHAR_ADVANCE.put('\uf823', 3);
      CHAR_ADVANCE.put('\uf824', 4);
      CHAR_ADVANCE.put('\uf825', 5);
      CHAR_ADVANCE.put('\uf826', 6);
      CHAR_ADVANCE.put('\uf827', 7);
      CHAR_ADVANCE.put('\uf828', 8);
      CHAR_ADVANCE.put('\uf829', 16);
      CHAR_ADVANCE.put('\uf82a', 32);
      CHAR_ADVANCE.put('\uf82b', 64);
      CHAR_ADVANCE.put('\uf82c', 128);
      CHAR_ADVANCE.put('\uf82d', 256);
      CHAR_ADVANCE.put('\uf82e', 512);
      CHAR_ADVANCE.put('\uf82f', 1024);
      CHAR_ADVANCE.put('\uf801', -1);
      CHAR_ADVANCE.put('\uf802', -2);
      CHAR_ADVANCE.put('\uf803', -3);
      CHAR_ADVANCE.put('\uf804', -4);
      CHAR_ADVANCE.put('\uf805', -5);
      CHAR_ADVANCE.put('\uf806', -6);
      CHAR_ADVANCE.put('\uf807', -7);
      CHAR_ADVANCE.put('\uf808', -8);
      CHAR_ADVANCE.put('\uf809', -16);
      CHAR_ADVANCE.put('\uf80a', -32);
      CHAR_ADVANCE.put('\uf80b', -64);
      CHAR_ADVANCE.put('\uf80c', -128);
      CHAR_ADVANCE.put('\uf80d', -256);
      CHAR_ADVANCE.put('\uf80e', -512);
      CHAR_ADVANCE.put('\uf80f', -1024);
   }
}
