package cs.cloudstudio.util;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;

public final class StatUtil {
   private static final Pattern NUMBER_PATTERN = Pattern.compile("-?\\d+");
   private static final Pattern TIME_PART_PATTERN = Pattern.compile("(\\d+)\\s*([a-zA-Zа-яА-Я]+)");

   private StatUtil() {
   }

   public static StatUtil.GameStats read(OfflinePlayer player) {
      if (player == null) {
         return new StatUtil.GameStats(-1L, -1L);
      }

      long placeholderKills = readLong(player, "%statistic_player_kills%");
      long placeholderPlaytime = readPlaytimeTicks(player);
      if (placeholderKills >= 0L && placeholderPlaytime >= 0L) {
         return new StatUtil.GameStats(placeholderKills, placeholderPlaytime);
      }

      StatUtil.GameStats direct = readDirect(player);
      long kills = placeholderKills >= 0L ? placeholderKills : direct.playerKills;
      long playtime = placeholderPlaytime >= 0L ? placeholderPlaytime : direct.playtimeTicks;
      return new StatUtil.GameStats(kills, playtime);
   }

   private static StatUtil.GameStats readDirect(OfflinePlayer player) {
      try {
         if (!player.isOnline()) {
            return new StatUtil.GameStats(-1L, -1L);
         }

         long kills = Math.max(0, player.getStatistic(Statistic.PLAYER_KILLS));
         long playtime = Math.max(0, player.getStatistic(Statistic.PLAY_ONE_MINUTE));
         return new StatUtil.GameStats(kills, playtime);
      } catch (Throwable ignored) {
         return new StatUtil.GameStats(-1L, -1L);
      }
   }

   private static long readPlaytimeTicks(OfflinePlayer player) {
      long seconds = readLong(player, "%statistic_seconds_played%");
      if (seconds >= 0L) {
         return seconds * 20L;
      }

      long ticks = readLong(player, "%statistic_play_one_minute%");
      if (ticks >= 0L) {
         return ticks;
      }

      String formatted = request(player, "%statistic_time_played%");
      long parsedSeconds = parseFormattedTimeSeconds(formatted);
      if (parsedSeconds >= 0L) {
         return parsedSeconds * 20L;
      }

      long minutes = readLong(player, "%statistic_minutes_played%");
      if (minutes >= 0L) {
         return minutes * 60L * 20L;
      }

      long hours = readLong(player, "%statistic_hours_played%");
      if (hours >= 0L) {
         return hours * 3600L * 20L;
      }

      long days = readLong(player, "%statistic_days_played%");
      return days >= 0L ? days * 86400L * 20L : -1L;
   }

   private static long readLong(OfflinePlayer player, String placeholder) {
      String raw = request(player, placeholder);
      return parseLong(raw);
   }

   private static String request(OfflinePlayer player, String placeholder) {
      try {
         String result = PlaceholderAPI.setPlaceholders(player, placeholder);
         return result == null ? "" : result.trim();
      } catch (Throwable ignored) {
         return "";
      }
   }

   private static long parseLong(String input) {
      if (isInvalid(input)) {
         return -1L;
      }

      String cleaned = stripColors(input).replace(" ", "").replace(",", "").trim();
      if (cleaned.isEmpty()) {
         return -1L;
      }

      try {
         return Math.max(0L, Long.parseLong(cleaned));
      } catch (NumberFormatException ignored) {
         Matcher matcher = NUMBER_PATTERN.matcher(cleaned);
         if (!matcher.find()) {
            return -1L;
         }

         try {
            return Math.max(0L, Long.parseLong(matcher.group()));
         } catch (NumberFormatException ignoredToo) {
            return -1L;
         }
      }
   }

   private static long parseFormattedTimeSeconds(String input) {
      if (isInvalid(input)) {
         return -1L;
      }

      String cleaned = stripColors(input).toLowerCase(Locale.ROOT).replace(",", " ").trim();
      if (cleaned.isEmpty()) {
         return 0L;
      }

      Matcher matcher = TIME_PART_PATTERN.matcher(cleaned);
      long total = 0L;
      boolean found = false;

      while (matcher.find()) {
         long value;
         try {
            value = Long.parseLong(matcher.group(1));
         } catch (NumberFormatException ignored) {
            continue;
         }

         String unit = matcher.group(2).toLowerCase(Locale.ROOT);
         long multiplier = resolveTimeMultiplier(unit);
         if (multiplier > 0L) {
            total += value * multiplier;
            found = true;
         }
      }

      return found ? Math.max(0L, total) : -1L;
   }

   private static long resolveTimeMultiplier(String unit) {
      if (unit.startsWith("w") || unit.startsWith("нед")) {
         return 604800L;
      } else if (unit.startsWith("d") || unit.startsWith("д")) {
         return 86400L;
      } else if (unit.startsWith("h") || unit.startsWith("ч")) {
         return 3600L;
      } else if (unit.startsWith("m") || unit.startsWith("м")) {
         return 60L;
      } else {
         return !unit.startsWith("s") && !unit.startsWith("с") ? -1L : 1L;
      }
   }

   private static boolean isInvalid(String input) {
      if (input == null) {
         return true;
      }

      String lower = input.toLowerCase(Locale.ROOT).trim();
      return lower.isEmpty()
         || lower.contains("%")
         || lower.contains("unknown statistic")
         || lower.contains("cannot get statistic")
         || lower.contains("could not get")
         || lower.contains("invalid");
   }

   private static String stripColors(String input) {
      StringBuilder builder = new StringBuilder(input.length());
      char[] chars = input.toCharArray();

      for (int index = 0; index < chars.length; index++) {
         char c = chars[index];
         if ((c == 167 || c == '&') && index + 1 < chars.length) {
            char next = Character.toLowerCase(chars[index + 1]);
            if (next == 'x' && index + 13 < chars.length) {
               index += 13;
            } else if (next == '#' && index + 7 < chars.length) {
               index += 7;
            } else {
               index++;
            }
         } else {
            builder.append(c);
         }
      }

      return builder.toString();
   }

   public static final class GameStats {
      public final long playerKills;
      public final long playtimeTicks;

      public GameStats(long playerKills, long playtimeTicks) {
         this.playerKills = playerKills;
         this.playtimeTicks = playtimeTicks;
      }
   }
}
