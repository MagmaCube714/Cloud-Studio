package cs.cloudstudio.config;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.util.ColorUtil;
import java.time.DateTimeException;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;

public final class ConfigManager {
   private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");
   private final CloudSiege plugin;
   private final Map<String, Set<String>> autoStartTimesByDay = new HashMap<>();
   private final Map<String, String> messages = new HashMap<>();
   private final Map<String, List<String>> messageLists = new HashMap<>();
   private final Map<String, String> bossBars = new HashMap<>();
   private LocationConfig locationConfig;
   private RewardConfig rewardConfig;
   private String worldName;
   private int startTime;
   private int endTime;
   private int nextWaveTime;
   private int maxPlayers;
   private int inventorySize;
   private int joinQueueDelay;
   private String joinQueueTitle;
   private String joinQueueSubtitle;
   private boolean cancelNaturalSpawns;
   private boolean forceEventSpawns;
   private boolean commandSpawnFallback;
   private boolean fallbackVanillaSpawn;
   private EntityType fallbackEntityType;
   private ZoneId scheduleZone = ZoneId.of("Europe/Moscow");

   public ConfigManager(CloudSiege plugin) {
      this.plugin = plugin;
   }

   public void reload() {
      this.plugin.reloadConfig();
      this.reloadSettings();
      this.reloadMessages();
      this.reloadBossBars();
      this.reloadSchedule();
      this.locationConfig = new LocationConfig(this.plugin);
      this.rewardConfig = new RewardConfig(this.plugin);
      this.locationConfig.reload();
      this.rewardConfig.reload();
   }

   public FileConfiguration getConfig() {
      return this.plugin.getConfig();
   }

   public LocationConfig getLocationConfig() {
      return this.locationConfig;
   }

   public RewardConfig getRewardConfig() {
      return this.rewardConfig;
   }

   public String getWorldName() {
      return this.worldName;
   }

   public int getStartTime() {
      return this.startTime;
   }

   public int getEndTime() {
      return this.endTime;
   }

   public int getNextWaveTime() {
      return this.nextWaveTime;
   }

   public int getMaxPlayers() {
      return this.maxPlayers;
   }

   public int getInventorySize() {
      return this.inventorySize;
   }

   public int getJoinQueueDelay() {
      return this.joinQueueDelay;
   }

   public String getJoinQueueTitle() {
      return this.joinQueueTitle;
   }

   public String getJoinQueueSubtitle() {
      return this.joinQueueSubtitle;
   }

   public boolean isCancelNaturalSpawns() {
      return this.cancelNaturalSpawns;
   }

   public boolean isForceEventSpawns() {
      return this.forceEventSpawns;
   }

   public boolean isCommandSpawnFallback() {
      return this.commandSpawnFallback;
   }

   public boolean isFallbackVanillaSpawn() {
      return this.fallbackVanillaSpawn;
   }

   public EntityType getFallbackEntityType() {
      return this.fallbackEntityType;
   }

   public ZoneId getScheduleZone() {
      return this.scheduleZone;
   }

   public boolean hasSchedule() {
      return !this.autoStartTimesByDay.isEmpty();
   }

   public String message(String path) {
      String message = this.messages.get(path);
      return message == null ? "" : message;
   }

   public List<String> messageList(String path) {
      List<String> list = this.messageLists.get(path);
      return list == null ? Collections.emptyList() : list;
   }

   public String bossBar(String path) {
      String bossBar = this.bossBars.get(path);
      return bossBar == null ? "" : bossBar;
   }

   public boolean isAutoStartTime(String day, String time) {
      if (day != null && time != null) {
         Set<String> times = this.autoStartTimesByDay.get(day.toLowerCase(Locale.ROOT));
         return times != null && times.contains(time);
      } else {
         return false;
      }
   }

   public Set<String> getAutoStartTimes(DayOfWeek day) {
      if (day == null) {
         return Collections.emptySet();
      }

      Set<String> times = this.autoStartTimesByDay.get(day.name().toLowerCase(Locale.ROOT));
      return times == null ? Collections.emptySet() : Collections.unmodifiableSet(times);
   }

   private void reloadSettings() {
      FileConfiguration config = this.getConfig();
      this.worldName = config.getString("settings.world", "world_siege");
      this.startTime = Math.max(1, config.getInt("settings.time.start", 30));
      this.endTime = Math.max(0, config.getInt("settings.time.end", 120));
      this.nextWaveTime = Math.max(0, config.getInt("settings.time.next-wave", 0));
      this.maxPlayers = Math.max(1, config.getInt("settings.max-player", 60));
      this.inventorySize = this.normalizeInventorySize(config.getInt("settings.inventory-size", 54));
      this.joinQueueDelay = Math.max(0, config.getInt("settings.join-queue.delay", 1));
      this.joinQueueTitle = config.getString("settings.join-queue.title", "&6Вход на арену");
      this.joinQueueSubtitle = config.getString("settings.join-queue.subtitle", "&7Вы &6%position% &7в очереди на арену");
      this.cancelNaturalSpawns = config.getBoolean("settings.cancel-natural-spawns", true);
      this.forceEventSpawns = config.getBoolean("settings.force-event-spawns", true);
      this.commandSpawnFallback = config.getBoolean("settings.command-spawn-fallback", true);
      this.fallbackVanillaSpawn = config.getBoolean("settings.fallback-vanilla-spawn", false);
      this.fallbackEntityType = this.readEntityType(config.getString("settings.fallback-entity-type", "PILLAGER"));
   }

   private void reloadMessages() {
      this.messages.clear();
      this.messageLists.clear();
      ConfigurationSection section = this.getConfig().getConfigurationSection("messages");
      if (section != null) {
         for (String key : section.getKeys(false)) {
            if (section.isList(key)) {
               List<String> colored = ColorUtil.color(section.getStringList(key));
               this.messageLists.put(key, Collections.unmodifiableList(colored));
            } else {
               this.messages.put(key, ColorUtil.color(section.getString(key, "")));
            }
         }
      }
   }

   private void reloadBossBars() {
      this.bossBars.clear();
      ConfigurationSection section = this.getConfig().getConfigurationSection("bossbars");
      if (section != null) {
         for (String key : section.getKeys(false)) {
            this.bossBars.put(key, ColorUtil.color(section.getString(key, "")));
         }
      }
   }

   private void reloadSchedule() {
      this.autoStartTimesByDay.clear();
      this.scheduleZone = ZoneId.of("Europe/Moscow");
      ConfigurationSection section = this.getConfig().getConfigurationSection("schedule");
      if (section != null && !section.getKeys(false).isEmpty()) {
         String timezone = section.getString("timezone", "Europe/Moscow");

         try {
            this.scheduleZone = ZoneId.of(timezone);
         } catch (DateTimeException exception) {
            this.plugin.warning("Неверный timezone в schedule: Europe/Moscow используется по умолчанию");
            this.scheduleZone = ZoneId.of("Europe/Moscow");
         }

         for (String key : section.getKeys(false)) {
            String day = key.trim().toLowerCase(Locale.ROOT);
            if (!"timezone".equals(day) && this.isDayKey(day)) {
               for (String time : section.getStringList(key)) {
                  this.addAutoStartTime(day, time);
               }
            }
         }
      }
   }

   private boolean isDayKey(String key) {
      return "monday".equals(key)
         || "tuesday".equals(key)
         || "wednesday".equals(key)
         || "thursday".equals(key)
         || "friday".equals(key)
         || "saturday".equals(key)
         || "sunday".equals(key);
   }

   private void addAutoStartTime(String day, String time) {
      if (time != null && !time.trim().isEmpty()) {
         String value = time.trim();
         if (!this.isValidTime(value)) {
            this.plugin.warning("Расписание " + day + " содержит неверное время: " + value);
         } else {
            this.autoStartTimesByDay.computeIfAbsent(day, ignored -> new HashSet<>()).add(value);
         }
      }
   }

   private boolean isValidTime(String value) {
      try {
         LocalTime.parse(value, TIME_FORMATTER);
         return value.length() == 5;
      } catch (DateTimeException exception) {
         return false;
      }
   }

   private int normalizeInventorySize(int size) {
      if (size < 9) {
         return 9;
      } else {
         return size > 54 ? 54 : Math.max(9, size / 9 * 9);
      }
   }

   private EntityType readEntityType(String typeName) {
      if (typeName != null && !typeName.isEmpty()) {
         try {
            EntityType type = EntityType.valueOf(typeName.toUpperCase(Locale.ROOT));
            return type.isAlive() ? type : EntityType.PILLAGER;
         } catch (IllegalArgumentException exception) {
            this.plugin.warning("settings.fallback-entity-type содержит неверный тип моба: " + typeName);
            return EntityType.PILLAGER;
         }
      } else {
         return EntityType.PILLAGER;
      }
   }
}
