package cs.cloudstudio.config;

import cs.cloudstudio.CloudSiege;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

public final class RewardConfig {
   private static final int MAX_REWARD_SLOTS = 54;
   private final CloudSiege plugin;
   private final File file;
   private FileConfiguration config;
   private final ItemStack[] rewardsBySlot = new ItemStack[54];

   public RewardConfig(CloudSiege plugin) {
      this.plugin = plugin;
      this.file = new File(plugin.getDataFolder(), "reward.yml");
   }

   public void reload() {
      this.config = YamlConfiguration.loadConfiguration(this.file);
      this.clearRewards();
      this.loadItems(this.config.getConfigurationSection("items"));
      if (this.isEmpty()) {
         this.loadLegacyItems();
      }
   }

   public List<ItemStack> getRewards() {
      List<ItemStack> result = new ArrayList<>();

      for (ItemStack item : this.rewardsBySlot) {
         if (!this.isEmpty(item)) {
            result.add(item.clone());
         }
      }

      return result;
   }

   public ItemStack[] getRewardSlots(int size) {
      int inventorySize = this.normalizeSize(size);
      ItemStack[] result = new ItemStack[inventorySize];

      for (int slot = 0; slot < inventorySize && slot < this.rewardsBySlot.length; slot++) {
         ItemStack item = this.rewardsBySlot[slot];
         if (!this.isEmpty(item)) {
            result[slot] = item.clone();
         }
      }

      return result;
   }

   public List<ItemStack> getRewardsForRows(int minRow, int maxRow, int size) {
      int inventorySize = this.normalizeSize(size);
      int firstRow = this.clamp(minRow, 1, 6);
      int lastRow = this.clamp(maxRow, firstRow, 6);
      List<ItemStack> result = new ArrayList<>();

      for (int row = firstRow; row <= lastRow; row++) {
         int start = (row - 1) * 9;
         int end = Math.min(start + 8, inventorySize - 1);

         for (int slot = start; slot <= end && slot < this.rewardsBySlot.length; slot++) {
            ItemStack item = this.rewardsBySlot[slot];
            if (!this.isEmpty(item)) {
               result.add(item.clone());
            }
         }
      }

      return result;
   }

   public void saveRewards(ItemStack[] items) {
      this.config.set("format", "slots");
      this.config.set("items", null);
      if (items != null) {
         int limit = Math.min(items.length, 54);

         for (int slot = 0; slot < limit; slot++) {
            ItemStack item = items[slot];
            if (!this.isEmpty(item)) {
               this.config.set("items." + slot, item.clone());
            }
         }
      }

      this.removeLegacyTiers();
      this.save();
      this.reload();
   }

   private void clearRewards() {
      for (int i = 0; i < this.rewardsBySlot.length; i++) {
         this.rewardsBySlot[i] = null;
      }
   }

   private void loadItems(ConfigurationSection section) {
      if (section != null) {
         List<String> keys = new ArrayList<>(section.getKeys(false));
         keys.sort(Comparator.comparingInt(this::parseInt));
         boolean slotBased = this.isSlotBased(keys);
         int legacyIndex = 0;

         for (String key : keys) {
            if (section.get(key) instanceof ItemStack stack && !this.isEmpty(stack)) {
               int slot = slotBased ? this.parseInt(key) : legacyIndex++;
               if (slot >= 0 && slot < this.rewardsBySlot.length) {
                  this.rewardsBySlot[slot] = stack.clone();
               }
            }
         }
      }
   }

   private void loadLegacyItems() {
      List<String> tierKeys = new ArrayList<>(this.config.getKeys(false));
      tierKeys.sort(Comparator.comparingInt(this::parseInt));
      int slot = 0;

      for (String tierKey : tierKeys) {
         ConfigurationSection section = this.config.getConfigurationSection(tierKey + ".rewards");
         if (section != null) {
            List<String> keys = new ArrayList<>(section.getKeys(false));
            keys.sort(Comparator.comparingInt(this::parseInt));

            for (String key : keys) {
               if (section.get(key) instanceof ItemStack stack && !this.isEmpty(stack)) {
                  while (slot < this.rewardsBySlot.length && !this.isEmpty(this.rewardsBySlot[slot])) {
                     slot++;
                  }

                  if (slot >= this.rewardsBySlot.length) {
                     return;
                  }

                  this.rewardsBySlot[slot++] = stack.clone();
               }
            }
         }
      }
   }

   private boolean isSlotBased(List<String> keys) {
      if ("slots".equalsIgnoreCase(this.config.getString("format", ""))) {
         return true;
      }

      if (keys.contains("0")) {
         return true;
      }

      for (String key : keys) {
         int value = this.parseInt(key);
         if (value >= keys.size()) {
            return true;
         }
      }

      return false;
   }

   private void removeLegacyTiers() {
      for (String key : new ArrayList<>(this.config.getKeys(false))) {
         if (this.isOnlyDigits(key)) {
            this.config.set(key, null);
         }
      }
   }

   private void save() {
      try {
         this.config.save(this.file);
      } catch (IOException e) {
         this.plugin.warning("reward.yml не сохранен: " + e.getMessage());
      }
   }

   private boolean isEmpty() {
      for (ItemStack item : this.rewardsBySlot) {
         if (!this.isEmpty(item)) {
            return false;
         }
      }

      return true;
   }

   private boolean isEmpty(ItemStack item) {
      return item == null || item.getType() == Material.AIR;
   }

   private int normalizeSize(int size) {
      if (size < 9) {
         return 9;
      } else {
         return size > 54 ? 54 : Math.max(9, size / 9 * 9);
      }
   }

   private int clamp(int value, int min, int max) {
      return value < min ? min : Math.min(value, max);
   }

   private boolean isOnlyDigits(String value) {
      if (value != null && !value.isEmpty()) {
         for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c < '0' || c > '9') {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private int parseInt(String value) {
      if (value != null && !value.isEmpty()) {
         int result = 0;
         boolean found = false;

         for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c >= '0' && c <= '9') {
               found = true;
               result = result * 10 + (c - '0');
            }
         }

         return found ? result : 0;
      } else {
         return 0;
      }
   }
}
