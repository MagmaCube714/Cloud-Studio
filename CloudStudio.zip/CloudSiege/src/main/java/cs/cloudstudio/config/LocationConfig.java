package cs.cloudstudio.config;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.manager.data.MobSpawnData;
import cs.cloudstudio.util.LocationUtil;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public final class LocationConfig {
   private final CloudSiege plugin;
   private final File file;
   private final Map<Integer, List<MobSpawnData>> mobsByRound = new HashMap<>();
   private FileConfiguration config;
   private int maxRound;

   public LocationConfig(CloudSiege plugin) {
      this.plugin = plugin;
      this.file = new File(plugin.getDataFolder(), "location.yml");
   }

   public void reload() {
      this.config = YamlConfiguration.loadConfiguration(this.file);
      this.rebuildCache();
   }

   public List<MobSpawnData> getMobs(int round) {
      List<MobSpawnData> mobs = this.mobsByRound.get(round);
      return mobs == null ? Collections.emptyList() : mobs;
   }

   public int getMaxRound() {
      return this.maxRound;
   }

   public void addLocation(int round, int type, Location location) {
      String base = "entity." + round + "-round.type-mobs." + type;
      if (!this.config.contains(base + ".mob")) {
         this.config.set(base + ".mob", "goblin_1");
         this.config.set(base + ".count", 1);
         this.config.set(base + ".damage", 32.0);
         this.config.set(base + ".health", 500.0);
      }

      ConfigurationSection cords = this.config.getConfigurationSection(base + ".cords");
      int next = cords == null ? 1 : this.maxNumericKey(cords) + 1;
      String path = base + ".cords." + next;
      this.config.set(path + ".x", location.getBlockX());
      this.config.set(path + ".y", location.getBlockY());
      this.config.set(path + ".z", location.getBlockZ());
      this.config.set(path + ".yaw", location.getYaw());
      this.config.set(path + ".pitch", location.getPitch());
      this.save();
      this.rebuildCache();
   }

   public boolean removeLocation(int round, int type) {
      String path = "entity." + round + "-round.type-mobs." + type + ".cords";
      ConfigurationSection cords = this.config.getConfigurationSection(path);
      if (cords != null && !cords.getKeys(false).isEmpty()) {
         int last = this.maxNumericKey(cords);
         if (last <= 0) {
            return false;
         }

         this.config.set(path + "." + last, null);
         this.save();
         this.rebuildCache();
         return true;
      } else {
         return false;
      }
   }

   public void save() {
      try {
         this.config.save(this.file);
      } catch (IOException e) {
         this.plugin.warning("location.yml не сохранен: " + e.getMessage());
      }
   }

   private void rebuildCache() {
      this.mobsByRound.clear();
      this.maxRound = 0;
      ConfigurationSection section = this.config.getConfigurationSection("entity");
      if (section != null) {
         List<String> roundKeys = new ArrayList<>(section.getKeys(false));
         roundKeys.sort(Comparator.comparingInt(this::parseInt));

         for (String roundKey : roundKeys) {
            if (roundKey.endsWith("-round")) {
               int round = this.parseInt(roundKey);
               if (round > 0) {
                  List<MobSpawnData> mobs = this.loadMobs(section.getConfigurationSection(roundKey + ".type-mobs"));
                  if (!mobs.isEmpty()) {
                     this.mobsByRound.put(round, Collections.unmodifiableList(mobs));
                     if (round > this.maxRound) {
                        this.maxRound = round;
                     }
                  }
               }
            }
         }
      }
   }

   private List<MobSpawnData> loadMobs(ConfigurationSection section) {
      if (section == null) {
         return Collections.emptyList();
      }

      List<String> keys = new ArrayList<>(section.getKeys(false));
      keys.sort(Comparator.comparingInt(this::parseInt));
      List<MobSpawnData> result = new ArrayList<>();

      for (String key : keys) {
         ConfigurationSection mobSection = section.getConfigurationSection(key);
         if (mobSection != null) {
            List<Location> locations = this.loadLocations(mobSection.getConfigurationSection("cords"));
            if (!locations.isEmpty()) {
               result.add(
                  new MobSpawnData(
                     mobSection.getString("mob", "PILLAGER"),
                     mobSection.getInt("count", 1),
                     mobSection.getDouble("damage", 0.0),
                     mobSection.getDouble("health", 0.0),
                     locations
                  )
               );
            }
         }
      }

      return result;
   }

   private List<Location> loadLocations(ConfigurationSection section) {
      if (section == null) {
         return Collections.emptyList();
      }

      List<String> keys = new ArrayList<>(section.getKeys(false));
      keys.sort(Comparator.comparingInt(this::parseInt));
      List<Location> result = new ArrayList<>();
      String defaultWorld = this.plugin.getConfigManager().getWorldName();

      for (String key : keys) {
         Location location = LocationUtil.fromSection(section.getConfigurationSection(key), defaultWorld);
         if (location != null) {
            result.add(location);
         }
      }

      return result;
   }

   private int maxNumericKey(ConfigurationSection section) {
      int max = 0;

      for (String key : section.getKeys(false)) {
         int value = this.parseInt(key);
         if (value > max) {
            max = value;
         }
      }

      return max;
   }

   private int parseInt(String value) {
      if (value != null && !value.isEmpty()) {
         int result = 0;
         boolean found = false;

         for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c >= '0' && c <= '9') {
               found = true;
               result = result * 10 + (c - '0');
            }
         }

         return found ? result : 0;
      } else {
         return 0;
      }
   }
}
