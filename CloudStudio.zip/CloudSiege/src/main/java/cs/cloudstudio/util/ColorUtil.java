package cs.cloudstudio.util;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;

public final class ColorUtil {
   private ColorUtil() {
   }

   public static String color(String value) {
      return ChatColor.translateAlternateColorCodes('&', value == null ? "" : value);
   }

   public static List<String> color(List<String> values) {
      if (values != null && !values.isEmpty()) {
         List<String> result = new ArrayList<>(values.size());

         for (String value : values) {
            result.add(color(value));
         }

         return result;
      } else {
         return new ArrayList<>(0);
      }
   }

   public static String strip(String value) {
      String stripped = ChatColor.stripColor(color(value));
      return stripped == null ? "" : stripped.trim();
   }
}
