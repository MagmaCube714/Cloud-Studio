package cs.cloudstudio.util;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public final class TimeUtil {
   private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("HH:mm");

   private TimeUtil() {
   }

   public static String currentMinute(ZoneId zoneId) {
      return LocalDateTime.now(zoneId).format(FORMATTER);
   }

   public static String currentDayKey(ZoneId zoneId) {
      return LocalDateTime.now(zoneId).getDayOfWeek().name().toLowerCase(Locale.ROOT);
   }
}
