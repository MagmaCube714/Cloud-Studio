package cs.cloudstudio.util;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

public final class LocationUtil {
   private LocationUtil() {
   }

   public static Location fromSection(ConfigurationSection section, String defaultWorld) {
      if (section == null) {
         return null;
      }

      String worldName = section.getString("world", defaultWorld);
      World world = findWorld(worldName);
      return world == null
         ? null
         : new Location(
            world,
            section.getDouble("x"),
            section.getDouble("y"),
            section.getDouble("z"),
            (float)section.getDouble("yaw", 0.0),
            (float)section.getDouble("pitch", 0.0)
         );
   }

   public static World findWorld(String worldName) {
      if (worldName != null && !worldName.isEmpty()) {
         World world = Bukkit.getWorld(worldName);
         if (world != null) {
            return world;
         }

         for (World loadedWorld : Bukkit.getWorlds()) {
            if (loadedWorld.getName().equalsIgnoreCase(worldName)) {
               return loadedWorld;
            }
         }

         return null;
      } else {
         return null;
      }
   }
}
