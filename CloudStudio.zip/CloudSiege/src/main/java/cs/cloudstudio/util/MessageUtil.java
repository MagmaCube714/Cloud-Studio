package cs.cloudstudio.util;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;

public final class MessageUtil {
   private MessageUtil() {
   }

   public static void send(CommandSender sender, String message) {
      if (sender != null && message != null && !message.isEmpty()) {
         sender.sendMessage(message);
      }
   }

   public static void send(CommandSender sender, List<String> messages) {
      if (sender != null && messages != null && !messages.isEmpty()) {
         for (String message : messages) {
            send(sender, message);
         }
      }
   }

   public static void broadcast(String message) {
      if (message != null && !message.isEmpty()) {
         Bukkit.broadcastMessage(message);
      }
   }

   public static void broadcast(List<String> messages) {
      if (messages != null && !messages.isEmpty()) {
         for (String message : messages) {
            broadcast(message);
         }
      }
   }
}
