package cs.cloudstudio.command;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.command.sub.EditSubCommand;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import cs.cloudstudio.command.sub.StartSubCommand;
import cs.cloudstudio.command.sub.StopSubCommand;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public final class AdminCommand extends BaseCommand implements CommandExecutor, TabCompleter {
   private final CloudSiege plugin;

   public AdminCommand(CloudSiege plugin) {
      this.plugin = plugin;
      this.register(new StartSubCommand(plugin));
      this.register(new StopSubCommand(plugin));
      this.register(new ReloadSubCommand(plugin));
      this.register(new EditSubCommand(plugin));
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("cloudsiege.admin")) {
         sender.sendMessage(this.plugin.getConfigManager().message("no-perm"));
         return true;
      } else if (args.length == 0) {
         sender.sendMessage(this.plugin.getConfigManager().message("admin-usage"));
         return true;
      } else {
         SubCommand subCommand = this.getSubCommand(args[0]);
         if (subCommand == null) {
            sender.sendMessage(this.plugin.getConfigManager().message("admin-usage"));
            return true;
         } else {
            subCommand.execute(sender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.hasPermission("cloudsiege.admin")) {
         return Collections.emptyList();
      }

      if (args.length == 1) {
         return this.completeSubCommands(args[0]);
      }

      SubCommand subCommand = this.getSubCommand(args[0]);
      return subCommand == null ? Collections.emptyList() : subCommand.tab(sender, args);
   }
}
