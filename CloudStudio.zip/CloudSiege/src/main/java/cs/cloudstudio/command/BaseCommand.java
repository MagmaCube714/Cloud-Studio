package cs.cloudstudio.command;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public abstract class BaseCommand {
   private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();

   protected void register(SubCommand subCommand) {
      if (subCommand != null && subCommand.getName() != null) {
         this.subCommands.put(subCommand.getName().toLowerCase(Locale.ROOT), subCommand);
      }
   }

   protected SubCommand getSubCommand(String name) {
      return name == null ? null : this.subCommands.get(name.toLowerCase(Locale.ROOT));
   }

   protected Collection<SubCommand> getSubCommands() {
      return this.subCommands.values();
   }

   protected List<String> completeSubCommands(String prefix) {
      String safePrefix = prefix == null ? "" : prefix.toLowerCase(Locale.ROOT);
      List<String> result = new ArrayList<>();

      for (SubCommand subCommand : this.subCommands.values()) {
         String name = subCommand.getName();
         if (name.startsWith(safePrefix)) {
            result.add(name);
         }
      }

      return result;
   }
}
