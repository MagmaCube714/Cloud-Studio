package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand implements SubCommand {
   private final CloudSiege plugin;

   public ReloadSubCommand(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "reload";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      this.plugin.reloadPlugin();
      sender.sendMessage(this.plugin.getConfigManager().message("reload"));
   }
}
