package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;

public final class StartSubCommand implements SubCommand {
   private final CloudSiege plugin;

   public StartSubCommand(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "start";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      this.plugin.getDefenseEvent().start(sender);
   }
}
