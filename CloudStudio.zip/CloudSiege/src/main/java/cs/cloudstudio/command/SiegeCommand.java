package cs.cloudstudio.command;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.util.MessageUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class SiegeCommand implements CommandExecutor, TabCompleter {
   private static final String[] SUB_COMMANDS = new String[]{"join", "leave", "reward"};
   private final CloudSiege plugin;

   public SiegeCommand(CloudSiege plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player player)) {
         MessageUtil.send(sender, this.plugin.getConfigManager().message("only-player"));
         return true;
      } else if (args.length == 0) {
         MessageUtil.send(player, this.plugin.getConfigManager().message("siege-usage"));
         return true;
      } else {
         String sub = args[0].toLowerCase(Locale.ROOT);
         if (sub.equals("join")) {
            this.plugin.getDefenseEvent().join(player);
            return true;
         } else if (sub.equals("leave")) {
            this.plugin.getDefenseEvent().leave(player);
            return true;
         } else if (sub.equals("reward")) {
            this.plugin.getRewardHandler().openRewards(player);
            return true;
         } else {
            MessageUtil.send(player, this.plugin.getConfigManager().message("siege-usage"));
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (args.length != 1) {
         return Collections.emptyList();
      }

      String prefix = args[0].toLowerCase(Locale.ROOT);
      List<String> result = new ArrayList<>(SUB_COMMANDS.length);

      for (String value : SUB_COMMANDS) {
         if (value.startsWith(prefix)) {
            result.add(value);
         }
      }

      return result;
   }
}
