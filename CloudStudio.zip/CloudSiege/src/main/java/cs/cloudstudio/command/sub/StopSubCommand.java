package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;

public final class StopSubCommand implements SubCommand {
   private final CloudSiege plugin;

   public StopSubCommand(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "stop";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      if (this.plugin.getDefenseEvent().isInactive()) {
         sender.sendMessage(this.plugin.getConfigManager().message("not-running"));
      } else {
         this.plugin.getDefenseEvent().forceStop(false);
         sender.sendMessage(this.plugin.getConfigManager().message("event-stopped"));
      }
   }
}
