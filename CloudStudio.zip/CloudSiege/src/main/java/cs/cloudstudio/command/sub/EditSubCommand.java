package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.command.SubCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class EditSubCommand implements SubCommand {
   private final CloudSiege plugin;

   public EditSubCommand(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @Override
   public String getName() {
      return "edit";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage(this.plugin.getConfigManager().message("only-player"));
      } else {
         this.plugin.getRewardHandler().openEditor((Player)sender);
      }
   }
}
