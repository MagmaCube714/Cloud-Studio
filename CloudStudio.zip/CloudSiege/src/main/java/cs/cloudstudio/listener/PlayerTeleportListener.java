package cs.cloudstudio.listener;

import cs.cloudstudio.CloudSiege;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;

public final class PlayerTeleportListener implements Listener {
   private final CloudSiege plugin;

   public PlayerTeleportListener(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onTeleport(PlayerTeleportEvent event) {
      this.plugin.getDefenseEvent().handleTeleport(event.getPlayer(), event.getFrom(), event.getTo(), event.getCause());
   }
}
