package cs.cloudstudio.listener;

import cs.cloudstudio.CloudSiege;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerQuitListener implements Listener {
   private final CloudSiege plugin;

   public PlayerQuitListener(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.plugin.getDefenseEvent().handleQuit(event.getPlayer());
      this.plugin.getRewardHandler().handlePlayerQuit(event.getPlayer());
   }

   @EventHandler
   public void onKick(PlayerKickEvent event) {
      this.plugin.getDefenseEvent().handleQuit(event.getPlayer());
      this.plugin.getRewardHandler().handlePlayerQuit(event.getPlayer());
   }

   @EventHandler
   public void onDeath(PlayerDeathEvent event) {
      this.plugin.getDefenseEvent().handlePlayerDeath(event.getEntity());
      this.plugin.getRewardHandler().stripRewardMarkers(event.getDrops());
      this.plugin.getRewardHandler().handlePlayerQuit(event.getEntity());
   }
}
