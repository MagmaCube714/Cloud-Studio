package cs.cloudstudio.listener;

import cs.cloudstudio.CloudSiege;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public final class PlayerJoinListener implements Listener {
   private final CloudSiege plugin;

   public PlayerJoinListener(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      this.plugin.getDefenseEvent().handleJoin(event.getPlayer());
   }
}
