package cs.cloudstudio.listener;

import cs.cloudstudio.CloudSiege;
import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;

public final class CreatureSpawnListener implements Listener {
   private final CloudSiege plugin;

   public CreatureSpawnListener(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onSpawn(CreatureSpawnEvent event) {
      if (this.plugin.getDefenseEvent().getMobSpawnManager().shouldForceSpawn(event.getLocation())) {
         event.setCancelled(false);
      } else if (this.plugin.getConfigManager().isCancelNaturalSpawns()) {
         World world = event.getLocation().getWorld();
         if (world != null && world.getName().equalsIgnoreCase(this.plugin.getConfigManager().getWorldName())) {
            SpawnReason reason = event.getSpawnReason();
            if (reason == SpawnReason.NATURAL || reason == SpawnReason.PATROL || reason == SpawnReason.RAID) {
               event.setCancelled(true);
            }
         }
      }
   }
}
