package cs.cloudstudio.listener;

import cs.cloudstudio.CloudSiege;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;

public final class InventoryListener implements Listener {
   private final CloudSiege plugin;

   public InventoryListener(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         if (mayBeRewardWindow(event.getView().getTopInventory()) && this.plugin.getRewardHandler().isRewardInventory(event.getView().getTitle())) {
            this.plugin.getRewardHandler().handleRewardClick(event, player);
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDrag(InventoryDragEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         if (mayBeRewardWindow(event.getView().getTopInventory()) && this.plugin.getRewardHandler().isRewardInventory(event.getView().getTitle())) {
            this.plugin.getRewardHandler().handleRewardDrag(event, player);
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onClose(InventoryCloseEvent event) {
      if (event.getPlayer() instanceof Player) {
         Player player = (Player)event.getPlayer();
         if (this.plugin.getRewardHandler().isEditing(player) && this.plugin.getRewardHandler().isEditInventory(event.getView().getTitle())) {
            this.plugin.getRewardHandler().saveEditor(player, event.getInventory());
         } else {
            if (mayBeRewardWindow(event.getView().getTopInventory()) && this.plugin.getRewardHandler().isRewardInventory(event.getView().getTitle())) {
               this.plugin.getRewardHandler().handleRewardClose(player, event.getInventory());
            }
         }
      }
   }

   private static boolean mayBeRewardWindow(Inventory top) {
      return top != null && top.getType() == InventoryType.CHEST && top.getHolder(false) == null;
   }
}
