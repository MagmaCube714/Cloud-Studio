package cs.cloudstudio.listener;

import cs.cloudstudio.CloudSiege;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

public final class EntityDeathListener implements Listener {
   private final CloudSiege plugin;

   public EntityDeathListener(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onDeath(EntityDeathEvent event) {
      if (event.getEntity() instanceof Player) {
         this.plugin.getDefenseEvent().markDeath((Player)event.getEntity());
      } else {
         if (this.plugin.getDefenseEvent().isActiveMob(event.getEntity().getUniqueId())) {
            this.plugin.getDefenseEvent().handleDeath(event.getEntity());
         }
      }
   }
}
