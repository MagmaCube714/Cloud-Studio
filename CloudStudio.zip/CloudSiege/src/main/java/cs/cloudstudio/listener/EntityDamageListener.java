package cs.cloudstudio.listener;

import cs.cloudstudio.CloudSiege;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.projectiles.ProjectileSource;

public final class EntityDamageListener implements Listener {
   private final CloudSiege plugin;

   public EntityDamageListener(CloudSiege plugin) {
      this.plugin = plugin;
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onDamageGuard(EntityDamageByEntityEvent event) {
      if (this.plugin.getDefenseEvent().isActiveMob(event.getEntity().getUniqueId())) {
         Player player = this.getPlayer(event.getDamager());
         if (player != null && !this.plugin.getDefenseEvent().isParticipant(player.getUniqueId()) && !this.plugin.getDefenseEvent().tryRejoin(player)) {
            event.setCancelled(true);
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
   public void onDamage(EntityDamageByEntityEvent event) {
      Entity target = event.getEntity();
      if (this.plugin.getDefenseEvent().isActiveMob(target.getUniqueId())) {
         Player player = this.getPlayer(event.getDamager());
         if (player != null && this.plugin.getDefenseEvent().isParticipant(player.getUniqueId())) {
            double damage = event.getFinalDamage();
            if (target instanceof LivingEntity) {
               damage = Math.min(damage, ((LivingEntity)target).getHealth());
            }

            if (!(damage <= 0.0)) {
               this.plugin.getDefenseEvent().addDamage(player, target, damage);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
   public void onRegain(EntityRegainHealthEvent event) {
      if (this.plugin.getDefenseEvent().shouldCancelRegain(event.getEntity())) {
         event.setCancelled(true);
      }
   }

   private Player getPlayer(Entity damager) {
      if (damager instanceof Player) {
         return (Player)damager;
      }

      if (damager instanceof Projectile) {
         ProjectileSource source = ((Projectile)damager).getShooter();
         if (source instanceof Player) {
            return (Player)source;
         }
      }

      return null;
   }
}
