package cs.cloudstudio.menu;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.manager.data.PlayerEventData;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.MessageUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.Event.Result;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class RewardHandler {
   private final CloudSiege plugin;
   private final NamespacedKey rewardKey;
   private final Set<UUID> editing = new HashSet<>();
   private final Map<UUID, RewardHandler.RewardSession> sessions = new HashMap<>();
   private final Map<UUID, PlayerEventData> storedRewards = new HashMap<>();
   private final Random random = new Random();
   private String rewardTitle;
   private String editTitle;
   private int inventorySize;
   private int lowMin;
   private int lowMax;
   private double mediumDamage;
   private int mediumMin;
   private int mediumMax;
   private double highDamage;
   private int highMin;
   private int highMax;

   public RewardHandler(CloudSiege plugin) {
      this.plugin = plugin;
      this.rewardKey = new NamespacedKey(plugin, "reward_session");
      this.reload();
   }

   public void reload() {
      this.flushOpenRewardSessions();
      this.sessions.clear();
      this.editing.clear();
      this.rewardTitle = ColorUtil.color(this.plugin.getConfig().getString("settings.inventory-name", ""));
      this.editTitle = ColorUtil.color(this.plugin.getConfig().getString("rewards.edit-title", ""));
      this.inventorySize = this.plugin.getConfigManager().getInventorySize();
      this.lowMin = Math.max(1, this.plugin.getConfig().getInt("rewards.low.minLootCount", this.plugin.getConfig().getInt("rewards.low.min", 3)));
      this.lowMax = Math.max(this.lowMin, this.plugin.getConfig().getInt("rewards.low.maxLootCount", this.plugin.getConfig().getInt("rewards.low.max", 4)));
      this.mediumDamage = Math.max(0.0, this.plugin.getConfig().getDouble("rewards.medium.damage", 500.0));
      this.mediumMin = Math.max(1, this.plugin.getConfig().getInt("rewards.medium.minLootCount", this.plugin.getConfig().getInt("rewards.medium.min", 4)));
      this.mediumMax = Math.max(
         this.mediumMin, this.plugin.getConfig().getInt("rewards.medium.maxLootCount", this.plugin.getConfig().getInt("rewards.medium.max", 5))
      );
      this.highDamage = Math.max(this.mediumDamage, this.plugin.getConfig().getDouble("rewards.high.damage", 1000.0));
      this.highMin = Math.max(1, this.plugin.getConfig().getInt("rewards.high.minLootCount", this.plugin.getConfig().getInt("rewards.high.min", 5)));
      this.highMax = Math.max(this.highMin, this.plugin.getConfig().getInt("rewards.high.maxLootCount", this.plugin.getConfig().getInt("rewards.high.max", 7)));
   }

   public void openRewards(Player player) {
      UUID uuid = player.getUniqueId();
      PlayerEventData data = this.getRewardData(uuid);
      if (data == null) {
         MessageUtil.send(player, this.plugin.getConfigManager().message("reward-no-access"));
      } else if (data.isClaimed()) {
         this.consumeReward(uuid, data);
         MessageUtil.send(player, this.plugin.getConfigManager().message("reward-already-claimed"));
      } else if (!data.isRewardReady()) {
         MessageUtil.send(player, this.plugin.getConfigManager().message("reward-not-ready"));
      } else {
         RewardHandler.RewardSession oldSession = this.sessions.get(uuid);
         if (oldSession != null) {
            player.openInventory(oldSession.inventory);
         } else {
            Map<Integer, ItemStack> pendingRewards = data.getPendingRewardSlots();
            if (pendingRewards.isEmpty()) {
               pendingRewards = this.generateRewardSlots(data.getDamage());
               data.setPendingRewardSlots(pendingRewards);
            }

            if (pendingRewards.isEmpty()) {
               MessageUtil.send(player, this.plugin.getConfigManager().message("reward-empty"));
            } else {
               Inventory inventory = Bukkit.createInventory(null, this.inventorySize, this.rewardTitle);
               this.placeRewardItems(inventory, pendingRewards);
               this.sessions.put(uuid, new RewardHandler.RewardSession(inventory, data, pendingRewards));
               player.openInventory(inventory);
            }
         }
      }
   }

   public void openEditor(Player player) {
      Inventory inventory = Bukkit.createInventory(null, this.inventorySize, this.editTitle);
      ItemStack[] rewards = this.plugin.getConfigManager().getRewardConfig().getRewardSlots(inventory.getSize());

      for (int slot = 0; slot < rewards.length && slot < inventory.getSize(); slot++) {
         ItemStack item = rewards[slot];
         if (!this.isEmpty(item)) {
            inventory.setItem(slot, item.clone());
         }
      }

      this.editing.add(player.getUniqueId());
      player.openInventory(inventory);
   }

   public void storeReward(UUID uuid, PlayerEventData data) {
      if (uuid != null && data != null && data.isRewardReady()) {
         if (data.isClaimed()) {
            this.consumeReward(uuid, data);
         } else {
            PlayerEventData existing = this.storedRewards.get(uuid);
            if (existing != null) {
               if (existing.isClaimed()) {
                  this.consumeReward(uuid, existing);
               }
            } else {
               this.storedRewards.put(uuid, new PlayerEventData(data));
            }
         }
      }
   }

   public void preserveRewardSession(UUID uuid) {
      if (uuid != null) {
         RewardHandler.RewardSession session = this.sessions.remove(uuid);
         if (session != null) {
            Player player = Bukkit.getPlayer(uuid);
            this.finishSession(player, uuid, session, false);
            if (player != null && player.isOnline() && player.getOpenInventory().getTopInventory() == session.inventory) {
               player.closeInventory();
            }
         }
      }
   }

   public void handleRewardClick(InventoryClickEvent event, Player player) {
      this.denyClick(event);
      RewardHandler.RewardSession session = this.sessions.get(player.getUniqueId());
      if (session == null || event.getView().getTopInventory() != session.inventory) {
         this.syncInventory(player);
      } else if (event.getClickedInventory() != null && event.getClickedInventory() == session.inventory) {
         this.claimRewardItem(player, session, event.getSlot());
         this.syncInventory(player);
      } else {
         this.syncInventory(player);
      }
   }

   public void handleRewardDrag(InventoryDragEvent event, Player player) {
      event.setCancelled(true);
      event.setResult(Result.DENY);
      this.syncInventory(player);
   }

   public void handleRewardClose(Player player, Inventory inventory) {
      UUID uuid = player.getUniqueId();
      RewardHandler.RewardSession session = this.sessions.get(uuid);
      if (session != null && session.inventory == inventory) {
         this.sessions.remove(uuid);
         this.finishSession(player, uuid, session, true);
      }
   }

   public void saveEditor(Player player, Inventory inventory) {
      if (this.editing.remove(player.getUniqueId())) {
         this.plugin.getConfigManager().getRewardConfig().saveRewards(inventory.getContents());
         MessageUtil.send(player, this.plugin.getConfigManager().message("reward-saved"));
      }
   }

   public void handlePlayerQuit(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         RewardHandler.RewardSession session = this.sessions.remove(uuid);
         if (session != null) {
            this.finishSession(player, uuid, session, false);
         }

         this.editing.remove(uuid);
         this.stripRewardMarkers(player);
      }
   }

   public void stripRewardMarkers(List<ItemStack> items) {
      if (items != null && !items.isEmpty()) {
         for (int i = 0; i < items.size(); i++) {
            ItemStack item = items.get(i);
            if (this.hasRewardMarker(item)) {
               items.set(i, this.stripRewardMarker(item));
            }
         }
      }
   }

   public void clearPlayer(UUID uuid) {
      if (uuid != null) {
         RewardHandler.RewardSession session = this.sessions.remove(uuid);
         this.editing.remove(uuid);
         Player player = Bukkit.getPlayer(uuid);
         PlayerEventData activeData = this.getActiveEventData(uuid);
         if (session != null) {
            this.finishSession(player, uuid, session, false);
            if (session.data == activeData && activeData != null && !activeData.isRewardReady()) {
               activeData.setPendingRewards(Collections.emptyList());
            }

            if (player != null && player.isOnline() && player.getOpenInventory().getTopInventory() == session.inventory) {
               player.closeInventory();
            }
         } else {
            if (activeData != null && !activeData.isRewardReady()) {
               activeData.setPendingRewards(Collections.emptyList());
            }

            if (player != null && this.isRewardInventory(player.getOpenInventory().getTitle())) {
               player.closeInventory();
            }
         }
      }
   }

   public boolean isEditing(Player player) {
      return this.editing.contains(player.getUniqueId());
   }

   public boolean isRewardInventory(String title) {
      return title != null && title.equals(this.rewardTitle);
   }

   public boolean isEditInventory(String title) {
      return title != null && title.equals(this.editTitle);
   }

   private PlayerEventData getRewardData(UUID uuid) {
      PlayerEventData stored = this.storedRewards.get(uuid);
      return stored != null ? stored : this.getActiveEventData(uuid);
   }

   private PlayerEventData getActiveEventData(UUID uuid) {
      return this.plugin.getDefenseEvent() == null ? null : this.plugin.getDefenseEvent().getPlayerData(uuid);
   }

   private void finishSession(Player player, UUID uuid, RewardHandler.RewardSession session, boolean sendMessage) {
      this.returnForeignItems(player, session.inventory);
      this.updatePendingRewards(session.data, session);
      if (player != null) {
         this.stripRewardMarkers(player);
      }

      if (!session.data.isClaimed() && session.rewards.isEmpty()) {
         this.consumeReward(uuid, session.data);
         if (sendMessage && player != null) {
            MessageUtil.send(player, this.plugin.getConfigManager().message("reward-claimed"));
         }
      } else {
         if (!session.data.isClaimed() && session.data.isRewardReady()) {
            this.storedRewards.put(uuid, new PlayerEventData(session.data));
         }
      }
   }

   private void consumeReward(UUID uuid, PlayerEventData sessionData) {
      if (sessionData != null) {
         sessionData.setClaimed(true);
         sessionData.setRewardReady(false);
         sessionData.setPendingRewards(Collections.emptyList());
      }

      PlayerEventData stored = this.storedRewards.remove(uuid);
      if (stored != null && stored != sessionData) {
         stored.setClaimed(true);
         stored.setRewardReady(false);
         stored.setPendingRewards(Collections.emptyList());
      }

      PlayerEventData active = this.getActiveEventData(uuid);
      if (active != null && active != sessionData) {
         active.setClaimed(true);
         active.setRewardReady(false);
         active.setPendingRewards(Collections.emptyList());
      }
   }

   private void denyClick(InventoryClickEvent event) {
      event.setCancelled(true);
      event.setResult(Result.DENY);
   }

   private boolean isSafeRewardClick(InventoryClickEvent event) {
      ClickType click = event.getClick();
      InventoryAction action = event.getAction();
      if (click == ClickType.UNKNOWN || click == ClickType.CREATIVE || click == ClickType.MIDDLE || action == InventoryAction.UNKNOWN) {
         return false;
      } else if (click == ClickType.DOUBLE_CLICK || action == InventoryAction.COLLECT_TO_CURSOR) {
         return false;
      } else if (click == ClickType.DROP
         || click == ClickType.CONTROL_DROP
         || action == InventoryAction.DROP_ALL_CURSOR
         || action == InventoryAction.DROP_ONE_CURSOR
         || action == InventoryAction.DROP_ALL_SLOT
         || action == InventoryAction.DROP_ONE_SLOT) {
         return false;
      } else if (click == ClickType.NUMBER_KEY || click == ClickType.SWAP_OFFHAND || action == InventoryAction.HOTBAR_SWAP) {
         return false;
      } else {
         return event.getClickedInventory() == null ? this.isEmpty(event.getCursor()) : this.isAllowedRewardAction(action);
      }
   }

   private boolean isAllowedRewardAction(InventoryAction action) {
      switch (action) {
         case NOTHING:
         case PICKUP_ALL:
         case PICKUP_HALF:
         case PICKUP_ONE:
         case PICKUP_SOME:
         case PLACE_ALL:
         case PLACE_ONE:
         case PLACE_SOME:
         case SWAP_WITH_CURSOR:
         case MOVE_TO_OTHER_INVENTORY:
            return true;
         default:
            return false;
      }
   }

   private void syncInventory(Player player) {
      player.updateInventory();
      Bukkit.getScheduler().runTask(this.plugin, () -> {
         if (player.isOnline()) {
            player.updateInventory();
         }
      });
   }

   private void flushOpenRewardSessions() {
      if (!this.sessions.isEmpty()) {
         for (Entry<UUID, RewardHandler.RewardSession> entry : new ArrayList<>(this.sessions.entrySet())) {
            UUID uuid = entry.getKey();
            RewardHandler.RewardSession session = entry.getValue();
            this.finishSession(Bukkit.getPlayer(uuid), uuid, session, false);
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.getOpenInventory().getTopInventory() == session.inventory) {
               player.closeInventory();
            }
         }
      }
   }

   private Map<Integer, ItemStack> generateRewardSlots(double damage) {
      List<ItemStack> pool = this.uniqueRewards(this.plugin.getConfigManager().getRewardConfig().getRewards());
      if (pool.isEmpty()) {
         return Collections.emptyMap();
      }

      int min = this.lowMin;
      int max = this.lowMax;
      if (damage >= this.highDamage) {
         min = this.highMin;
         max = this.highMax;
      } else if (damage >= this.mediumDamage) {
         min = this.mediumMin;
         max = this.mediumMax;
      }

      int amount = min + this.random.nextInt(max - min + 1);
      amount = Math.min(amount, this.inventorySize);
      amount = Math.min(amount, pool.size());
      if (amount <= 0) {
         return Collections.emptyMap();
      }

      Collections.shuffle(pool, this.random);
      List<Integer> slots = new ArrayList<>(this.inventorySize);

      for (int slot = 0; slot < this.inventorySize; slot++) {
         slots.add(slot);
      }

      Collections.shuffle(slots, this.random);
      Map<Integer, ItemStack> result = new LinkedHashMap<>();

      for (int index = 0; index < amount; index++) {
         result.put(slots.get(index), pool.get(index).clone());
      }

      return result;
   }

   private int getTargetRewardRow(double damage) {
      if (this.highDamage <= 0.0 || damage >= this.highDamage) {
         return 6;
      } else if (!(this.mediumDamage <= 0.0) && !(damage >= this.mediumDamage)) {
         double span = Math.max(1.0, this.mediumDamage);
         double progress = Math.max(0.0, Math.min(1.0, damage / span));
         return 1 + (int)Math.floor(progress * 2.0);
      } else {
         double span = Math.max(1.0, this.highDamage - this.mediumDamage);
         double progress = Math.max(0.0, Math.min(1.0, (damage - this.mediumDamage) / span));
         return 3 + (int)Math.floor(progress * 3.0);
      }
   }

   private List<ItemStack> getTierPool(int targetRow) {
      int maxRow = Math.max(1, Math.min(6, targetRow));
      int minRow = Math.max(1, maxRow - 1);
      List<ItemStack> pool = this.plugin.getConfigManager().getRewardConfig().getRewardsForRows(minRow, maxRow, this.inventorySize);
      if (!pool.isEmpty()) {
         return pool;
      }

      for (int row = maxRow - 2; row >= 1; row--) {
         pool = this.plugin.getConfigManager().getRewardConfig().getRewardsForRows(row, row, this.inventorySize);
         if (!pool.isEmpty()) {
            return pool;
         }
      }

      return this.plugin.getConfigManager().getRewardConfig().getRewards();
   }

   private void placeRewardItems(Inventory inventory, Map<Integer, ItemStack> items) {
      if (items != null && !items.isEmpty()) {
         for (Entry<Integer, ItemStack> entry : items.entrySet()) {
            Integer slot = entry.getKey();
            ItemStack item = entry.getValue();
            if (slot != null && slot >= 0 && slot < inventory.getSize() && !this.isEmpty(item)) {
               inventory.setItem(slot, this.markRewardItem(item));
            }
         }
      }
   }

   private void updatePendingRewards(PlayerEventData data, RewardHandler.RewardSession session) {
      data.setPendingRewardSlots(session.rewards);
   }

   private List<ItemStack> inventoryRewardItems(Inventory inventory) {
      List<ItemStack> items = new ArrayList<>();

      for (ItemStack item : inventory.getContents()) {
         if (this.hasRewardMarker(item)) {
            items.add(this.stripRewardMarker(item));
         }
      }

      return items;
   }

   private void returnForeignItems(Player player, Inventory inventory) {
      if (player != null && inventory != null) {
         List<ItemStack> items = new ArrayList<>();

         for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack item = inventory.getItem(slot);
            if (!this.isEmpty(item)) {
               if (this.hasRewardMarker(item)) {
                  inventory.clear(slot);
               } else {
                  items.add(this.stripRewardMarker(item));
                  inventory.clear(slot);
               }
            }
         }

         this.giveOrDrop(player, items);
      }
   }

   private void giveOrDrop(Player player, List<ItemStack> items) {
      if (items != null && !items.isEmpty()) {
         Location location = player.getLocation();

         for (ItemStack item : items) {
            if (!this.isEmpty(item)) {
               Map<Integer, ItemStack> leftovers = player.getInventory().addItem(new ItemStack[]{item.clone()});
               if (!leftovers.isEmpty()) {
                  for (ItemStack leftover : leftovers.values()) {
                     if (!this.isEmpty(leftover) && location.getWorld() != null) {
                        location.getWorld().dropItemNaturally(location, leftover.clone());
                     }
                  }
               }
            }
         }

         this.syncInventory(player);
      }
   }

   private ItemStack markRewardItem(ItemStack item) {
      ItemStack copy = item.clone();
      ItemMeta meta = copy.getItemMeta();
      if (meta != null) {
         meta.getPersistentDataContainer().set(this.rewardKey, PersistentDataType.BYTE, (byte)1);
         copy.setItemMeta(meta);
      }

      return copy;
   }

   private ItemStack stripRewardMarker(ItemStack item) {
      ItemStack copy = item.clone();
      ItemMeta meta = copy.getItemMeta();
      if (meta != null) {
         meta.getPersistentDataContainer().remove(this.rewardKey);
         copy.setItemMeta(meta);
      }

      return copy;
   }

   private boolean hasRewardMarker(ItemStack item) {
      if (this.isEmpty(item) || !item.hasItemMeta()) {
         return false;
      }

      return item.getPersistentDataContainer().has(this.rewardKey, PersistentDataType.BYTE);
   }

   private void claimRewardItem(Player player, RewardHandler.RewardSession session, int slot) {
      if (slot >= 0 && slot < session.inventory.getSize()) {
         ItemStack expected = session.rewards.get(slot);
         ItemStack clicked = session.inventory.getItem(slot);
         if (expected != null && !this.isEmpty(clicked) && this.hasRewardMarker(clicked) && this.isSameReward(expected, clicked)) {
            ItemStack reward = this.stripRewardMarker(clicked);
            if (!this.hasInventorySpace(player, reward)) {
               MessageUtil.send(player, this.plugin.getConfigManager().message("inventory-full"));
            } else {
               Map<Integer, ItemStack> leftovers = player.getInventory().addItem(new ItemStack[]{reward.clone()});
               if (!leftovers.isEmpty()) {
                  this.giveOrDrop(player, new ArrayList<>(leftovers.values()));
               }

               session.rewards.remove(slot);
               session.inventory.clear(slot);
               session.data.setPendingRewardSlots(session.rewards);
               if (!session.data.isClaimed() && session.rewards.isEmpty()) {
                  UUID uuid = player.getUniqueId();
                  this.sessions.remove(uuid);
                  this.consumeReward(uuid, session.data);
                  MessageUtil.send(player, this.plugin.getConfigManager().message("reward-claimed"));
               }
            }
         }
      }
   }

   private boolean hasInventorySpace(Player player, ItemStack item) {
      if (player != null && !this.isEmpty(item)) {
         int remaining = item.getAmount();

         for (ItemStack content : player.getInventory().getStorageContents()) {
            if (this.isEmpty(content)) {
               return true;
            }

            if (content.isSimilar(item)) {
               remaining -= Math.max(0, content.getMaxStackSize() - content.getAmount());
               if (remaining <= 0) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private List<ItemStack> uniqueRewards(List<ItemStack> source) {
      List<ItemStack> result = new ArrayList<>();
      if (source != null && !source.isEmpty()) {
         for (ItemStack item : source) {
            if (!this.isEmpty(item) && !this.containsSimilar(result, item)) {
               result.add(item.clone());
            }
         }

         return result;
      } else {
         return result;
      }
   }

   private boolean containsSimilar(List<ItemStack> list, ItemStack item) {
      for (ItemStack existing : list) {
         if (this.isSameReward(existing, item)) {
            return true;
         }
      }

      return false;
   }

   private boolean isSameReward(ItemStack expected, ItemStack item) {
      if (!this.isEmpty(expected) && !this.isEmpty(item)) {
         ItemStack clean = this.hasRewardMarker(item) ? this.stripRewardMarker(item) : item;
         return expected.getAmount() == clean.getAmount() && expected.isSimilar(clean);
      } else {
         return false;
      }
   }

   private void stripRewardMarkers(Player player) {
      PlayerInventory inventory = player.getInventory();
      ItemStack[] contents = inventory.getContents();
      boolean changed = false;

      for (int i = 0; i < contents.length; i++) {
         ItemStack item = contents[i];
         if (this.hasRewardMarker(item)) {
            contents[i] = this.stripRewardMarker(item);
            changed = true;
         }
      }

      if (changed) {
         inventory.setContents(contents);
      }

      ItemStack cursor = player.getItemOnCursor();
      if (this.hasRewardMarker(cursor)) {
         player.setItemOnCursor(this.stripRewardMarker(cursor));
      }
   }

   private boolean isEmpty(ItemStack item) {
      return item == null || item.getType() == Material.AIR;
   }

   private static final class RewardSession {
      private final Inventory inventory;
      private final PlayerEventData data;
      private final Map<Integer, ItemStack> rewards;

      private RewardSession(Inventory inventory, PlayerEventData data, Map<Integer, ItemStack> rewards) {
         this.inventory = inventory;
         this.data = data;
         this.rewards = new LinkedHashMap<>();
         if (rewards != null) {
            for (Entry<Integer, ItemStack> entry : rewards.entrySet()) {
               ItemStack item = entry.getValue();
               if (entry.getKey() != null && item != null && item.getType() != Material.AIR) {
                  this.rewards.put(entry.getKey(), item.clone());
               }
            }
         }
      }
   }
}
