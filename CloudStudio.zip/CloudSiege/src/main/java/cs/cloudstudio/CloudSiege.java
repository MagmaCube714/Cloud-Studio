package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.command.SiegeCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.listener.CreatureSpawnListener;
import cs.cloudstudio.listener.EntityDamageListener;
import cs.cloudstudio.listener.EntityDeathListener;
import cs.cloudstudio.listener.InventoryListener;
import cs.cloudstudio.listener.PlayerJoinListener;
import cs.cloudstudio.listener.PlayerQuitListener;
import cs.cloudstudio.listener.PlayerTeleportListener;
import cs.cloudstudio.manager.ClanRewardHandler;
import cs.cloudstudio.manager.DefenseEvent;
import cs.cloudstudio.manager.ScheduleManager;
import cs.cloudstudio.menu.RewardHandler;
import cs.cloudstudio.util.ColorUtil;
import java.io.File;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudSiege extends JavaPlugin {
   private ConfigManager configManager;
   private DefenseEvent defenseEvent;
   private RewardHandler rewardHandler;
   private ClanRewardHandler clanRewardHandler;
   private ScheduleManager scheduleManager;

   public void onEnable() {
      if (this.checkRequiredDependencies()) {
         this.saveDefaultConfig();
         this.saveResourceIfMissing("location.yml");
         this.saveResourceIfMissing("reward.yml");
         this.configManager = new ConfigManager(this);
         this.configManager.reload();
         this.clanRewardHandler = new ClanRewardHandler(this);
         this.rewardHandler = new RewardHandler(this);
         this.defenseEvent = new DefenseEvent(this);
         this.scheduleManager = new ScheduleManager(this);
         this.registerCommands();
         this.registerListeners();
         this.scheduleManager.start();
         this.console("&fCloudSiege &aуспешно загружен!");
      }
   }

   public void onDisable() {
      if (this.scheduleManager != null) {
         this.scheduleManager.stop();
      }

      if (this.defenseEvent != null) {
         this.defenseEvent.forceStop(false);
         this.defenseEvent.getBossBarHandler().shutdown();
      }

      Bukkit.getScheduler().cancelTasks(this);
      this.console("&fCloudSiege &cуспешно выгружен!");
   }

   public void reloadPlugin() {
      this.configManager.reload();
      this.rewardHandler.reload();
      this.clanRewardHandler.reload();
      this.defenseEvent.getBossBarHandler().reload();
      this.scheduleManager.restart();
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public DefenseEvent getDefenseEvent() {
      return this.defenseEvent;
   }

   public RewardHandler getRewardHandler() {
      return this.rewardHandler;
   }

   public ClanRewardHandler getClanRewardHandler() {
      return this.clanRewardHandler;
   }

   public void warning(String message) {
      this.getLogger().warning("[CloudSiege] " + message);
   }

   public void console(String message) {
      Bukkit.getConsoleSender().sendMessage(ColorUtil.color(message));
   }

   private void registerCommands() {
      SiegeCommand siegeCommand = new SiegeCommand(this);
      PluginCommand siege = this.getCommand("siege");
      if (siege != null) {
         siege.setExecutor(siegeCommand);
         siege.setTabCompleter(siegeCommand);
      }

      AdminCommand adminCommand = new AdminCommand(this);
      PluginCommand cloudSiege = this.getCommand("cloudsiege");
      if (cloudSiege != null) {
         cloudSiege.setExecutor(adminCommand);
         cloudSiege.setTabCompleter(adminCommand);
      }
   }

   private void registerListeners() {
      PluginManager pluginManager = Bukkit.getPluginManager();
      pluginManager.registerEvents(new EntityDamageListener(this), this);
      pluginManager.registerEvents(new EntityDeathListener(this), this);
      pluginManager.registerEvents(new CreatureSpawnListener(this), this);
      pluginManager.registerEvents(new PlayerJoinListener(this), this);
      pluginManager.registerEvents(new PlayerQuitListener(this), this);
      pluginManager.registerEvents(new PlayerTeleportListener(this), this);
      pluginManager.registerEvents(new InventoryListener(this), this);
   }

   private boolean checkRequiredDependencies() {
      if (Bukkit.getPluginManager().getPlugin("CloudClans") == null) {
         this.console("&fCloudSiege &cCloudClans не найден, плагин отключён");
         Bukkit.getPluginManager().disablePlugin(this);
         return false;
      } else if (Bukkit.getPluginManager().getPlugin("MythicMobs") == null) {
         this.console("&fCloudSiege &cMythicMobs не найден, плагин отключён");
         Bukkit.getPluginManager().disablePlugin(this);
         return false;
      } else {
         return true;
      }
   }

   private void saveResourceIfMissing(String name) {
      File file = new File(this.getDataFolder(), name);
      if (!file.exists()) {
         this.saveResource(name, false);
      }
   }
}
