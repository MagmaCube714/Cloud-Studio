package cs.cloudstudio.manager;

public enum EventPhase {
   INACTIVE,
   WAITING,
   WAVE,
   BOSS,
   END;
}
