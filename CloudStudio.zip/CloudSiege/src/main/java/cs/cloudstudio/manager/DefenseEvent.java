package cs.cloudstudio.manager;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.manager.data.MobSpawnData;
import cs.cloudstudio.manager.data.PlayerEventData;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.LocationUtil;
import cs.cloudstudio.util.MessageUtil;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

public final class DefenseEvent {
   private static final int EMPTY_STOP_DELAY_SECONDS = 120;
   private static final int END_DELAY_SECONDS = 120;
   private static final long DEATH_RETURN_GRACE_MILLIS = 120000L;
   private static final int WAVE_SPAWNS_PER_BATCH = 3;
   private static final long WAVE_SPAWN_BATCH_PERIOD_TICKS = 2L;
   private static final EnumSet<Material> CHESTPLATES = EnumSet.of(Material.DIAMOND_CHESTPLATE, Material.NETHERITE_CHESTPLATE);
   private static final EnumSet<Material> LEGGINGS = EnumSet.of(Material.DIAMOND_LEGGINGS, Material.NETHERITE_LEGGINGS);
   private static final EnumSet<Material> BOOTS = EnumSet.of(Material.DIAMOND_BOOTS, Material.NETHERITE_BOOTS);
   private final CloudSiege plugin;
   private final BossBarHandler bossBarHandler;
   private final MobSpawnManager mobSpawnManager;
   private final Set<UUID> participants = new HashSet<>();
   private final Set<UUID> eligibleParticipants = new HashSet<>();
   private final Set<UUID> activeMobs = new HashSet<>();
   private final Set<UUID> bossMobs = new HashSet<>();
   private final Map<UUID, Double> mobHealthSnapshots = new HashMap<>();
   private final Map<UUID, Location> mobLocations = new HashMap<>();
   private final Set<UUID> internalTeleports = new HashSet<>();
   private final Map<UUID, Long> recentDeaths = new HashMap<>();
   private final Map<UUID, BukkitTask> joinQueueTasks = new LinkedHashMap<>();
   private final Map<UUID, PlayerEventData> playerData = new HashMap<>();
   private EventPhase phase = EventPhase.INACTIVE;
   private BukkitTask task;
   private BukkitTask mobWatchTask;
   private BukkitTask emptyStopTask;
   private BukkitTask spawnBatchTask;
   private int countdown;
   private int round;
   private int totalMobs;
   private boolean nextRoundScheduled;
   private boolean finishing;
   private boolean teleportedOut;
   private boolean bossKilled;
   private int failedRoundSpawns;
   private int currentWaveSpawned;
   private int currentWaveProcessed;
   private int currentWaveExpected;
   private boolean waveSpawning;
   private double lastBossHealthSnapshot = -1.0;
   private double lastBossMaxHealthSnapshot = -1.0;

   public DefenseEvent(CloudSiege plugin) {
      this.plugin = plugin;
      this.bossBarHandler = new BossBarHandler(plugin);
      this.mobSpawnManager = new MobSpawnManager(plugin);
   }

   public boolean start(CommandSender sender) {
      if (this.phase != EventPhase.INACTIVE) {
         if (sender != null) {
            sender.sendMessage(this.plugin.getConfigManager().message("already-started"));
         }

         return false;
      } else {
         this.participants.clear();
         this.eligibleParticipants.clear();
         this.playerData.clear();
         this.cancelJoinQueue();
         this.cancelEmptyStop();
         this.cancelSpawnBatchTask();
         this.activeMobs.clear();
         this.bossMobs.clear();
         this.mobHealthSnapshots.clear();
         this.mobLocations.clear();
         this.plugin.getClanRewardHandler().clear();
         this.phase = EventPhase.WAITING;
         this.countdown = this.plugin.getConfigManager().getStartTime();
         this.totalMobs = 0;
         this.round = 0;
         this.nextRoundScheduled = false;
         this.finishing = false;
         this.teleportedOut = false;
         this.bossKilled = false;
         this.failedRoundSpawns = 0;
         this.currentWaveSpawned = 0;
         this.currentWaveProcessed = 0;
         this.currentWaveExpected = 0;
         this.waveSpawning = false;
         this.lastBossHealthSnapshot = -1.0;
         this.lastBossMaxHealthSnapshot = -1.0;
         this.internalTeleports.clear();
         this.recentDeaths.clear();
         MessageUtil.broadcast(this.plugin.getConfigManager().messageList("event-start"));
         if (sender != null) {
            sender.sendMessage(this.plugin.getConfigManager().message("event-started"));
         }

         this.bossBarHandler.updateWaiting(this.countdown);
         this.task = Bukkit.getScheduler().runTaskTimer(this.plugin, this::tickWaiting, 20L, 20L);
         return true;
      }
   }

   public void join(Player player) {
      UUID uuid = player.getUniqueId();
      if (this.participants.contains(uuid)) {
         MessageUtil.send(player, this.plugin.getConfigManager().message("already-joined"));
         this.bossBarHandler.add(player);
      } else if (this.joinQueueTasks.containsKey(uuid)) {
         this.sendJoinQueueTitle(player, this.getJoinQueuePosition(uuid));
      } else if (this.phase == EventPhase.INACTIVE || this.phase == EventPhase.END) {
         MessageUtil.send(player, this.plugin.getConfigManager().message("event-not-active"));
      } else if (this.phase == EventPhase.WAITING) {
         if (this.participants.size() + this.joinQueueTasks.size() >= this.plugin.getConfigManager().getMaxPlayers()) {
            MessageUtil.send(player, this.plugin.getConfigManager().message("event-full"));
         } else if (!this.hasRequiredArmor(player)) {
            MessageUtil.send(player, this.plugin.getConfigManager().message("armor-required"));
         } else {
            Location location = LocationUtil.fromSection(
               this.plugin.getConfig().getConfigurationSection("settings.spawn-cord"), this.plugin.getConfigManager().getWorldName()
            );
            if (location == null) {
               this.plugin.warning("Не удалось телепортировать игрока на ивент: settings.spawn-cord указан неверно");
            } else {
               this.cancelEmptyStop();
               this.queueJoin(player);
            }
         }
      } else if (!this.eligibleParticipants.contains(uuid)) {
         MessageUtil.send(player, this.plugin.getConfigManager().message("cannot-join"));
      } else {
         this.cancelEmptyStop();
         this.queueJoin(player);
      }
   }

   public void leave(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         if (this.cancelQueuedJoin(uuid)) {
            MessageUtil.send(player, this.plugin.getConfigManager().message("left"));
            this.checkEmptyAfterLeave();
         } else if (!this.participants.contains(uuid)) {
            MessageUtil.send(player, this.plugin.getConfigManager().message("not-joined"));
         } else {
            boolean keepReward = this.phase == EventPhase.END;
            if (keepReward) {
               PlayerEventData data = this.playerData.get(uuid);
               if (data != null) {
                  data.setRewardReady(true);
                  this.plugin.getRewardHandler().storeReward(uuid, data);
               }

               this.plugin.getRewardHandler().preserveRewardSession(uuid);
            }

            Location location = this.getEndLocation();
            if (location != null) {
               this.teleport(player, location);
            } else {
               this.plugin.warning("Не удалось телепортировать игрока после выхода с ивента: settings.end-cord указан неверно");
            }

            this.freezeActiveMobHealths();
            this.refreshProgressFromSnapshots();
            this.removeParticipant(player, false);
            MessageUtil.send(player, this.plugin.getConfigManager().message("left"));
            this.checkEmptyAfterLeave();
         }
      }
   }

   public void addDamage(Player player, Entity target, double damage) {
      UUID playerId = player.getUniqueId();
      if (this.participants.contains(playerId) && this.activeMobs.contains(target.getUniqueId())) {
         PlayerEventData data = this.playerData.get(playerId);
         if (data == null) {
            data = new PlayerEventData();
            this.playerData.put(playerId, data);
         }

         data.addDamage(damage);
         this.rememberMobHealthAfterDamage(target, damage);
         this.plugin.getClanRewardHandler().addDamage(player, damage);
         if (this.bossMobs.contains(target.getUniqueId()) && target instanceof LivingEntity) {
            this.updateBossProgress((LivingEntity)target, damage);
         }
      }
   }

   public void registerMob(UUID uuid, boolean boss) {
      this.activeMobs.add(uuid);
      Entity entity = Bukkit.getEntity(uuid);
      if (entity instanceof LivingEntity living) {
         double health = living.getHealth();
         double maxHealth = Math.max(1.0, this.getMaxHealth(living));
         this.mobHealthSnapshots.put(uuid, health);
         this.mobLocations.put(uuid, entity.getLocation());
         if (boss) {
            this.lastBossHealthSnapshot = Math.max(0.001, Math.min(health, maxHealth));
            this.lastBossMaxHealthSnapshot = maxHealth;
         }
      }

      if (boss) {
         this.bossMobs.add(uuid);
      }
   }

   public void handleDeath(Entity entity) {
      UUID uuid = entity.getUniqueId();
      boolean tracked = this.activeMobs.remove(uuid);
      boolean boss = this.bossMobs.remove(uuid) || entity.hasMetadata("cloudsiege_boss");
      if (boss) {
         Double snapshot = this.mobHealthSnapshots.get(uuid);
         this.lastBossHealthSnapshot = snapshot == null ? 0.001 : Math.max(0.001, snapshot);
         if (entity instanceof LivingEntity) {
            this.lastBossMaxHealthSnapshot = Math.max(1.0, this.getMaxHealth((LivingEntity)entity));
         }
      }

      if (tracked || boss) {
         this.mobSpawnManager.unregisterMob(uuid);
         this.mobHealthSnapshots.remove(uuid);
         this.mobLocations.remove(uuid);
         if (boss) {
            if (this.phase != EventPhase.BOSS) {
               this.forceStop(false);
            } else if (this.participants.isEmpty()) {
               this.checkEmptyAfterLeave();
            } else {
               this.bossKilled = true;
               this.bossBarHandler.setProgress(0.0);
               this.finishWithRewards();
            }
         } else {
            this.updateWaveProgress();
            if (this.activeMobs.isEmpty() && this.phase == EventPhase.WAVE && !this.waveSpawning) {
               if (this.participants.isEmpty()) {
                  this.checkEmptyAfterLeave();
                  return;
               }

               if (this.hasPendingWaveSpawns()) {
                  this.resumeWaveSpawning();
                  return;
               }

               this.scheduleNextRound();
            }
         }
      }
   }

   public void forceStop(boolean rewards) {
      this.forceStop(rewards, true);
   }

   public void forceStop(boolean rewards, boolean teleportParticipants) {
      if (this.phase != EventPhase.INACTIVE) {
         if (rewards && this.bossKilled) {
            for (Entry<UUID, PlayerEventData> entry : this.playerData.entrySet()) {
               PlayerEventData data = entry.getValue();
               data.setRewardReady(true);
               this.plugin.getRewardHandler().storeReward(entry.getKey(), data);
            }
         }

         this.cancelTask();
         this.cancelMobWatchTask();
         this.cancelSpawnBatchTask();
         this.cancelEmptyStop();
         this.mobSpawnManager.clearAliveMobs();
         this.mobHealthSnapshots.clear();
         this.mobLocations.clear();

         for (UUID uuid : this.participants) {
            if (rewards && this.bossKilled) {
               this.plugin.getRewardHandler().preserveRewardSession(uuid);
            } else {
               this.plugin.getRewardHandler().clearPlayer(uuid);
            }
         }

         if (teleportParticipants && !this.participants.isEmpty() && !this.teleportedOut) {
            this.teleportOut();
         }

         this.bossBarHandler.close();
         this.cancelJoinQueue();
         this.activeMobs.clear();
         this.bossMobs.clear();
         this.mobHealthSnapshots.clear();
         this.mobLocations.clear();
         this.participants.clear();
         this.eligibleParticipants.clear();
         this.playerData.clear();
         this.internalTeleports.clear();
         this.recentDeaths.clear();
         this.plugin.getClanRewardHandler().clear();
         this.totalMobs = 0;
         this.nextRoundScheduled = false;
         this.finishing = false;
         this.teleportedOut = false;
         this.bossKilled = false;
         this.failedRoundSpawns = 0;
         this.currentWaveSpawned = 0;
         this.currentWaveProcessed = 0;
         this.currentWaveExpected = 0;
         this.waveSpawning = false;
         this.lastBossHealthSnapshot = -1.0;
         this.lastBossMaxHealthSnapshot = -1.0;
         this.phase = EventPhase.INACTIVE;
      }
   }

   public boolean isParticipant(UUID uuid) {
      return this.participants.contains(uuid);
   }

   public int getParticipantCount() {
      return this.participants.size();
   }

   public void handlePlayerDeath(Player player) {
      if (player != null) {
         if (this.phase == EventPhase.END) {
            this.bossBarHandler.add(player);
         } else {
            UUID uuid = player.getUniqueId();
            boolean wasParticipant = this.participants.contains(uuid);
            boolean wasQueued = this.cancelQueuedJoin(uuid);
            if (!wasParticipant) {
               this.bossBarHandler.add(player);
               if (wasQueued) {
                  this.checkEmptyAfterLeave();
               }
            } else {
               this.eligibleParticipants.add(uuid);
               this.freezeActiveMobHealths();
               this.refreshProgressFromSnapshots();
               this.removeParticipant(player, false);
               this.bossBarHandler.add(player);
               this.checkEmptyAfterLeave();
            }
         }
      }
   }

   public void handleJoin(Player player) {
      if (player != null && this.phase != EventPhase.INACTIVE) {
         this.bossBarHandler.add(player);
         Bukkit.getScheduler().runTask(this.plugin, () -> {
            if (player.isOnline() && this.phase != EventPhase.INACTIVE) {
               this.bossBarHandler.add(player);
               this.moveLoggedOutPlayerOut(player);
            }
         });
      }
   }

   public void handleQuit(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         boolean wasQueued = this.cancelQueuedJoin(uuid);
         boolean wasParticipant = this.participants.contains(uuid);
         if (wasQueued || wasParticipant) {
            this.eligibleParticipants.add(uuid);
         }

         this.bossBarHandler.removeCompletely(uuid);
         if (wasQueued || wasParticipant) {
            if (this.phase == EventPhase.END) {
               PlayerEventData data = this.playerData.get(uuid);
               if (data != null) {
                  data.setRewardReady(true);
                  this.plugin.getRewardHandler().storeReward(uuid, data);
               }

               this.plugin.getRewardHandler().preserveRewardSession(uuid);
               this.removeParticipant(player, false);
            } else {
               this.freezeActiveMobHealths();
               this.refreshProgressFromSnapshots();
               this.removeParticipant(player, false);
               this.checkEmptyAfterLeave();
            }
         }
      }
   }

   public void markDeath(Player player) {
      if (player != null && this.participants.contains(player.getUniqueId())) {
         this.recentDeaths.put(player.getUniqueId(), System.currentTimeMillis());
      }
   }

   public boolean tryRejoin(Player player) {
      if (player != null && (this.phase == EventPhase.WAVE || this.phase == EventPhase.BOSS)) {
         UUID uuid = player.getUniqueId();
         if (this.participants.contains(uuid)) {
            return true;
         } else if (this.eligibleParticipants.contains(uuid) && this.isInsideArena(player.getLocation())) {
            this.participants.add(uuid);
            this.recentDeaths.remove(uuid);
            this.bossBarHandler.add(player);
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean diedRecently(UUID uuid) {
      Long time = this.recentDeaths.get(uuid);
      if (time == null) {
         return false;
      } else if (System.currentTimeMillis() - time > 120000L) {
         this.recentDeaths.remove(uuid);
         return false;
      } else {
         return true;
      }
   }

   public void handleTeleport(Player player, Location from, Location to, TeleportCause cause) {
      if (this.phase != EventPhase.INACTIVE && player != null) {
         UUID uuid = player.getUniqueId();
         if (this.participants.contains(uuid) && !this.internalTeleports.contains(uuid)) {
            if (!this.isInsideArena(to)) {
               if (!this.diedRecently(uuid) && !player.isDead()) {
                  if (this.phase == EventPhase.END) {
                     PlayerEventData data = this.playerData.get(uuid);
                     if (data != null) {
                        data.setRewardReady(true);
                        this.plugin.getRewardHandler().storeReward(uuid, data);
                     }

                     this.plugin.getRewardHandler().preserveRewardSession(uuid);
                     this.removeParticipant(player, false);
                  } else {
                     this.freezeActiveMobHealths();
                     this.refreshProgressFromSnapshots();
                     this.removeParticipant(player, false);
                     MessageUtil.send(player, this.plugin.getConfigManager().message("left"));
                     this.checkEmptyAfterLeave();
                  }
               }
            }
         }
      }
   }

   public boolean isInactive() {
      return this.phase == EventPhase.INACTIVE;
   }

   public boolean isRunning() {
      return this.phase == EventPhase.WAVE || this.phase == EventPhase.BOSS;
   }

   public EventPhase getPhase() {
      return this.phase;
   }

   public PlayerEventData getPlayerData(UUID uuid) {
      return this.playerData.get(uuid);
   }

   public boolean isActiveMob(UUID uuid) {
      return this.activeMobs.contains(uuid);
   }

   public boolean isBossMob(UUID uuid) {
      return this.bossMobs.contains(uuid);
   }

   public BossBarHandler getBossBarHandler() {
      return this.bossBarHandler;
   }

   public MobSpawnManager getMobSpawnManager() {
      return this.mobSpawnManager;
   }

   private void queueJoin(Player player) {
      UUID uuid = player.getUniqueId();
      this.eligibleParticipants.add(uuid);
      this.joinQueueTasks.put(uuid, null);
      this.sendJoinQueueTitle(player, this.getJoinQueuePosition(uuid));
      long delay = this.plugin.getConfigManager().getJoinQueueDelay() * 20L;
      BukkitTask task = Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.completeQueuedJoin(uuid), delay);
      this.joinQueueTasks.put(uuid, task);
   }

   private void completeQueuedJoin(UUID uuid) {
      this.joinQueueTasks.remove(uuid);
      this.updateJoinQueueTitles();
      Player player = Bukkit.getPlayer(uuid);
      if (player != null && player.isOnline()) {
         if (this.participants.contains(uuid)) {
            MessageUtil.send(player, this.plugin.getConfigManager().message("already-joined"));
            this.bossBarHandler.add(player);
         } else if (this.phase == EventPhase.INACTIVE || this.phase == EventPhase.END) {
            MessageUtil.send(player, this.plugin.getConfigManager().message("event-not-active"));
         } else if (this.phase == EventPhase.WAITING) {
            if (this.participants.size() >= this.plugin.getConfigManager().getMaxPlayers()) {
               MessageUtil.send(player, this.plugin.getConfigManager().message("event-full"));
            } else if (!this.hasRequiredArmor(player)) {
               MessageUtil.send(player, this.plugin.getConfigManager().message("armor-required"));
            } else {
               Location location = LocationUtil.fromSection(
                  this.plugin.getConfig().getConfigurationSection("settings.spawn-cord"), this.plugin.getConfigManager().getWorldName()
               );
               if (location != null && this.teleport(player, location)) {
                  this.cancelEmptyStop();
                  this.participants.add(uuid);
                  this.eligibleParticipants.add(uuid);
                  this.playerData.putIfAbsent(uuid, new PlayerEventData());
                  MessageUtil.send(player, this.plugin.getConfigManager().message("joined"));
                  this.bossBarHandler.add(player);
                  if (this.task == null && this.countdown <= 0) {
                     this.startRound(1);
                  } else {
                     this.bossBarHandler.updateWaiting(this.countdown);
                  }
               } else {
                  this.plugin.warning("Не удалось телепортировать игрока на ивент: settings.spawn-cord указан неверно");
               }
            }
         } else if (this.eligibleParticipants.contains(uuid)) {
            if (!this.rejoinRunningEvent(player)) {
               this.checkEmptyAfterLeave();
            }
         } else {
            MessageUtil.send(player, this.plugin.getConfigManager().message("cannot-join"));
         }
      }
   }

   private boolean rejoinRunningEvent(Player player) {
      UUID uuid = player.getUniqueId();
      if (!this.hasRequiredArmor(player)) {
         MessageUtil.send(player, this.plugin.getConfigManager().message("armor-required"));
         return false;
      }

      Location location = LocationUtil.fromSection(
         this.plugin.getConfig().getConfigurationSection("settings.spawn-cord"), this.plugin.getConfigManager().getWorldName()
      );
      if (location != null && this.teleport(player, location)) {
         this.cancelEmptyStop();
         this.eligibleParticipants.add(uuid);
         this.participants.add(uuid);
         this.playerData.putIfAbsent(uuid, new PlayerEventData());
         MessageUtil.send(player, this.plugin.getConfigManager().message("joined"));
         this.bossBarHandler.add(player);
         if (this.phase == EventPhase.WAITING) {
            this.bossBarHandler.updateWaiting(this.countdown);
         } else {
            this.resumeProgressAfterRejoin();
         }

         return true;
      } else {
         this.plugin.warning("Не удалось телепортировать игрока на ивент: settings.spawn-cord указан неверно");
         return false;
      }
   }

   private void resumeProgressAfterRejoin() {
      this.stabilizeActiveMobHealths();
      this.refreshProgressFromSnapshots();
      if (this.phase == EventPhase.WAVE) {
         if (this.hasPendingWaveSpawns()) {
            this.resumeWaveSpawning();
         } else {
            if (this.activeMobs.isEmpty() && !this.waveSpawning && !this.nextRoundScheduled) {
               this.scheduleNextRound();
            }
         }
      } else {
         if (this.phase == EventPhase.BOSS && this.activeMobs.isEmpty() && !this.bossKilled && !this.finishing) {
            Entity boss = this.mobSpawnManager.getBossEntity();
            if (boss != null && boss.isValid() && !boss.isDead()) {
               this.registerMob(boss.getUniqueId(), true);
               this.refreshProgressFromSnapshots();
               return;
            }

            this.startBoss(false);
         }
      }
   }

   private boolean cancelQueuedJoin(UUID uuid) {
      if (!this.joinQueueTasks.containsKey(uuid)) {
         return false;
      }

      BukkitTask task = this.joinQueueTasks.remove(uuid);
      if (task != null) {
         task.cancel();
      }

      this.updateJoinQueueTitles();
      return true;
   }

   private void cancelJoinQueue() {
      for (BukkitTask task : this.joinQueueTasks.values()) {
         if (task != null) {
            task.cancel();
         }
      }

      this.joinQueueTasks.clear();
   }

   private int getJoinQueuePosition(UUID uuid) {
      int position = 1;

      for (UUID queued : this.joinQueueTasks.keySet()) {
         if (queued.equals(uuid)) {
            return position;
         }

         position++;
      }

      return position;
   }

   private void updateJoinQueueTitles() {
      int position = 1;

      for (UUID uuid : this.joinQueueTasks.keySet()) {
         Player queued = Bukkit.getPlayer(uuid);
         if (queued != null && queued.isOnline()) {
            this.sendJoinQueueTitle(queued, position);
         }

         position++;
      }
   }

   private void sendJoinQueueTitle(Player player, int position) {
      String title = ColorUtil.color(this.plugin.getConfigManager().getJoinQueueTitle());
      String subtitle = ColorUtil.color(this.plugin.getConfigManager().getJoinQueueSubtitle().replace("%position%", String.valueOf(position)));
      player.sendTitle(title, subtitle, 10, 40, 10);
   }

   private boolean isInsideArena(Location location) {
      return location != null && location.getWorld() != null
         ? location.getWorld().getName().equalsIgnoreCase(this.plugin.getConfigManager().getWorldName())
         : false;
   }

   private void moveLoggedOutPlayerOut(Player player) {
      if (player != null && player.isOnline() && this.phase != EventPhase.INACTIVE) {
         UUID uuid = player.getUniqueId();
         if (!this.participants.contains(uuid) && !this.joinQueueTasks.containsKey(uuid) && this.eligibleParticipants.contains(uuid)) {
            if (this.isInsideArena(player.getLocation())) {
               Location location = this.getEndLocation();
               if (location != null) {
                  this.teleport(player, location);
               }
            }
         }
      }
   }

   private boolean teleport(Player player, Location location) {
      if (player != null && location != null) {
         UUID uuid = player.getUniqueId();
         this.internalTeleports.add(uuid);

         try {
            return player.teleport(location);
         } finally {
            this.internalTeleports.remove(uuid);
         }
      } else {
         return false;
      }
   }

   private void removeParticipant(Player player, boolean removeData) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         if (!this.participants.remove(uuid)) {
            this.bossBarHandler.remove(player);
         } else {
            this.bossBarHandler.remove(player);
            this.plugin.getClanRewardHandler().clearPlayer(uuid);
            if (removeData) {
               this.playerData.remove(uuid);
               this.plugin.getRewardHandler().clearPlayer(uuid);
            }

            if (this.phase == EventPhase.WAITING) {
               this.bossBarHandler.updateWaiting(this.countdown);
            }
         }
      }
   }

   private void checkEmptyAfterLeave() {
      if (this.phase != EventPhase.INACTIVE && this.phase != EventPhase.END) {
         if (this.participants.isEmpty() && this.joinQueueTasks.isEmpty()) {
            this.pauseWaveProgressionForEmptyEvent();
            this.scheduleEmptyStop();
         } else {
            this.cancelEmptyStop();
         }
      }
   }

   private void pauseWaveProgressionForEmptyEvent() {
      if (this.phase == EventPhase.WAVE) {
         this.freezeActiveMobHealths();
         if (this.spawnBatchTask != null) {
            this.spawnBatchTask.cancel();
            this.spawnBatchTask = null;
            this.waveSpawning = false;
         }

         if (this.task != null) {
            this.cancelTask();
         }

         this.nextRoundScheduled = false;
         this.updateWaveProgress();
      } else {
         if (this.phase == EventPhase.BOSS) {
            this.freezeActiveMobHealths();
            this.refreshProgressFromSnapshots();
         }
      }
   }

   private void tickWaiting() {
      if (this.phase == EventPhase.WAITING) {
         this.countdown--;
         if (this.countdown <= 0) {
            this.cancelTask();
            if (this.participants.isEmpty()) {
               MessageUtil.broadcast(this.plugin.getConfigManager().message("event-cancelled-empty"));
               this.scheduleEmptyStop();
            } else {
               this.startRound(1);
            }
         } else {
            this.bossBarHandler.updateWaiting(this.countdown);
         }
      }
   }

   private void startRound(int nextRound) {
      this.cancelSpawnBatchTask();
      this.activeMobs.clear();
      this.bossMobs.clear();
      this.mobHealthSnapshots.clear();
      this.mobLocations.clear();
      this.failedRoundSpawns = 0;
      this.currentWaveSpawned = 0;
      this.currentWaveProcessed = 0;
      this.round = nextRound;
      this.eligibleParticipants.addAll(this.participants);
      this.phase = EventPhase.WAVE;
      List<MobSpawnData> mobs = this.plugin.getConfigManager().getLocationConfig().getMobs(this.round);
      this.currentWaveExpected = this.expectedMobs(mobs);
      this.totalMobs = this.currentWaveExpected;
      this.nextRoundScheduled = false;
      this.bossBarHandler.switchTo(this.bossBarTitle("wave" + this.round), 1.0);
      if (!mobs.isEmpty() && this.currentWaveExpected > 0) {
         this.startMobWatch();
         this.startWaveSpawnTask(mobs, nextRound);
      } else {
         this.stopBecauseWaveFailed("В location.yml нет мобов для волны " + this.round);
      }
   }

   private void startWaveSpawnTask(final List<MobSpawnData> mobs, final int waveRound) {
      if (this.phase == EventPhase.WAVE && this.round == waveRound && this.hasPendingWaveSpawns()) {
         this.cancelSpawnBatchTask();
         this.waveSpawning = true;
         this.spawnBatchTask = this.mobSpawnManager
            .spawnRoundGradually(mobs, 3, 2L, this.currentWaveProcessed, this.currentWaveSpawned, new MobSpawnManager.SpawnBatchCallback() {
               @Override
               public void onProgress(int processedRequests, int successfulSpawns) {
                  if (DefenseEvent.this.phase == EventPhase.WAVE && DefenseEvent.this.round == waveRound) {
                     DefenseEvent.this.currentWaveProcessed = Math.max(DefenseEvent.this.currentWaveProcessed, processedRequests);
                     DefenseEvent.this.currentWaveSpawned = Math.max(DefenseEvent.this.currentWaveSpawned, successfulSpawns);
                     DefenseEvent.this.totalMobs = Math.max(DefenseEvent.this.currentWaveExpected, DefenseEvent.this.currentWaveSpawned);
                     if (DefenseEvent.this.participants.isEmpty()) {
                        DefenseEvent.this.pauseWaveProgressionForEmptyEvent();
                        DefenseEvent.this.checkEmptyAfterLeave();
                     } else {
                        if (processedRequests % 5 == 0 || successfulSpawns % 5 == 0) {
                           DefenseEvent.this.updateWaveProgress();
                        }
                     }
                  }
               }

               @Override
               public void onComplete(int processedRequests, int successfulSpawns) {
                  if (DefenseEvent.this.phase == EventPhase.WAVE && DefenseEvent.this.round == waveRound) {
                     DefenseEvent.this.spawnBatchTask = null;
                     DefenseEvent.this.waveSpawning = false;
                     DefenseEvent.this.currentWaveProcessed = Math.max(DefenseEvent.this.currentWaveProcessed, processedRequests);
                     DefenseEvent.this.currentWaveSpawned = Math.max(DefenseEvent.this.currentWaveSpawned, successfulSpawns);
                     DefenseEvent.this.totalMobs = Math.max(DefenseEvent.this.currentWaveExpected, DefenseEvent.this.currentWaveSpawned);
                     if (DefenseEvent.this.participants.isEmpty()) {
                        DefenseEvent.this.updateWaveProgress();
                        DefenseEvent.this.checkEmptyAfterLeave();
                     } else if (DefenseEvent.this.activeMobs.isEmpty()) {
                        if (DefenseEvent.this.currentWaveSpawned <= 0) {
                           DefenseEvent.this.retryWaveSpawn(mobs);
                        } else {
                           DefenseEvent.this.failedRoundSpawns = 0;
                           DefenseEvent.this.updateWaveProgress();
                           DefenseEvent.this.scheduleNextRound();
                        }
                     } else {
                        DefenseEvent.this.failedRoundSpawns = 0;
                        DefenseEvent.this.updateWaveProgress();
                     }
                  }
               }
            });
      }
   }

   private void resumeWaveSpawning() {
      if (this.phase == EventPhase.WAVE && !this.waveSpawning && this.hasPendingWaveSpawns()) {
         List<MobSpawnData> mobs = this.plugin.getConfigManager().getLocationConfig().getMobs(this.round);
         if (mobs.isEmpty()) {
            this.stopBecauseWaveFailed("В location.yml нет мобов для волны " + this.round);
         } else {
            this.currentWaveExpected = this.expectedMobs(mobs);
            this.totalMobs = Math.max(this.totalMobs, this.currentWaveExpected);
            this.startMobWatch();
            this.startWaveSpawnTask(mobs, this.round);
         }
      }
   }

   private boolean hasPendingWaveSpawns() {
      return this.phase == EventPhase.WAVE && this.currentWaveExpected > 0 && this.currentWaveProcessed < this.currentWaveExpected;
   }

   private void retryWaveSpawn(List<MobSpawnData> mobs) {
      this.waveSpawning = false;
      this.cancelSpawnBatchTask();
      this.failedRoundSpawns++;
      if (this.failedRoundSpawns >= 3) {
         this.stopBecauseWaveFailed("Не удалось заспавнить мобов волны " + this.round + ": " + this.describeMobs(mobs));
      } else {
         this.task = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            if (this.phase == EventPhase.WAVE && this.activeMobs.isEmpty() && !this.participants.isEmpty()) {
               this.task = null;
               this.startRound(this.round);
            }
         }, 40L);
      }
   }

   private void stopBecauseWaveFailed(String reason) {
      this.plugin.warning(reason + " Босс не будет запущен, чтобы не пропускать волны");
      MessageUtil.broadcast(this.plugin.getConfigManager().message("event-cancelled-wave-failed"));
      this.forceStop(false);
   }

   private String describeMobs(List<MobSpawnData> mobs) {
      if (mobs != null && !mobs.isEmpty()) {
         StringBuilder builder = new StringBuilder();

         for (MobSpawnData data : mobs) {
            if (builder.length() > 0) {
               builder.append(", ");
            }

            builder.append(data.getMob()).append(" x").append(data.getCount()).append(" на локациях: ").append(data.getLocations().size());
         }

         return builder.toString();
      } else {
         return "нет мобов";
      }
   }

   private void scheduleNextRound() {
      if (!this.nextRoundScheduled && this.phase == EventPhase.WAVE) {
         if (this.hasPendingWaveSpawns()) {
            if (!this.participants.isEmpty()) {
               this.resumeWaveSpawning();
            }
         } else if (!this.activeMobs.isEmpty()) {
            this.updateWaveProgress();
         } else if (this.participants.isEmpty()) {
            this.checkEmptyAfterLeave();
         } else {
            this.nextRoundScheduled = true;
            int delay = this.plugin.getConfigManager().getNextWaveTime();
            if (delay <= 0) {
               this.startNextRoundOrBoss();
            } else {
               this.task = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                  if (this.phase == EventPhase.WAVE && this.nextRoundScheduled && !this.participants.isEmpty()) {
                     this.task = null;
                     this.startNextRoundOrBoss();
                  }
               }, delay * 20L);
            }
         }
      }
   }

   private void startNextRoundOrBoss() {
      int maxRound = this.plugin.getConfigManager().getLocationConfig().getMaxRound();
      if (this.round < maxRound) {
         this.startRound(this.round + 1);
      } else {
         this.startBoss();
      }
   }

   private void startBoss() {
      this.startBoss(true);
   }

   private void startBoss(boolean fullHealth) {
      this.cancelSpawnBatchTask();
      this.waveSpawning = false;
      this.currentWaveSpawned = 0;
      this.currentWaveProcessed = 0;
      this.currentWaveExpected = 0;
      this.activeMobs.clear();
      this.bossMobs.clear();
      this.mobHealthSnapshots.clear();
      this.mobLocations.clear();
      this.phase = EventPhase.BOSS;
      this.totalMobs = 1;
      this.nextRoundScheduled = false;
      double savedBossHealth = this.lastBossHealthSnapshot;
      double savedBossMaxHealth = this.lastBossMaxHealthSnapshot;
      this.bossBarHandler.switchTo(this.bossBarTitle("boss"), fullHealth ? 1.0 : this.getSavedBossProgress());
      int spawned = this.mobSpawnManager.spawnBoss();
      if (!fullHealth) {
         this.lastBossHealthSnapshot = savedBossHealth;
         this.lastBossMaxHealthSnapshot = savedBossMaxHealth;
         this.applyBossHealthSnapshot();
      }

      this.startMobWatch();
      if (spawned <= 0 || this.activeMobs.isEmpty()) {
         this.forceStop(false);
      }
   }

   private void finishWithRewards() {
      if (!this.finishing && this.bossKilled && this.phase == EventPhase.BOSS) {
         this.beginEnding(true, true);
      }
   }

   private void beginEnding(boolean rewards, boolean teleportParticipants) {
      if (this.phase != EventPhase.INACTIVE && this.phase != EventPhase.END) {
         this.finishing = true;
         this.phase = EventPhase.END;
         this.cancelTask();
         this.cancelMobWatchTask();
         this.cancelSpawnBatchTask();
         this.cancelEmptyStop();
         this.mobSpawnManager.clearAliveMobs();
         this.activeMobs.clear();
         this.bossMobs.clear();
         this.mobHealthSnapshots.clear();
         this.mobLocations.clear();
         if (rewards) {
            for (Entry<UUID, PlayerEventData> entry : this.playerData.entrySet()) {
               PlayerEventData data = entry.getValue();
               data.setRewardReady(true);
               this.plugin.getRewardHandler().storeReward(entry.getKey(), data);
            }

            this.plugin.getClanRewardHandler().rewardTop();
         }

         int delay = 120;
         String delayText = String.valueOf(delay);
         this.bossBarHandler.switchTo(this.plugin.getConfigManager().bossBar("end").replace("%time%", delayText), 1.0);
         if (rewards) {
            MessageUtil.broadcast(this.replaceLines(this.plugin.getConfigManager().messageList("event-end"), "%time%", delayText));
         }

         if (delay <= 0) {
            if (teleportParticipants) {
               this.teleportOut();
            }

            this.forceStop(rewards, teleportParticipants);
         } else {
            this.task = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               if (this.phase == EventPhase.END) {
                  this.task = null;
                  if (teleportParticipants) {
                     this.teleportOut();
                  }

                  this.forceStop(rewards, teleportParticipants);
               }
            }, delay * 20L);
         }
      }
   }

   private List<String> replaceLines(List<String> lines, String placeholder, String value) {
      List<String> result = new ArrayList<>(lines.size());

      for (String line : lines) {
         result.add(line == null ? "" : line.replace(placeholder, value));
      }

      return result;
   }

   private int expectedMobs(List<MobSpawnData> mobs) {
      int result = 0;

      for (MobSpawnData data : mobs) {
         result += data.getCount() * data.getLocations().size();
      }

      return result;
   }

   private void updateWaveProgress() {
      if (this.phase == EventPhase.WAVE) {
         if (!this.participants.isEmpty()) {
            this.pruneInactiveMobs();
         }

         this.bossBarHandler.setTitle(this.bossBarTitle("wave" + this.round));
         this.bossBarHandler.setProgress(this.waveProgress());
      }
   }

   private double waveProgress() {
      int total = this.waveTotalMobs();
      return (double)this.waveRemainingMobs() / total;
   }

   private int waveTotalMobs() {
      int spawned = Math.max(this.currentWaveSpawned, this.activeMobs.size());
      boolean pending = this.waveSpawning || this.hasPendingWaveSpawns();
      return Math.max(1, pending ? Math.max(this.currentWaveExpected, spawned) : spawned);
   }

   private int waveKilledMobs() {
      return Math.max(0, Math.max(this.currentWaveSpawned, this.activeMobs.size()) - this.activeMobs.size());
   }

   private int waveRemainingMobs() {
      return Math.max(0, this.waveTotalMobs() - this.waveKilledMobs());
   }

   private void updateBossProgress(LivingEntity boss, double incomingDamage) {
      if (this.phase == EventPhase.BOSS) {
         double maxHealth = this.getMaxHealth(boss);
         if (!(maxHealth <= 0.0)) {
            double remaining = Math.max(0.0, boss.getHealth() - Math.max(0.0, incomingDamage));
            this.lastBossHealthSnapshot = Math.max(0.001, Math.min(remaining, maxHealth));
            this.lastBossMaxHealthSnapshot = maxHealth;
            this.bossBarHandler.setTitle(this.bossBarTitle("boss"));
            this.bossBarHandler.setProgress(remaining / maxHealth);
         }
      }
   }

   private double getMaxHealth(LivingEntity entity) {
      AttributeInstance attribute = entity.getAttribute(Attribute.MAX_HEALTH);
      return attribute == null ? entity.getMaxHealth() : attribute.getValue();
   }

   public boolean shouldCancelRegain(Entity entity) {
      if (entity != null && this.activeMobs.contains(entity.getUniqueId())) {
         if (entity instanceof LivingEntity) {
            this.stabilizeMobHealth((LivingEntity)entity);
         }

         return true;
      } else {
         return false;
      }
   }

   public void trackMobHealth(Entity entity) {
      if (entity instanceof LivingEntity) {
         UUID uuid = entity.getUniqueId();
         if (this.activeMobs.contains(uuid)) {
            LivingEntity living = (LivingEntity)entity;
            double maxHealth = Math.max(1.0, this.getMaxHealth(living));
            double health = Math.max(0.0, Math.min(living.getHealth(), maxHealth));
            this.mobHealthSnapshots.put(uuid, health);
            this.mobLocations.put(uuid, entity.getLocation());
            if (this.bossMobs.contains(uuid)) {
               this.lastBossHealthSnapshot = Math.max(0.001, health);
               this.lastBossMaxHealthSnapshot = maxHealth;
            }
         }
      }
   }

   private void rememberMobHealthAfterDamage(Entity entity, double damage) {
      if (entity instanceof LivingEntity && !(damage <= 0.0)) {
         LivingEntity living = (LivingEntity)entity;
         UUID uuid = living.getUniqueId();
         if (this.activeMobs.contains(uuid)) {
            double snapshot = Math.max(0.0, living.getHealth() - damage);
            this.mobHealthSnapshots.put(uuid, snapshot);
            if (this.bossMobs.contains(uuid)) {
               double maxHealth = Math.max(1.0, this.getMaxHealth(living));
               this.lastBossHealthSnapshot = Math.max(0.001, Math.min(snapshot, maxHealth));
               this.lastBossMaxHealthSnapshot = maxHealth;
            }
         }
      }
   }

   private void freezeActiveMobHealths() {
      for (UUID uuid : this.activeMobs) {
         Entity entity = Bukkit.getEntity(uuid);
         if (entity instanceof LivingEntity && entity.isValid() && !entity.isDead()) {
            LivingEntity living = (LivingEntity)entity;
            double snapshot = Math.max(0.0, Math.min(living.getHealth(), this.getMaxHealth(living)));
            this.mobHealthSnapshots.put(uuid, snapshot);
            this.mobLocations.put(uuid, living.getLocation());
            if (this.bossMobs.contains(uuid)) {
               double maxHealth = Math.max(1.0, this.getMaxHealth(living));
               this.lastBossHealthSnapshot = Math.max(0.001, Math.min(snapshot, maxHealth));
               this.lastBossMaxHealthSnapshot = maxHealth;
            }
         }
      }
   }

   private void stabilizeActiveMobHealths() {
      for (UUID uuid : this.activeMobs) {
         Entity entity = Bukkit.getEntity(uuid);
         if (entity instanceof LivingEntity && entity.isValid() && !entity.isDead()) {
            this.stabilizeMobHealth((LivingEntity)entity);
         }
      }
   }

   private void stabilizeMobHealth(LivingEntity entity) {
      if (entity != null && !entity.isDead() && entity.isValid()) {
         UUID uuid = entity.getUniqueId();
         this.mobLocations.put(uuid, entity.getLocation());
         double maxHealth = this.getMaxHealth(entity);
         if (!(maxHealth <= 0.0)) {
            double current = Math.max(0.0, Math.min(entity.getHealth(), maxHealth));
            Double snapshot = this.mobHealthSnapshots.get(uuid);
            if (snapshot == null) {
               this.mobHealthSnapshots.put(uuid, current);
            } else if (current > snapshot + 0.001) {
               this.setMobHealthSafely(entity, snapshot);
               if (this.bossMobs.contains(uuid)) {
                  this.lastBossHealthSnapshot = Math.max(0.001, Math.min(snapshot, maxHealth));
                  this.lastBossMaxHealthSnapshot = maxHealth;
                  this.bossBarHandler.setTitle(this.bossBarTitle("boss"));
                  this.bossBarHandler.setProgress(this.lastBossHealthSnapshot / maxHealth);
               }
            } else {
               this.mobHealthSnapshots.put(uuid, current);
               if (this.bossMobs.contains(uuid)) {
                  this.lastBossHealthSnapshot = Math.max(0.001, Math.min(current, maxHealth));
                  this.lastBossMaxHealthSnapshot = maxHealth;
                  this.bossBarHandler.setTitle(this.bossBarTitle("boss"));
                  this.bossBarHandler.setProgress(this.lastBossHealthSnapshot / maxHealth);
               }
            }
         }
      }
   }

   private void setMobHealthSafely(LivingEntity entity, double health) {
      if (entity != null && !entity.isDead() && entity.isValid()) {
         double maxHealth = Math.max(1.0, this.getMaxHealth(entity));
         double safe = Math.max(0.001, Math.min(health, maxHealth));
         entity.setHealth(safe);
      }
   }

   private void applyBossHealthSnapshot() {
      if (!(this.lastBossHealthSnapshot <= 0.0)) {
         Entity entity = this.mobSpawnManager.getBossEntity();
         if (entity instanceof LivingEntity && !entity.isDead() && entity.isValid()) {
            LivingEntity living = (LivingEntity)entity;
            double maxHealth = Math.max(1.0, this.getMaxHealth(living));
            double health = Math.max(0.001, Math.min(this.lastBossHealthSnapshot, maxHealth));
            this.setMobHealthSafely(living, health);
            this.mobHealthSnapshots.put(living.getUniqueId(), health);
            this.mobLocations.put(living.getUniqueId(), living.getLocation());
            this.lastBossHealthSnapshot = health;
            this.lastBossMaxHealthSnapshot = maxHealth;
            this.bossBarHandler.setTitle(this.bossBarTitle("boss"));
            this.bossBarHandler.setProgress(health / maxHealth);
         }
      }
   }

   private String bossBarTitle(String key) {
      String title = this.plugin.getConfigManager().bossBar(key);
      if ((title == null || title.isEmpty()) && key != null && key.startsWith("wave")) {
         title = this.plugin.getConfigManager().bossBar("wave3");
      }

      if (title == null) {
         title = "";
      }

      title = title.replace("%player%", String.valueOf(this.participants.size()));
      title = title.replace("%max_player%", String.valueOf(this.plugin.getConfigManager().getMaxPlayers()));
      title = title.replace("%round%", String.valueOf(this.round));
      int totalWaveMobs = this.phase == EventPhase.WAVE
         ? this.waveTotalMobs()
         : Math.max(this.currentWaveExpected, Math.max(this.totalMobs, this.currentWaveSpawned));
      int killedWaveMobs = this.waveKilledMobs();
      int remainingWaveMobs = this.phase == EventPhase.WAVE ? this.waveRemainingMobs() : this.activeMobs.size();
      title = title.replace("%mobs%", String.valueOf(remainingWaveMobs));
      title = title.replace("%alive_mobs%", String.valueOf(this.activeMobs.size()));
      title = title.replace("%remaining_mobs%", String.valueOf(remainingWaveMobs));
      title = title.replace("%killed_mobs%", String.valueOf(killedWaveMobs));
      title = title.replace("%spawned_mobs%", String.valueOf(this.currentWaveSpawned));
      title = title.replace("%total_mobs%", String.valueOf(totalWaveMobs));
      title = title.replace("%health%", this.formatBossBarNumber(this.getBossBarHealthValue()));
      return title.replace("%max_health%", this.formatBossBarNumber(this.getBossBarMaxHealthValue()));
   }

   private double getBossBarHealthValue() {
      if (this.phase != EventPhase.BOSS) {
         return 0.0;
      } else {
         Entity boss = this.mobSpawnManager.getBossEntity();
         if (boss instanceof LivingEntity && boss.isValid() && !boss.isDead()) {
            LivingEntity living = (LivingEntity)boss;
            double maxHealth = Math.max(1.0, this.getMaxHealth(living));
            return Math.max(0.0, Math.min(this.lastBossHealthSnapshot > 0.0 ? this.lastBossHealthSnapshot : living.getHealth(), maxHealth));
         } else {
            return this.lastBossHealthSnapshot <= 0.0 ? 0.0 : this.lastBossHealthSnapshot;
         }
      }
   }

   private double getBossBarMaxHealthValue() {
      if (this.phase != EventPhase.BOSS) {
         return 0.0;
      } else if (this.lastBossMaxHealthSnapshot > 0.0) {
         return this.lastBossMaxHealthSnapshot;
      } else {
         Entity boss = this.mobSpawnManager.getBossEntity();
         if (boss instanceof LivingEntity && boss.isValid() && !boss.isDead()) {
            this.lastBossMaxHealthSnapshot = Math.max(1.0, this.getMaxHealth((LivingEntity)boss));
            return this.lastBossMaxHealthSnapshot;
         } else {
            return 0.0;
         }
      }
   }

   private String formatBossBarNumber(double value) {
      return Math.abs(value - Math.rint(value)) < 0.001 ? String.valueOf((long)Math.rint(value)) : String.format(Locale.US, "%.1f", value);
   }

   private void refreshProgressFromSnapshots() {
      if (this.phase == EventPhase.BOSS) {
         this.bossBarHandler.setTitle(this.bossBarTitle("boss"));
         this.bossBarHandler.setProgress(this.getSavedBossProgress());
      } else {
         if (this.phase == EventPhase.WAVE) {
            this.updateWaveProgress();
         }
      }
   }

   private double getSavedBossProgress() {
      if (this.lastBossMaxHealthSnapshot <= 0.0) {
         Entity boss = this.mobSpawnManager.getBossEntity();
         if (boss instanceof LivingEntity && boss.isValid() && !boss.isDead()) {
            this.lastBossMaxHealthSnapshot = Math.max(1.0, this.getMaxHealth((LivingEntity)boss));
         }
      }

      if (this.lastBossMaxHealthSnapshot <= 0.0) {
         return 1.0;
      }

      double health = this.lastBossHealthSnapshot <= 0.0 ? this.lastBossMaxHealthSnapshot : this.lastBossHealthSnapshot;
      return Math.max(0.0, Math.min(1.0, health / this.lastBossMaxHealthSnapshot));
   }

   private boolean hasRequiredArmor(Player player) {
      return this.hasArmor(player.getInventory().getChestplate(), CHESTPLATES)
         && this.hasArmor(player.getInventory().getLeggings(), LEGGINGS)
         && this.hasArmor(player.getInventory().getBoots(), BOOTS);
   }

   private boolean hasArmor(ItemStack item, EnumSet<Material> allowed) {
      return item != null && allowed.contains(item.getType());
   }

   private void teleportOut() {
      if (!this.teleportedOut) {
         Location location = this.getEndLocation();
         if (location == null) {
            this.plugin.warning("Не удалось телепортировать игроков после ивента: settings.end-cord указан неверно");
         } else {
            this.teleportedOut = true;

            for (UUID uuid : this.participants) {
               Player player = Bukkit.getPlayer(uuid);
               if (player != null && player.isOnline()) {
                  this.teleport(player, location);
               }
            }
         }
      }
   }

   private Location getEndLocation() {
      ConfigurationSection section = this.plugin.getConfig().getConfigurationSection("settings.end-cord");
      return LocationUtil.fromSection(section, this.plugin.getConfigManager().getWorldName());
   }

   private void startMobWatch() {
      this.cancelMobWatchTask();
      this.mobWatchTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::tickMobWatch, 20L, 20L);
   }

   private void tickMobWatch() {
      if (this.phase == EventPhase.WAVE || this.phase == EventPhase.BOSS) {
         if (this.participants.isEmpty() && this.emptyStopTask != null) {
            this.stabilizeActiveMobHealths();
            this.refreshProgressFromSnapshots();
         } else {
            boolean changed = this.pruneInactiveMobs();
            if (this.phase == EventPhase.WAVE) {
               if (changed) {
                  this.updateWaveProgress();
               }

               if (!this.waveSpawning) {
                  if (this.activeMobs.isEmpty()) {
                     if (this.hasPendingWaveSpawns()) {
                        this.resumeWaveSpawning();
                     } else {
                        this.scheduleNextRound();
                     }
                  }
               }
            } else {
               if (this.phase == EventPhase.BOSS && changed && this.activeMobs.isEmpty()) {
                  if (this.participants.isEmpty()) {
                     this.checkEmptyAfterLeave();
                     return;
                  }

                  this.forceStop(false);
               }
            }
         }
      }
   }

   private boolean pruneInactiveMobs() {
      if (this.activeMobs.isEmpty()) {
         return false;
      }

      boolean changed = false;
      Iterator<UUID> iterator = this.activeMobs.iterator();

      while (iterator.hasNext()) {
         UUID uuid = iterator.next();
         Entity entity = Bukkit.getEntity(uuid);
         if (entity == null || !entity.isValid() || entity.isDead()) {
            Location lastLocation = this.mobLocations.get(uuid);
            if (lastLocation == null
               || lastLocation.getWorld() == null
               || lastLocation.getWorld().isChunkLoaded(lastLocation.getBlockX() >> 4, lastLocation.getBlockZ() >> 4)) {
               iterator.remove();
               if (this.bossMobs.contains(uuid)) {
                  Double snapshot = this.mobHealthSnapshots.get(uuid);
                  if (snapshot != null) {
                     this.lastBossHealthSnapshot = Math.max(0.001, snapshot);
                  }
               }

               this.bossMobs.remove(uuid);
               this.mobHealthSnapshots.remove(uuid);
               this.mobLocations.remove(uuid);
               this.mobSpawnManager.unregisterMob(uuid);
               changed = true;
            }
         } else if (entity instanceof LivingEntity) {
            this.stabilizeMobHealth((LivingEntity)entity);
         }
      }

      return changed;
   }

   private void scheduleEmptyStop() {
      if (this.emptyStopTask == null && this.phase != EventPhase.INACTIVE && this.phase != EventPhase.END) {
         int delay = 120;
         if (delay <= 0) {
            this.forceStop(false, false);
         } else {
            this.emptyStopTask = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               this.emptyStopTask = null;
               if (this.phase != EventPhase.INACTIVE && this.phase != EventPhase.END && this.participants.isEmpty()) {
                  this.forceStop(false, false);
               }
            }, delay * 20L);
         }
      }
   }

   private void cancelEmptyStop() {
      if (this.emptyStopTask != null) {
         this.emptyStopTask.cancel();
         this.emptyStopTask = null;
      }
   }

   private void cancelSpawnBatchTask() {
      if (this.spawnBatchTask != null) {
         this.spawnBatchTask.cancel();
         this.spawnBatchTask = null;
      }

      this.waveSpawning = false;
   }

   private void cancelTask() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }
   }

   private void cancelMobWatchTask() {
      if (this.mobWatchTask != null) {
         this.mobWatchTask.cancel();
         this.mobWatchTask = null;
      }
   }
}
