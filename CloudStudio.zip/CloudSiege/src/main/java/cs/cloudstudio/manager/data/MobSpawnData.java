package cs.cloudstudio.manager.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Location;

public final class MobSpawnData {
   private final String mob;
   private final int count;
   private final double damage;
   private final double health;
   private final List<Location> locations;

   public MobSpawnData(String mob, int count, double damage, double health, List<Location> locations) {
      this.mob = mob != null && !mob.isEmpty() ? mob : "PILLAGER";
      this.count = Math.max(1, count);
      this.damage = damage;
      this.health = health;
      this.locations = Collections.unmodifiableList(new ArrayList<>(locations));
   }

   public String getMob() {
      return this.mob;
   }

   public int getCount() {
      return this.count;
   }

   public double getDamage() {
      return this.damage;
   }

   public double getHealth() {
      return this.health;
   }

   public List<Location> getLocations() {
      return this.locations;
   }
}
