package cs.cloudstudio.manager;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.manager.data.MobSpawnData;
import cs.cloudstudio.util.LocationUtil;
import io.lumine.mythic.api.exceptions.InvalidMobTypeException;
import io.lumine.mythic.bukkit.MythicBukkit;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitTask;

public final class MobSpawnManager {
   public static final String MOB_META = "cloudsiege_mob";
   public static final String BOSS_META = "cloudsiege_boss";
   private final CloudSiege plugin;
   private final Set<String> warnedMobs = new HashSet<>();
   private final Set<UUID> trackedMobs = new HashSet<>();
   private final Set<MobSpawnManager.PendingSpawn> pendingSpawns = new HashSet<>();
   private final Map<String, MobSpawnManager.SpawnInvoker> spawnInvokers = new HashMap<>();
   private final Map<String, Method> entityGetterMethods = new HashMap<>();
   private final Set<String> missingEntityGetters = new HashSet<>();
   private boolean warnedApi;
   private boolean environmentChecked;
   private MobSpawnManager.MythicEnvironment environment;
   private Entity bossEntity;

   public MobSpawnManager(CloudSiege plugin) {
      this.plugin = plugin;
   }

   public int spawnRound(List<MobSpawnData> mobs) {
      int spawned = 0;

      for (MobSpawnData data : mobs) {
         for (Location location : data.getLocations()) {
            spawned += this.spawn(data, location, false);
         }
      }

      return spawned;
   }

   public BukkitTask spawnRoundGradually(List<MobSpawnData> mobs, int perBatch, long periodTicks, MobSpawnManager.SpawnBatchCallback callback) {
      return this.spawnRoundGradually(mobs, perBatch, periodTicks, 0, callback);
   }

   public BukkitTask spawnRoundGradually(List<MobSpawnData> mobs, int perBatch, long periodTicks, int startIndex, MobSpawnManager.SpawnBatchCallback callback) {
      return this.spawnRoundGradually(mobs, perBatch, periodTicks, startIndex, startIndex, callback);
   }

   public BukkitTask spawnRoundGradually(
      List<MobSpawnData> mobs, int perBatch, long periodTicks, int startIndex, int initialSuccessfulSpawns, MobSpawnManager.SpawnBatchCallback callback
   ) {
      List<MobSpawnManager.SpawnRequest> requests = this.createSpawnRequests(mobs);
      if (requests.isEmpty()) {
         if (callback != null) {
            callback.onComplete(0, 0);
         }

         return null;
      } else {
         int safePerBatch = Math.max(1, perBatch);
         long safePeriodTicks = Math.max(1L, periodTicks);
         int safeStartIndex = Math.max(0, Math.min(startIndex, requests.size()));
         int[] processedRequests = new int[]{safeStartIndex};
         int[] successfulSpawns = new int[]{Math.max(0, initialSuccessfulSpawns)};
         BukkitTask[] holder = new BukkitTask[1];
         holder[0] = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            int processedThisBatch = 0;

            while (processedThisBatch < safePerBatch && processedRequests[0] < requests.size()) {
               MobSpawnManager.SpawnRequest request = requests.get(processedRequests[0]);
               processedRequests[0]++;
               successfulSpawns[0] += this.spawnOne(request.data, request.location, false);
               processedThisBatch++;
               if (callback != null) {
                  callback.onProgress(processedRequests[0], successfulSpawns[0]);
               }
            }

            if (processedRequests[0] >= requests.size()) {
               if (holder[0] != null) {
                  holder[0].cancel();
               }

               if (callback != null) {
                  callback.onComplete(processedRequests[0], successfulSpawns[0]);
               }
            }
         }, 0L, safePeriodTicks);
         return holder[0];
      }
   }

   private List<MobSpawnManager.SpawnRequest> createSpawnRequests(List<MobSpawnData> mobs) {
      List<MobSpawnManager.SpawnRequest> requests = new ArrayList<>();
      if (mobs != null) {
         for (MobSpawnData data : mobs) {
            if (data != null && data.getCount() > 0) {
               for (Location location : data.getLocations()) {
                  if (location != null) {
                     for (int i = 0; i < data.getCount(); i++) {
                        requests.add(new MobSpawnManager.SpawnRequest(data, location));
                     }
                  }
               }
            }
         }
      }

      return requests;
   }

   public int spawnBoss() {
      ConfigurationSection section = this.plugin.getConfig().getConfigurationSection("settings.boss-settings");
      if (section == null) {
         return 0;
      }

      Location location = LocationUtil.fromSection(section, this.plugin.getConfigManager().getWorldName());
      if (location == null) {
         return 0;
      }

      MobSpawnData data = new MobSpawnData(
         section.getString("mob", "goblin_3"), 1, section.getDouble("damage", 0.0), section.getDouble("health", 0.0), Collections.singletonList(location)
      );
      return this.spawn(data, location, true);
   }

   public void clearAliveMobs() {
      for (UUID uuid : this.trackedMobs) {
         Entity entity = Bukkit.getEntity(uuid);
         if (entity != null && entity.hasMetadata("cloudsiege_mob")) {
            entity.remove();
         }
      }

      this.trackedMobs.clear();
      this.bossEntity = null;
      this.pendingSpawns.clear();
   }

   public void unregisterMob(UUID uuid) {
      if (uuid != null) {
         this.trackedMobs.remove(uuid);
         if (this.bossEntity != null && uuid.equals(this.bossEntity.getUniqueId())) {
            this.bossEntity = null;
         }
      }
   }

   public Entity getBossEntity() {
      return this.bossEntity;
   }

   public boolean shouldForceSpawn(Location location) {
      if (this.plugin.getConfigManager().isForceEventSpawns() && location != null && location.getWorld() != null && !this.pendingSpawns.isEmpty()) {
         long now = System.currentTimeMillis();
         Iterator<MobSpawnManager.PendingSpawn> iterator = this.pendingSpawns.iterator();

         while (iterator.hasNext()) {
            MobSpawnManager.PendingSpawn pending = iterator.next();
            if (pending.expiresAt < now) {
               iterator.remove();
            } else if (pending.matches(location)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private int spawn(MobSpawnData data, Location location, boolean boss) {
      if (data != null && location != null && location.getWorld() != null && data.getCount() > 0) {
         int spawned = 0;

         for (int i = 0; i < data.getCount(); i++) {
            spawned += this.spawnOne(data, location, boss);
         }

         return spawned;
      } else {
         return 0;
      }
   }

   private int spawnOne(MobSpawnData data, Location location, boolean boss) {
      if (data != null && location != null && location.getWorld() != null) {
         this.tryLoadChunk(location);
         if (this.plugin.getConfigManager().isForceEventSpawns()) {
            this.prepareForcedSpawn(location);
         }

         LivingEntity entity = this.spawnMythicMob(data.getMob(), location);
         if (entity == null && this.plugin.getConfigManager().isFallbackVanillaSpawn()) {
            entity = this.spawnVanilla(data, location);
         }

         if (entity == null) {
            return 0;
         }

         entity.teleport(location);
         this.mark(entity, data, boss);
         return 1;
      } else {
         return 0;
      }
   }

   private void prepareForcedSpawn(Location location) {
      if (location != null && location.getWorld() != null) {
         long now = System.currentTimeMillis();
         this.cleanupPendingSpawns(now);
         this.pendingSpawns.add(new MobSpawnManager.PendingSpawn(location, now + 2000L));
      }
   }

   private void cleanupPendingSpawns(long now) {
      Iterator<MobSpawnManager.PendingSpawn> iterator = this.pendingSpawns.iterator();

      while (iterator.hasNext()) {
         if (iterator.next().expiresAt < now) {
            iterator.remove();
         }
      }
   }

   private LivingEntity spawnMythicMob(String mob, Location location) {
      MythicBukkit mythic = MythicBukkit.inst();
      if (mythic == null) {
         if (!this.warnedApi) {
            this.warnedApi = true;
            this.plugin.warning("MythicMobs недоступен: используется fallback через команду MythicMobs");
         }

         return this.spawnMythicMobCommand(mob, location);
      } else {
         try {
            Entity entity = mythic.getAPIHelper().spawnMythicMob(mob, location);
            if (entity instanceof LivingEntity) {
               return (LivingEntity)entity;
            }
         } catch (InvalidMobTypeException exception) {
            if (this.warnedMobs.add(mob.toLowerCase(Locale.ROOT))) {
               this.plugin.warning("Моб MythicMobs не найден: " + mob);
            }
         } catch (RuntimeException exception) {
            if (this.warnedMobs.add(mob.toLowerCase(Locale.ROOT))) {
               this.plugin.warning("MythicMobs не смог заспавнить " + mob + ": " + exception.getMessage());
            }
         }

         return this.spawnMythicMobCommand(mob, location);
      }
   }

   private boolean isSafeMobId(String mob) {
      if (mob != null && !mob.isEmpty() && mob.length() <= 64) {
         for (int i = 0; i < mob.length(); i++) {
            char c = mob.charAt(i);
            if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z') && (c < '0' || c > '9') && c != '_' && c != '-' && c != ':') {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private LivingEntity spawnMythicMobCommand(String mob, Location location) {
      if (this.plugin.getConfigManager().isCommandSpawnFallback() && location != null && location.getWorld() != null && this.isSafeMobId(mob)) {
         Set<UUID> before = new HashSet<>();

         for (Entity entity : location.getWorld().getNearbyEntities(location, 8.0, 8.0, 8.0)) {
            before.add(entity.getUniqueId());
         }

         String command = "mm mobs spawn "
            + mob
            + " 1 "
            + location.getWorld().getName()
            + ","
            + location.getX()
            + ","
            + location.getY()
            + ","
            + location.getZ();
         Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
         LivingEntity result = null;
         double bestDistance = Double.MAX_VALUE;

         for (Entity entity : location.getWorld().getNearbyEntities(location, 8.0, 8.0, 8.0)) {
            if (!before.contains(entity.getUniqueId()) && entity instanceof LivingEntity) {
               Location entityLocation = entity.getLocation();
               double dx = entityLocation.getX() - location.getX();
               double dy = entityLocation.getY() - location.getY();
               double dz = entityLocation.getZ() - location.getZ();
               double distance = dx * dx + dy * dy + dz * dz;
               if (distance < bestDistance) {
                  bestDistance = distance;
                  result = (LivingEntity)entity;
               }
            }
         }

         return result;
      } else {
         return null;
      }
   }

   private LivingEntity spawnVanilla(MobSpawnData data, Location location) {
      EntityType type = this.plugin.getConfigManager().getFallbackEntityType();
      Entity entity = location.getWorld().spawnEntity(location, type);
      return entity instanceof LivingEntity ? (LivingEntity)entity : null;
   }

   private void mark(LivingEntity entity, MobSpawnData data, boolean boss) {
      UUID uuid = entity.getUniqueId();
      this.trackedMobs.add(uuid);
      entity.setMetadata("cloudsiege_mob", new FixedMetadataValue(this.plugin, true));
      if (boss) {
         entity.setMetadata("cloudsiege_boss", new FixedMetadataValue(this.plugin, true));
         this.bossEntity = entity;
      }

      if (data.getHealth() > 0.0) {
         AttributeInstance health = entity.getAttribute(Attribute.MAX_HEALTH);
         if (health != null) {
            health.setBaseValue(data.getHealth());
            entity.setHealth(Math.min(data.getHealth(), health.getValue()));
         }
      }

      if (data.getDamage() > 0.0) {
         AttributeInstance damage = entity.getAttribute(Attribute.ATTACK_DAMAGE);
         if (damage != null) {
            damage.setBaseValue(data.getDamage());
         }
      }

      this.plugin.getDefenseEvent().registerMob(uuid, boss);
      this.plugin.getDefenseEvent().trackMobHealth(entity);
   }

   private MobSpawnManager.MythicEnvironment findEnvironment() {
      if (this.environmentChecked) {
         return this.environment;
      }

      this.environmentChecked = true;
      this.environment = this.createEnvironment("io.lumine.mythic.bukkit.MythicBukkit", "io.lumine.mythic.bukkit.BukkitAdapter");
      if (this.environment != null) {
         return this.environment;
      }

      this.environment = this.createEnvironment("io.lumine.mythic.bukkit.MythicBukkit", "io.lumine.mythic.bukkit.adapters.BukkitAdapter");
      if (this.environment != null) {
         return this.environment;
      }

      this.environment = this.createEnvironment("io.lumine.xikage.mythicmobs.MythicMobs", "io.lumine.xikage.mythicmobs.adapters.bukkit.BukkitAdapter");
      return this.environment;
   }

   private MobSpawnManager.MythicEnvironment createEnvironment(String mainClassName, String adapterClassName) {
      try {
         Class<?> mainClass = Class.forName(mainClassName);
         Class<?> adapterClass = Class.forName(adapterClassName);
         Object instance = mainClass.getMethod("inst").invoke(null);
         Object mobManager = instance.getClass().getMethod("getMobManager").invoke(instance);
         Method getMobMethod = this.findMethod(mobManager.getClass(), "getMythicMob", 1);
         Method adaptLocationMethod = this.findAdaptMethod(adapterClass);
         return getMobMethod != null && adaptLocationMethod != null
            ? new MobSpawnManager.MythicEnvironment(mobManager, getMobMethod, adaptLocationMethod)
            : null;
      } catch (ClassNotFoundException ignored) {
         return null;
      } catch (ReflectiveOperationException ignored) {
         return null;
      }
   }

   private Object findMythicMob(MobSpawnManager.MythicEnvironment environment, String mob) {
      try {
         Object result = environment.getMobMethod.invoke(environment.mobManager, mob);
         return result instanceof Optional<?> optional ? optional.orElse(null) : result;
      } catch (IllegalAccessException | InvocationTargetException ignored) {
         return null;
      }
   }

   private Object adaptLocation(MobSpawnManager.MythicEnvironment environment, Location location) {
      try {
         return environment.adaptLocationMethod.invoke(null, location);
      } catch (IllegalAccessException | InvocationTargetException ignored) {
         return null;
      }
   }

   private Object invokeSpawn(Object mythicMob, Object mythicLocation) {
      String key = mythicMob.getClass().getName() + "#" + mythicLocation.getClass().getName();
      MobSpawnManager.SpawnInvoker invoker = this.spawnInvokers.get(key);
      if (invoker == null) {
         invoker = this.createSpawnInvoker(mythicMob.getClass(), mythicLocation.getClass());
         this.spawnInvokers.put(key, invoker == null ? MobSpawnManager.SpawnInvoker.EMPTY : invoker);
      }

      if (invoker == MobSpawnManager.SpawnInvoker.EMPTY) {
         return null;
      }

      try {
         return invoker.invoke(mythicMob, mythicLocation);
      } catch (IllegalAccessException | InvocationTargetException ignored) {
         return null;
      }
   }

   private MobSpawnManager.SpawnInvoker createSpawnInvoker(Class<?> mobClass, Class<?> locationClass) {
      for (Method method : mobClass.getMethods()) {
         if (method.getName().equals("spawn") && method.getParameterCount() == 2) {
            Class<?>[] types = method.getParameterTypes();
            if (types[0].isAssignableFrom(locationClass)) {
               Object level = this.levelArgument(types[1]);
               if (level != null) {
                  return new MobSpawnManager.SpawnInvoker(method, level);
               }
            }
         }
      }

      for (Method method : mobClass.getMethods()) {
         if (method.getName().equals("spawn") && method.getParameterCount() == 1 && method.getParameterTypes()[0].isAssignableFrom(locationClass)) {
            return new MobSpawnManager.SpawnInvoker(method, null);
         }
      }

      return null;
   }

   private Method findAdaptMethod(Class<?> adapterClass) {
      for (Method method : adapterClass.getMethods()) {
         if (method.getName().equals("adapt")
            && Modifier.isStatic(method.getModifiers())
            && method.getParameterCount() == 1
            && method.getParameterTypes()[0].isAssignableFrom(Location.class)) {
            return method;
         }
      }

      return null;
   }

   private Object levelArgument(Class<?> type) {
      if (type == double.class || type == Double.class) {
         return 1.0;
      } else if (type == float.class || type == Float.class) {
         return 1.0F;
      } else if (type == int.class || type == Integer.class) {
         return 1;
      } else {
         return type != long.class && type != Long.class ? null : 1L;
      }
   }

   private Entity extractBukkitEntity(Object value, int depth) {
      if (value == null || depth > 5) {
         return null;
      } else if (value instanceof Entity) {
         return (Entity)value;
      } else if (value instanceof Optional<?> optional) {
         return optional.isPresent() ? this.extractBukkitEntity(optional.get(), depth + 1) : null;
      } else {
         Entity direct = this.invokeEntityGetter(value, "getBukkitEntity", depth);
         if (direct != null) {
            return direct;
         }

         Entity nested = this.invokeEntityGetter(value, "getEntity", depth);
         return nested != null ? nested : this.invokeEntityGetter(value, "getLivingEntity", depth);
      }
   }

   private Entity invokeEntityGetter(Object value, String methodName, int depth) {
      String key = value.getClass().getName() + "#" + methodName;
      if (this.missingEntityGetters.contains(key)) {
         return null;
      }

      Method method = this.entityGetterMethods.get(key);
      if (method == null) {
         try {
            method = value.getClass().getMethod(methodName);
            this.entityGetterMethods.put(key, method);
         } catch (NoSuchMethodException ignored) {
            this.missingEntityGetters.add(key);
            return null;
         }
      }

      try {
         Object result = method.invoke(value);
         return this.extractBukkitEntity(result, depth + 1);
      } catch (IllegalAccessException | InvocationTargetException ignored) {
         return null;
      }
   }

   private Method findMethod(Class<?> owner, String name, int parameters) {
      for (Method method : owner.getMethods()) {
         if (method.getName().equals(name)
            && method.getParameterCount() == parameters
            && (parameters != 1 || method.getParameterTypes()[0].isAssignableFrom(String.class))) {
            return method;
         }
      }

      return null;
   }

   private void tryLoadChunk(Location location) {
      World world = location.getWorld();
      int chunkX = location.getBlockX() >> 4;
      int chunkZ = location.getBlockZ() >> 4;

      try {
         if (!world.isChunkLoaded(chunkX, chunkZ)) {
            world.loadChunk(chunkX, chunkZ);
         }
      } catch (Throwable var6) {
      }
   }

   private static final class MythicEnvironment {
      private final Object mobManager;
      private final Method getMobMethod;
      private final Method adaptLocationMethod;

      private MythicEnvironment(Object mobManager, Method getMobMethod, Method adaptLocationMethod) {
         this.mobManager = mobManager;
         this.getMobMethod = getMobMethod;
         this.adaptLocationMethod = adaptLocationMethod;
      }
   }

   private static final class PendingSpawn {
      private final String world;
      private final double x;
      private final double y;
      private final double z;
      private final long expiresAt;

      private PendingSpawn(Location location, long expiresAt) {
         this.world = location.getWorld().getName();
         this.x = location.getX();
         this.y = location.getY();
         this.z = location.getZ();
         this.expiresAt = expiresAt;
      }

      private boolean matches(Location location) {
         if (!this.world.equalsIgnoreCase(location.getWorld().getName())) {
            return false;
         }

         double dx = location.getX() - this.x;
         double dy = location.getY() - this.y;
         double dz = location.getZ() - this.z;
         return dx * dx + dy * dy + dz * dz <= 16.0;
      }
   }

   public interface SpawnBatchCallback {
      void onProgress(int var1, int var2);

      void onComplete(int var1, int var2);
   }

   private static final class SpawnInvoker {
      private static final MobSpawnManager.SpawnInvoker EMPTY = new MobSpawnManager.SpawnInvoker(null, null);
      private final Method method;
      private final Object level;

      private SpawnInvoker(Method method, Object level) {
         this.method = method;
         this.level = level;
      }

      private Object invoke(Object mythicMob, Object mythicLocation) throws InvocationTargetException, IllegalAccessException {
         if (this.method == null) {
            return null;
         } else {
            return this.level == null ? this.method.invoke(mythicMob, mythicLocation) : this.method.invoke(mythicMob, mythicLocation, this.level);
         }
      }
   }

   private static final class SpawnRequest {
      private final MobSpawnData data;
      private final Location location;

      private SpawnRequest(MobSpawnData data, Location location) {
         this.data = data;
         this.location = location;
      }
   }
}
