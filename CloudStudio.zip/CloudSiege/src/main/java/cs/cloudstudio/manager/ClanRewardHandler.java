package cs.cloudstudio.manager;

import cs.cloudstudio.CloudSiege;
import cs.cloudstudio.util.ColorUtil;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class ClanRewardHandler {
   private static final double MAX_VALUE = 2.0E9;
   private static final String NO_CLAN = "";
   private final CloudSiege plugin;
   private final Map<String, ClanRewardHandler.ClanDamage> clanDamage = new HashMap<>();
   private final Map<UUID, String> playerClanCache = new HashMap<>();
   private boolean enabled;
   private int topLimit;
   private int experience;
   private int coins;
   private List<String> messages = Collections.emptyList();
   private boolean missingWarningLogged;

   public ClanRewardHandler(CloudSiege plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.enabled = this.plugin.getConfig().getBoolean("clans.enabled", true);
      this.topLimit = Math.max(1, this.plugin.getConfig().getInt("clans.top-limit", 3));
      this.experience = Math.max(0, this.plugin.getConfig().getInt("clans.experience", 50));
      this.coins = Math.max(0, this.plugin.getConfig().getInt("clans.coins", 50));
      this.messages = ColorUtil.color(this.plugin.getConfig().getStringList("clans.messages"));
      this.missingWarningLogged = false;
   }

   public void clear() {
      this.clanDamage.clear();
      this.playerClanCache.clear();
   }

   public void addDamage(Player player, double damage) {
      if (this.enabled && player != null && !(damage <= 0.0)) {
         UUID uuid = player.getUniqueId();
         String clanName = this.playerClanCache.get(uuid);
         if (clanName == null) {
            Object clan = this.resolveClan(player);
            String var8 = clan == null ? "" : this.stringValue(clan, "getName");
            clanName = var8 != null && !var8.isEmpty() ? var8 : "";
            this.playerClanCache.put(uuid, clanName);
         }

         if (!clanName.isEmpty()) {
            String key = clanName.toLowerCase(Locale.ROOT);
            ClanRewardHandler.ClanDamage data = this.clanDamage.get(key);
            if (data == null) {
               data = new ClanRewardHandler.ClanDamage(clanName);
               this.clanDamage.put(key, data);
            }

            data.damage += damage;
         }
      }
   }

   public void rewardTop() {
      if (this.enabled && !this.clanDamage.isEmpty()) {
         Object cloudClans = this.getCloudClans();
         Object manager = this.getClanManager(cloudClans);
         Object database = this.getDatabase(cloudClans);
         if (cloudClans != null && manager != null && database != null) {
            List<ClanRewardHandler.ClanDamage> top = new ArrayList<>(this.clanDamage.values());
            top.removeIf(datax -> datax.damage <= 0.0);
            top.sort(Comparator.<ClanRewardHandler.ClanDamage>comparingDouble(datax -> datax.damage).reversed());
            int size = Math.min(this.topLimit, top.size());

            for (int i = 0; i < size; i++) {
               ClanRewardHandler.ClanDamage data = top.get(i);
               Object clan = this.invoke(manager, "getClanByName", new Object[]{data.name});
               if (clan != null) {
                  this.rewardClan(cloudClans, clan, i + 1, data.damage);
               }
            }
         } else {
            this.warnMissing();
         }
      }
   }

   public void clearPlayer(UUID uuid) {
      if (uuid != null) {
         this.playerClanCache.remove(uuid);
      }
   }

   private void rewardClan(Object cloudClans, Object clan, int place, double damage) {
      double oldExp;
      double oldPoints;
      double newExp;
      synchronized (clan) {
         oldExp = sanitize(this.doubleValue(clan, "getExp"));
         oldPoints = sanitize(this.doubleValue(clan, "getPoints"));
         newExp = safeAdd(oldExp, this.experience);
         double newPoints = safeAdd(oldPoints, this.coins);
         this.invoke(clan, "setExp", new Object[]{newExp});
         this.invoke(clan, "setPoints", new Object[]{newPoints});
      }

      if (!this.saveClan(cloudClans, clan)) {
         this.rollback(cloudClans, clan, oldExp, oldPoints);
         this.plugin.warning("Награда клану " + this.stringValue(clan, "getName") + " не сохранена: ошибка базы данных кланов");
      } else {
         this.checkLevelChange(clan, oldExp, newExp);
         this.sendMessages(clan, place, damage);
      }
   }

   private boolean saveClan(Object cloudClans, Object clan) {
      Object database = this.getDatabase(cloudClans);
      if (database != null && clan != null) {
         Object result = this.invoke(database, "saveClanNow", new Object[]{clan});
         if (result instanceof Boolean && (Boolean)result) {
            return true;
         }

         Object asyncResult = this.invoke(database, "saveClan", new Object[]{clan});
         if (asyncResult != ClanRewardHandler.InvocationFailed.INSTANCE) {
            return true;
         }

         Object direct = this.invoke(clan, "saveToDatabase", new Object[0]);
         return direct != ClanRewardHandler.InvocationFailed.INSTANCE;
      } else {
         return false;
      }
   }

   private void rollback(Object cloudClans, Object clan, double oldExp, double oldPoints) {
      try {
         synchronized (clan) {
            this.invoke(clan, "setExp", new Object[]{oldExp});
            this.invoke(clan, "setPoints", new Object[]{oldPoints});
         }

         this.saveClan(cloudClans, clan);
      } catch (RuntimeException var10) {
      }
   }

   private static double sanitize(double value) {
      return Double.isFinite(value) && value > 0.0 ? Math.min(2.0E9, value) : 0.0;
   }

   private static double safeAdd(double base, double value) {
      return !(value <= 0.0) && !(base >= 2.0E9) ? Math.min(2.0E9, base + value) : base;
   }

   private void sendMessages(Object clan, int place, double damage) {
      if (!this.messages.isEmpty()) {
         Object cloudClans = this.getCloudClans();
         Object manager = this.getClanManager(cloudClans);
         if (manager != null) {
            String clanName = this.stringValue(clan, "getName");
            String placeText = String.valueOf(place);
            String damageText = String.valueOf((long)damage);
            String experienceText = String.valueOf(this.experience);
            String coinsText = String.valueOf(this.coins);

            for (Player player : Bukkit.getOnlinePlayers()) {
               Object playerClan = this.invoke(manager, "getPlayerClan", new Object[]{player});
               String playerClanName = playerClan == null ? "" : this.stringValue(playerClan, "getName");
               if (playerClanName.equalsIgnoreCase(clanName)) {
                  for (String message : this.messages) {
                     player.sendMessage(this.replace(message, clanName, placeText, damageText, experienceText, coinsText));
                  }
               }
            }
         }
      }
   }

   private Object resolveClan(Player player) {
      Object cloudClans = this.getCloudClans();
      Object manager = this.getClanManager(cloudClans);
      if (manager == null) {
         this.warnMissing();
         return null;
      } else {
         return this.invoke(manager, "getPlayerClan", new Object[]{player});
      }
   }

   private Object getCloudClans() {
      Object pluginInstance = Bukkit.getPluginManager().getPlugin("CloudClans");
      return pluginInstance != null && Bukkit.getPluginManager().isPluginEnabled("CloudClans") ? pluginInstance : null;
   }

   private Object getClanManager(Object cloudClans) {
      return cloudClans == null ? null : this.invoke(cloudClans, "getClanManager", new Object[0]);
   }

   private Object getDatabase(Object cloudClans) {
      return cloudClans == null ? null : this.invoke(cloudClans, "getDatabase", new Object[0]);
   }

   private void checkLevelChange(Object clan, double oldExp, double newExp) {
   }

   private String replace(String value, String clan, String place, String damage, String experience, String coins) {
      return value != null && !value.isEmpty()
         ? value.replace("%clan%", clan)
            .replace("%place%", place)
            .replace("%damage%", damage)
            .replace("%experience%", experience)
            .replace("%exp%", experience)
            .replace("%reward_exp%", experience)
            .replace("%points%", coins)
            .replace("%coins%", coins)
            .replace("%reward_points%", coins)
         : "";
   }

   private void warnMissing() {
      if (!this.missingWarningLogged) {
         this.missingWarningLogged = true;
         this.plugin.warning("Клановые награды отключены: CloudClans недоступен");
      }
   }

   private String stringValue(Object owner, String methodName) {
      Object value = this.invoke(owner, methodName, new Object[0]);
      return value != null && value != ClanRewardHandler.InvocationFailed.INSTANCE ? String.valueOf(value) : "";
   }

   private double doubleValue(Object owner, String methodName) {
      Object value = this.invoke(owner, methodName, new Object[0]);
      return value instanceof Number ? ((Number)value).doubleValue() : 0.0;
   }

   private Object invoke(Object owner, String name, Object[] args) {
      if (owner == null) {
         return ClanRewardHandler.InvocationFailed.INSTANCE;
      }

      try {
         Method method = this.findCompatibleMethod(owner.getClass(), name, args);
         return method == null ? ClanRewardHandler.InvocationFailed.INSTANCE : method.invoke(owner, args);
      } catch (IllegalAccessException | InvocationTargetException | RuntimeException exception) {
         return ClanRewardHandler.InvocationFailed.INSTANCE;
      }
   }

   private Method findCompatibleMethod(Class<?> owner, String name, Object[] args) {
      for (Method method : owner.getMethods()) {
         if (method.getName().equals(name) && method.getParameterCount() == args.length) {
            Class<?>[] types = method.getParameterTypes();
            boolean compatible = true;

            for (int i = 0; i < types.length; i++) {
               Object arg = args[i];
               if (arg != null) {
                  Class<?> type = this.wrap(types[i]);
                  if (!type.isAssignableFrom(arg.getClass())) {
                     compatible = false;
                     break;
                  }
               }
            }

            if (compatible) {
               return method;
            }
         }
      }

      return null;
   }

   private Class<?> wrap(Class<?> type) {
      if (!type.isPrimitive()) {
         return type;
      } else if (type == double.class) {
         return Double.class;
      } else if (type == int.class) {
         return Integer.class;
      } else if (type == long.class) {
         return Long.class;
      } else if (type == float.class) {
         return Float.class;
      } else if (type == boolean.class) {
         return Boolean.class;
      } else if (type == byte.class) {
         return Byte.class;
      } else if (type == short.class) {
         return Short.class;
      } else {
         return type == char.class ? Character.class : type;
      }
   }

   private static final class ClanDamage {
      private final String name;
      private double damage;

      private ClanDamage(String name) {
         this.name = name;
      }
   }

   private enum InvocationFailed {
      INSTANCE;
   }
}
