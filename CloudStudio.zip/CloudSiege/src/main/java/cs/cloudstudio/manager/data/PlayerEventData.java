package cs.cloudstudio.manager.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public final class PlayerEventData {
   private double damage;
   private boolean rewardReady;
   private boolean claimed;
   private final List<ItemStack> pendingRewards = new ArrayList<>();
   private final Map<Integer, ItemStack> pendingRewardSlots = new LinkedHashMap<>();

   public PlayerEventData() {
   }

   public PlayerEventData(PlayerEventData source) {
      if (source != null) {
         this.damage = source.damage;
         this.rewardReady = source.rewardReady;
         this.claimed = source.claimed;
         if (!source.pendingRewardSlots.isEmpty()) {
            this.setPendingRewardSlots(source.pendingRewardSlots);
         } else {
            this.setPendingRewards(source.pendingRewards);
         }
      }
   }

   public void addDamage(double value) {
      if (value > 0.0) {
         this.damage += value;
      }
   }

   public double getDamage() {
      return this.damage;
   }

   public boolean isRewardReady() {
      return this.rewardReady;
   }

   public void setRewardReady(boolean rewardReady) {
      this.rewardReady = rewardReady;
   }

   public boolean isClaimed() {
      return this.claimed;
   }

   public void setClaimed(boolean claimed) {
      this.claimed = claimed;
   }

   public List<ItemStack> getPendingRewards() {
      return this.pendingRewards;
   }

   public Map<Integer, ItemStack> getPendingRewardSlots() {
      Map<Integer, ItemStack> result = new LinkedHashMap<>();

      for (Entry<Integer, ItemStack> entry : this.pendingRewardSlots.entrySet()) {
         ItemStack item = entry.getValue();
         if (entry.getKey() != null && !this.isEmpty(item)) {
            result.put(entry.getKey(), item.clone());
         }
      }

      return result;
   }

   public void setPendingRewards(List<ItemStack> rewards) {
      this.pendingRewards.clear();
      this.pendingRewardSlots.clear();
      if (rewards != null && !rewards.isEmpty()) {
         int slot = 0;

         for (ItemStack item : rewards) {
            if (!this.isEmpty(item)) {
               ItemStack copy = item.clone();
               this.pendingRewards.add(copy.clone());
               this.pendingRewardSlots.put(slot++, copy);
            }
         }
      }
   }

   public void setPendingRewardSlots(Map<Integer, ItemStack> rewards) {
      this.pendingRewards.clear();
      this.pendingRewardSlots.clear();
      if (rewards != null && !rewards.isEmpty()) {
         for (Entry<Integer, ItemStack> entry : rewards.entrySet()) {
            ItemStack item = entry.getValue();
            Integer slot = entry.getKey();
            if (slot != null && slot >= 0 && !this.isEmpty(item)) {
               ItemStack copy = item.clone();
               this.pendingRewardSlots.put(slot, copy.clone());
               this.pendingRewards.add(copy);
            }
         }
      }
   }

   private boolean isEmpty(ItemStack item) {
      return item == null || item.getType() == Material.AIR;
   }
}
