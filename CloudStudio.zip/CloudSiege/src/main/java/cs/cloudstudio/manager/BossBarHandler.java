package cs.cloudstudio.manager;

import cs.cloudstudio.CloudSiege;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import me.neznamy.tab.api.TabAPI;
import me.neznamy.tab.api.TabPlayer;
import me.neznamy.tab.api.bossbar.BarColor;
import me.neznamy.tab.api.bossbar.BarStyle;
import me.neznamy.tab.api.bossbar.BossBar;
import me.neznamy.tab.api.bossbar.BossBarManager;
import me.neznamy.tab.api.event.EventBus;
import me.neznamy.tab.api.event.EventHandler;
import me.neznamy.tab.api.event.player.PlayerLoadEvent;
import me.neznamy.tab.api.event.plugin.TabLoadEvent;
import org.bukkit.entity.Player;

public final class BossBarHandler {
   private final CloudSiege plugin;
   private final Set<UUID> viewers = new HashSet<>();
   private TabAPI tabApi;
   private BossBarManager tabBossBars;
   private EventBus tabEventBus;
   private EventHandler<PlayerLoadEvent> playerLoadHandler;
   private EventHandler<TabLoadEvent> tabLoadHandler;
   private BossBar bossBar;
   private boolean visibleToAll;
   private String currentTitle = "";
   private double currentProgress = -1.0;
   private BarColor configuredColor;
   private BarStyle configuredStyle;
   private BarColor currentColor;
   private BarStyle currentStyle;

   public BossBarHandler(CloudSiege plugin) {
      this.plugin = plugin;
      this.refreshConfiguredStyle();
      this.refreshTabApi();
   }

   public void show(String title) {
      this.show(title, true);
   }

   public void switchTo(String title, double progress) {
      this.switchTo(title, progress, true);
   }

   public void switchTo(String title, double progress, boolean visibleToAll) {
      this.visibleToAll = visibleToAll;
      String safeTitle = title == null ? "" : title;
      double normalized = this.normalizeProgress(progress);
      if (this.ensureBossBar(safeTitle, normalized)) {
         this.updateColorAndStyle();
         this.setTitle(safeTitle);
         this.setProgress(normalized);
         this.syncPlayers();
      }
   }

   public void show(String title, boolean visibleToAll) {
      this.visibleToAll = visibleToAll;
      String safeTitle = title == null ? "" : title;
      if (this.ensureBossBar(safeTitle, 1.0)) {
         this.updateColorAndStyle();
         this.setTitle(safeTitle);
         this.syncPlayers();
      }
   }

   public void add(Player player) {
      if (player != null && player.isOnline()) {
         this.addTabPlayer(this.getTabPlayer(player.getUniqueId()));
      }
   }

   public void remove(Player player) {
      if (player != null) {
         UUID uuid = player.getUniqueId();
         if (this.bossBar == null) {
            this.viewers.remove(uuid);
         } else if (this.visibleToAll && player.isOnline() && this.shouldSee(uuid)) {
            this.add(player);
         } else {
            this.removeCompletely(uuid);
         }
      }
   }

   public void removeCompletely(UUID uuid) {
      if (uuid != null) {
         this.viewers.remove(uuid);
         this.removeTabPlayer(this.getTabPlayer(uuid));
      }
   }

   public void updateWaiting(int secondsLeft) {
      int safeSeconds = Math.max(0, secondsLeft);
      String title = this.plugin
         .getConfigManager()
         .bossBar("start")
         .replace("%player%", String.valueOf(this.plugin.getDefenseEvent().getParticipantCount()))
         .replace("%max_player%", String.valueOf(this.plugin.getConfigManager().getMaxPlayers()))
         .replace("%time%", String.valueOf(safeSeconds));
      if (this.bossBar != null && this.visibleToAll) {
         this.updateColorAndStyle();
         this.setTitle(title);
      } else {
         this.show(title, true);
      }

      int startTime = Math.max(1, this.plugin.getConfigManager().getStartTime());
      this.setProgress((double)safeSeconds / startTime);
   }

   public void setProgress(double progress) {
      BossBar bar = this.bossBar;
      if (bar != null) {
         double normalized = this.normalizeProgress(progress);
         if (!(Math.abs(this.currentProgress - normalized) < 5.0E-4)) {
            bar.setProgress(this.toTabProgress(normalized));
            this.currentProgress = normalized;
         }
      }
   }

   public void setTitle(String title) {
      String safeTitle = title == null ? "" : title;
      BossBar bar = this.bossBar;
      if (bar != null && !this.currentTitle.equals(safeTitle)) {
         bar.setTitle(safeTitle);
         this.currentTitle = safeTitle;
      }
   }

   public void reload() {
      this.refreshConfiguredStyle();
      if (this.bossBar != null) {
         this.updateColorAndStyle();
         this.syncPlayers();
      }
   }

   public void close() {
      this.removeRuntimeBar();
      this.viewers.clear();
      this.visibleToAll = false;
      this.currentTitle = "";
      this.currentProgress = -1.0;
      this.currentColor = null;
      this.currentStyle = null;
   }

   public void shutdown() {
      this.close();
      this.unregisterTabEvents();
   }

   public void syncPlayers() {
      if (this.bossBar == null) {
         this.viewers.clear();
      } else {
         Iterator<UUID> iterator = this.viewers.iterator();

         while (iterator.hasNext()) {
            UUID uuid = iterator.next();
            TabPlayer tabPlayer = this.getTabPlayer(uuid);
            if (tabPlayer == null || !tabPlayer.isLoaded() || !this.shouldSee(uuid)) {
               iterator.remove();
               this.removeTabPlayer(tabPlayer);
            }
         }

         if (this.visibleToAll && this.tabApi != null) {
            for (TabPlayer tabPlayer : this.tabApi.getOnlinePlayers()) {
               this.addTabPlayer(tabPlayer);
            }
         }
      }
   }

   private boolean ensureBossBar(String title, double progress) {
      if (this.bossBar != null) {
         return true;
      }

      if (!this.isTabReady() && !this.refreshTabApi()) {
         return false;
      }

      this.currentColor = this.configuredColor;
      this.currentStyle = this.configuredStyle;
      int attempt = 0;

      while (attempt < 2) {
         try {
            this.bossBar = this.tabBossBars.createBossBar(title, this.toTabProgress(progress), this.currentColor, this.currentStyle);
            this.currentTitle = title;
            this.currentProgress = progress;
            return true;
         } catch (IllegalStateException exception) {
            this.bossBar = null;
            if (attempt > 0 || !this.refreshTabApi()) {
               this.plugin.warning("TAB не смог создать bossbar: " + exception.getMessage());
               return false;
            }

            attempt++;
         } catch (RuntimeException exception) {
            this.bossBar = null;
            this.plugin.warning("TAB не смог создать bossbar: " + exception.getMessage());
            return false;
         }
      }

      return false;
   }

   private void addTabPlayer(TabPlayer tabPlayer) {
      BossBar bar = this.bossBar;
      if (bar != null && tabPlayer != null && tabPlayer.isLoaded() && this.shouldSee(tabPlayer.getUniqueId())) {
         this.viewers.add(tabPlayer.getUniqueId());
         if (!bar.containsPlayer(tabPlayer)) {
            bar.addPlayer(tabPlayer);
         }
      }
   }

   private void removeTabPlayer(TabPlayer tabPlayer) {
      BossBar bar = this.bossBar;
      if (bar != null && tabPlayer != null && bar.containsPlayer(tabPlayer)) {
         bar.removePlayer(tabPlayer);
      }
   }

   private void removeRuntimeBar() {
      BossBar bar = this.bossBar;
      this.bossBar = null;
      if (bar != null) {
         for (TabPlayer player : new ArrayList<>(bar.getPlayers())) {
            bar.removePlayer(player);
         }

         if (this.tabBossBars != null) {
            try {
               this.tabBossBars.removeBossBar(bar);
            } catch (RuntimeException var4) {
            }
         }
      }
   }

   private void updateColorAndStyle() {
      BossBar bar = this.bossBar;
      if (bar != null) {
         BarColor color = this.configuredColor;
         if (color != this.currentColor) {
            bar.setColor(color);
            this.currentColor = color;
         }

         BarStyle style = this.configuredStyle;
         if (style != this.currentStyle) {
            bar.setStyle(style);
            this.currentStyle = style;
         }
      }
   }

   private void refreshConfiguredStyle() {
      this.configuredColor = this.getBarColor();
      this.configuredStyle = this.getBarStyle();
   }

   private BarColor getBarColor() {
      String value = this.normalize(this.plugin.getConfig().getString("bossbars.color", "PURPLE"));

      try {
         return BarColor.valueOf(value);
      } catch (IllegalArgumentException exception) {
         return BarColor.PURPLE;
      }
   }

   private BarStyle getBarStyle() {
      String value = this.normalize(this.plugin.getConfig().getString("bossbars.style", "PROGRESS"));
      if ("SOLID".equals(value)) {
         value = "PROGRESS";
      } else if (value.startsWith("SEGMENTED_")) {
         value = value.replace("SEGMENTED_", "NOTCHED_");
      }

      try {
         return BarStyle.valueOf(value);
      } catch (IllegalArgumentException exception) {
         return BarStyle.PROGRESS;
      }
   }

   private String normalize(String value) {
      return value == null ? "" : value.trim().toUpperCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
   }

   private double normalizeProgress(double progress) {
      return !Double.isNaN(progress) && !Double.isInfinite(progress) ? Math.max(0.0, Math.min(1.0, progress)) : 0.0;
   }

   private float toTabProgress(double normalizedProgress) {
      return (float)(this.normalizeProgress(normalizedProgress) * 100.0);
   }

   private boolean shouldSee(UUID uuid) {
      return uuid != null && (this.visibleToAll || this.plugin.getDefenseEvent().isParticipant(uuid));
   }

   private TabPlayer getTabPlayer(UUID uuid) {
      return this.tabApi != null && uuid != null ? this.tabApi.getPlayer(uuid) : null;
   }

   private boolean refreshTabApi() {
      try {
         this.tabApi = TabAPI.getInstance();
         this.tabBossBars = this.tabApi.getBossBarManager();
      } catch (IllegalStateException exception) {
         this.tabApi = null;
         this.tabBossBars = null;
         this.plugin.warning("TAB API 6.1.0 не готов: " + exception.getMessage());
         return false;
      }

      if (this.tabBossBars == null) {
         return false;
      }

      this.registerTabEvents();
      return true;
   }

   private boolean isTabReady() {
      return this.tabApi != null && this.tabBossBars != null;
   }

   private void registerTabEvents() {
      if (this.isTabReady() && this.tabEventBus == null) {
         this.tabEventBus = this.tabApi.getEventBus();
         if (this.tabEventBus != null) {
            this.playerLoadHandler = event -> this.addTabPlayer(event.getPlayer());
            this.tabLoadHandler = event -> this.recreateAfterTabReload();
            this.tabEventBus.register(PlayerLoadEvent.class, this.playerLoadHandler);
            this.tabEventBus.register(TabLoadEvent.class, this.tabLoadHandler);
         }
      }
   }

   private void unregisterTabEvents() {
      if (this.tabEventBus != null) {
         try {
            if (this.playerLoadHandler != null) {
               this.tabEventBus.unregister(this.playerLoadHandler);
            }

            if (this.tabLoadHandler != null) {
               this.tabEventBus.unregister(this.tabLoadHandler);
            }
         } catch (RuntimeException var2) {
         }
      }

      this.tabEventBus = null;
      this.playerLoadHandler = null;
      this.tabLoadHandler = null;
   }

   private void recreateAfterTabReload() {
      boolean restore = this.bossBar != null;
      this.bossBar = null;
      if (restore && this.refreshTabApi()) {
         String title = this.currentTitle;
         double progress = this.currentProgress < 0.0 ? 1.0 : this.currentProgress;
         if (this.ensureBossBar(title, progress)) {
            this.syncPlayers();
         }
      }
   }
}
