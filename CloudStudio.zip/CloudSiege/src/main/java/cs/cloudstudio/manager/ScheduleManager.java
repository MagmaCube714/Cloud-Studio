package cs.cloudstudio.manager;

import cs.cloudstudio.CloudSiege;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

public final class ScheduleManager {
   private final CloudSiege plugin;
   private BukkitTask task;
   private boolean running;
   private long generation;

   public ScheduleManager(CloudSiege plugin) {
      this.plugin = plugin;
   }

   public void start() {
      this.stop();
      if (this.plugin.getConfigManager().hasSchedule()) {
         this.running = true;
         this.generation++;
         this.armNext(ZonedDateTime.now(this.plugin.getConfigManager().getScheduleZone()));
      }
   }

   public void restart() {
      this.start();
   }

   public void stop() {
      this.running = false;
      this.generation++;
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }
   }

   private void armNext(ZonedDateTime reference) {
      if (this.task != null) {
         this.task.cancel();
      }

      this.task = null;
      if (this.running && this.plugin.isEnabled() && this.plugin.getConfigManager().hasSchedule()) {
         ZonedDateTime target = this.nextSchedule(reference);
         if (target != null) {
            long expectedGeneration = this.generation;
            this.task = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
               this.task = null;
               if (this.running && this.plugin.isEnabled() && expectedGeneration == this.generation) {
                  ZonedDateTime now = ZonedDateTime.now(this.plugin.getConfigManager().getScheduleZone());
                  if (now.isBefore(target)) {
                     this.armNext(now);
                  } else {
                     if (this.plugin.getDefenseEvent().isInactive()) {
                        this.plugin.getDefenseEvent().start(null);
                     }

                     this.armNext(target.plusMinutes(1L));
                  }
               }
            }, ticksUntil(reference, target));
         }
      }
   }

   private ZonedDateTime nextSchedule(ZonedDateTime reference) {
      ZoneId zone = this.plugin.getConfigManager().getScheduleZone();
      LocalDate start = reference.toLocalDate();
      ZonedDateTime best = null;

      for (int offset = 0; offset <= 7; offset++) {
         LocalDate date = start.plusDays(offset);

         for (String raw : this.plugin.getConfigManager().getAutoStartTimes(date.getDayOfWeek())) {
            LocalTime time = LocalTime.parse(raw);
            ZonedDateTime candidate = ZonedDateTime.of(date, time, zone);
            if (candidate.plusMinutes(1L).isAfter(reference) && (best == null || candidate.isBefore(best))) {
               best = candidate;
            }
         }

         if (best != null) {
            break;
         }
      }

      return best;
   }

   private static long ticksUntil(ZonedDateTime from, ZonedDateTime target) {
      long millis = Math.max(0L, Duration.between(from, target).toMillis());
      return Math.max(1L, (millis + 49L) / 50L);
   }
}
