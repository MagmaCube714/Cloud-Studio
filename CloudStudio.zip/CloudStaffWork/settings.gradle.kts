﻿rootProject.name = "CloudStaffWork"
