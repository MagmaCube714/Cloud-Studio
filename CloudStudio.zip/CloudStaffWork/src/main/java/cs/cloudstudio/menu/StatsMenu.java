package cs.cloudstudio.menu;

import cs.cloudstudio.CloudStaffWork;
import cs.cloudstudio.manager.model.Stats;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.TimeUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class StatsMenu implements Listener {
   private final CloudStaffWork plugin;
   private String guiTitle;
   private int size;
   private int monthSlot;
   private int weekSlot;
   private int daySlot;
   private Material monthMaterial;
   private Material weekMaterial;
   private Material dayMaterial;
   private String monthTitle;
   private String weekTitle;
   private String dayTitle;
   private List<String> monthLore;
   private List<String> weekLore;
   private List<String> dayLore;
   private int monthNeedBans;
   private int weekNeedBans;
   private int dayNeedBans;
   private int monthNeedMutes;
   private int weekNeedMutes;
   private int dayNeedMutes;
   private String completeText;
   private String incompleteText;

   public StatsMenu(CloudStaffWork plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.guiTitle = ColorUtil.color(this.plugin.getConfig().getString("stats.gui.title", "Статистика %name%"));
      this.size = this.normalizeSize(this.plugin.getConfig().getInt("stats.gui.size", 27));
      this.monthSlot = this.plugin.getConfig().getInt("stats.gui.month.slot", 15);
      this.weekSlot = this.plugin.getConfig().getInt("stats.gui.week.slot", 13);
      this.daySlot = this.plugin.getConfig().getInt("stats.gui.day.slot", 11);
      this.monthMaterial = this.parseMaterial(this.plugin.getConfig().getString("stats.gui.month.material"));
      this.weekMaterial = this.parseMaterial(this.plugin.getConfig().getString("stats.gui.week.material"));
      this.dayMaterial = this.parseMaterial(this.plugin.getConfig().getString("stats.gui.day.material"));
      this.monthTitle = ColorUtil.color(this.plugin.getConfig().getString("stats.gui.month.title", ""));
      this.weekTitle = ColorUtil.color(this.plugin.getConfig().getString("stats.gui.week.title", ""));
      this.dayTitle = ColorUtil.color(this.plugin.getConfig().getString("stats.gui.day.title", ""));
      this.monthLore = this.immutableColoredList(this.plugin.getConfig().getStringList("stats.gui.month.lore"));
      this.weekLore = this.immutableColoredList(this.plugin.getConfig().getStringList("stats.gui.week.lore"));
      this.dayLore = this.immutableColoredList(this.plugin.getConfig().getStringList("stats.gui.day.lore"));
      this.monthNeedBans = this.plugin.getConfig().getInt("stats.requirements.month.bans");
      this.weekNeedBans = this.plugin.getConfig().getInt("stats.requirements.week.bans");
      this.dayNeedBans = this.plugin.getConfig().getInt("stats.requirements.day.bans");
      this.monthNeedMutes = this.plugin.getConfig().getInt("stats.requirements.month.mutes");
      this.weekNeedMutes = this.plugin.getConfig().getInt("stats.requirements.week.mutes");
      this.dayNeedMutes = this.plugin.getConfig().getInt("stats.requirements.day.mutes");
      this.completeText = ColorUtil.color(this.plugin.getConfig().getString("stats.requirements.complete", ""));
      this.incompleteText = ColorUtil.color(this.plugin.getConfig().getString("stats.requirements.incomplete", ""));
   }

   public void open(Player viewer, String target, Stats[] stats) {
      StatsMenu.StatsHolder holder = new StatsMenu.StatsHolder();
      Inventory inventory = Bukkit.createInventory(holder, this.size, this.inventoryTitle(target));
      holder.setInventory(inventory);
      this.setItem(inventory, this.monthSlot, this.item(target, "month", stats[1]));
      this.setItem(inventory, this.weekSlot, this.item(target, "week", stats[2]));
      this.setItem(inventory, this.daySlot, this.item(target, "day", stats[3]));
      viewer.openInventory(inventory);
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onClick(InventoryClickEvent event) {
      Inventory top = event.getView().getTopInventory();
      if (top.getHolder() instanceof StatsMenu.StatsHolder) {
         event.setCancelled(true);
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDrag(InventoryDragEvent event) {
      Inventory top = event.getView().getTopInventory();
      if (top.getHolder() instanceof StatsMenu.StatsHolder) {
         int topSize = top.getSize();

         for (Integer rawSlot : event.getRawSlots()) {
            if (rawSlot != null && rawSlot < topSize) {
               event.setCancelled(true);
               return;
            }
         }
      }
   }

   private ItemStack item(String target, String period, Stats stats) {
      int needBans = this.needBans(period);
      int needMutes = this.needMutes(period);
      String complete = stats.getBans() >= needBans && stats.getMutes() >= needMutes ? this.completeText : this.incompleteText;
      String played = TimeUtil.format(stats.getPlayed());
      String bans = String.valueOf(stats.getBans());
      String mutes = String.valueOf(stats.getMutes());
      String unbans = String.valueOf(stats.getUnbans());
      String unmutes = String.valueOf(stats.getUnmutes());
      String kicks = String.valueOf(stats.getKicks());
      String needBansText = String.valueOf(needBans);
      String needMutesText = String.valueOf(needMutes);
      ItemStack item = new ItemStack(this.materialForPeriod(period));
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(
            this.formatLine(this.title(period), target, period, played, bans, mutes, unbans, unmutes, kicks, needBansText, needMutesText, complete)
         );
         List<String> sourceLore = this.lore(period);
         List<String> lore = new ArrayList<>(sourceLore.size());

         for (String line : sourceLore) {
            lore.add(this.formatLine(line, target, period, played, bans, mutes, unbans, unmutes, kicks, needBansText, needMutesText, complete));
         }

         meta.setLore(lore);
         item.setItemMeta(meta);
      }

      return item;
   }

   private void setItem(Inventory inventory, int slot, ItemStack item) {
      if (slot >= 0 && slot < inventory.getSize()) {
         inventory.setItem(slot, item);
      }
   }

   private String inventoryTitle(String target) {
      return this.guiTitle.replace("%name%", target).replace("%player%", target).replace("{$name}", target).replace("{$player}", target);
   }

   private String formatLine(
      String line,
      String target,
      String period,
      String played,
      String bans,
      String mutes,
      String unbans,
      String unmutes,
      String kicks,
      String needBans,
      String needMutes,
      String complete
   ) {
      return line != null && !line.isEmpty()
         ? line.replace("%name%", target)
            .replace("%player%", target)
            .replace("{$name}", target)
            .replace("{$player}", target)
            .replace("%played%", played)
            .replace("%bans%", bans)
            .replace("%mutes%", mutes)
            .replace("%unbans%", unbans)
            .replace("%unmutes%", unmutes)
            .replace("%kicks%", kicks)
            .replace("%period%", period)
            .replace("%cloudstaffwork_need_" + period + "_bans%", needBans)
            .replace("%cloudstaffwork_need_" + period + "_mutes%", needMutes)
            .replace("%cloudstaffwork_need_" + period + "_complete%", complete)
         : "";
   }

   private Material materialForPeriod(String period) {
      if ("month".equals(period)) {
         return this.monthMaterial;
      } else {
         return "week".equals(period) ? this.weekMaterial : this.dayMaterial;
      }
   }

   private String title(String period) {
      if ("month".equals(period)) {
         return this.monthTitle;
      } else {
         return "week".equals(period) ? this.weekTitle : this.dayTitle;
      }
   }

   private List<String> lore(String period) {
      if ("month".equals(period)) {
         return this.monthLore;
      } else {
         return "week".equals(period) ? this.weekLore : this.dayLore;
      }
   }

   private int needBans(String period) {
      if ("month".equals(period)) {
         return this.monthNeedBans;
      } else {
         return "week".equals(period) ? this.weekNeedBans : this.dayNeedBans;
      }
   }

   private int needMutes(String period) {
      if ("month".equals(period)) {
         return this.monthNeedMutes;
      } else {
         return "week".equals(period) ? this.weekNeedMutes : this.dayNeedMutes;
      }
   }

   private int normalizeSize(int configuredSize) {
      int normalized = Math.max(9, Math.min(54, configuredSize));
      return normalized / 9 * 9;
   }

   private Material parseMaterial(String name) {
      if (name == null) {
         return Material.PAPER;
      }

      Material material = Material.matchMaterial(name);
      return material != null && material != Material.AIR && material.isItem() ? material : Material.PAPER;
   }

   private List<String> immutableColoredList(List<String> source) {
      if (source != null && !source.isEmpty()) {
         List<String> result = new ArrayList<>(source.size());

         for (String line : source) {
            result.add(ColorUtil.color(line));
         }

         return Collections.unmodifiableList(result);
      } else {
         return Collections.emptyList();
      }
   }

   private static final class StatsHolder implements InventoryHolder {
      private Inventory inventory;

      public Inventory getInventory() {
         return this.inventory;
      }

      private void setInventory(Inventory inventory) {
         this.inventory = inventory;
      }
   }
}
