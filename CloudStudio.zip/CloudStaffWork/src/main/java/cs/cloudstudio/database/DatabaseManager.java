package cs.cloudstudio.database;

import com.zaxxer.hikari.HikariDataSource;
import cs.cloudstudio.CloudStaffWork;
import cs.cloudstudio.config.DatabaseSettings;
import cs.cloudstudio.database.dialect.MySqlDialect;
import cs.cloudstudio.database.dialect.SqlDialect;
import cs.cloudstudio.database.dialect.SqliteDialect;
import cs.cloudstudio.manager.model.Stats;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import org.bukkit.plugin.IllegalPluginAccessException;

public final class DatabaseManager {
   private final CloudStaffWork plugin;
   private final DatabaseSettings settings;
   private final ExecutorService executor;
   private volatile boolean closing;
   private HikariDataSource dataSource;
   private StaffRepository repository;

   public DatabaseManager(CloudStaffWork plugin, DatabaseSettings settings) {
      this.plugin = plugin;
      this.settings = settings;
      this.executor = Executors.newSingleThreadExecutor(new DatabaseManager.DatabaseThreadFactory());
   }

   public void connect() {
      try {
         this.dataSource = DataSourceFactory.create(this.plugin.getDataFolder(), this.settings);
         SqlDialect dialect = this.settings.getType() == DatabaseType.MYSQL ? new MySqlDialect() : new SqliteDialect();
         this.repository = new StaffRepository(this.dataSource, dialect);
      } catch (RuntimeException exception) {
         throw new IllegalStateException("База данных не подключена", exception);
      }
   }

   public void createTables() {
      this.executeCritical(new DatabaseManager.SqlCallable<Void>() {
         public Void call() throws SQLException {
            DatabaseManager.this.repository.createTables();
            return null;
         }
      }, "createTables");
   }

   public void close() {
      this.closing = true;
      this.executor.shutdown();

      try {
         if (!this.executor.awaitTermination(10L, TimeUnit.SECONDS)) {
            this.executor.shutdownNow();
         }
      } catch (InterruptedException exception) {
         Thread.currentThread().interrupt();
         this.executor.shutdownNow();
      }

      if (this.dataSource != null) {
         this.dataSource.close();
         this.dataSource = null;
         this.repository = null;
      }
   }

   public Map<String, String> loadPeriods() {
      Map<String, String> periods = this.executeBlocking(new DatabaseManager.SqlCallable<Map<String, String>>() {
         public Map<String, String> call() throws SQLException {
            return DatabaseManager.this.repository.loadPeriods();
         }
      }, "loadPeriods");
      return periods == null ? new HashMap<>(0) : periods;
   }

   public boolean setPeriod(final String name, final String value) {
      Boolean result = this.executeBlocking(new DatabaseManager.SqlCallable<Boolean>() {
         public Boolean call() throws SQLException {
            DatabaseManager.this.repository.setPeriod(name, value);
            return Boolean.TRUE;
         }
      }, "setPeriod");
      return result != null && result;
   }

   public boolean setPeriodAndClearTable(final String period, final String value) {
      Boolean result = this.executeBlocking(new DatabaseManager.SqlCallable<Boolean>() {
         public Boolean call() throws SQLException {
            DatabaseManager.this.repository.setPeriodAndClearTable(period, value);
            return Boolean.TRUE;
         }
      }, "setPeriodAndClearTable");
      return result != null && result;
   }

   public void setPeriodAsync(final String name, final String value, DatabaseManager.ResultCallback<Boolean> callback) {
      this.executeAsyncResult(new DatabaseManager.SqlCallable<Boolean>() {
         public Boolean call() throws SQLException {
            DatabaseManager.this.repository.setPeriod(name, value);
            return Boolean.TRUE;
         }
      }, "setPeriodAsync", callback);
   }

   public void setPeriodAndClearTableAsync(final String period, final String value, DatabaseManager.ResultCallback<Boolean> callback) {
      this.executeAsyncResult(new DatabaseManager.SqlCallable<Boolean>() {
         public Boolean call() throws SQLException {
            DatabaseManager.this.repository.setPeriodAndClearTable(period, value);
            return Boolean.TRUE;
         }
      }, "setPeriodAndClearTableAsync", callback);
   }

   public void loadAllPeriodsAsync(final String player, final boolean emptyWhenMissing, DatabaseManager.ResultCallback<Stats[]> callback) {
      if (callback != null) {
         if (player != null && !player.isEmpty() && !this.closing) {
            this.executeAsyncResult(new DatabaseManager.SqlCallable<Stats[]>() {
               public Stats[] call() throws SQLException {
                  return DatabaseManager.this.repository.loadAllPeriods(player, emptyWhenMissing);
               }
            }, "loadAllPeriodsAsync", callback);
         } else {
            this.callSync(callback, null);
         }
      }
   }

   public void saveAllAsync(final String player, Stats all, Stats month, Stats week, Stats day) {
      if (player != null && !player.isEmpty() && all != null && month != null && week != null && day != null && !this.closing) {
         final Stats allCopy = all.copy();
         final Stats monthCopy = month.copy();
         final Stats weekCopy = week.copy();
         final Stats dayCopy = day.copy();
         this.executeAsync(new DatabaseManager.SqlRunnable() {
            @Override
            public void run() throws SQLException {
               DatabaseManager.this.repository.saveAll(player, allCopy, monthCopy, weekCopy, dayCopy);
            }
         }, "saveAllAsync");
      }
   }

   public void incrementActionAsync(final String player, String type) {
      final String column = this.actionColumn(type);
      if (column != null && player != null && !player.isEmpty() && !this.closing) {
         this.executeAsync(new DatabaseManager.SqlRunnable() {
            @Override
            public void run() throws SQLException {
               DatabaseManager.this.repository.incrementAction(player, column);
            }
         }, "incrementActionAsync");
      }
   }

   private String actionColumn(String type) {
      if ("bans".equals(type)) {
         return "bans";
      } else if ("mutes".equals(type)) {
         return "mutes";
      } else if ("unbans".equals(type)) {
         return "unbans";
      } else if ("unmutes".equals(type)) {
         return "unmutes";
      } else {
         return "kicks".equals(type) ? "kicks" : null;
      }
   }

   private <T> T executeCritical(DatabaseManager.SqlCallable<T> callable, String operation) {
      try {
         Future<T> future = this.executor.submit(callable);
         return future.get();
      } catch (InterruptedException exception) {
         Thread.currentThread().interrupt();
         throw new IllegalStateException("Критическая ошибка базы данных: " + operation, exception);
      } catch (Exception exception) {
         throw new IllegalStateException("Критическая ошибка базы данных: " + operation, exception.getCause() == null ? exception : exception.getCause());
      }
   }

   private <T> T executeBlocking(DatabaseManager.SqlCallable<T> callable, String operation) {
      if (this.closing) {
         return null;
      }

      try {
         Future<T> future = this.executor.submit(callable);
         return future.get();
      } catch (RejectedExecutionException exception) {
         if (!this.closing) {
            this.plugin.warning("Операция базы данных отклонена: " + operation);
         }
      } catch (InterruptedException exception) {
         Thread.currentThread().interrupt();
         this.plugin.warning("Операция базы данных прервана: " + operation);
      } catch (Exception exception) {
         this.handle(operation, exception.getCause() == null ? exception : exception.getCause());
      }

      return null;
   }

   private void executeAsync(final DatabaseManager.SqlRunnable runnable, final String operation) {
      if (!this.closing) {
         try {
            this.executor.execute(new Runnable() {
               @Override
               public void run() {
                  try {
                     runnable.run();
                  } catch (Exception exception) {
                     DatabaseManager.this.handle(operation, exception);
                  }
               }
            });
         } catch (RejectedExecutionException exception) {
            if (!this.closing) {
               this.plugin.warning("Операция базы данных отклонена: " + operation);
            }
         }
      }
   }

   private <T> void executeAsyncResult(final DatabaseManager.SqlCallable<T> callable, final String operation, final DatabaseManager.ResultCallback<T> callback) {
      if (this.closing) {
         if (callback != null) {
            this.callSync(callback, null);
         }
      } else {
         try {
            this.executor.execute(new Runnable() {
               @Override
               public void run() {
                  T result = null;

                  try {
                     result = callable.call();
                  } catch (Exception exception) {
                     DatabaseManager.this.handle(operation, exception);
                  }

                  if (callback != null) {
                     DatabaseManager.this.callSync(callback, result);
                  }
               }
            });
         } catch (RejectedExecutionException exception) {
            if (!this.closing) {
               this.plugin.warning("Операция базы данных отклонена: " + operation);
            }

            if (callback != null) {
               this.callSync(callback, null);
            }
         }
      }
   }

   private <T> void callSync(final DatabaseManager.ResultCallback<T> callback, final T value) {
      if (this.plugin.isEnabled()) {
         if (this.plugin.getServer().isPrimaryThread()) {
            callback.complete(value);
         } else {
            try {
               this.plugin.getServer().getScheduler().runTask(this.plugin, new Runnable() {
                  @Override
                  public void run() {
                     if (DatabaseManager.this.plugin.isEnabled()) {
                        callback.complete(value);
                     }
                  }
               });
            } catch (IllegalPluginAccessException var4) {
            }
         }
      }
   }

   private void handle(String operation, Throwable throwable) {
      String message = throwable == null ? "неизвестная ошибка" : throwable.getMessage();
      this.plugin.warning("Ошибка базы данных в операции " + operation + ": " + message);
   }

   private static final class DatabaseThreadFactory implements ThreadFactory {
      @Override
      public Thread newThread(Runnable runnable) {
         Thread thread = new Thread(runnable, "CloudStaffWork-Database");
         thread.setDaemon(true);
         return thread;
      }
   }

   public interface ResultCallback<T> {
      void complete(T var1);
   }

   private interface SqlCallable<T> extends Callable<T> {
   }

   private interface SqlRunnable {
      void run() throws Exception;
   }
}
