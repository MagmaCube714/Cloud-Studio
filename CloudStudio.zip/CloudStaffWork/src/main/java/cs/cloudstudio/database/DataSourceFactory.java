package cs.cloudstudio.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import cs.cloudstudio.config.DatabaseSettings;
import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public final class DataSourceFactory {
   private DataSourceFactory() {
   }

   public static HikariDataSource create(File dataFolder, DatabaseSettings settings) {
      return settings.getType() == DatabaseType.MYSQL ? createMySql(settings) : createSqlite(dataFolder, settings);
   }

   private static HikariDataSource createSqlite(File dataFolder, DatabaseSettings settings) {
      File file = settings.sqliteFile(dataFolder);
      File parent = file.getParentFile();
      if (parent != null && !parent.exists() && !parent.mkdirs()) {
         throw new IllegalStateException("Папка базы данных не создана");
      }

      HikariConfig config = new HikariConfig();
      config.setPoolName("CloudStaffWork-SQLite");
      config.setJdbcUrl("jdbc:sqlite:" + file.getAbsolutePath());
      config.setDriverClassName("org.sqlite.JDBC");
      config.setMaximumPoolSize(1);
      config.setMinimumIdle(1);
      config.setConnectionTimeout(10000L);
      config.setIdleTimeout(600000L);
      config.setMaxLifetime(1800000L);
      config.setInitializationFailTimeout(-1L);
      HikariDataSource dataSource = new HikariDataSource(config);
      applySqlitePragmas(dataSource);
      return dataSource;
   }

   private static HikariDataSource createMySql(DatabaseSettings settings) {
      HikariConfig config = new HikariConfig();
      config.setPoolName("CloudStaffWork-MySQL");
      config.setDriverClassName("com.mysql.cj.jdbc.Driver");
      config.setJdbcUrl(
         "jdbc:mysql://"
            + settings.getHost()
            + ":"
            + settings.getPort()
            + "/"
            + settings.getPlayerDatabase()
            + "?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=UTC"
      );
      config.setUsername(settings.getUsername());
      config.setPassword(settings.getPassword());
      config.setMaximumPoolSize(4);
      config.setMinimumIdle(1);
      config.setConnectionTimeout(10000L);
      config.setIdleTimeout(600000L);
      config.setMaxLifetime(1800000L);
      Properties properties = new Properties();
      properties.setProperty("cachePrepStmts", "true");
      properties.setProperty("prepStmtCacheSize", "250");
      properties.setProperty("prepStmtCacheSqlLimit", "2048");
      properties.setProperty("useServerPrepStmts", "true");
      properties.setProperty("rewriteBatchedStatements", "true");
      config.setDataSourceProperties(properties);
      return new HikariDataSource(config);
   }

   private static void applySqlitePragmas(HikariDataSource dataSource) {
      try (
         Connection connection = dataSource.getConnection();
         Statement statement = connection.createStatement();
      ) {
         statement.executeUpdate("PRAGMA foreign_keys=ON");
         statement.executeUpdate("PRAGMA busy_timeout=5000");
         statement.executeUpdate("PRAGMA journal_mode=WAL");
         statement.executeUpdate("PRAGMA synchronous=NORMAL");
         statement.executeUpdate("PRAGMA temp_store=MEMORY");
      } catch (SQLException exception) {
         throw new IllegalStateException("SQLite не инициализирован", exception);
      }
   }
}
