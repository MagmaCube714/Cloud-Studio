package cs.cloudstudio.database.dialect;

public interface SqlDialect {
   String createStatsTable(String var1);

   String createPeriodsTable();

   String upsertStats(String var1);

   String incrementAction(String var1, String var2);

   String upsertPeriod();
}
