package cs.cloudstudio.database.dialect;

public final class SqliteDialect implements SqlDialect {
   @Override
   public String createStatsTable(String table) {
      return "CREATE TABLE IF NOT EXISTS "
         + table
         + " (player VARCHAR(30) PRIMARY KEY, played BIGINT NOT NULL DEFAULT 0, bans INT NOT NULL DEFAULT 0, mutes INT NOT NULL DEFAULT 0, unbans INT NOT NULL DEFAULT 0, unmutes INT NOT NULL DEFAULT 0, kicks INT NOT NULL DEFAULT 0)";
   }

   @Override
   public String createPeriodsTable() {
      return "CREATE TABLE IF NOT EXISTS periods (name VARCHAR(16) PRIMARY KEY, value VARCHAR(32) NOT NULL)";
   }

   @Override
   public String upsertStats(String table) {
      return "INSERT INTO "
         + table
         + " (player,played,bans,mutes,unbans,unmutes,kicks) VALUES (?,?,?,?,?,?,?) ON CONFLICT(player) DO UPDATE SET played=excluded.played,bans=excluded.bans,mutes=excluded.mutes,unbans=excluded.unbans,unmutes=excluded.unmutes,kicks=excluded.kicks";
   }

   @Override
   public String incrementAction(String table, String column) {
      return "INSERT INTO "
         + table
         + " (player,"
         + column
         + ") VALUES (?,1) ON CONFLICT(player) DO UPDATE SET "
         + column
         + "=CASE WHEN "
         + column
         + ">=2147483647 THEN 2147483647 ELSE "
         + column
         + "+1 END";
   }

   @Override
   public String upsertPeriod() {
      return "INSERT INTO periods (name,value) VALUES (?,?) ON CONFLICT(name) DO UPDATE SET value=excluded.value";
   }
}
