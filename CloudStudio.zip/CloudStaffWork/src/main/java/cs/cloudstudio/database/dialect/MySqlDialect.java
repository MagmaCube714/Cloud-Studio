package cs.cloudstudio.database.dialect;

public final class MySqlDialect implements SqlDialect {
   @Override
   public String createStatsTable(String table) {
      return "CREATE TABLE IF NOT EXISTS "
         + table
         + " (player VARCHAR(30) NOT NULL PRIMARY KEY, played BIGINT NOT NULL DEFAULT 0, bans INT NOT NULL DEFAULT 0, mutes INT NOT NULL DEFAULT 0, unbans INT NOT NULL DEFAULT 0, unmutes INT NOT NULL DEFAULT 0, kicks INT NOT NULL DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
   }

   @Override
   public String createPeriodsTable() {
      return "CREATE TABLE IF NOT EXISTS periods (name VARCHAR(16) NOT NULL PRIMARY KEY, value VARCHAR(32) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
   }

   @Override
   public String upsertStats(String table) {
      return "INSERT INTO "
         + table
         + " (player,played,bans,mutes,unbans,unmutes,kicks) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE played=VALUES(played),bans=VALUES(bans),mutes=VALUES(mutes),unbans=VALUES(unbans),unmutes=VALUES(unmutes),kicks=VALUES(kicks)";
   }

   @Override
   public String incrementAction(String table, String column) {
      return "INSERT INTO "
         + table
         + " (player,"
         + column
         + ") VALUES (?,1) ON DUPLICATE KEY UPDATE "
         + column
         + "=CASE WHEN "
         + column
         + ">=2147483647 THEN 2147483647 ELSE "
         + column
         + "+1 END";
   }

   @Override
   public String upsertPeriod() {
      return "INSERT INTO periods (name,value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=VALUES(value)";
   }
}
