package cs.cloudstudio.database;

import cs.cloudstudio.database.dialect.SqlDialect;
import cs.cloudstudio.manager.model.Stats;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;

public final class StaffRepository {
   public static final String TABLE_ALL = "all_stats";
   public static final String TABLE_MONTH = "month_stats";
   public static final String TABLE_WEEK = "week_stats";
   public static final String TABLE_DAY = "day_stats";
   private static final String[] PERIOD_TABLES = new String[]{"all_stats", "month_stats", "week_stats", "day_stats"};
   private final DataSource dataSource;
   private final SqlDialect dialect;

   public StaffRepository(DataSource dataSource, SqlDialect dialect) {
      this.dataSource = dataSource;
      this.dialect = dialect;
   }

   public void createTables() throws SQLException {
      try (
         Connection connection = this.dataSource.getConnection();
         Statement statement = connection.createStatement();
      ) {
         statement.executeUpdate(this.dialect.createStatsTable("all_stats"));
         statement.executeUpdate(this.dialect.createStatsTable("month_stats"));
         statement.executeUpdate(this.dialect.createStatsTable("week_stats"));
         statement.executeUpdate(this.dialect.createStatsTable("day_stats"));
         statement.executeUpdate(this.dialect.createPeriodsTable());
      }
   }

   public Map<String, String> loadPeriods() throws SQLException {
      Map<String, String> result = new HashMap<>(4);

      try (
         Connection connection = this.dataSource.getConnection();
         Statement statement = connection.createStatement();
         ResultSet resultSet = statement.executeQuery("SELECT name,value FROM periods");
      ) {
         while (resultSet.next()) {
            result.put(resultSet.getString(1), resultSet.getString(2));
         }
      }

      return result;
   }

   public void setPeriod(String name, String value) throws SQLException {
      try (Connection connection = this.dataSource.getConnection()) {
         this.setPeriod(connection, name, value);
      }
   }

   public void setPeriodAndClearTable(String period, String value) throws SQLException {
      try (Connection connection = this.dataSource.getConnection()) {
         boolean autoCommit = connection.getAutoCommit();

         try {
            connection.setAutoCommit(false);
            this.setPeriod(connection, period, value);
            this.clearTable(connection, this.tableName(period));
            connection.commit();
         } catch (SQLException exception) {
            this.rollbackQuietly(connection);
            throw exception;
         } finally {
            connection.setAutoCommit(autoCommit);
         }
      }
   }

   public Stats[] loadAllPeriods(String player, boolean emptyWhenMissing) throws SQLException {
      Stats[] stats = this.emptyStatsArray();
      String sql = "SELECT 0,played,bans,mutes,unbans,unmutes,kicks FROM all_stats WHERE player=? UNION ALL SELECT 1,played,bans,mutes,unbans,unmutes,kicks FROM month_stats WHERE player=? UNION ALL SELECT 2,played,bans,mutes,unbans,unmutes,kicks FROM week_stats WHERE player=? UNION ALL SELECT 3,played,bans,mutes,unbans,unmutes,kicks FROM day_stats WHERE player=?";
      boolean found = false;

      try (
         Connection connection = this.dataSource.getConnection();
         PreparedStatement statement = connection.prepareStatement(sql);
      ) {
         statement.setString(1, player);
         statement.setString(2, player);
         statement.setString(3, player);
         statement.setString(4, player);

         try (ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
               int index = resultSet.getInt(1);
               if (index >= 0 && index < stats.length) {
                  stats[index] = this.readStats(resultSet, 2);
                  found = true;
               }
            }
         }
      }

      return !found && !emptyWhenMissing ? null : stats;
   }

   public void saveAll(String player, Stats all, Stats month, Stats week, Stats day) throws SQLException {
      try (Connection connection = this.dataSource.getConnection()) {
         boolean autoCommit = connection.getAutoCommit();

         try {
            connection.setAutoCommit(false);
            this.save(connection, "all_stats", player, all);
            this.save(connection, "month_stats", player, month);
            this.save(connection, "week_stats", player, week);
            this.save(connection, "day_stats", player, day);
            connection.commit();
         } catch (SQLException exception) {
            this.rollbackQuietly(connection);
            throw exception;
         } finally {
            connection.setAutoCommit(autoCommit);
         }
      }
   }

   public void incrementAction(String player, String column) throws SQLException {
      try (Connection connection = this.dataSource.getConnection()) {
         boolean autoCommit = connection.getAutoCommit();

         try {
            connection.setAutoCommit(false);

            for (String table : PERIOD_TABLES) {
               this.increment(connection, table, player, column);
            }

            connection.commit();
         } catch (SQLException exception) {
            this.rollbackQuietly(connection);
            throw exception;
         } finally {
            connection.setAutoCommit(autoCommit);
         }
      }
   }

   private void save(Connection connection, String table, String player, Stats stats) throws SQLException {
      try (PreparedStatement statement = connection.prepareStatement(this.dialect.upsertStats(table))) {
         statement.setString(1, player);
         statement.setLong(2, stats.getPlayed());
         statement.setInt(3, stats.getBans());
         statement.setInt(4, stats.getMutes());
         statement.setInt(5, stats.getUnbans());
         statement.setInt(6, stats.getUnmutes());
         statement.setInt(7, stats.getKicks());
         statement.executeUpdate();
      }
   }

   private void increment(Connection connection, String table, String player, String column) throws SQLException {
      try (PreparedStatement statement = connection.prepareStatement(this.dialect.incrementAction(table, column))) {
         statement.setString(1, player);
         statement.executeUpdate();
      }
   }

   private void setPeriod(Connection connection, String name, String value) throws SQLException {
      try (PreparedStatement statement = connection.prepareStatement(this.dialect.upsertPeriod())) {
         statement.setString(1, name);
         statement.setString(2, value);
         statement.executeUpdate();
      }
   }

   private void clearTable(Connection connection, String table) throws SQLException {
      try (Statement statement = connection.createStatement()) {
         statement.executeUpdate("DELETE FROM " + table);
      }
   }

   private Stats readStats(ResultSet resultSet, int offset) throws SQLException {
      return new Stats(
         resultSet.getLong(offset),
         resultSet.getInt(offset + 1),
         resultSet.getInt(offset + 2),
         resultSet.getInt(offset + 3),
         resultSet.getInt(offset + 4),
         resultSet.getInt(offset + 5)
      );
   }

   private Stats[] emptyStatsArray() {
      return new Stats[]{new Stats(), new Stats(), new Stats(), new Stats()};
   }

   private String tableName(String period) {
      if ("month".equals(period)) {
         return "month_stats";
      } else if ("week".equals(period)) {
         return "week_stats";
      } else {
         return "day".equals(period) ? "day_stats" : "all_stats";
      }
   }

   private void rollbackQuietly(Connection connection) {
      try {
         connection.rollback();
      } catch (SQLException var3) {
      }
   }
}
