package cs.cloudstudio.database;

public enum DatabaseType {
   SQLITE,
   MYSQL;

   public static DatabaseType from(String value) {
      return value != null && value.equalsIgnoreCase("MySQL") ? MYSQL : SQLITE;
   }
}
