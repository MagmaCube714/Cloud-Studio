package cs.cloudstudio.manager;

import cs.cloudstudio.CloudStaffWork;
import cs.cloudstudio.database.DatabaseManager;
import cs.cloudstudio.util.DateUtil;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Map;
import org.bukkit.scheduler.BukkitTask;

public final class PeriodManager {
   private final CloudStaffWork plugin;
   private final DatabaseManager databaseManager;
   private final StaffManager staffManager;
   private String currentDay;
   private String currentWeek;
   private String currentMonth;
   private boolean periodCheckRunning;
   private BukkitTask periodTask;

   public PeriodManager(CloudStaffWork plugin, DatabaseManager databaseManager, StaffManager staffManager) {
      this.plugin = plugin;
      this.databaseManager = databaseManager;
      this.staffManager = staffManager;
   }

   public void load() {
      Map<String, String> periods = this.databaseManager.loadPeriods();
      this.currentDay = periods.get("day");
      this.currentWeek = periods.get("week");
      this.currentMonth = periods.get("month");
      this.checkPeriodsStartup();
   }

   public void start() {
      this.scheduleNextPeriodBoundary();
   }

   private void scheduleNextPeriodBoundary() {
      if (this.periodTask != null) {
         this.periodTask.cancel();
         this.periodTask = null;
      }

      if (this.plugin.isEnabled()) {
         ZonedDateTime now = ZonedDateTime.now();
         ZonedDateTime next = now.toLocalDate().plusDays(1L).atStartOfDay(now.getZone()).plusSeconds(1L);
         long millis = Math.max(1L, Duration.between(now, next).toMillis());
         long ticks = Math.max(1L, (millis + 49L) / 50L);
         this.periodTask = this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
            this.periodTask = null;
            this.checkPeriodsAsync();
            this.scheduleNextPeriodBoundary();
         }, ticks);
      }
   }

   private void checkPeriodsStartup() {
      LocalDate now = LocalDate.now();
      this.currentDay = this.checkPeriodBlocking("day", DateUtil.day(now), this.currentDay);
      this.currentWeek = this.checkPeriodBlocking("week", DateUtil.week(now), this.currentWeek);
      this.currentMonth = this.checkPeriodBlocking("month", DateUtil.month(now), this.currentMonth);
   }

   private String checkPeriodBlocking(String period, String actual, String current) {
      if (actual.equals(current)) {
         return current;
      }

      boolean changed = current == null ? this.databaseManager.setPeriod(period, actual) : this.databaseManager.setPeriodAndClearTable(period, actual);
      if (!changed) {
         return current;
      }

      if (current != null) {
         this.staffManager.resetPeriod(period);
      }

      return actual;
   }

   private void checkPeriodsAsync() {
      if (!this.periodCheckRunning) {
         LocalDate now = LocalDate.now();
         String actualDay = DateUtil.day(now);
         final String actualWeek = DateUtil.week(now);
         final String actualMonth = DateUtil.month(now);
         if (!actualDay.equals(this.currentDay) || !actualWeek.equals(this.currentWeek) || !actualMonth.equals(this.currentMonth)) {
            this.periodCheckRunning = true;
            this.updatePeriodAsync("day", actualDay, this.currentDay, new Runnable() {
               @Override
               public void run() {
                  PeriodManager.this.updatePeriodAsync("week", actualWeek, PeriodManager.this.currentWeek, new Runnable() {
                     @Override
                     public void run() {
                        PeriodManager.this.updatePeriodAsync("month", actualMonth, PeriodManager.this.currentMonth, new Runnable() {
                           @Override
                           public void run() {
                              PeriodManager.this.periodCheckRunning = false;
                           }
                        });
                     }
                  });
               }
            });
         }
      }
   }

   private void updatePeriodAsync(final String period, final String actual, final String current, final Runnable next) {
      if (actual.equals(current)) {
         next.run();
      } else {
         DatabaseManager.ResultCallback<Boolean> callback = new DatabaseManager.ResultCallback<Boolean>() {
            public void complete(Boolean value) {
               if (Boolean.TRUE.equals(value)) {
                  if ("day".equals(period)) {
                     PeriodManager.this.currentDay = actual;
                  } else if ("week".equals(period)) {
                     PeriodManager.this.currentWeek = actual;
                  } else if ("month".equals(period)) {
                     PeriodManager.this.currentMonth = actual;
                  }

                  if (current != null) {
                     PeriodManager.this.staffManager.resetPeriod(period);
                  }
               }

               next.run();
            }
         };
         if (current == null) {
            this.databaseManager.setPeriodAsync(period, actual, callback);
         } else {
            this.databaseManager.setPeriodAndClearTableAsync(period, actual, callback);
         }
      }
   }
}
