package cs.cloudstudio.manager.model;

public final class Stats {
   private long played;
   private int bans;
   private int mutes;
   private int unbans;
   private int unmutes;
   private int kicks;

   public Stats() {
   }

   public Stats(long played, int bans, int mutes, int unbans, int unmutes, int kicks) {
      this.played = Math.max(0L, played);
      this.bans = Math.max(0, bans);
      this.mutes = Math.max(0, mutes);
      this.unbans = Math.max(0, unbans);
      this.unmutes = Math.max(0, unmutes);
      this.kicks = Math.max(0, kicks);
   }

   public long getPlayed() {
      return this.played;
   }

   public void addPlayed(long value) {
      if (value > 0L) {
         this.played = value > Long.MAX_VALUE - this.played ? Long.MAX_VALUE : this.played + value;
      }
   }

   public int getBans() {
      return this.bans;
   }

   public int getMutes() {
      return this.mutes;
   }

   public int getUnbans() {
      return this.unbans;
   }

   public int getUnmutes() {
      return this.unmutes;
   }

   public int getKicks() {
      return this.kicks;
   }

   public void addBan() {
      this.bans = this.increment(this.bans);
   }

   public void addMute() {
      this.mutes = this.increment(this.mutes);
   }

   public void addUnban() {
      this.unbans = this.increment(this.unbans);
   }

   public void addUnmute() {
      this.unmutes = this.increment(this.unmutes);
   }

   public void addKick() {
      this.kicks = this.increment(this.kicks);
   }

   public void clear() {
      this.played = 0L;
      this.bans = 0;
      this.mutes = 0;
      this.unbans = 0;
      this.unmutes = 0;
      this.kicks = 0;
   }

   public Stats copy() {
      return new Stats(this.played, this.bans, this.mutes, this.unbans, this.unmutes, this.kicks);
   }

   private int increment(int value) {
      return value == Integer.MAX_VALUE ? Integer.MAX_VALUE : value + 1;
   }
}
