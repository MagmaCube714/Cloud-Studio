package cs.cloudstudio.manager;

import cs.cloudstudio.CloudStaffWork;
import cs.cloudstudio.database.DatabaseManager;
import cs.cloudstudio.manager.model.StaffPlayer;
import cs.cloudstudio.manager.model.Stats;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class StaffManager {
   private final CloudStaffWork plugin;
   private final DatabaseManager database;
   private final GroupManager groups;
   private final Map<UUID, StaffPlayer> working = new HashMap<>();
   private final Map<String, StaffPlayer> workingByName = new HashMap<>();
   private final Set<UUID> pendingStart = new HashSet<>();

   public StaffManager(CloudStaffWork plugin, DatabaseManager database) {
      this.plugin = plugin;
      this.database = database;
      this.groups = new GroupManager(plugin);
   }

   public void reload() {
      this.groups.reload();
   }

   public boolean isWorking(Player player) {
      return this.working.containsKey(player.getUniqueId());
   }

   public boolean isPending(Player player) {
      return this.pendingStart.contains(player.getUniqueId());
   }

   public StaffPlayer get(Player player) {
      return this.working.get(player.getUniqueId());
   }

   public Collection<StaffPlayer> getWorking() {
      return new ArrayList<>(this.working.values());
   }

   public void start(Player player, final StaffManager.StartCallback callback) {
      final UUID uuid = player.getUniqueId();
      if (this.working.containsKey(uuid)) {
         this.complete(callback, true);
      } else if (!this.pendingStart.add(uuid)) {
         this.complete(callback, true);
      } else {
         final String group = this.groups.getGroup(player);
         if (!this.groups.hasGroup(group)) {
            this.pendingStart.remove(uuid);
            this.complete(callback, false);
         } else {
            String name = player.getName();
            this.database.loadAllPeriodsAsync(name, true, new DatabaseManager.ResultCallback<Stats[]>() {
               public void complete(Stats[] stats) {
                  StaffManager.this.pendingStart.remove(uuid);
                  Player online = Bukkit.getPlayer(uuid);
                  if (online == null || !online.isOnline()) {
                     StaffManager.this.complete(callback, true);
                  } else if (StaffManager.this.working.containsKey(uuid)) {
                     StaffManager.this.complete(callback, true);
                  } else if (stats == null) {
                     StaffManager.this.complete(callback, false);
                  } else {
                     String currentName = online.getName();
                     StaffPlayer staff = new StaffPlayer(uuid, currentName, group, stats[0], stats[1], stats[2], stats[3]);
                     StaffManager.this.working.put(uuid, staff);
                     StaffManager.this.workingByName.put(StaffManager.this.lower(currentName), staff);
                     StaffManager.this.groups.applyEnable(online, group);
                     StaffManager.this.complete(callback, true);
                  }
               }
            });
         }
      }
   }

   public void stop(Player player) {
      this.stopInternal(player);
   }

   public void stopSilently(Player player) {
      this.stopInternal(player);
      this.pendingStart.remove(player.getUniqueId());
   }

   public void stopAll() {
      this.pendingStart.clear();
      if (!this.working.isEmpty()) {
         for (StaffPlayer staff : this.getWorking()) {
            Player player = Bukkit.getPlayer(staff.getUniqueId());
            if (player != null) {
               this.stopInternal(player);
            } else {
               this.finishAndSave(staff);
               this.working.remove(staff.getUniqueId());
               this.workingByName.remove(this.lower(staff.getName()));
            }
         }
      }
   }

   public void addAction(Player player, String type) {
      String action = this.normalizeAction(type);
      if (action != null) {
         StaffPlayer staff = this.get(player);
         if (staff != null) {
            this.addAction(staff, action);
         } else {
            this.database.incrementActionAsync(player.getName(), action);
         }
      }
   }

   public void addAction(String playerName, String type) {
      if (playerName != null && !playerName.isEmpty()) {
         String action = this.normalizeAction(type);
         if (action != null) {
            StaffPlayer staff = this.workingByName.get(this.lower(playerName));
            if (staff != null) {
               this.addAction(staff, action);
            } else {
               this.database.incrementActionAsync(playerName, action);
            }
         }
      }
   }

   public void snapshotsAsync(String player, final StaffManager.SnapshotCallback callback) {
      if (callback != null) {
         if (player != null && !player.isEmpty()) {
            StaffPlayer staff = this.findWorking(player);
            if (staff != null) {
               callback.complete(this.copyWithCurrentPlayed(staff));
            } else {
               this.database.loadAllPeriodsAsync(player, false, new DatabaseManager.ResultCallback<Stats[]>() {
                  public void complete(Stats[] value) {
                     callback.complete(value);
                  }
               });
            }
         } else {
            callback.complete(null);
         }
      }
   }

   public void resetPeriod(String period) {
      if (!this.working.isEmpty()) {
         long now = System.currentTimeMillis();

         for (StaffPlayer staff : this.working.values()) {
            if ("month".equals(period)) {
               staff.resetMonth(now);
            } else if ("week".equals(period)) {
               staff.resetWeek(now);
            } else if ("day".equals(period)) {
               staff.resetDay(now);
            }

            this.save(staff);
         }
      }
   }

   private Stats[] copyWithCurrentPlayed(StaffPlayer staff) {
      long now = System.currentTimeMillis();
      Stats all = staff.getAll().copy();
      Stats month = staff.getMonth().copy();
      Stats week = staff.getWeek().copy();
      Stats day = staff.getDay().copy();
      all.addPlayed(staff.getCurrentPlayed(now));
      month.addPlayed(staff.getCurrentMonthPlayed(now));
      week.addPlayed(staff.getCurrentWeekPlayed(now));
      day.addPlayed(staff.getCurrentDayPlayed(now));
      return new Stats[]{all, month, week, day};
   }

   private StaffPlayer findWorking(String player) {
      StaffPlayer staff = this.workingByName.get(this.lower(player));
      if (staff != null) {
         return staff;
      }

      Player online = Bukkit.getPlayerExact(player);
      return online == null ? null : this.working.get(online.getUniqueId());
   }

   private void stopInternal(Player player) {
      UUID uuid = player.getUniqueId();
      StaffPlayer staff = this.working.remove(uuid);
      if (staff != null) {
         this.workingByName.remove(this.lower(staff.getName()));
         this.finishAndSave(staff);
         this.groups.applyDisable(player, staff.getGroup());
      }
   }

   private void finishAndSave(StaffPlayer staff) {
      long now = System.currentTimeMillis();
      staff.getAll().addPlayed(staff.getCurrentPlayed(now));
      staff.getMonth().addPlayed(staff.getCurrentMonthPlayed(now));
      staff.getWeek().addPlayed(staff.getCurrentWeekPlayed(now));
      staff.getDay().addPlayed(staff.getCurrentDayPlayed(now));
      this.save(staff);
   }

   private void addAction(StaffPlayer staff, String action) {
      if (this.addAction(staff.getAll(), action)) {
         this.addAction(staff.getMonth(), action);
         this.addAction(staff.getWeek(), action);
         this.addAction(staff.getDay(), action);
         this.save(staff);
      }
   }

   private void save(StaffPlayer staff) {
      this.database.saveAllAsync(staff.getName(), staff.getAll(), staff.getMonth(), staff.getWeek(), staff.getDay());
   }

   private boolean addAction(Stats stats, String type) {
      if ("bans".equals(type)) {
         stats.addBan();
         return true;
      } else if ("mutes".equals(type)) {
         stats.addMute();
         return true;
      } else if ("unbans".equals(type)) {
         stats.addUnban();
         return true;
      } else if ("unmutes".equals(type)) {
         stats.addUnmute();
         return true;
      } else if ("kicks".equals(type)) {
         stats.addKick();
         return true;
      } else {
         return false;
      }
   }

   private String normalizeAction(String type) {
      if (type != null && !type.isEmpty()) {
         String normalized = type.toLowerCase(Locale.ROOT);
         return !"bans".equals(normalized)
               && !"mutes".equals(normalized)
               && !"unbans".equals(normalized)
               && !"unmutes".equals(normalized)
               && !"kicks".equals(normalized)
            ? null
            : normalized;
      } else {
         return null;
      }
   }

   private void complete(StaffManager.StartCallback callback, boolean started) {
      if (callback != null) {
         callback.complete(started);
      }
   }

   private String lower(String value) {
      return value.toLowerCase(Locale.ROOT);
   }

   public interface SnapshotCallback {
      void complete(Stats[] var1);
   }

   public interface StartCallback {
      void complete(boolean var1);
   }
}
