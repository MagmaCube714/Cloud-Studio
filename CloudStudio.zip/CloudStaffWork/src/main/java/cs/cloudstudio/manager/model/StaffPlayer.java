package cs.cloudstudio.manager.model;

import java.util.UUID;

public final class StaffPlayer {
   private final UUID uniqueId;
   private final String name;
   private final String group;
   private final long startedAt;
   private final Stats all;
   private final Stats month;
   private final Stats week;
   private final Stats day;
   private long monthStartedAt;
   private long weekStartedAt;
   private long dayStartedAt;

   public StaffPlayer(UUID uniqueId, String name, String group, Stats all, Stats month, Stats week, Stats day) {
      this.uniqueId = uniqueId;
      this.name = name;
      this.group = group;
      this.all = all;
      this.month = month;
      this.week = week;
      this.day = day;
      this.startedAt = System.currentTimeMillis();
      this.monthStartedAt = this.startedAt;
      this.weekStartedAt = this.startedAt;
      this.dayStartedAt = this.startedAt;
   }

   public UUID getUniqueId() {
      return this.uniqueId;
   }

   public String getName() {
      return this.name;
   }

   public String getGroup() {
      return this.group;
   }

   public long getStartedAt() {
      return this.startedAt;
   }

   public Stats getAll() {
      return this.all;
   }

   public Stats getMonth() {
      return this.month;
   }

   public Stats getWeek() {
      return this.week;
   }

   public Stats getDay() {
      return this.day;
   }

   public long getCurrentPlayed() {
      return this.elapsedSince(this.startedAt, System.currentTimeMillis());
   }

   public long getCurrentMonthPlayed() {
      return this.elapsedSince(this.monthStartedAt, System.currentTimeMillis());
   }

   public long getCurrentWeekPlayed() {
      return this.elapsedSince(this.weekStartedAt, System.currentTimeMillis());
   }

   public long getCurrentDayPlayed() {
      return this.elapsedSince(this.dayStartedAt, System.currentTimeMillis());
   }

   public long getCurrentPlayed(long now) {
      return this.elapsedSince(this.startedAt, now);
   }

   public long getCurrentMonthPlayed(long now) {
      return this.elapsedSince(this.monthStartedAt, now);
   }

   public long getCurrentWeekPlayed(long now) {
      return this.elapsedSince(this.weekStartedAt, now);
   }

   public long getCurrentDayPlayed(long now) {
      return this.elapsedSince(this.dayStartedAt, now);
   }

   public void resetMonth(long now) {
      this.month.clear();
      this.monthStartedAt = now;
   }

   public void resetWeek(long now) {
      this.week.clear();
      this.weekStartedAt = now;
   }

   public void resetDay(long now) {
      this.day.clear();
      this.dayStartedAt = now;
   }

   private long elapsedSince(long time, long now) {
      return now <= time ? 0L : now - time;
   }
}
