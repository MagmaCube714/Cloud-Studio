package cs.cloudstudio.manager;

import cs.cloudstudio.CloudStaffWork;
import org.bukkit.Bukkit;

public final class DependencyManager {
   private final CloudStaffWork plugin;

   public DependencyManager(CloudStaffWork plugin) {
      this.plugin = plugin;
   }

   public boolean checkRequired() {
      if (Bukkit.getPluginManager().getPlugin("LuckPerms") == null) {
         this.plugin.log("&fCloudStaffWork &cLuckPerms не найден, плагин отключён");
         Bukkit.getPluginManager().disablePlugin(this.plugin);
         return false;
      } else if (Bukkit.getPluginManager().getPlugin("LiteBans") == null) {
         this.plugin.log("&fCloudStaffWork &cLiteBans не найден, плагин отключён");
         Bukkit.getPluginManager().disablePlugin(this.plugin);
         return false;
      } else {
         return true;
      }
   }
}
