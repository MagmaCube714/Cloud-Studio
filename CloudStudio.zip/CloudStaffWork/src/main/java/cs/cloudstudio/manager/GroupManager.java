package cs.cloudstudio.manager;

import cs.cloudstudio.CloudStaffWork;
import cs.cloudstudio.util.ColorUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.types.InheritanceNode;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public final class GroupManager {
   private static final String MESSAGE_PREFIX = "[message]";
   private static final String LP_USER_PREFIX = "lp user ";
   private static final String LUCKPERMS_USER_PREFIX = "luckperms user ";
   private static final String PARENT_PREFIX = "parent ";
   private final CloudStaffWork plugin;
   private final LuckPerms luckPerms;
   private final Set<String> configuredGroups = new HashSet<>();
   private final Map<String, List<String>> enableCommands = new HashMap<>();
   private final Map<String, List<String>> disableCommands = new HashMap<>();

   public GroupManager(CloudStaffWork plugin) {
      this.plugin = plugin;
      this.luckPerms = LuckPermsProvider.get();
      this.reload();
   }

   public void reload() {
      this.configuredGroups.clear();
      this.enableCommands.clear();
      this.disableCommands.clear();
      ConfigurationSection section = this.plugin.getConfig().getConfigurationSection("worker-groups");
      if (section != null) {
         for (String group : section.getKeys(false)) {
            this.configuredGroups.add(group);
            List<String> enable = this.collect("worker-groups." + group + ".enable.commands", "worker-groups." + group + ".enable.switch-commands-in-enable");
            if (!enable.isEmpty()) {
               this.enableCommands.put(group, Collections.unmodifiableList(enable));
            }

            List<String> disable = this.collect(
               "worker-groups." + group + ".disable.commands", "worker-groups." + group + ".disable.switch-commands-in-disable"
            );
            if (!disable.isEmpty()) {
               this.disableCommands.put(group, Collections.unmodifiableList(disable));
            }
         }
      }
   }

   public String getGroup(Player player) {
      try {
         User user = this.luckPerms.getPlayerAdapter(Player.class).getUser(player);
         String group = user.getPrimaryGroup();
         return group != null && !group.isEmpty() ? group : "default";
      } catch (RuntimeException exception) {
         return "default";
      }
   }

   public boolean hasGroup(String group) {
      return this.configuredGroups.contains(group);
   }

   public void applyEnable(Player player, String group) {
      this.executeCommands(player, this.enableCommands.get(group));
   }

   public void applyDisable(Player player, String group) {
      this.executeCommands(player, this.disableCommands.get(group));
   }

   private List<String> collect(String first, String second) {
      List<String> commands = new ArrayList<>(8);
      commands.addAll(this.plugin.getConfig().getStringList(first));
      commands.addAll(this.plugin.getConfig().getStringList(second));
      return commands;
   }

   private void executeCommands(Player player, List<String> commands) {
      if (commands != null && !commands.isEmpty()) {
         String name = player.getName();

         for (String command : commands) {
            if (command != null && !command.isEmpty()) {
               String prepared = this.prepare(command, name).trim();
               if (!prepared.isEmpty()) {
                  if (this.startsWithMessagePrefix(prepared)) {
                     this.broadcast(prepared.substring("[message]".length()).trim());
                  } else {
                     if (prepared.charAt(0) == '/') {
                        prepared = prepared.substring(1).trim();
                        if (prepared.isEmpty()) {
                           continue;
                        }
                     }

                     if (!this.tryLuckPermsParentCommand(player, prepared)) {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), prepared);
                     }
                  }
               }
            }
         }
      }
   }

   private boolean tryLuckPermsParentCommand(Player player, String command) {
      String rest;
      if (this.startsWithIgnoreCase(command, "lp user ")) {
         rest = command.substring("lp user ".length()).trim();
      } else {
         if (!this.startsWithIgnoreCase(command, "luckperms user ")) {
            return false;
         }

         rest = command.substring("luckperms user ".length()).trim();
      }

      String name = player.getName();
      if (!rest.regionMatches(true, 0, name, 0, name.length())) {
         return false;
      } else {
         rest = rest.substring(name.length()).trim();
         if (!this.startsWithIgnoreCase(rest, "parent ")) {
            return false;
         } else {
            rest = rest.substring("parent ".length()).trim();
            int split = this.indexOfWhitespace(rest);
            if (split <= 0) {
               return false;
            } else {
               String action = rest.substring(0, split);
               String group = rest.substring(split).trim();
               if (group.isEmpty() || this.indexOfWhitespace(group) != -1) {
                  return false;
               } else if ("add".equalsIgnoreCase(action)) {
                  this.updateParent(player, group, true);
                  return true;
               } else if ("remove".equalsIgnoreCase(action)) {
                  this.updateParent(player, group, false);
                  return true;
               } else {
                  return false;
               }
            }
         }
      }
   }

   private void updateParent(Player player, String group, boolean add) {
      try {
         User user = this.luckPerms.getPlayerAdapter(Player.class).getUser(player);
         InheritanceNode node = (InheritanceNode)InheritanceNode.builder(group).build();
         if (add) {
            user.data().add(node);
         } else {
            user.data().remove(node);
         }

         this.luckPerms.getUserManager().saveUser(user);
      } catch (RuntimeException exception) {
         Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + player.getName() + " parent " + (add ? "add " : "remove ") + group);
      }
   }

   private String prepare(String value, String name) {
      return value.replace("%name%", name).replace("%player%", name).replace("{$name}", name).replace("{$player}", name);
   }

   private void broadcast(String message) {
      if (message != null && !message.isEmpty()) {
         String colored = ColorUtil.color(message);
         Bukkit.getConsoleSender().sendMessage(colored);

         for (Player target : Bukkit.getOnlinePlayers()) {
            if (target.hasPermission("cloudstaffwork.use")) {
               target.sendMessage(colored);
            }
         }
      }
   }

   private boolean startsWithMessagePrefix(String value) {
      return value.length() >= "[message]".length() && value.regionMatches(true, 0, "[message]", 0, "[message]".length());
   }

   private boolean startsWithIgnoreCase(String value, String prefix) {
      return value.length() >= prefix.length() && value.regionMatches(true, 0, prefix, 0, prefix.length());
   }

   private int indexOfWhitespace(String value) {
      for (int i = 0; i < value.length(); i++) {
         if (Character.isWhitespace(value.charAt(i))) {
            return i;
         }
      }

      return -1;
   }
}
