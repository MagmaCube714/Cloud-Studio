package cs.cloudstudio.util;

public final class TimeUtil {
   private TimeUtil() {
   }

   public static String format(long millis) {
      long total = Math.max(0L, millis) / 1000L;
      long days = total / 86400L;
      long hours = total % 86400L / 3600L;
      long minutes = total % 3600L / 60L;
      long seconds = total % 60L;
      if (days > 0L) {
         return days + "д " + hours + "ч " + minutes + "м";
      } else if (hours > 0L) {
         return hours + "ч " + minutes + "м " + seconds + "с";
      } else {
         return minutes > 0L ? minutes + "м " + seconds + "с" : seconds + "с";
      }
   }
}
