package cs.cloudstudio.util;

import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.Locale;

public final class DateUtil {
   private static final WeekFields WEEK_FIELDS = WeekFields.of(Locale.getDefault());

   private DateUtil() {
   }

   public static String day() {
      return day(LocalDate.now());
   }

   public static String day(LocalDate date) {
      return date.toString();
   }

   public static String week() {
      return week(LocalDate.now());
   }

   public static String week(LocalDate date) {
      return date.get(WEEK_FIELDS.weekBasedYear()) + "-" + date.get(WEEK_FIELDS.weekOfWeekBasedYear());
   }

   public static String month() {
      return month(LocalDate.now());
   }

   public static String month(LocalDate date) {
      return date.getYear() + "-" + date.getMonthValue();
   }
}
