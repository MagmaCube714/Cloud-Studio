package cs.cloudstudio.util;

import org.bukkit.ChatColor;

public final class ColorUtil {
   private ColorUtil() {
   }

   public static String color(String value) {
      if (value != null && !value.isEmpty()) {
         return value.indexOf(38) == -1 ? value : ChatColor.translateAlternateColorCodes('&', value);
      } else {
         return "";
      }
   }
}
