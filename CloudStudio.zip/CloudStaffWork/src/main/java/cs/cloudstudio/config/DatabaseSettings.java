package cs.cloudstudio.config;

import cs.cloudstudio.database.DatabaseType;
import java.io.File;
import java.util.Locale;
import org.bukkit.configuration.file.FileConfiguration;

public final class DatabaseSettings {
   private final DatabaseType type;
   private final String host;
   private final int port;
   private final String username;
   private final String password;
   private final String playerDatabase;

   private DatabaseSettings(DatabaseType type, String host, int port, String username, String password, String playerDatabase) {
      this.type = type;
      this.host = host;
      this.port = port;
      this.username = username;
      this.password = password;
      this.playerDatabase = playerDatabase;
   }

   public static DatabaseSettings load(FileConfiguration config) {
      DatabaseType type = DatabaseType.from(config.getString("database.type", "SQLite"));
      String host = nonEmpty(config.getString("database.host"), "localhost");
      int port = config.getInt("database.port", 3306);
      if (port <= 0 || port > 65535) {
         port = 3306;
      }

      String username = nonEmpty(config.getString("database.username"), "admin");
      String password = config.getString("database.password", "admin");
      String playerDatabase = sanitizeName(config.getString("database.playerDatabase"), "data");
      return new DatabaseSettings(type, host, port, username, password == null ? "" : password, playerDatabase);
   }

   public DatabaseType getType() {
      return this.type;
   }

   public String getHost() {
      return this.host;
   }

   public int getPort() {
      return this.port;
   }

   public String getUsername() {
      return this.username;
   }

   public String getPassword() {
      return this.password;
   }

   public String getPlayerDatabase() {
      return this.playerDatabase;
   }

   public File sqliteFile(File dataFolder) {
      String fileName = this.playerDatabase.endsWith(".db") ? this.playerDatabase : this.playerDatabase + ".db";
      return new File(dataFolder, fileName);
   }

   private static String nonEmpty(String value, String fallback) {
      return value != null && !value.trim().isEmpty() ? value.trim() : fallback;
   }

   private static String sanitizeName(String value, String fallback) {
      String source = nonEmpty(value, fallback).toLowerCase(Locale.ROOT);
      StringBuilder builder = new StringBuilder(source.length());

      for (int i = 0; i < source.length(); i++) {
         char c = source.charAt(i);
         if (c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '_' || c == '-') {
            builder.append(c);
         }
      }

      return builder.length() == 0 ? fallback : builder.toString();
   }
}
