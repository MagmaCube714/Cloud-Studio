package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.command.StaffWorkCommand;
import cs.cloudstudio.config.DatabaseSettings;
import cs.cloudstudio.database.DatabaseManager;
import cs.cloudstudio.listener.LiteBansListener;
import cs.cloudstudio.listener.StaffListener;
import cs.cloudstudio.manager.DependencyManager;
import cs.cloudstudio.manager.PeriodManager;
import cs.cloudstudio.manager.StaffManager;
import cs.cloudstudio.menu.StatsMenu;
import cs.cloudstudio.util.ColorUtil;
import java.io.File;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudStaffWork extends JavaPlugin {
   private DatabaseManager databaseManager;
   private StaffManager staffManager;
   private StatsMenu statsMenu;
   private PeriodManager periodManager;
   private LiteBansListener liteBansListener;
   private StaffWorkCommand staffWorkCommand;
   private AdminCommand adminCommand;

   public DatabaseManager getDatabaseManager() {
      return this.databaseManager;
   }

   public StaffManager getStaffManager() {
      return this.staffManager;
   }

   public StatsMenu getStatsMenu() {
      return this.statsMenu;
   }

   public void onEnable() {
      this.saveDefaultConfigIfMissing();
      if (new DependencyManager(this).checkRequired()) {
         if (!this.connectDatabase()) {
            Bukkit.getPluginManager().disablePlugin(this);
         } else {
            this.staffManager = new StaffManager(this, this.databaseManager);
            this.statsMenu = new StatsMenu(this);
            this.periodManager = new PeriodManager(this, this.databaseManager, this.staffManager);
            this.periodManager.load();
            this.periodManager.start();
            this.registerCommands();
            this.registerListeners();
            this.log("&fCloudStaffWork &aуспешно загружен!");
         }
      }
   }

   public void onDisable() {
      if (this.liteBansListener != null) {
         this.liteBansListener.unregister();
      }

      this.liteBansListener = null;
      if (this.staffManager != null) {
         this.staffManager.stopAll();
      }

      Bukkit.getScheduler().cancelTasks(this);
      if (this.databaseManager != null) {
         this.databaseManager.close();
         this.databaseManager = null;
      }

      this.log("&fCloudStaffWork &cуспешно выгружен!");
   }

   public void reloadPlugin() {
      this.reloadConfig();
      if (this.adminCommand != null) {
         this.adminCommand.reload();
      }

      if (this.staffWorkCommand != null) {
         this.staffWorkCommand.reload();
      }

      if (this.staffManager != null) {
         this.staffManager.reload();
      }

      if (this.statsMenu != null) {
         this.statsMenu.reload();
      }
   }

   public void log(String message) {
      Bukkit.getConsoleSender().sendMessage(ColorUtil.color(message));
   }

   public void warning(String message) {
      this.getLogger().warning("[CloudStaffWork] " + message);
   }

   private boolean connectDatabase() {
      try {
         DatabaseSettings databaseSettings = DatabaseSettings.load(this.getConfig());
         this.databaseManager = new DatabaseManager(this, databaseSettings);
         this.databaseManager.connect();
         this.databaseManager.createTables();
         return true;
      } catch (RuntimeException exception) {
         this.log("&fCloudStaffWork &cБаза данных не подключена, плагин отключён");
         this.warning("База данных не подключена: проверьте настройки database");
         return false;
      }
   }

   private void registerCommands() {
      this.staffWorkCommand = new StaffWorkCommand(this);
      PluginCommand sw = this.getCommand("sw");
      if (sw == null) {
         this.warning("Команда /sw отсутствует в plugin.yml");
      } else {
         sw.setExecutor(this.staffWorkCommand);
         sw.setTabCompleter(this.staffWorkCommand);
      }

      this.adminCommand = new AdminCommand(this);
      PluginCommand cloudStaffWork = this.getCommand("cloudstaffwork");
      if (cloudStaffWork == null) {
         this.warning("Команда /cloudstaffwork отсутствует в plugin.yml");
      } else {
         cloudStaffWork.setExecutor(this.adminCommand);
         cloudStaffWork.setTabCompleter(this.adminCommand);
      }
   }

   private void registerListeners() {
      Bukkit.getPluginManager().registerEvents(new StaffListener(this), this);
      Bukkit.getPluginManager().registerEvents(this.statsMenu, this);
      this.liteBansListener = new LiteBansListener(this);
      this.liteBansListener.register();
   }

   private void saveDefaultConfigIfMissing() {
      File file = new File(this.getDataFolder(), "config.yml");
      if (!file.isFile()) {
         this.saveDefaultConfig();
      }
   }
}
