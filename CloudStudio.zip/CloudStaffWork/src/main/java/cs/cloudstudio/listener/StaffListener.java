package cs.cloudstudio.listener;

import cs.cloudstudio.CloudStaffWork;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class StaffListener implements Listener {
   private final CloudStaffWork plugin;

   public StaffListener(CloudStaffWork plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.plugin.getStaffManager().stopSilently(event.getPlayer());
   }

   @EventHandler
   public void onKick(PlayerKickEvent event) {
      this.plugin.getStaffManager().stopSilently(event.getPlayer());
   }
}
