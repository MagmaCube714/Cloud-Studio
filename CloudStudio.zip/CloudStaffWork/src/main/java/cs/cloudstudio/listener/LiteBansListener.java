package cs.cloudstudio.listener;

import cs.cloudstudio.CloudStaffWork;
import java.util.UUID;
import litebans.api.Entry;
import litebans.api.Events;
import litebans.api.Events.Listener;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class LiteBansListener extends Listener {
   private final CloudStaffWork plugin;

   public LiteBansListener(CloudStaffWork plugin) {
      this.plugin = plugin;
   }

   public void register() {
      Events.get().register(this);
   }

   public void unregister() {
      Events.get().unregister(this);
   }

   public void entryAdded(Entry entry) {
      this.record(addedAction(entry.getType()), entry.getExecutorUUID());
   }

   public void entryRemoved(Entry entry) {
      this.record(removedAction(entry.getType()), entry.getRemovedByUUID());
   }

   private void record(String action, String executorUuid) {
      if (action != null && executorUuid != null && !executorUuid.isBlank()) {
         UUID uuid = parseUuid(executorUuid);
         if (uuid != null && this.plugin.isEnabled()) {
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               if (this.plugin.isEnabled()) {
                  Player executor = Bukkit.getPlayer(uuid);
                  if (executor != null && executor.isOnline()) {
                     this.plugin.getStaffManager().addAction(executor, action);
                  }
               }
            });
         }
      }
   }

   private static String addedAction(String type) {
      if ("ban".equals(type)) {
         return "bans";
      } else if ("mute".equals(type)) {
         return "mutes";
      } else {
         return "kick".equals(type) ? "kicks" : null;
      }
   }

   private static String removedAction(String type) {
      if ("ban".equals(type)) {
         return "unbans";
      } else {
         return "mute".equals(type) ? "unmutes" : null;
      }
   }

   private static UUID parseUuid(String value) {
      String normalized = value;
      if (value.length() == 32) {
         normalized = value.substring(0, 8)
            + "-"
            + value.substring(8, 12)
            + "-"
            + value.substring(12, 16)
            + "-"
            + value.substring(16, 20)
            + "-"
            + value.substring(20);
      }

      try {
         return UUID.fromString(normalized);
      } catch (IllegalArgumentException exception) {
         return null;
      }
   }
}
