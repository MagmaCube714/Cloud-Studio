package cs.cloudstudio.command;

import cs.cloudstudio.CloudStaffWork;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.CommandSender;

public abstract class BaseCommand implements SubCommand {
   protected final CloudStaffWork plugin;

   protected BaseCommand(CloudStaffWork plugin) {
      this.plugin = plugin;
   }

   @Override
   public List<String> tab(CommandSender sender, String[] args) {
      return Collections.emptyList();
   }

   @Override
   public void reload() {
   }
}
