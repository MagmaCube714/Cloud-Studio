package cs.cloudstudio.command;

import cs.cloudstudio.CloudStaffWork;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import cs.cloudstudio.util.ColorUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

public final class AdminCommand implements TabExecutor {
   private final CloudStaffWork plugin;
   private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();
   private String noPermissionMessage;
   private String usageMessage;

   public AdminCommand(CloudStaffWork plugin) {
      this.plugin = plugin;
      this.register(new ReloadSubCommand(plugin));
      this.reload();
   }

   public void reload() {
      this.noPermissionMessage = ColorUtil.color(this.plugin.getConfig().getString("messages.no-perm"));
      this.usageMessage = ColorUtil.color(this.plugin.getConfig().getString("messages.admin-usage"));

      for (SubCommand subCommand : this.subCommands.values()) {
         subCommand.reload();
      }
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("cloudstaffwork.admin")) {
         sender.sendMessage(this.noPermissionMessage);
         return true;
      } else if (args.length == 0) {
         sender.sendMessage(this.usageMessage);
         return true;
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            sender.sendMessage(this.usageMessage);
            return true;
         } else {
            subCommand.execute(sender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (sender instanceof Player && !sender.hasPermission("cloudstaffwork.admin")) {
         return Collections.emptyList();
      }

      if (args.length == 1) {
         return this.matches(args[0], new ArrayList<>(this.subCommands.keySet()));
      }

      SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
      return subCommand == null ? Collections.emptyList() : subCommand.tab(sender, args);
   }

   private void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.getName().toLowerCase(Locale.ROOT), subCommand);
   }

   private List<String> matches(String prefix, List<String> values) {
      List<String> result = new ArrayList<>();

      for (String value : values) {
         if (value.regionMatches(true, 0, prefix, 0, prefix.length())) {
            result.add(value);
         }
      }

      Collections.sort(result, String.CASE_INSENSITIVE_ORDER);
      return result;
   }
}
