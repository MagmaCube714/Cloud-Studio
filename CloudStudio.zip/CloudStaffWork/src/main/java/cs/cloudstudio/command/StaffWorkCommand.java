package cs.cloudstudio.command;

import cs.cloudstudio.CloudStaffWork;
import cs.cloudstudio.manager.StaffManager;
import cs.cloudstudio.manager.model.Stats;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.TimeUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

public final class StaffWorkCommand implements TabExecutor {
   private static final int MAX_PLAYER_NAME_LENGTH = 30;
   private final CloudStaffWork plugin;
   private String noPermissionMessage;
   private String noGroupMessage;
   private String statsConsoleMessage;
   private String statsNotUserMessage;
   private String consoleHeader;
   private String consoleMonth;
   private String consoleWeek;
   private String consoleDay;
   private int monthNeedBans;
   private int weekNeedBans;
   private int dayNeedBans;
   private int monthNeedMutes;
   private int weekNeedMutes;
   private int dayNeedMutes;
   private String completeText;
   private String incompleteText;

   public StaffWorkCommand(CloudStaffWork plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.noPermissionMessage = ColorUtil.color(this.plugin.getConfig().getString("messages.no-perm"));
      this.noGroupMessage = ColorUtil.color(this.plugin.getConfig().getString("messages.no-group"));
      this.statsConsoleMessage = ColorUtil.color(this.plugin.getConfig().getString("messages.stats-console"));
      this.statsNotUserMessage = ColorUtil.color(this.plugin.getConfig().getString("stats.not-user"));
      this.consoleHeader = ColorUtil.color(this.plugin.getConfig().getString("stats.console.header", ""));
      this.consoleMonth = ColorUtil.color(this.plugin.getConfig().getString("stats.console.month", ""));
      this.consoleWeek = ColorUtil.color(this.plugin.getConfig().getString("stats.console.week", ""));
      this.consoleDay = ColorUtil.color(this.plugin.getConfig().getString("stats.console.day", ""));
      this.monthNeedBans = this.plugin.getConfig().getInt("stats.requirements.month.bans");
      this.weekNeedBans = this.plugin.getConfig().getInt("stats.requirements.week.bans");
      this.dayNeedBans = this.plugin.getConfig().getInt("stats.requirements.day.bans");
      this.monthNeedMutes = this.plugin.getConfig().getInt("stats.requirements.month.mutes");
      this.weekNeedMutes = this.plugin.getConfig().getInt("stats.requirements.week.mutes");
      this.dayNeedMutes = this.plugin.getConfig().getInt("stats.requirements.day.mutes");
      this.completeText = ColorUtil.color(this.plugin.getConfig().getString("stats.requirements.complete", ""));
      this.incompleteText = ColorUtil.color(this.plugin.getConfig().getString("stats.requirements.incomplete", ""));
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (args.length > 0 && args[0].equalsIgnoreCase("stats")) {
         this.stats(sender, args);
         return true;
      } else if (!(sender instanceof Player player)) {
         sender.sendMessage(ColorUtil.color("&cКоманда доступна только от лица игрока"));
         return true;
      } else {
         if (!player.hasPermission("cloudstaffwork.use")) {
            player.sendMessage(this.noPermissionMessage);
            return true;
         }

         if (this.plugin.getStaffManager().isWorking(player)) {
            this.plugin.getStaffManager().stop(player);
            return true;
         }

         if (this.plugin.getStaffManager().isPending(player)) {
            return true;
         }

         final UUID uuid = player.getUniqueId();
         this.plugin.getStaffManager().start(player, new StaffManager.StartCallback() {
            @Override
            public void complete(boolean started) {
               if (!started) {
                  Player online = Bukkit.getPlayer(uuid);
                  if (online != null) {
                     online.sendMessage(StaffWorkCommand.this.noGroupMessage);
                  }
               }
            }
         });
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!this.canUseStatsTab(sender)) {
         return Collections.emptyList();
      } else if (args.length == 1) {
         return this.matches(args[0], "stats");
      } else {
         return args.length == 2 && "stats".regionMatches(true, 0, args[0], 0, args[0].length()) ? this.completePlayers(args[1]) : Collections.emptyList();
      }
   }

   private void stats(CommandSender sender, String[] args) {
      if (args.length == 1) {
         if (!(sender instanceof Player player)) {
            sender.sendMessage(this.statsConsoleMessage);
         } else if (!this.canViewOwnStats(player)) {
            player.sendMessage(this.noPermissionMessage);
         } else {
            this.openStats(sender, player.getName());
         }
      } else {
         String target = args[1];
         if (target.length() > 30) {
            sender.sendMessage(this.statsNotUserMessage);
         } else {
            boolean own = sender instanceof Player && ((Player)sender).getName().equalsIgnoreCase(target);
            if (!(sender instanceof Player player && (own ? !this.canViewOwnStats(player) : !player.hasPermission("cloudstaffwork.curator")))) {
               this.openStats(sender, target);
            } else {
               player.sendMessage(this.noPermissionMessage);
            }
         }
      }
   }

   private void openStats(final CommandSender sender, final String target) {
      if (sender instanceof Player) {
         final UUID viewerId = ((Player)sender).getUniqueId();
         this.plugin.getStaffManager().snapshotsAsync(target, new StaffManager.SnapshotCallback() {
            @Override
            public void complete(Stats[] stats) {
               Player viewer = Bukkit.getPlayer(viewerId);
               if (viewer != null) {
                  if (stats == null) {
                     viewer.sendMessage(StaffWorkCommand.this.statsNotUserMessage);
                  } else {
                     StaffWorkCommand.this.plugin.getStatsMenu().open(viewer, target, stats);
                  }
               }
            }
         });
      } else {
         this.plugin.getStaffManager().snapshotsAsync(target, new StaffManager.SnapshotCallback() {
            @Override
            public void complete(Stats[] stats) {
               if (stats == null) {
                  sender.sendMessage(StaffWorkCommand.this.statsNotUserMessage);
               } else {
                  StaffWorkCommand.this.sendTextStats(sender, target, stats);
               }
            }
         });
      }
   }

   private void sendTextStats(CommandSender sender, String target, Stats[] stats) {
      this.sendConfigured(sender, this.consoleHeader, target, null, null);
      this.sendConfigured(sender, this.consoleMonth, target, "month", stats[1]);
      this.sendConfigured(sender, this.consoleWeek, target, "week", stats[2]);
      this.sendConfigured(sender, this.consoleDay, target, "day", stats[3]);
   }

   private void sendConfigured(CommandSender sender, String line, String target, String period, Stats stats) {
      if (line != null && !line.isEmpty()) {
         sender.sendMessage(this.formatStatsLine(line, target, period, stats));
      }
   }

   private String formatStatsLine(String line, String target, String period, Stats stats) {
      String result = line.replace("%name%", target).replace("%player%", target).replace("{$name}", target).replace("{$player}", target);
      if (period != null && stats != null) {
         int needBans = this.needBans(period);
         int needMutes = this.needMutes(period);
         return result.replace("%played%", TimeUtil.format(stats.getPlayed()))
            .replace("%bans%", String.valueOf(stats.getBans()))
            .replace("%mutes%", String.valueOf(stats.getMutes()))
            .replace("%unbans%", String.valueOf(stats.getUnbans()))
            .replace("%unmutes%", String.valueOf(stats.getUnmutes()))
            .replace("%kicks%", String.valueOf(stats.getKicks()))
            .replace("%period%", period)
            .replace("%cloudstaffwork_need_" + period + "_bans%", String.valueOf(needBans))
            .replace("%cloudstaffwork_need_" + period + "_mutes%", String.valueOf(needMutes))
            .replace(
               "%cloudstaffwork_need_" + period + "_complete%",
               stats.getBans() >= needBans && stats.getMutes() >= needMutes ? this.completeText : this.incompleteText
            );
      } else {
         return result;
      }
   }

   private int needBans(String period) {
      if ("month".equals(period)) {
         return this.monthNeedBans;
      } else {
         return "week".equals(period) ? this.weekNeedBans : this.dayNeedBans;
      }
   }

   private int needMutes(String period) {
      if ("month".equals(period)) {
         return this.monthNeedMutes;
      } else {
         return "week".equals(period) ? this.weekNeedMutes : this.dayNeedMutes;
      }
   }

   private boolean canUseStatsTab(CommandSender sender) {
      return !(sender instanceof Player) || sender.hasPermission("cloudstaffwork.use") || sender.hasPermission("cloudstaffwork.curator");
   }

   private boolean canViewOwnStats(Player player) {
      return player.hasPermission("cloudstaffwork.use") || player.hasPermission("cloudstaffwork.curator");
   }

   private List<String> completePlayers(String prefix) {
      List<String> result = new ArrayList<>(Bukkit.getOnlinePlayers().size());

      for (Player player : Bukkit.getOnlinePlayers()) {
         String name = player.getName();
         if (name.regionMatches(true, 0, prefix, 0, prefix.length())) {
            result.add(name);
         }
      }

      Collections.sort(result, String.CASE_INSENSITIVE_ORDER);
      return result;
   }

   private List<String> matches(String prefix, String value) {
      return value.regionMatches(true, 0, prefix, 0, prefix.length()) ? Collections.singletonList(value) : Collections.emptyList();
   }
}
