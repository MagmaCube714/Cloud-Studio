package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudStaffWork;
import cs.cloudstudio.command.BaseCommand;
import cs.cloudstudio.util.ColorUtil;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand extends BaseCommand {
   private String reloadedMessage;

   public ReloadSubCommand(CloudStaffWork plugin) {
      super(plugin);
      this.reload();
   }

   @Override
   public String getName() {
      return "reload";
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      this.plugin.reloadPlugin();
      sender.sendMessage(this.reloadedMessage);
   }

   @Override
   public void reload() {
      this.reloadedMessage = ColorUtil.color(this.plugin.getConfig().getString("messages.reloaded"));
   }
}
