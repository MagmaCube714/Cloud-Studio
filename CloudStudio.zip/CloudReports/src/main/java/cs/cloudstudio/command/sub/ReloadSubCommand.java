package cs.cloudstudio.command.sub;

import cs.cloudstudio.CloudReports;
import cs.cloudstudio.command.BaseCommand;
import org.bukkit.command.CommandSender;

public final class ReloadSubCommand extends BaseCommand {
   public ReloadSubCommand(CloudReports plugin) {
      super(plugin);
   }

   @Override
   public void execute(CommandSender sender, String[] args) {
      this.plugin().configManager().reload();
      sender.sendMessage(this.plugin().configManager().message("reload-config"));
   }

   @Override
   public String getName() {
      return "reload";
   }
}
