package cs.cloudstudio.command;

import org.bukkit.command.CommandSender;

public interface SubCommand {
   void execute(CommandSender var1, String[] var2);

   String getName();
}
