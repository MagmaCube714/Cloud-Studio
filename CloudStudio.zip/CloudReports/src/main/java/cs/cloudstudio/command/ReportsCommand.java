package cs.cloudstudio.command;

import cs.cloudstudio.CloudReports;
import cs.cloudstudio.menu.MainMenu;
import java.util.Collections;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class ReportsCommand implements CommandExecutor, TabCompleter {
   private final CloudReports plugin;

   public ReportsCommand(CloudReports plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("cloudreports.staff")) {
         sender.sendMessage(this.plugin.configManager().message("no-permission"));
         return true;
      } else if (!(sender instanceof Player)) {
         sender.sendMessage(this.plugin.configManager().message("only-player"));
         return true;
      } else {
         new MainMenu(this.plugin, 0).open((Player)sender);
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      return Collections.emptyList();
   }
}
