package cs.cloudstudio.command;

import cs.cloudstudio.CloudReports;
import cs.cloudstudio.util.ColorUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class ReportCommand implements CommandExecutor, TabCompleter {
   private final CloudReports plugin;
   private final Map<UUID, Long> lastReports = new HashMap<>();

   public ReportCommand(CloudReports plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!(sender instanceof Player player)) {
         sender.sendMessage(this.plugin.configManager().message("only-player"));
         return true;
      } else {
         if (args.length < 2) {
            player.sendMessage(this.plugin.configManager().message("usage-report"));
            return true;
         }

         Player target = Bukkit.getPlayerExact(args[0]);
         if (target == null) {
            player.sendMessage(this.plugin.configManager().message("player-not-found"));
            return true;
         }

         if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage(this.plugin.configManager().message("cannot-report-self"));
            return true;
         }

         String reason = this.reason(args);
         if (reason.isEmpty()) {
            player.sendMessage(this.plugin.configManager().message("usage-report"));
            return true;
         }

         String targetName = target.getName();
         String reporterName = player.getName();
         long now = System.currentTimeMillis();
         boolean bypass = player.hasPermission("cloudreports.staff");
         if (!bypass) {
            long cooldownMillis = this.plugin.configManager().reportCooldownSeconds() * 1000L;
            Long last = this.lastReports.get(player.getUniqueId());
            if (cooldownMillis > 0L && last != null && now - last < cooldownMillis) {
               long left = (cooldownMillis - (now - last) + 999L) / 1000L;
               player.sendMessage(this.plugin.configManager().message("report-cooldown").replace("{time}", String.valueOf(left)));
               return true;
            }

            int maxPerTarget = this.plugin.configManager().maxReportsPerTarget();
            if (maxPerTarget > 0 && this.plugin.reportsManager().reportsBy(targetName, reporterName) >= maxPerTarget) {
               player.sendMessage(this.plugin.configManager().message("report-limit").replace("{target}", targetName));
               return true;
            }
         }

         if (!this.plugin.reportsManager().addReport(targetName, reporterName, reason, now)) {
            return true;
         }

         this.rememberReport(player.getUniqueId(), now);
         player.sendMessage(this.plugin.configManager().message("report-sent").replace("{target}", targetName));
         this.notifyStaff(reporterName, targetName, reason);
         return true;
      }
   }

   private void rememberReport(UUID uuid, long now) {
      if (this.lastReports.size() > 512) {
         long cooldownMillis = this.plugin.configManager().reportCooldownSeconds() * 1000L;
         this.lastReports.values().removeIf(time -> now - time >= cooldownMillis);
      }

      this.lastReports.put(uuid, now);
   }

   private void notifyStaff(String reporter, String target, String reason) {
      String notification = this.plugin
         .configManager()
         .message("report-notify")
         .replace("{reporter}", reporter)
         .replace("{target}", target)
         .replace("{reason}", reason);
      Bukkit.getConsoleSender().sendMessage(notification);

      for (Player player : Bukkit.getOnlinePlayers()) {
         if (player.hasPermission("cloudreports.staff")) {
            player.sendMessage(notification);
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (args.length != 1) {
         return Collections.emptyList();
      }

      String input = args[0].toLowerCase(Locale.ROOT);
      String senderName = sender.getName();
      Collection<? extends Player> onlinePlayers = Bukkit.getOnlinePlayers();
      List<String> completions = new ArrayList<>(Math.min(onlinePlayers.size(), 10));

      for (Player player : onlinePlayers) {
         String name = player.getName();
         if (!name.equalsIgnoreCase(senderName) && name.toLowerCase(Locale.ROOT).startsWith(input)) {
            completions.add(name);
            if (completions.size() >= 10) {
               break;
            }
         }
      }

      return completions;
   }

   private String reason(String[] args) {
      StringBuilder builder = new StringBuilder();

      for (int i = 1; i < args.length; i++) {
         if (builder.length() > 0) {
            builder.append(' ');
         }

         builder.append(args[i]);
      }

      String reason = ColorUtil.strip(this.plugin.configManager().color(builder.toString())).trim();
      int maxLength = this.plugin.configManager().maxReasonLength();
      return reason.length() > maxLength ? reason.substring(0, maxLength) : reason;
   }
}
