package cs.cloudstudio.command;

import cs.cloudstudio.CloudReports;

public abstract class BaseCommand implements SubCommand {
   private final CloudReports plugin;

   protected BaseCommand(CloudReports plugin) {
      this.plugin = plugin;
   }

   protected CloudReports plugin() {
      return this.plugin;
   }
}
