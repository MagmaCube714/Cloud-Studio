package cs.cloudstudio.command;

import cs.cloudstudio.CloudReports;
import cs.cloudstudio.command.sub.ReloadSubCommand;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

public final class AdminCommand implements CommandExecutor, TabCompleter {
   private static final String PERMISSION = "cloudreports.admin";
   private static final List<String> SUBCOMMANDS = Collections.unmodifiableList(Arrays.asList("reload"));
   private final CloudReports plugin;
   private final Map<String, SubCommand> subCommands = new HashMap<>();

   public AdminCommand(CloudReports plugin) {
      this.plugin = plugin;
      this.register(new ReloadSubCommand(plugin));
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("cloudreports.admin")) {
         sender.sendMessage(this.plugin.configManager().message("no-permission"));
         return true;
      } else if (args.length == 0) {
         sender.sendMessage(this.plugin.configManager().message("usage"));
         return true;
      } else {
         SubCommand subCommand = this.subCommands.get(args[0].toLowerCase(Locale.ROOT));
         if (subCommand == null) {
            sender.sendMessage(this.plugin.configManager().message("usage"));
            return true;
         } else {
            subCommand.execute(sender, args);
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (sender.hasPermission("cloudreports.admin") && args.length == 1) {
         String input = args[0].toLowerCase(Locale.ROOT);
         List<String> result = new ArrayList<>();

         for (String subCommand : SUBCOMMANDS) {
            if (subCommand.startsWith(input)) {
               result.add(subCommand);
            }
         }

         return result;
      } else {
         return Collections.emptyList();
      }
   }

   private void register(SubCommand subCommand) {
      this.subCommands.put(subCommand.getName().toLowerCase(Locale.ROOT), subCommand);
   }
}
