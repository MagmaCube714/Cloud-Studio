package cs.cloudstudio.manager;

import cs.cloudstudio.database.Database;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public final class ReportsManager {
   private final Database database;

   public ReportsManager(Database database) {
      this.database = database;
   }

   public boolean addReport(String target, String reporter, String reason, long timestamp) {
      return this.database.add(target, new Report(reporter, reason, timestamp));
   }

   public boolean removeReports(String target) {
      return this.database.remove(target);
   }

   public int reportsBy(String target, String reporter) {
      return this.database.count(target, reporter);
   }

   public boolean hasReports(String target) {
      return this.database.count(target) > 0;
   }

   public List<ReportData> reports() {
      Collection<ReportData> reports = this.database.reports();
      if (reports.isEmpty()) {
         return Collections.emptyList();
      } else {
         return reports instanceof List ? (List)reports : new ArrayList<>(reports);
      }
   }
}
