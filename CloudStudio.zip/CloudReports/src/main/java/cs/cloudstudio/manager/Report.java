package cs.cloudstudio.manager;

public final class Report {
   private final String reporter;
   private final String reason;
   private final long timestamp;

   public Report(String reporter, String reason, long timestamp) {
      this.reporter = reporter == null ? "" : reporter;
      this.reason = reason == null ? "" : reason;
      this.timestamp = timestamp;
   }

   public String reporter() {
      return this.reporter;
   }

   public String reason() {
      return this.reason;
   }

   public long timestamp() {
      return this.timestamp;
   }
}
