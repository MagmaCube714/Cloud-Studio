package cs.cloudstudio.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ReportData {
   private final String target;
   private final List<Report> reports;

   public ReportData(String target) {
      this.target = target == null ? "" : target;
      this.reports = new ArrayList<>(2);
   }

   public String target() {
      return this.target;
   }

   public synchronized List<Report> reports() {
      return Collections.unmodifiableList(new ArrayList<>(this.reports));
   }

   public synchronized void add(Report report) {
      if (report != null) {
         this.reports.add(report);
      }
   }

   public synchronized int count() {
      return this.reports.size();
   }

   public synchronized long lastReportTime() {
      int size = this.reports.size();
      return size == 0 ? 0L : this.reports.get(size - 1).timestamp();
   }

   public synchronized ReportData copy() {
      ReportData copy = new ReportData(this.target);
      copy.reports.addAll(this.reports);
      return copy;
   }
}
