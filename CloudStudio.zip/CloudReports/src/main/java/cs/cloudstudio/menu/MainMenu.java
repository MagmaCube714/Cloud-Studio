package cs.cloudstudio.menu;

import cs.cloudstudio.CloudReports;
import cs.cloudstudio.config.ConfigValues;
import cs.cloudstudio.manager.Report;
import cs.cloudstudio.manager.ReportData;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.ItemUtil;
import cs.cloudstudio.util.TimeUtil;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class MainMenu implements InventoryHolder {
   private static final int[] REPORT_SLOTS = new int[]{
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      10,
      11,
      12,
      13,
      14,
      16,
      19,
      20,
      21,
      22,
      23,
      24,
      25,
      28,
      29,
      30,
      31,
      32,
      33,
      34,
      37,
      38,
      39,
      40,
      41,
      42,
      43,
      46,
      47,
      48,
      49,
      50,
      51,
      52
   };
   public static final int[] PREVIOUS_SLOT = new int[]{26, 35};
   public static final int[] NEXT_SLOT = new int[]{15, 27};
   private static final int MAX_REPORT_LINES = 20;
   private static final int MAX_REASONS_LENGTH = 200;
   private static final int[] DECORATION_SLOTS = new int[]{0, 8, 9, 17, 36, 44, 45, 53};
   private final CloudReports plugin;
   private final int page;
   private final Inventory inventory;
   private final NamespacedKey targetKey;
   private final NamespacedKey menuItemKey;
   private boolean hasNextPage;

   public MainMenu(CloudReports plugin, int page) {
      this.plugin = plugin;
      this.page = Math.max(0, page);
      this.targetKey = plugin.reportTargetKey();
      this.menuItemKey = plugin.menuItemKey();
      ConfigValues.Reports menu = plugin.configManager().values().reports();
      this.inventory = Bukkit.createInventory(this, menu.size(), ColorUtil.component(menu.title()));
      this.fill(menu);
   }

   private void fill(ConfigValues.Reports menu) {
      this.addDecorations(menu);
      List<ReportData> reports = this.plugin.reportsManager().reports();
      if (!reports.isEmpty()) {
         int pageSize = this.validReportSlots(this.inventory.getSize());
         if (pageSize > 0) {
            int start = this.page * pageSize;
            if (start >= reports.size()) {
               if (this.page > 0) {
                  this.setItems(PREVIOUS_SLOT, ItemUtil.markMenuItem(this.menuItemKey, ItemUtil.item(menu.previous())));
               }
            } else {
               int end = Math.min(reports.size(), start + pageSize);
               int reportIndex = start;

               for (int slot : REPORT_SLOTS) {
                  if (slot < this.inventory.getSize()) {
                     this.inventory.setItem(slot, this.reportItem(reports.get(reportIndex), menu));
                     if (++reportIndex >= end) {
                        break;
                     }
                  }
               }

               if (this.page > 0) {
                  this.setItems(PREVIOUS_SLOT, ItemUtil.markMenuItem(this.menuItemKey, ItemUtil.item(menu.previous())));
               }

               if (end < reports.size()) {
                  this.setItems(NEXT_SLOT, ItemUtil.markMenuItem(this.menuItemKey, ItemUtil.item(menu.next())));
                  this.hasNextPage = true;
               }
            }
         }
      }
   }

   private int validReportSlots(int inventorySize) {
      int count = 0;

      for (int slot : REPORT_SLOTS) {
         if (slot < inventorySize) {
            count++;
         }
      }

      return count;
   }

   private void addDecorations(ConfigValues.Reports menu) {
      ItemStack item = ItemUtil.markMenuItem(this.menuItemKey, ItemUtil.item(menu.decoration()));
      this.setItems(DECORATION_SLOTS, item);
   }

   private void setItems(int[] slots, ItemStack item) {
      if (item != null) {
         int inventorySize = this.inventory.getSize();

         for (int slot : slots) {
            if (slot >= 0 && slot < inventorySize) {
               this.inventory.setItem(slot, item.clone());
            }
         }
      }
   }

   private ItemStack reportItem(ReportData data, ConfigValues.Reports menu) {
      String target = data.target();
      long lastReportTime = data.lastReportTime();
      String time = TimeUtil.formatTimestamp(lastReportTime);
      String count = String.valueOf(data.count());
      ConfigValues.Item source = menu.reportItem();
      ItemStack item = new ItemStack(source.material() == null ? Material.STONE : source.material());
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      if (source.name() != null && !source.name().isEmpty()) {
         meta.displayName(ColorUtil.itemText(this.replaceReportPlaceholders(source.name(), target, time, count)));
      }

      if (source.lore() != null && !source.lore().isEmpty()) {
         meta.lore(ColorUtil.itemText(this.reportLore(data, menu, target, time, count)));
      }

      if (source.modelData() > 0) {
         ColorUtil.applyModelData(meta, source.modelData());
      }

      meta.getPersistentDataContainer().set(this.targetKey, PersistentDataType.STRING, target);
      meta.getPersistentDataContainer().set(this.menuItemKey, PersistentDataType.BYTE, (byte)1);
      item.setItemMeta(meta);
      return item;
   }

   private List<String> reportLore(ReportData data, ConfigValues.Reports menu, String target, String time, String count) {
      List<String> sourceLore = menu.reportItem().lore();
      List<String> lore = new ArrayList<>(sourceLore.size() + data.count());
      List<String> reportLines = null;

      for (String line : sourceLore) {
         if (line.indexOf("{reports}") >= 0) {
            if (reportLines == null) {
               reportLines = this.reportLines(data.reports(), menu.reportLine());
            }

            lore.addAll(reportLines);
         } else {
            lore.add(this.replaceReportPlaceholders(line, target, time, count));
         }
      }

      return lore;
   }

   private List<String> reportLines(List<Report> reports, String format) {
      Map<String, StringBuilder> grouped = new LinkedHashMap<>();

      for (Report report : reports) {
         StringBuilder reasons = grouped.get(report.reporter());
         if (reasons == null) {
            grouped.put(report.reporter(), new StringBuilder(limit(report.reason(), MAX_REASONS_LENGTH)));
         } else if (reasons.length() < MAX_REASONS_LENGTH) {
            reasons.append(", ").append(report.reason());
            if (reasons.length() > MAX_REASONS_LENGTH) {
               reasons.setLength(MAX_REASONS_LENGTH);
               reasons.append("...");
            }
         }
      }

      List<String> lines = new ArrayList<>(Math.min(grouped.size(), MAX_REPORT_LINES + 1));

      for (Entry<String, StringBuilder> entry : grouped.entrySet()) {
         if (lines.size() >= MAX_REPORT_LINES) {
            lines.add("§7... +" + (grouped.size() - MAX_REPORT_LINES));
            break;
         }

         lines.add(format.replace("{reporter}", entry.getKey()).replace("{reason}", entry.getValue().toString()));
      }

      return lines;
   }

   private static String limit(String text, int max) {
      return text.length() <= max ? text : text.substring(0, max) + "...";
   }

   private String replaceReportPlaceholders(String line, String target, String time, String count) {
      return line.replace("{target}", target).replace("{time}", time).replace("{count}", count);
   }

   public int page() {
      return this.page;
   }

   public boolean hasNextPage() {
      return this.hasNextPage;
   }

   public Inventory getInventory() {
      return this.inventory;
   }

   public void open(Player player) {
      player.openInventory(this.inventory);
   }
}
