package cs.cloudstudio.menu;

import cs.cloudstudio.CloudReports;
import cs.cloudstudio.config.ConfigValues;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class ManageMenu implements InventoryHolder {
   public static final int TELEPORT_SLOT = 11;
   public static final int SUMMON_SLOT = 13;
   public static final int REMOVE_SLOT = 15;
   private final String target;
   private final Inventory inventory;
   private final NamespacedKey menuItemKey;

   public ManageMenu(CloudReports plugin, String target) {
      this.target = target;
      this.menuItemKey = plugin.menuItemKey();
      ConfigValues.Manage menu = plugin.configManager().values().manage();
      this.inventory = Bukkit.createInventory(this, menu.size(), ColorUtil.component(menu.title()));
      this.fill(menu);
   }

   private void fill(ConfigValues.Manage menu) {
      this.setItem(11, ItemUtil.item(menu.teleport()));
      this.setItem(13, ItemUtil.item(menu.summon()));
      this.setItem(15, ItemUtil.item(menu.remove()));
   }

   private void setItem(int slot, ItemStack item) {
      if (item != null && slot >= 0 && slot < this.inventory.getSize()) {
         ItemMeta meta = item.getItemMeta();
         if (meta != null) {
            meta.getPersistentDataContainer().set(this.menuItemKey, PersistentDataType.BYTE, (byte)1);
            item.setItemMeta(meta);
         }

         this.inventory.setItem(slot, item);
      }
   }

   public String target() {
      return this.target;
   }

   public Inventory getInventory() {
      return this.inventory;
   }

   public void open(Player player) {
      player.openInventory(this.inventory);
   }
}
