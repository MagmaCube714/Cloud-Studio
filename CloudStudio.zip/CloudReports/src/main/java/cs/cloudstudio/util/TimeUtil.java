package cs.cloudstudio.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public final class TimeUtil {
   private static final ThreadLocal<SimpleDateFormat> DATE_FORMAT = new ThreadLocal<SimpleDateFormat>() {
      protected SimpleDateFormat initialValue() {
         return new SimpleDateFormat("dd.MM.yyyy HH:mm");
      }
   };

   private TimeUtil() {
   }

   public static String formatTimestamp(long timestamp) {
      return DATE_FORMAT.get().format(new Date(timestamp));
   }
}
