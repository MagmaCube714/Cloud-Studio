package cs.cloudstudio.util;

import cs.cloudstudio.CloudReports;
import cs.cloudstudio.config.ConfigValues;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class ItemUtil {
   private static final String MENU_ITEM_KEY = "menu_item";

   private ItemUtil() {
   }

   public static Material material(String name, Material fallback) {
      Material material = name == null ? null : Material.matchMaterial(name);
      return material == null ? fallback : material;
   }

   public static ItemStack item(ConfigValues.Item source) {
      return item(source, null);
   }

   public static ItemStack item(ConfigValues.Item source, Map<String, String> placeholders) {
      ItemStack item = new ItemStack(source.material() == null ? Material.STONE : source.material());
      ItemMeta meta = item.getItemMeta();
      if (meta == null) {
         return item;
      }

      if (source.name() != null && !source.name().isEmpty()) {
         meta.displayName(ColorUtil.itemText(apply(source.name(), placeholders)));
      }

      if (source.lore() != null && !source.lore().isEmpty()) {
         List<String> lore = new ArrayList<>(source.lore().size());

         for (String line : source.lore()) {
            lore.add(apply(line, placeholders));
         }

         meta.lore(ColorUtil.itemText(lore));
      }

      if (source.modelData() > 0) {
         ColorUtil.applyModelData(meta, source.modelData());
      }

      item.setItemMeta(meta);
      return item;
   }

   public static ItemStack markMenuItem(CloudReports plugin, ItemStack item) {
      return markMenuItem(plugin.menuItemKey(), item);
   }

   public static ItemStack markMenuItem(NamespacedKey menuItemKey, ItemStack item) {
      if (item != null && !item.getType().isAir()) {
         ItemMeta meta = item.getItemMeta();
         if (meta == null) {
            return item;
         }

         meta.getPersistentDataContainer().set(menuItemKey, PersistentDataType.BYTE, (byte)1);
         item.setItemMeta(meta);
         return item;
      } else {
         return item;
      }
   }

   public static boolean isMenuItem(CloudReports plugin, ItemStack item) {
      return isMenuItem(plugin.menuItemKey(), item);
   }

   public static boolean isMenuItem(NamespacedKey menuItemKey, ItemStack item) {
      if (item != null && !item.getType().isAir() && item.hasItemMeta()) {
         ItemMeta meta = item.getItemMeta();
         return meta != null && meta.getPersistentDataContainer().has(menuItemKey, PersistentDataType.BYTE);
      } else {
         return false;
      }
   }

   public static NamespacedKey menuItemKey(CloudReports plugin) {
      return plugin.menuItemKey() == null ? new NamespacedKey(plugin, "menu_item") : plugin.menuItemKey();
   }

   public static String apply(String text, Map<String, String> placeholders) {
      String result = text == null ? "" : text;
      if (placeholders != null && !placeholders.isEmpty()) {
         for (Entry<String, String> entry : placeholders.entrySet()) {
            result = result.replace(entry.getKey(), entry.getValue());
         }

         return result;
      } else {
         return result;
      }
   }
}
