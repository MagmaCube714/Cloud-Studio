package cs.cloudstudio.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;

public final class ColorUtil {
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
   private static final char COLOR_CHAR = '§';
   private static final Pattern STRIP_PATTERN = Pattern.compile("(?i)§[0-9A-FK-ORX]");
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
      .character(COLOR_CHAR)
      .hexColors()
      .useUnusualXRepeatedCharacterHexFormat()
      .build();

   private ColorUtil() {
   }

   public static String strip(String text) {
      return text == null ? "" : STRIP_PATTERN.matcher(text).replaceAll("");
   }

   public static Component component(String legacyText) {
      return LEGACY.deserialize(legacyText == null ? "" : legacyText);
   }

   public static Component itemText(String legacyText) {
      if (legacyText == null || legacyText.isEmpty()) {
         return Component.empty();
      }

      Component component = LEGACY.deserialize(legacyText);
      List<Component> children = new ArrayList<>(component.children().size());

      for (Component child : component.children()) {
         children.add(child.decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE));
      }

      component = component.children(children);
      return legacyText.charAt(0) == COLOR_CHAR ? component.decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE) : component;
   }

   public static List<Component> itemText(List<String> legacyLines) {
      List<Component> result = new ArrayList<>(legacyLines.size());

      for (String line : legacyLines) {
         result.add(itemText(line));
      }

      return result;
   }

   public static void applyModelData(ItemMeta meta, int modelData) {
      CustomModelDataComponent component = meta.getCustomModelDataComponent();
      component.setFloats(List.of((float)modelData));
      meta.setCustomModelDataComponent(component);
   }

   public static String color(String text) {
      if (text != null && !text.isEmpty()) {
         Matcher matcher = HEX_PATTERN.matcher(text);
         StringBuffer buffer = new StringBuffer(text.length() + 32);

         while (matcher.find()) {
            String hex = matcher.group(1);
            matcher.appendReplacement(
               buffer, "§x§" + hex.charAt(0) + "§" + hex.charAt(1) + "§" + hex.charAt(2) + "§" + hex.charAt(3) + "§" + hex.charAt(4) + "§" + hex.charAt(5)
            );
         }

         matcher.appendTail(buffer);
         return translateAlternateColorCodes('&', buffer.toString());
      } else {
         return "";
      }
   }

   public static List<String> color(List<String> input) {
      if (input != null && !input.isEmpty()) {
         List<String> result = new ArrayList<>(input.size());

         for (String line : input) {
            result.add(color(line));
         }

         return Collections.unmodifiableList(result);
      } else {
         return Collections.emptyList();
      }
   }

   private static String translateAlternateColorCodes(char altColorChar, String text) {
      char[] chars = text.toCharArray();

      for (int i = 0; i < chars.length - 1; i++) {
         if (chars[i] == altColorChar && isColorCode(chars[i + 1])) {
            chars[i] = 167;
            chars[i + 1] = Character.toLowerCase(chars[i + 1]);
         }
      }

      return new String(chars);
   }

   private static boolean isColorCode(char character) {
      return character >= '0' && character <= '9'
         || character >= 'a' && character <= 'f'
         || character >= 'A' && character <= 'F'
         || "kKlLmMnNoOrRxX".indexOf(character) >= 0;
   }
}
