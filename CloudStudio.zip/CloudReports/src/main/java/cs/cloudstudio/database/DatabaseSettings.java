package cs.cloudstudio.database;

import org.bukkit.configuration.file.FileConfiguration;

public final class DatabaseSettings {
   private final DatabaseType type;
   private final String host;
   private final int port;
   private final String username;
   private final String password;
   private final String reportDatabase;

   private DatabaseSettings(DatabaseType type, String host, int port, String username, String password, String reportDatabase) {
      this.type = type == null ? DatabaseType.SQLITE : type;
      this.host = host != null && !host.trim().isEmpty() ? host.trim() : "localhost";
      this.port = port <= 0 ? 3306 : port;
      this.username = username == null ? "admin" : username;
      this.password = password == null ? "admin" : password;
      this.reportDatabase = reportDatabase != null && !reportDatabase.trim().isEmpty() ? reportDatabase.trim() : "data";
   }

   public static DatabaseSettings load(FileConfiguration config) {
      return new DatabaseSettings(
         DatabaseType.fromString(config.getString("database.type", "SQLite")),
         config.getString("database.host", "localhost"),
         config.getInt("database.port", 3306),
         config.getString("database.username", "admin"),
         config.getString("database.password", "admin"),
         config.getString("database.reportDatabase", config.getString("database.playerDatabase", "data"))
      );
   }

   public DatabaseType type() {
      return this.type;
   }

   public String host() {
      return this.host;
   }

   public int port() {
      return this.port;
   }

   public String username() {
      return this.username;
   }

   public String password() {
      return this.password;
   }

   public String reportDatabase() {
      return this.reportDatabase;
   }
}
