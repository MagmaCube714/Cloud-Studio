package cs.cloudstudio.database;

import cs.cloudstudio.CloudReports;
import cs.cloudstudio.manager.Report;
import cs.cloudstudio.manager.ReportData;
import java.io.File;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;

public final class ReportsDatabase extends Database {
   private static final String TABLE = "reports";
   private final CloudReports plugin;
   private final ReentrantLock lock = new ReentrantLock();
   private final ExecutorService executor = Executors.newSingleThreadExecutor(runnable -> {
      Thread thread = new Thread(runnable, "CloudReports-Database");
      thread.setDaemon(true);
      return thread;
   });
   private final Map<String, ReportData> cache = new ConcurrentHashMap<>();
   private volatile Connection connection;
   private volatile boolean connected;
   private DatabaseSettings settings;

   public ReportsDatabase(CloudReports plugin) {
      this.plugin = plugin;
   }

   @Override
   protected void connectImpl() {
      this.lock.lock();

      try {
         if (!this.connected) {
            this.settings = DatabaseSettings.load(this.plugin.getConfig());
            this.openConnection();
            this.configureConnection();
            this.connection.setAutoCommit(false);
            this.createTable();
            this.migrateTable();
            this.load();
            this.connected = true;
            return;
         }
      } catch (Exception exception) {
         this.connected = false;
         this.closeConnectionQuietly();
         this.plugin.warning("База данных не подключена: " + exception.getMessage());
         return;
      } finally {
         this.lock.unlock();
      }
   }

   private void openConnection() throws Exception {
      if (this.settings.type() == DatabaseType.MYSQL) {
         Class.forName("com.mysql.cj.jdbc.Driver");
         this.connection = DriverManager.getConnection(this.mysqlUrl(), this.settings.username(), this.settings.password());
      } else {
         Class.forName("org.sqlite.JDBC");
         File folder = this.plugin.getDataFolder();
         if (!folder.exists() && !folder.mkdirs()) {
            throw new SQLException("не удалось создать папку плагина");
         }

         File file = new File(folder, safeDatabaseName(this.settings.reportDatabase()) + ".db");
         this.connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
      }
   }

   private String mysqlUrl() {
      return "jdbc:mysql://"
         + this.settings.host()
         + ":"
         + this.settings.port()
         + "/"
         + safeDatabaseName(this.settings.reportDatabase())
         + "?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=UTC";
   }

   private void configureConnection() throws SQLException {
      if (this.settings.type() == DatabaseType.SQLITE) {
         try (Statement statement = this.connection.createStatement()) {
            statement.execute("PRAGMA busy_timeout=5000");
            statement.execute("PRAGMA journal_mode=WAL");
            statement.execute("PRAGMA synchronous=NORMAL");
            statement.execute("PRAGMA wal_autocheckpoint=1000");
            statement.execute("PRAGMA journal_size_limit=16777216");
            statement.execute("PRAGMA foreign_keys=ON");
         }
      }
   }

   private void createTable() throws SQLException {
      try (Statement statement = this.connection.createStatement()) {
         statement.executeUpdate(this.createTableSql());
         this.connection.commit();
      }
   }

   private String createTableSql() {
      return this.settings.type() == DatabaseType.MYSQL
         ? "CREATE TABLE IF NOT EXISTS reports(id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,target_key VARCHAR(64),target VARCHAR(64) NOT NULL,reporter VARCHAR(64) NOT NULL,reason TEXT NOT NULL,timestamp BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
         : "CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY AUTOINCREMENT,target_key TEXT,target TEXT NOT NULL,reporter TEXT NOT NULL,reason TEXT NOT NULL,timestamp INTEGER NOT NULL)";
   }

   private void migrateTable() throws SQLException {
      if (!this.hasColumn("target_key")) {
         try (Statement statement = this.connection.createStatement()) {
            statement.executeUpdate("ALTER TABLE reports ADD COLUMN target_key " + (this.settings.type() == DatabaseType.MYSQL ? "VARCHAR(64)" : "TEXT"));
         }
      }

      try (Statement statement = this.connection.createStatement()) {
         statement.executeUpdate("UPDATE reports SET target_key = LOWER(target) WHERE target_key IS NULL OR target_key = ''");
         this.createIndex(statement, "reports_target_key_index", "target_key");
         this.createIndex(statement, "reports_timestamp_index", "timestamp");
         this.connection.commit();
      }
   }

   private boolean hasColumn(String name) throws SQLException {
      if (this.settings.type() == DatabaseType.SQLITE) {
         try (
            Statement statement = this.connection.createStatement();
            ResultSet result = statement.executeQuery("PRAGMA table_info(reports)");
         ) {
            while (result.next()) {
               if (name.equalsIgnoreCase(result.getString("name"))) {
                  return true;
               }
            }

            return false;
         }
      } else {
         DatabaseMetaData metaData = this.connection.getMetaData();

         try (ResultSet result = metaData.getColumns(null, null, "reports", name)) {
            if (result.next()) {
               return true;
            }
         }

         try (ResultSet result = metaData.getColumns(null, null, "reports".toUpperCase(Locale.ROOT), name)) {
            return result.next();
         }
      }
   }

   private void createIndex(Statement statement, String name, String column) throws SQLException {
      if (this.settings.type() == DatabaseType.MYSQL) {
         try {
            statement.executeUpdate("CREATE INDEX " + name + " ON reports(" + column + ")");
         } catch (SQLException var5) {
         }
      } else {
         statement.executeUpdate("CREATE INDEX IF NOT EXISTS " + name + " ON reports(" + column + ")");
      }
   }

   private void load() throws SQLException {
      this.cache.clear();

      try (
         Statement statement = this.connection.createStatement();
         ResultSet result = statement.executeQuery("SELECT target_key, target, reporter, reason, timestamp FROM reports ORDER BY timestamp ASC");
      ) {
         while (result.next()) {
            String target = result.getString("target");
            String key = result.getString("target_key");
            if (key == null || key.trim().isEmpty()) {
               key = this.normalize(target);
            }

            ReportData data = this.cache.get(key);
            if (data == null) {
               data = new ReportData(target);
               this.cache.put(key, data);
            }

            data.add(new Report(result.getString("reporter"), result.getString("reason"), result.getLong("timestamp")));
         }
      }
   }

   @Override
   public Collection<ReportData> reports() {
      if (this.cache.isEmpty()) {
         return Collections.emptyList();
      }

      List<ReportData> result = new ArrayList<>(this.cache.size());

      for (ReportData data : this.cache.values()) {
         result.add(data.copy());
      }

      Collections.sort(result, new Comparator<ReportData>() {
         public int compare(ReportData first, ReportData second) {
            return Long.compare(second.lastReportTime(), first.lastReportTime());
         }
      });
      return result;
   }

   @Override
   public int count(String target) {
      ReportData data = this.cache.get(this.normalize(target));
      return data == null ? 0 : data.count();
   }

   @Override
   public int count(String target, String reporter) {
      ReportData data = this.cache.get(this.normalize(target));
      if (data == null || reporter == null) {
         return 0;
      }

      int count = 0;

      for (Report report : data.reports()) {
         if (reporter.equalsIgnoreCase(report.reporter())) {
            count++;
         }
      }

      return count;
   }

   @Override
   public boolean add(String target, Report report) {
      String key = this.normalize(target);
      if (!key.isEmpty() && report != null && this.connected) {
         ReportData data = this.cache.computeIfAbsent(key, ignored -> new ReportData(target));
         data.add(report);
         this.submit(() -> this.insert(key, target, report));
         return true;
      } else {
         return false;
      }
   }

   private void insert(String key, String target, Report report) {
      this.lock.lock();

      try {
         this.ensureConnection();

         try (PreparedStatement statement = this.connection
               .prepareStatement("INSERT INTO reports(target_key, target, reporter, reason, timestamp) VALUES(?, ?, ?, ?, ?)")) {
            statement.setString(1, key);
            statement.setString(2, target);
            statement.setString(3, report.reporter());
            statement.setString(4, report.reason());
            statement.setLong(5, report.timestamp());
            statement.executeUpdate();
            this.connection.commit();
         }
      } catch (Exception exception) {
         this.rollback();
         this.plugin.getLogger().log(Level.WARNING, "[CloudReports] Репорт не сохранён (" + report.reporter() + " -> " + target + ")", exception);
      } finally {
         this.lock.unlock();
      }
   }

   @Override
   public boolean remove(String target) {
      String key = this.normalize(target);
      if (key.isEmpty() || !this.connected) {
         return false;
      }

      boolean removed = this.cache.remove(key) != null;
      this.submit(() -> this.delete(key));
      return removed;
   }

   private void delete(String key) {
      this.lock.lock();

      try {
         this.ensureConnection();

         try (PreparedStatement statement = this.connection.prepareStatement("DELETE FROM reports WHERE target_key = ?")) {
            statement.setString(1, key);
            statement.executeUpdate();
            this.connection.commit();
         }
      } catch (Exception exception) {
         this.rollback();
         this.plugin.getLogger().log(Level.WARNING, "[CloudReports] Репорт не удалён (" + key + ")", exception);
      } finally {
         this.lock.unlock();
      }
   }

   private void submit(Runnable task) {
      try {
         this.executor.execute(task);
      } catch (RejectedExecutionException exception) {
         task.run();
      }
   }

   private void ensureConnection() throws Exception {
      if (this.connection == null || this.connection.isClosed() || !this.connection.isValid(3)) {
         this.closeConnectionQuietly();
         this.openConnection();
         this.configureConnection();
         this.connection.setAutoCommit(false);
      }
   }

   @Override
   protected void disconnectImpl() {
      this.connected = false;
      this.executor.shutdown();

      try {
         if (!this.executor.awaitTermination(15L, TimeUnit.SECONDS)) {
            this.plugin.warning("Не все записи в базу данных успели завершиться при выключении");
         }
      } catch (InterruptedException exception) {
         Thread.currentThread().interrupt();
      }

      this.lock.lock();

      try {
         this.closeConnection();
      } catch (SQLException exception) {
         this.plugin.warning("База данных не закрыта: " + exception.getMessage());
      } finally {
         this.cache.clear();
         this.connection = null;
         this.lock.unlock();
      }
   }

   private void rollback() {
      try {
         if (this.connection != null && !this.connection.isClosed()) {
            this.connection.rollback();
         }
      } catch (SQLException exception) {
         this.plugin.warning("Откат базы данных не выполнен: " + exception.getMessage());
      }
   }

   private void closeConnection() throws SQLException {
      if (this.connection != null && !this.connection.isClosed()) {
         this.connection.close();
      }
   }

   private void closeConnectionQuietly() {
      try {
         this.closeConnection();
      } catch (SQLException var5) {
      } finally {
         this.connection = null;
      }
   }

   public boolean isConnected() {
      try {
         return this.connected && this.connection != null && !this.connection.isClosed();
      } catch (SQLException exception) {
         return false;
      }
   }

   @Override
   protected Connection getConnection() {
      return this.connection;
   }

   private String normalize(String target) {
      return target == null ? "" : target.trim().toLowerCase(Locale.ROOT);
   }

   private static String safeDatabaseName(String raw) {
      if (raw != null && !raw.trim().isEmpty()) {
         String trimmed = raw.trim();
         StringBuilder builder = new StringBuilder(trimmed.length());

         for (int i = 0; i < trimmed.length(); i++) {
            char c = trimmed.charAt(i);
            if (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_' || c == '-') {
               builder.append(c);
            }
         }

         return builder.length() == 0 ? "data" : builder.toString();
      } else {
         return "data";
      }
   }
}
