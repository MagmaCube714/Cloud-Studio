package cs.cloudstudio.database;

import cs.cloudstudio.manager.Report;
import cs.cloudstudio.manager.ReportData;
import java.sql.Connection;
import java.util.Collection;

public abstract class Database {
   public final void connect() {
      this.connectImpl();
   }

   public final void disconnect() {
      this.disconnectImpl();
   }

   protected abstract void connectImpl();

   public abstract Collection<ReportData> reports();

   public abstract int count(String var1);

   public abstract int count(String target, String reporter);

   public abstract boolean add(String var1, Report var2);

   public abstract boolean remove(String var1);

   protected abstract void disconnectImpl();

   protected abstract Connection getConnection();
}
