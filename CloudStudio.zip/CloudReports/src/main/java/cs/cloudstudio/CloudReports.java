package cs.cloudstudio;

import cs.cloudstudio.command.AdminCommand;
import cs.cloudstudio.command.ReportCommand;
import cs.cloudstudio.command.ReportsCommand;
import cs.cloudstudio.config.ConfigManager;
import cs.cloudstudio.database.ReportsDatabase;
import cs.cloudstudio.listener.MenuListener;
import cs.cloudstudio.manager.ReportsManager;
import cs.cloudstudio.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;

public final class CloudReports extends JavaPlugin {
   private ConfigManager configManager;
   private ReportsDatabase database;
   private ReportsManager reportsManager;
   private NamespacedKey menuItemKey;
   private NamespacedKey reportTargetKey;

   public void onEnable() {
      this.saveDefaultConfig();
      this.menuItemKey = new NamespacedKey(this, "menu_item");
      this.reportTargetKey = new NamespacedKey(this, "report_target");
      this.configManager = new ConfigManager(this);
      this.database = new ReportsDatabase(this);
      this.database.connect();
      if (!this.database.isConnected()) {
         this.console("&fCloudReports &cбаза данных не подключена, плагин отключён");
         Bukkit.getPluginManager().disablePlugin(this);
      } else {
         this.reportsManager = new ReportsManager(this.database);
         this.registerCommands();
         this.getServer().getPluginManager().registerEvents(new MenuListener(this), this);
         this.console("&fCloudReports &aуспешно загружен!");
      }
   }

   public void onDisable() {
      this.getServer().getScheduler().cancelTasks(this);
      HandlerList.unregisterAll(this);
      if (this.database != null) {
         this.database.disconnect();
      }

      this.console("&fCloudReports &cуспешно выгружен!");
   }

   private void registerCommands() {
      this.register("report", new ReportCommand(this));
      this.register("reports", new ReportsCommand(this));
      this.register("cloudreports", new AdminCommand(this));
   }

   private void register(String name, CommandExecutor executor) {
      PluginCommand command = this.getCommand(name);
      if (command == null) {
         this.warning("Команда " + name + " не найдена в plugin.yml");
      } else {
         command.setExecutor(executor);
         if (executor instanceof TabCompleter) {
            command.setTabCompleter((TabCompleter)executor);
         }
      }
   }

   public ConfigManager configManager() {
      return this.configManager;
   }

   public ReportsDatabase database() {
      return this.database;
   }

   public ReportsManager reportsManager() {
      return this.reportsManager;
   }

   public NamespacedKey menuItemKey() {
      return this.menuItemKey;
   }

   public NamespacedKey reportTargetKey() {
      return this.reportTargetKey;
   }

   public void console(String message) {
      this.getServer().getConsoleSender().sendMessage(ColorUtil.color(message));
   }

   public void warning(String message) {
      this.getLogger().warning("[CloudReports] " + message);
   }
}
