package cs.cloudstudio.listener;

import cs.cloudstudio.CloudReports;
import cs.cloudstudio.menu.MainMenu;
import cs.cloudstudio.menu.ManageMenu;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.Event.Result;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class MenuListener implements Listener {
   private static final long MENU_CLICK_DELAY_NANOS = 250000000L;
   private final CloudReports plugin;
   private final NamespacedKey targetKey;
   private final NamespacedKey menuItemKey;
   private final Set<UUID> processing = new HashSet<>();
   private final Map<UUID, Long> clickCooldown = new HashMap<>();

   public MenuListener(CloudReports plugin) {
      this.plugin = plugin;
      this.targetKey = plugin.reportTargetKey();
      this.menuItemKey = plugin.menuItemKey();
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onDrag(InventoryDragEvent event) {
      HumanEntity entity = event.getWhoClicked();
      if (entity instanceof Player) {
         InventoryHolder holder = event.getView().getTopInventory().getHolder();
         if (this.menuHolder(holder)) {
            event.setCancelled(true);
            event.setResult(Result.DENY);
         } else {
            if (this.menuItem(event.getOldCursor())) {
               event.setCancelled(true);
               event.setResult(Result.DENY);
               this.cleanupMenuItems((Player)entity);
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onInventoryClick(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player player) {
         Inventory top = event.getView().getTopInventory();
         InventoryHolder holder = top.getHolder();
         if (!this.menuHolder(holder)) {
            if (this.menuItem(event.getCurrentItem()) || this.menuItem(event.getCursor())) {
               event.setCancelled(true);
               event.setResult(Result.DENY);
               this.cleanupMenuItems(player);
            }
         } else {
            event.setCancelled(true);
            event.setResult(Result.DENY);
            if (this.allowedClick(event)) {
               if (event.getRawSlot() >= 0 && event.getRawSlot() < top.getSize()) {
                  if (event.getClickedInventory() == top) {
                     ItemStack current = event.getCurrentItem();
                     if (this.menuItem(current)) {
                        if (this.startMenuClickCooldown(player)) {
                           UUID uuid = player.getUniqueId();
                           if (this.processing.add(uuid)) {
                              try {
                                 if (!(holder instanceof MainMenu)) {
                                    this.handleManageMenu((ManageMenu)holder, event, player);
                                    return;
                                 }

                                 this.handleMainMenu((MainMenu)holder, event, player);
                              } finally {
                                 this.processing.remove(uuid);
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
   public void onPlayerDrop(PlayerDropItemEvent event) {
      if (this.menuItem(event.getItemDrop().getItemStack())) {
         event.setCancelled(true);
         event.getItemDrop().remove();
         this.cleanupMenuItems(event.getPlayer());
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
   public void onSwapHand(PlayerSwapHandItemsEvent event) {
      if (this.menuItem(event.getMainHandItem()) || this.menuItem(event.getOffHandItem())) {
         event.setCancelled(true);
         this.cleanupMenuItems(event.getPlayer());
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onInventoryClose(InventoryCloseEvent event) {
      if (event.getPlayer() instanceof Player) {
         if (this.menuHolder(event.getInventory().getHolder())) {
            this.cleanupMenuItems((Player)event.getPlayer());
         }
      }
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onPlayerQuit(PlayerQuitEvent event) {
      this.clearPlayer(event.getPlayer());
   }

   @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
   public void onPlayerKick(PlayerKickEvent event) {
      this.clearPlayer(event.getPlayer());
   }

   private void handleMainMenu(MainMenu menu, InventoryClickEvent event, Player player) {
      int slot = event.getSlot();
      ItemStack item = event.getCurrentItem();
      if (this.contains(MainMenu.PREVIOUS_SLOT, slot)) {
         if (menu.page() > 0) {
            new MainMenu(this.plugin, menu.page() - 1).open(player);
         }
      } else if (this.contains(MainMenu.NEXT_SLOT, slot)) {
         if (menu.hasNextPage()) {
            new MainMenu(this.plugin, menu.page() + 1).open(player);
         }
      } else {
         String target = this.readTarget(item);
         if (target != null && this.plugin.reportsManager().hasReports(target)) {
            new ManageMenu(this.plugin, target).open(player);
         }
      }
   }

   private void handleManageMenu(ManageMenu menu, InventoryClickEvent event, Player player) {
      int slot = event.getSlot();
      ItemStack item = event.getCurrentItem();
      if (this.menuItem(item)) {
         String target = menu.target();
         if (slot == 11) {
            this.dispatch(player, this.plugin.configManager().values().manage().teleport().command(), target);
         } else if (slot == 13) {
            this.dispatch(player, this.plugin.configManager().values().manage().summon().command(), target);
         } else {
            if (slot == 15) {
               player.closeInventory();
               if (this.plugin.reportsManager().removeReports(target)) {
                  player.sendMessage(this.plugin.configManager().message("report-removed").replace("{target}", target));
               }
            }
         }
      }
   }

   private void dispatch(Player player, String command, String target) {
      if (command != null && !command.isEmpty() && this.safePlayerName(target)) {
         player.closeInventory();
         Bukkit.dispatchCommand(player, command.replace("{target}", target));
      }
   }

   private boolean menuHolder(InventoryHolder holder) {
      return holder instanceof MainMenu || holder instanceof ManageMenu;
   }

   private boolean allowedClick(InventoryClickEvent event) {
      InventoryAction action = event.getAction();
      return action == InventoryAction.PICKUP_ALL
         || action == InventoryAction.PICKUP_HALF
         || action == InventoryAction.PICKUP_ONE
         || action == InventoryAction.PICKUP_SOME
         || action == InventoryAction.MOVE_TO_OTHER_INVENTORY
         || action == InventoryAction.COLLECT_TO_CURSOR
         || action == InventoryAction.HOTBAR_SWAP;
   }

   private boolean startMenuClickCooldown(Player player) {
      if (!this.plugin.isEnabled()) {
         return false;
      }

      UUID uuid = player.getUniqueId();
      long now = System.nanoTime();
      Long nextAllowed = this.clickCooldown.get(uuid);
      if (nextAllowed != null && nextAllowed > now) {
         return false;
      }

      this.clickCooldown.put(uuid, now + 250000000L);
      return true;
   }

   private boolean contains(int[] slots, int value) {
      for (int slot : slots) {
         if (slot == value) {
            return true;
         }
      }

      return false;
   }

   private String readTarget(ItemStack item) {
      if (item != null && item.hasItemMeta()) {
         ItemMeta meta = item.getItemMeta();
         return meta == null ? null : (String)meta.getPersistentDataContainer().get(this.targetKey, PersistentDataType.STRING);
      } else {
         return null;
      }
   }

   private boolean menuItem(ItemStack item) {
      if (item != null && !item.getType().isAir() && item.hasItemMeta()) {
         return item.getPersistentDataContainer().has(this.menuItemKey, PersistentDataType.BYTE);
      } else {
         return false;
      }
   }

   private void cleanupMenuItems(Player player) {
      final UUID uuid = player.getUniqueId();
      this.plugin.getServer().getScheduler().runTask(this.plugin, new Runnable() {
         @Override
         public void run() {
            Player online = Bukkit.getPlayer(uuid);
            if (online != null) {
               MenuListener.this.removeMenuItems(online);
            }
         }
      });
   }

   private void removeMenuItems(Player player) {
      if (player != null && player.isOnline()) {
         boolean changed = false;
         ItemStack cursor = player.getItemOnCursor();
         if (this.menuItem(cursor)) {
            player.setItemOnCursor(null);
            changed = true;
         }

         PlayerInventory inventory = player.getInventory();

         for (int slot = 0; slot < inventory.getSize(); slot++) {
            if (this.menuItem(inventory.getItem(slot))) {
               inventory.setItem(slot, null);
               changed = true;
            }
         }

         if (changed) {
            player.updateInventory();
         }
      }
   }

   private void clearPlayer(Player player) {
      UUID uuid = player.getUniqueId();
      this.processing.remove(uuid);
      this.clickCooldown.remove(uuid);
      this.removeMenuItems(player);
   }

   private boolean safePlayerName(String name) {
      if (name != null && name.length() >= 3 && name.length() <= 16) {
         for (int i = 0; i < name.length(); i++) {
            char character = name.charAt(i);
            if ((character < 'a' || character > 'z') && (character < 'A' || character > 'Z') && (character < '0' || character > '9') && character != '_') {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }
}
