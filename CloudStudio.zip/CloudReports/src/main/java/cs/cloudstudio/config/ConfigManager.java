package cs.cloudstudio.config;

import cs.cloudstudio.CloudReports;
import cs.cloudstudio.util.ColorUtil;
import cs.cloudstudio.util.ItemUtil;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public final class ConfigManager {
   private static final List<String> DEFAULT_REPORT_LORE = Collections.unmodifiableList(
      Arrays.asList(
         "",
         "&fПоследняя жалоба:",
         "&e{time}",
         "",
         "&fВсего жалоб: &c{count}",
         "",
         "&fСписок пожаловшихся:",
         "{reports}",
         "",
         "&aНажмите для управления жалобой"
      )
   );
   private final CloudReports plugin;
   private final Map<String, String> messages = new HashMap<>();
   private static final Map<String, String> DEFAULT_MESSAGES = Map.of(
      "report-cooldown", "&6Репорты &7» &cПодождите &6{time} &cсек. перед следующей жалобой",
      "report-limit", "&6Репорты &7» &cВы уже подали достаточно жалоб на игрока &6{target}"
   );
   private ConfigValues values;
   private int maxReasonLength;
   private int reportCooldownSeconds;
   private int maxReportsPerTarget;

   public ConfigManager(CloudReports plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.plugin.reloadConfig();
      FileConfiguration config = this.plugin.getConfig();
      this.messages.clear();
      this.maxReasonLength = Math.max(16, Math.min(512, config.getInt("settings.max-reason-length", 200)));
      this.reportCooldownSeconds = Math.max(0, config.getInt("settings.report-cooldown", 30));
      this.maxReportsPerTarget = Math.max(0, config.getInt("settings.max-reports-per-target", 3));

      for (Map.Entry<String, String> entry : DEFAULT_MESSAGES.entrySet()) {
         this.messages.put(entry.getKey(), ColorUtil.color(entry.getValue()));
      }

      this.loadMessages(config.getConfigurationSection("messages"));
      this.values = new ConfigValues(
         this.loadReports(config.getConfigurationSection("menus.reports")), this.loadManage(config.getConfigurationSection("menus.manage"))
      );
   }

   private void loadMessages(ConfigurationSection section) {
      if (section != null) {
         for (String key : section.getKeys(false)) {
            if (!section.isList(key)) {
               this.messages.put(key.toLowerCase(Locale.ROOT), ColorUtil.color(section.getString(key, "")));
            }
         }
      }
   }

   private ConfigValues.Reports loadReports(ConfigurationSection section) {
      int size = this.inventorySize(section == null ? 54 : section.getInt("size", 54), 54);
      String title = ColorUtil.color(section == null ? "Репорты" : section.getString("name", "Репорты"));
      ConfigValues.Item reportItem = this.loadItem(
         section == null ? null : section.getConfigurationSection("report-item"), Material.BOOK, "&eЖалоба на &6{target}", DEFAULT_REPORT_LORE
      );
      String reportLine = ColorUtil.color(
         section == null ? "&e   {reporter}&6: &f[{reason}]" : section.getString("report-line", "&e   {reporter}&6: &f[{reason}]")
      );
      ConfigValues.Item decoration = this.loadItem(
         section == null ? null : section.getConfigurationSection("decoration"), Material.ORANGE_STAINED_GLASS_PANE, "&r", Collections.emptyList()
      );
      ConfigValues.Item previous = this.loadItem(
         section == null ? null : section.getConfigurationSection("previous"), Material.ARROW, "&6Предыдущая страница", Collections.emptyList()
      );
      ConfigValues.Item next = this.loadItem(
         section == null ? null : section.getConfigurationSection("next"), Material.ARROW, "&6Следующая страница", Collections.emptyList()
      );
      return new ConfigValues.Reports(size, title, reportItem, reportLine, decoration, previous, next);
   }

   private ConfigValues.Manage loadManage(ConfigurationSection section) {
      int size = this.inventorySize(section == null ? 27 : section.getInt("size", 27), 27);
      String title = ColorUtil.color(section == null ? "Управление жалобой" : section.getString("name", "Управление жалобой"));
      ConfigValues.Button teleport = this.loadButton(
         section == null ? null : section.getConfigurationSection("teleport"),
         Material.WHITE_WOOL,
         "&aТелепортироваться",
         Collections.emptyList(),
         "tp {target}"
      );
      ConfigValues.Button summon = this.loadButton(
         section == null ? null : section.getConfigurationSection("summon"),
         Material.LIME_WOOL,
         "&aТелепортировать к себе",
         Collections.emptyList(),
         "s {target}"
      );
      ConfigValues.Item remove = this.loadItem(
         section == null ? null : section.getConfigurationSection("remove"), Material.RED_WOOL, "&cУдалить репорт", Collections.emptyList()
      );
      return new ConfigValues.Manage(size, title, teleport, summon, remove);
   }

   private ConfigValues.Button loadButton(
      ConfigurationSection section, Material fallbackMaterial, String fallbackName, List<String> fallbackLore, String fallbackCommand
   ) {
      ConfigValues.Item item = this.loadItem(section, fallbackMaterial, fallbackName, fallbackLore);
      String command = section == null ? fallbackCommand : section.getString("command", fallbackCommand);
      return new ConfigValues.Button(item.material(), item.name(), item.lore(), item.modelData(), command == null ? "" : command.trim());
   }

   private ConfigValues.Item loadItem(ConfigurationSection section, Material fallbackMaterial, String fallbackName, List<String> fallbackLore) {
      Material material = ItemUtil.material(section == null ? null : section.getString("material"), fallbackMaterial);
      String name = ColorUtil.color(section == null ? fallbackName : section.getString("name", fallbackName));
      List<String> rawLore = section == null ? fallbackLore : section.getStringList("lore");
      if ((rawLore == null || rawLore.isEmpty()) && fallbackLore != null && !fallbackLore.isEmpty()) {
         rawLore = fallbackLore;
      }

      List<String> lore = ColorUtil.color(rawLore);
      int modelData = 0;
      if (section != null) {
         modelData = section.contains("model-data") ? section.getInt("model-data", 0) : section.getInt("model_data", 0);
      }

      return new ConfigValues.Item(material, name, lore, Math.max(0, modelData));
   }

   private int inventorySize(int size, int fallback) {
      int fixed = size <= 0 ? fallback : size;
      fixed = Math.max(9, Math.min(54, fixed));
      fixed -= fixed % 9;
      return fixed <= 0 ? fallback : fixed;
   }

   public ConfigValues values() {
      return this.values;
   }

   public String message(String key) {
      return key == null ? "" : this.messages.getOrDefault(key.toLowerCase(Locale.ROOT), "");
   }

   public String color(String text) {
      return ColorUtil.color(text);
   }

   public int maxReasonLength() {
      return this.maxReasonLength;
   }

   public int reportCooldownSeconds() {
      return this.reportCooldownSeconds;
   }

   public int maxReportsPerTarget() {
      return this.maxReportsPerTarget;
   }
}
