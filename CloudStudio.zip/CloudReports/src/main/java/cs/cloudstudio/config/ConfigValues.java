package cs.cloudstudio.config;

import java.util.List;
import org.bukkit.Material;

public final class ConfigValues {
   private final ConfigValues.Reports reports;
   private final ConfigValues.Manage manage;

   public ConfigValues(ConfigValues.Reports reports, ConfigValues.Manage manage) {
      this.reports = reports;
      this.manage = manage;
   }

   public ConfigValues.Reports reports() {
      return this.reports;
   }

   public ConfigValues.Manage manage() {
      return this.manage;
   }

   public static final class Button extends ConfigValues.Item {
      private final String command;

      public Button(Material material, String name, List<String> lore, int modelData, String command) {
         super(material, name, lore, modelData);
         this.command = command;
      }

      public String command() {
         return this.command;
      }
   }

   public static class Item {
      private final Material material;
      private final String name;
      private final List<String> lore;
      private final int modelData;

      public Item(Material material, String name, List<String> lore, int modelData) {
         this.material = material;
         this.name = name;
         this.lore = lore;
         this.modelData = modelData;
      }

      public Material material() {
         return this.material;
      }

      public String name() {
         return this.name;
      }

      public List<String> lore() {
         return this.lore;
      }

      public int modelData() {
         return this.modelData;
      }
   }

   public static final class Manage {
      private final int size;
      private final String title;
      private final ConfigValues.Button teleport;
      private final ConfigValues.Button summon;
      private final ConfigValues.Item remove;

      public Manage(int size, String title, ConfigValues.Button teleport, ConfigValues.Button summon, ConfigValues.Item remove) {
         this.size = size;
         this.title = title;
         this.teleport = teleport;
         this.summon = summon;
         this.remove = remove;
      }

      public int size() {
         return this.size;
      }

      public String title() {
         return this.title;
      }

      public ConfigValues.Button teleport() {
         return this.teleport;
      }

      public ConfigValues.Button summon() {
         return this.summon;
      }

      public ConfigValues.Item remove() {
         return this.remove;
      }
   }

   public static final class Reports {
      private final int size;
      private final String title;
      private final ConfigValues.Item reportItem;
      private final String reportLine;
      private final ConfigValues.Item decoration;
      private final ConfigValues.Item previous;
      private final ConfigValues.Item next;

      public Reports(
         int size,
         String title,
         ConfigValues.Item reportItem,
         String reportLine,
         ConfigValues.Item decoration,
         ConfigValues.Item previous,
         ConfigValues.Item next
      ) {
         this.size = size;
         this.title = title;
         this.reportItem = reportItem;
         this.reportLine = reportLine;
         this.decoration = decoration;
         this.previous = previous;
         this.next = next;
      }

      public int size() {
         return this.size;
      }

      public String title() {
         return this.title;
      }

      public ConfigValues.Item reportItem() {
         return this.reportItem;
      }

      public String reportLine() {
         return this.reportLine;
      }

      public ConfigValues.Item decoration() {
         return this.decoration;
      }

      public ConfigValues.Item previous() {
         return this.previous;
      }

      public ConfigValues.Item next() {
         return this.next;
      }
   }
}
